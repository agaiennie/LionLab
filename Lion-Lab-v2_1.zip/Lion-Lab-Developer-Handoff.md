# Lion Lab — Developer Handoff

**Prepared:** Tue Sep 29, 2026 (America/New_York)  
**Audience:** Incoming developer taking over from Andrew Gaiennie  
**Source tree on box:** `/workspace/lion-lab-full`  
**Origin cloud agent:** [bc-103d84a6-326b-54f0-9276-922b2c15c6d9](https://cursor.com/agents/bc-103d84a6-326b-54f0-9276-922b2c15c6d9)  
**Artifact zip (cloud build):** `/workspace/cloud-agent-artifacts/bc-103d84a6-326b-54f0-9276-922b2c15c6d9/lion-lab-full-app.zip`

This document is clinical and glossary-first. Prefer the working local tree over a raw re-extract of the artifact zip: local already includes phone UX polish (one-tap demo role sign-in; coach **Start here** hub) that landed after the Sep 27–28 cloud packaging.

---

## Glossary

| Term | Meaning |
| --- | --- |
| **Lion Lab** | Field-and-home toolkit for Red Lion Area HS (RLASD) football — athlete, parent, coach, and admin logins in one Next.js app. Text mark only: **Lion Lab / Red Lion Football** in red `#C8102E`. No lion-head art. |
| **Red Lion Area HS football** | Public high school football context in Red Lion, Pennsylvania. Demo roster is fictional grades ~9–12; product intent spans youth through varsity (roughly grades 4–12; often demo’d for 8th/9th). README in-repo says grades 7–12. |
| **FAST** | Sideline coaching acronym, locked: **F** First step · **A** Attack · **S** Shoulder level · **T** Through. Defense finish of Through = wrap, cheek to the ball, drive the legs. Block finish = hands inside, feet moving, drive, whistle plus one (no wrap on a block). **Square up is a separate skill**, not the letter S. |
| **Origin draft** | Unpublished Cursor Origin cloud draft (`tmp-*` style hosting). Not a lasting public URL. Do not treat Origin preview or Cloudflare trycloudflare tunnels as production. |
| **Athlete** | Player account. Sees own data only: Today, Train, Measure, Study, My path, Glossary. |
| **Parent** | Linked to one or more athletes by coach/admin invite. Sees linked kid only: Today, Home plan, Progress, Notes, Glossary. |
| **Coach** | Runs roster, Field cards, Skills, Log tests, Body tracker, Standards, CSV export. |
| **Admin** | Users, parent invites, season/study gate settings, plus coach tools. |
| **Study Lab** | In-app study block (minutes + 25/5 timer). Study gate can block home mobility / home train / home body-tracker saves until today’s study (or parent note) is done. Line: **Train the body. Train the mind.** |
| **Coach Skill Library** | ~33 coach-facing skill guides in `lib/content/skills.ts` (version `v1`). Routes `/skills`, `/skills/[id]`, `/skills/positions`, `/skills/positions/[pos]`. Teach pattern: **Demo → Break down → Speed up**, plus FAST letters, metric link, 5-minute station card. “Taught this week” checkbox on athlete roster page is a weekly reminder, not a grade. |
| **Battery** | Manual test set: 40, med ball (10 lb), stance. Scores use form index → adjusted **ESTIMATE** (not medical/recruiting). |
| **Body tracker** | `/tracker` — checklist and optional browser camera (MediaPipe prototype under `public/pose`). Field saves are not blocked by the study gate. |
| **Fuel habits** | Four daily checkboxes: water, protein at meals, sleep window, no heavy junk before practice. Not a meal plan. |
| **Fit notes** | Heuristic coaching notes from declared position + latest battery (`lib/content/fit.ts`). Not a full recommendation engine. |
| **Mobility** | Farm-plain drill names (Fence Lean, Gate Hinge, Corn-Row Plant, …) in `lib/content/mobility.ts`. Do not invent floral yoga names. |

**Culture line (product):** “We cannot ask for better players. We need to be better coaches.”

**Coach-facing UI preference:** simple, large, clinical — not baby talk; glossary/words guide; farm-plain mobility; branding red `#C8102E`; text mark only.

---

## Product goal

Field-and-home toolkit for Red Lion PA football so coaches can teach and track without asking kids to “be better athletes” in the abstract:

- Role-based logins: athlete / parent / coach / admin  
- Manual measurements (40, med ball, stance) with form % and adjusted estimates  
- Body tracker (checklist + camera prototype)  
- Mobility / FAST field cards  
- Fuel habits  
- Position-fit notes (partial)  
- Study Lab + study gate  
- Coach Skill Library (Demo → Break down → Speed up)  
- Later: playbook ↔ roster fit when Andrew provides materials  

Estimates are coaching tools. They are not medical advice, injury screens, or recruiting scores.

---

## What’s built (as of late Sep 2026)

Verified against `/workspace/lion-lab-full` source (not memory alone).

### Stack

- **Next.js** `16.3.5` (App Router), **React** `19.2.8`, TypeScript, Tailwind 4, shadcn/ui  
- **Auth.js / next-auth** `5.0.0-beta.32` — credentials (email + password), JWT session (14 days)  
- **Prisma** `6.x` — **SQLite** locally (`file:./dev.db`); production must switch to **Postgres**  
- bcryptjs passwords; no public signup  

### Demo accounts

Password for every seeded account: **`LionLab2026!`**

| Role | Name | Email |
| --- | --- | --- |
| Coach | Dana Ruiz | `coach@lionlab.local` |
| Parent | Pat Hale | `parent@lionlab.local` |
| Athlete | Marcus Hale | `marcus@lionlab.local` |
| Athlete | Avery Chen | `avery@lionlab.local` |
| Athlete | Jordan Brooks | `jordan@lionlab.local` |
| Admin | Sam Okonkwo | `admin@lionlab.local` |

Pat Hale is linked only to Marcus. Seeded athlete grades in `prisma/seed.ts`: Marcus 11, Avery 9, Jordan 12.

### Features present in the tree

| Area | Status in code |
| --- | --- |
| Auth + roles + session cookie gate (`proxy.ts`) | Built |
| One-tap demo role buttons on sign-in (`app/page.tsx` → `loginDirect`) | Built (local UX polish) |
| Coach **Start here** hub on `/today` (Field · Skills · Roster) | Built (local UX polish) |
| Roster, create/edit athletes, position filter, parent invite | Built |
| Manual test log (40 / med ball / stance) + scoring formulas | Built (`lib/scoring.ts`) |
| CSV roster export | Built (`GET /api/export/roster`) |
| Field tablet cards + FAST locked content | Built (`/field`, `lib/content/fast.ts`) |
| Coach Skill Library — **33 skills** | Built (`lib/content/skills.ts`, `SKILL_LIBRARY_VERSION = "v1"`) |
| Taught-this-week checkbox (`SkillMark`) | Built |
| Study Lab: minutes, timer, study gate, streak | Built |
| Fuel habits (4 checkboxes on DayLog) | Built |
| Mobility drills + home train logging | Built (`lib/content/mobility.ts`, `/train`, `/home`) |
| Body tracker checklist + camera prototype | Built (`/tracker`, `components/body-tracker.tsx`, `public/pose/*`) |
| Fit notes heuristics on My path / Progress | Partial — rule-based notes, not full recommender |
| Standards (season label, study gate on/off, timer mins) | Built |
| Glossary (~25 terms) | Built |
| Unit tests | `npm test` → `lib/scoring.test.ts`, `lib/habits.test.ts`, `lib/skills.test.ts` |

### Skill library inventory (33)

Fundamentals: athletic-stance, first-step, attack-contact, square-up, tackle-wrap (*Through the tackle*), secure-ball, catch-ball, conditioning-finish  

OL: ol-kick-slide, ol-run-landmark, ol-pull-path, ol-finish-block (*Through the block*)  

DL: dl-get-off, dl-shed, dl-gap  

LB: lb-read-step, lb-spill-force, lb-tackle-space  

DB: db-coverage-base, db-hip-turn, db-contested, db-contain  

WR: wr-release, wr-catch-contact, wr-force-block  

RB: rb-ball-security, rb-crease, rb-pass-pro  

QB: qb-exchange, qb-eyes, qb-progression  

ST: st-cover, st-kick-green  

### Phone UX polish (keep these)

1. **Sign-in:** large role buttons (Coach / Parent / Athlete / Admin) submit hidden email+password via `loginDirect`. Manual email form is under a `<details>` “Type email instead”.  
2. **Coach Today:** title **Start here** with three large links — Field, Skills, Roster — then a one-line study-today count.

### FAST (locked)

From `lib/content/fast.ts`:

> First step. Attack. Shoulder level. Through — wrap if you’re tackling, drive if you’re blocking.

T was redefined to **Through** (not “tackle” as the letter word). Square up remains its own landmark skill.

---

## What’s NOT built yet

| Gap | Notes from code |
| --- | --- |
| **Durable public hosting** | Still an unpublished Origin draft; trycloudflare tunnels die; need GitHub/Origin repo + Vercel (or similar) + Postgres. SQLite is demo-only. |
| **Full position-fit recommendations** | `fitNotes()` is a short heuristic (strengths/gaps/3 drills). Skills even say some metrics “will tie to position-fit later.” |
| **Body tracker “auto form” productization** | Camera scoring exists as a MediaPipe prototype (`public/pose/score.js`). It needs `localhost` or `https`. Checklist always works. Do not treat camera scores as finished athletic training product. |
| **Diet / habit tracker completeness** | Fuel is four booleans + tips — not macros, meal plans, or multi-week nutrition analytics. |
| **Playbook ↔ roster fit** | Not in tree. Wait for Andrew’s materials. |
| **Real email delivery** | Invites are in-person password share. No mailer. Demo emails are `*.lionlab.local`. |
| **Official athletics logo** | Text mark only until athletics allows lion-head art. |

---

## Tech stack & how to run locally

From `README-DEMO.md` / `package.json` (Node.js 20+):

```bash
cd lion-lab-full   # or wherever you unzipped the handoff package
cp .env.example .env
npm i
npm run db:setup
npm run dev -- -H 0.0.0.0 -p 43123
```

Open http://127.0.0.1:43123

| Script | What it does |
| --- | --- |
| `npm run db:setup` | `prisma db push && prisma db seed` → creates `prisma/dev.db` + demo roster |
| `npm run db:seed` | Seed only |
| `npm test` | Scoring, habits, skills tests |
| `npm run build` | `prisma generate && next build` |
| `npm start` | Production server after build |

**SQLite is demo-only.** Production: change `prisma/schema.prisma` provider to `postgresql`, set Neon (or other) `DATABASE_URL`, new `AUTH_SECRET`, `AUTH_TRUST_HOST=true`. See main `README.md` section “Deploy on Vercel or Origin”.

### Env vars (`.env.example`)

| Name | Purpose |
| --- | --- |
| `DATABASE_URL` | Local: `file:./dev.db` (relative to `prisma/`). Production: Postgres URL. |
| `AUTH_SECRET` | Session signing. Example value is local-only — regenerate before deploy (`openssl rand -base64 32`). |
| `AUTH_TRUST_HOST` | `true` so Auth.js accepts the host on Vercel/Origin. |

Do **not** ship a real `.env` with secrets in the handoff zip (only `.env.example`).

---

## Architecture map

```
lion-lab-full/
  app/
    page.tsx                 # Sign-in (one-tap demo + LoginForm)
    glossary/page.tsx
    api/auth/[...nextauth]/  # Auth.js handlers
    api/export/roster/       # CSV export (staff)
    actions.ts               # Login, roster, tests, passwords, staff
    actions/daily.ts         # Study / fuel / mobility day logs
    actions/skills.ts        # Taught-this-week marks
    (signed)/                # Authenticated shell
      today/                 # Role homes; coach Start here
      field/                 # Sideline FAST / mobility cards
      skills/…               # Skill library
      coach/…                # Roster + athlete detail + log tests
      tracker/               # Body tracker
      measure/ train/ study/ path/
      home/ progress/ notes/ # Parent-facing
      standards/ admin/ account/
  components/                # UI + feature components (login, nav, tracker, skills, …)
  lib/
    auth.ts                  # NextAuth config, homeFor → /today, isStaff
    content/
      skills.ts              # 33 skills (source of truth)
      fast.ts                # FAST locked copy
      mobility.ts            # Farm-plain drills
      fuel.ts fit.ts glossary-terms.ts
    scoring.ts habits.ts days.ts data.ts access.ts guards.ts
    demo-accounts.ts
  prisma/schema.prisma       # User, AthleteProfile, TestSession, DayLog, PoseSession, SkillMark, …
  prisma/seed.ts
  public/pose/               # MediaPipe / scoring JS prototype
  proxy.ts                   # Cookie gate for signed routes (Next 16 proxy convention)
```

### Auth model

- Credentials provider against `User.passwordHash`  
- Roles stored as strings: `ATHLETE` | `PARENT` | `COACH` | `ADMIN`  
- JWT carries `role`; `requireUser()` / `isStaff()` enforce pages  
- `proxy.ts` redirects unauthenticated hits on signed prefixes to `/`  
- No OAuth; no public registration  

### Main routes by role

| Role | Nav (from `components/app-nav.tsx`) |
| --- | --- |
| Athlete | `/today` `/train` `/measure` `/study` `/path` `/glossary` (+ `/athlete/profile`) |
| Parent | `/today` `/home` `/progress` `/notes` `/glossary` |
| Coach | `/today` `/coach` `/field` `/skills` `/coach/log` `/tracker` `/standards` `/glossary` |
| Admin | `/today` `/coach` `/admin` `/field` `/skills` `/tracker` `/standards` `/glossary` |

### Full page / API route list

**Pages:** `/` · `/glossary` · `/today` · `/train` · `/measure` · `/study` · `/path` · `/home` · `/progress` · `/notes` · `/field` · `/tracker` · `/standards` · `/account` · `/skills` · `/skills/[skillId]` · `/skills/positions` · `/skills/positions/[pos]` · `/coach` · `/coach/log` · `/coach/athletes/new` · `/coach/athletes/[id]` · `/coach/athletes/[id]/edit` · `/coach/athletes/[id]/tests/new` · `/coach/athletes/[id]/tests/[sessionId]` · `/admin` · `/athlete` · `/athlete/profile`

**API:** `/api/auth/[...nextauth]` · `/api/export/roster`

### Where skills content lives

- **Source of truth:** `lib/content/skills.ts` (`SKILLS` array, `LIBRARY_POSITIONS`, helpers)  
- **UI:** `components/skill-browser.tsx`, `components/skill-taught-button.tsx`  
- **Persistence of “taught this week”:** Prisma `SkillMark` (athleteId + skillId + weekKey)  

### Scoring formulas (still v1)

Documented in README:

- **40:** `adjusted = raw × (1 + 0.10 × (1 − form index))` — ESTIMATE  
- **Med ball:** `adjusted = raw × (0.90 + 0.10 × form index)` — ESTIMATE  
- **Stance:** 80%+ Game-ready, 60–79% Developing, under 60% Rebuild  

---

## Work history (Sep 2026 arc)

Chronological narrative for the incoming developer:

1. **Local Pose Coach / Lion Lab V0 camera prototypes** while Origin publishing was blocked. Early body-form / camera experiments (see also workspace artifacts like `Red-Lion-Pose-Coach-Browser-Prototype.zip`, `Lion-Lab-V0.zip`).  
2. **Origin cloud agent** [`bc-103d84a6-326b-54f0-9276-922b2c15c6d9`](https://cursor.com/agents/bc-103d84a6-326b-54f0-9276-922b2c15c6d9) built the full cloud field-and-home toolkit (Next.js + Prisma + roles + Study Lab + tracker + skills).  
3. **Unified prior tools** — body tracker ideas, mobility (farm-plain names), fuel habits, Study Lab — into one app.  
4. **Coach Skill Library shipped ~2026-09-27** — ~33 skills, Demo → Break down → Speed up, position lists, taught-this-week.  
5. **FAST T redefined to Through**; standards, glossary, and skill titles aligned (tackle wrap / block drive finishes; Square up stays separate).  
6. **Phone UX polish** — one-tap demo login; coach Start here hub; copy simplification for tired volunteer coaches (“Three taps. Then go work.”). Prefer the **local** `/workspace/lion-lab-full` tree for these patches over the raw Sep 27 artifact zip alone.  
7. **Hosting pain** — Origin unpublished draft (`tmp-*`); user misses `127.0.0.1` windows; Cloudflare trycloudflare tunnels are ephemeral. Not production.  
8. **Latest artifact zip packaged**; local runnable copy lives at `/workspace/lion-lab-full` on the shared agent box.

---

## Open decisions / next work

1. **Create Origin/GitHub repo + lasting deploy** (Vercel + Postgres/Neon). Rotate `AUTH_SECRET`. Do not point production at SQLite.  
2. **Continue UI/copy simplification** from phone feedback (large type, clinical wording, glossary links).  
3. **Implement remaining product:** stronger auto body-form scoring productization, fuller position-fit, habit/diet completeness beyond four checkboxes.  
4. **Playbook integration** when Andrew provides materials (library is explicitly *not* a playbook today).  
5. **Real emails for testers** — replace `*.lionlab.local` when inviting real parents/coaches; still share passwords in person unless a mailer is added.  
6. **Official logo** only if athletics allows — keep text mark (`#C8102E`) until then.

---

## Demo credentials

| Role | Name | Email | Password |
| --- | --- | --- | --- |
| Coach | Dana Ruiz | `coach@lionlab.local` | `LionLab2026!` |
| Parent | Pat Hale | `parent@lionlab.local` | `LionLab2026!` |
| Athlete | Marcus Hale | `marcus@lionlab.local` | `LionLab2026!` |
| Athlete | Avery Chen | `avery@lionlab.local` | `LionLab2026!` |
| Athlete | Jordan Brooks | `jordan@lionlab.local` | `LionLab2026!` |
| Admin | Sam Okonkwo | `admin@lionlab.local` | `LionLab2026!` |

Suggested first walkthrough: sign in as **Coach** → Start here → Field (FAST) → Skills → Roster → open Marcus → Taught this week. Then Athlete Marcus for Study / Fuel / Train. Then Parent for linked-kid Today.

---

## Constraints / do-nots

- Don’t invent floral yoga pose names for mobility — keep farm-plain names.  
- Keep glossary-first coach materials; link the word list from sections.  
- Don’t use official lion-head art without athletics permission (text mark only).  
- Don’t treat Cloudflare tunnel URLs or Origin unpublished drafts as permanent hosting.  
- Don’t ship demo passwords or local `AUTH_SECRET` into a real production env without rotation.  
- Don’t call adjusted scores anything other than **ESTIMATE** in athlete-facing UI.  
- Don’t change FAST letter meanings without an explicit product decision (especially S ≠ Square up, T = Through).

---

## Handoff package contents

This handoff zip should contain:

- Full app source (no `node_modules`, no `.next`, no `prisma/*.db`, no live `.env`)  
- `.env.example`  
- `README.md` + `README-DEMO.md`  
- `Lion-Lab-Developer-Handoff.md` at zip root  
- `START-HERE.txt` pointing here  

Optional: `Lion-Lab-Developer-Handoff.docx` beside the markdown.

---

## Quick verification checklist for the new developer

1. `npm i && npm run db:setup && npm run dev -- -H 0.0.0.0 -p 43123`  
2. One-tap Coach → lands on Start here (Field / Skills / Roster)  
3. `/skills` shows 33 skills; open tackle-wrap and ol-finish-block — Through finishes  
4. `/glossary` loads; FAST line matches Through  
5. `npm test` passes  
6. Roster CSV downloads when signed in as coach  

---

---

## Update — Sep 29, 2026 (build 2: "the full program")

Everything in "What's NOT built yet" above was either built or has a path forward. The tree in this zip is the source of truth.

**New in this build**

| Area | Where | Notes |
| --- | --- | --- |
| Public site + mandatory sign-up | `/`, `/signin`, `/signup`, `/join`, `/coach/approvals`, `/coach/board` | Join code (TeamSetting.joinCode), PENDING → coach approves; admins approve coaches. Public page shows only team totals. `DEMO_MODE` gates one-tap demo logins. |
| Measurement battery | `lib/content/metrics.ts`, `/coach/measure`, `Measurement` model | 14 tests incl. flexibility (sit & reach, ankle knee-to-wall, deep squat) and balance (single-leg, sway). Stopwatch with 10-yd split. Team gaps box. |
| Camera measurement | `/camera`, `components/camera-lab.tsx`, `lib/pose-metrics.ts` | Balance timer + sway, squat score, sit & reach guide. On-device only. Formulas documented in code and tested. |
| Position-fit engine | `lib/position-fit.ts`, `lib/fit-data.ts`, `/coach/fit`, `components/fit-card.tsx` | 11 roles, weighted percentiles, target-size factors, confidence, greedy two-way depth board, coach weight overrides. Replaces `fitNotes()` as the main read (old notes kept on My path). |
| Recruiting | `/coach/recruit`, `lib/content/recruiting.ts`, `Prospect` model | Gap → "look for" profile from roster numbers, cross-sport + girls' teams map, non-athlete profile, PIAA guardrails. |
| Leadership exams | `/exams`, `/coach/exams`, `lib/content/exam-bank.ts` | QB Reads (20), MLB Fits (20), Captain's Standard (19). Server-graded. Exams feed QB/MLB fit. |
| Fuel & exercise | `/fuel`, `lib/content/fuel-guide.ts`, `lib/content/flex-balance-program.ts` | Youth-safe. Flex/balance program is chosen from each kid's weakest numbers. Farm-plain drill names kept. |
| Academics first | `components/academic-card.tsx`, `TeamSetting.weeklyStudyMinutes` | GOOD/WATCH/HOLD, weekly minutes (WATCH ×1.5), roster chips, CSV column. |

**Infrastructure changes**

- Prisma runs through **driver adapters** (`lib/db-adapter.ts`): SQLite locally, Postgres (`@prisma/adapter-pg`) when `DATABASE_URL` is `postgres://`. `scripts/prepare-schema.mjs` sets the provider from the env, so there's one schema file. Verified against real Postgres 16: build, smoke test, and writes.
- `prisma/postgres-init.sql`: the full schema as SQL for Neon's editor.
- `scripts/create-admin.ts`: creates the production admin + starter exams, with no demo accounts.
- Fonts are self-hosted (`app/fonts`), so the build no longer depends on Google Fonts.
- **Security fix:** coach pages under `/coach/athletes/*` and `/coach` relied only on the layout guard. Next renders layouts and pages in parallel, so athlete and parent sessions could receive roster data in the HTML stream before the redirect. Page-level `requireStaff()` has been added, and a leak test confirms it's clean. `requireUser()` now re-checks account status on every request.
- Demo roster: 22 fictional junior-high athletes with realistic numbers (`lib/seed/demo-roster.ts`). The original three are now grade 7–8.
- Tests: 52 passing (`npm test`). Lint has pre-existing React-compiler warnings in older components (body-tracker, study-timer, local-day). They don't block the build.

**Deploy:** see `README-DEPLOY.md` (Neon + Vercel, about 45 minutes).

**Still open**

1. Deploy, rotate `AUTH_SECRET`, set `DEMO_MODE=false`, change the join code.
2. Coach's own playbook into the exams (the editor is ready) and play diagrams (not built).
3. Anchors in `lib/position-fit.ts` are coaching estimates. Re-tune them after a season of real data, or switch to team percentiles only once 8+ kids are tested per grade band.
4. Email delivery (password resets, approval notices) is still not built. Approvals happen in-app.
5. District sign-off on minors' data (see the privacy checklist in README-DEPLOY).

*End of handoff. Prefer reading the repo over this doc when they disagree — and then fix this doc.*
