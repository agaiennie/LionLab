// One place that decides which database driver Prisma talks through.
// - DATABASE_URL starting with postgres:// or postgresql:// -> Postgres (Neon, Supabase, RDS…)
// - anything else (file:…) -> local SQLite file, for laptops and demos
// Prisma runs in "driver adapter" mode, so no native Prisma engine download is needed.
import path from "node:path";
import { PrismaBetterSQLite3 } from "@prisma/adapter-better-sqlite3";
import { PrismaPg } from "@prisma/adapter-pg";

export const DEFAULT_SQLITE_URL = "file:./prisma/dev.db";

export function databaseUrl(): string {
  return process.env.DATABASE_URL?.trim() || DEFAULT_SQLITE_URL;
}

export function isPostgresUrl(url: string): boolean {
  return /^postgres(ql)?:\/\//i.test(url);
}

export function makeAdapter(url: string = databaseUrl()) {
  if (isPostgresUrl(url)) {
    return new PrismaPg({ connectionString: url });
  }
  const file = url.replace(/^file:/, "");
  const absolute = path.isAbsolute(file) ? file : path.join(/*turbopackIgnore: true*/ process.cwd(), file);
  return new PrismaBetterSQLite3({ url: `file:${absolute}` });
}
