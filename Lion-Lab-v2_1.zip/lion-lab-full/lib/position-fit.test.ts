import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { anchorStanding, buildDepth, factorScore, fitRoles, percentile, type FitAthlete } from "./position-fit";

function kid(id: string, over: Partial<FitAthlete["values"]>, grade = 8): FitAthlete {
  return { id, name: id, grade, positions: [], values: { HEIGHT: 64, WEIGHT: 130, ...over } };
}

describe("percentile", () => {
  it("is direction aware", () => {
    assert.equal(percentile(5.0, [5.0, 5.5, 6.0, 6.5], true), 87.5);
    assert.equal(percentile(5.0, [5.0, 5.5, 6.0, 6.5], false), 12.5);
  });
});

describe("anchors and factors", () => {
  it("clamps and handles reversed anchors (lower is better)", () => {
    assert.equal(anchorStanding(5.2, [6.6, 5.2]), 100);
    assert.equal(anchorStanding(7.0, [6.6, 5.2]), 0);
    assert.equal(Math.round(anchorStanding(5.9, [6.6, 5.2])), 50);
  });
  it("target factors peak at the target", () => {
    assert.equal(factorScore({ key: "WEIGHT", weight: 1, mode: "target", target: 55 }, 55), 100);
    assert.ok(factorScore({ key: "WEIGHT", weight: 1, mode: "target", target: 55 }, 95) < 50);
  });
});

describe("fitRoles", () => {
  const roster: FitAthlete[] = [];
  for (let i = 0; i < 10; i++) {
    roster.push(kid(`small${i}`, { WEIGHT: 100 + i, HEIGHT: 60, SPRINT_40: 5.4 + i * 0.05, PRO_AGILITY: 4.8 + i * 0.05, SPLIT_10: 1.8, VERTICAL: 20, BROAD_JUMP: 85 }));
  }
  roster.push(kid("big", { WEIGHT: 230, HEIGHT: 70, SPRINT_40: 7.0, PRO_AGILITY: 6.2, SPLIT_10: 2.3, MEDBALL_ROT: 30, MEDBALL_CHEST: 20, VERTICAL: 10, BROAD_JUMP: 60 }));
  it("puts the heavy, slow kid on the line", () => {
    const top = fitRoles(roster.find((k) => k.id === "big")!, roster)[0]!;
    assert.ok(["OL", "DT"].includes(top.role), top.role);
  });
  it("puts the fastest light kid at a speed spot", () => {
    const top = fitRoles(roster.find((k) => k.id === "small0")!, roster)[0]!;
    assert.ok(["CB", "WR", "S", "RB", "OLB"].includes(top.role), top.role);
  });
  it("low data means low confidence", () => {
    const lonely = kid("new", {});
    const fit = fitRoles(lonely, [...roster, lonely]).find((f) => f.role === "QB")!;
    assert.ok(fit.confidence < 0.3);
  });
  it("depth places each athlete at most once per side", () => {
    const depth = buildDepth(roster);
    const seen = new Map<string, number>();
    for (const row of depth) for (const a of row.assigned) seen.set(a.id, (seen.get(a.id) ?? 0) + 1);
    for (const count of seen.values()) assert.ok(count <= 2);
  });
});
