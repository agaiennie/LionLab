/** Hidden form field. Real people never see it; simple bots fill every box. */
export const HONEYPOT = "website";

export const SPORTS = [
  "None yet",
  "Basketball",
  "Wrestling",
  "Soccer",
  "Baseball/softball",
  "Track",
  "Cross country",
  "Lacrosse",
  "Volleyball",
  "Field hockey",
  "Other",
] as const;
