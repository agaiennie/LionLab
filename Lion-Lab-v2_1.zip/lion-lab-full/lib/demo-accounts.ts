export const DEMO_PASSWORD = "LionLab2026!";

export const DEMO_ACCOUNTS = [
  {
    role: "Coach",
    name: "Dana Ruiz",
    email: "coach@lionlab.local",
    password: DEMO_PASSWORD,
  },
  {
    role: "Parent",
    name: "Pat Hale",
    email: "parent@lionlab.local",
    password: DEMO_PASSWORD,
  },
  {
    role: "Athlete",
    name: "Marcus Hale",
    email: "marcus@lionlab.local",
    password: DEMO_PASSWORD,
  },
  {
    role: "Athlete",
    name: "Avery Chen",
    email: "avery@lionlab.local",
    password: DEMO_PASSWORD,
  },
  {
    role: "Athlete",
    name: "Jordan Brooks",
    email: "jordan@lionlab.local",
    password: DEMO_PASSWORD,
  },
  {
    role: "Admin",
    name: "Sam Okonkwo",
    email: "admin@lionlab.local",
    password: DEMO_PASSWORD,
  },
] as const;
