// Academics first. Pure helpers (no DB) so they can be unit-tested.
import { shiftDay } from "./habits";

export const ACADEMIC_STATUSES = ["GOOD", "WATCH", "HOLD"] as const;
export type AcademicStatus = (typeof ACADEMIC_STATUSES)[number];

export function isAcademicStatus(value: unknown): value is AcademicStatus {
  return typeof value === "string" && (ACADEMIC_STATUSES as readonly string[]).includes(value);
}

export function asAcademicStatus(value: unknown): AcademicStatus {
  return isAcademicStatus(value) ? value : "GOOD";
}

export const ACADEMIC_MEANING: Record<AcademicStatus, { label: string; meaning: string }> = {
  GOOD: { label: "Good", meaning: "Cleared. Keep the weekly study minutes." },
  WATCH: {
    label: "Watch",
    meaning: "Extra study minutes (1.5× the weekly target) and a weekly check-in with a coach.",
  },
  HOLD: {
    label: "Hold",
    meaning: "No game until grades are fixed. Practice is up to the coach.",
  },
};

export const PIAA_LINE =
  "In Pennsylvania, PIAA eligibility requires passing at least four full-credit subjects, checked weekly.";

export const GRADES_FIRST_LINE = "Grades come first.";

export const WATCH_MULTIPLIER = 1.5;

/** Monday (YYYY-MM-DD) of the week containing `day`. Weeks run Mon–Sun. */
export function weekStartKey(day: string): string {
  const [year, month, date] = day.split("-").map(Number);
  const weekday = new Date(Date.UTC(year, month - 1, date)).getUTCDay(); // 0 = Sun
  const back = weekday === 0 ? 6 : weekday - 1;
  return shiftDay(day, -back);
}

/** Sum of study minutes from Monday `weekStart` through Sunday. */
export function weekStudyTotal(
  days: { day: string; studyMinutes: number }[],
  weekStart: string,
): number {
  const end = shiftDay(weekStart, 6);
  return days
    .filter((row) => row.day >= weekStart && row.day <= end)
    .reduce((sum, row) => sum + Math.max(0, row.studyMinutes), 0);
}

/** WATCH raises the weekly target by 1.5×, rounded up. */
export function effectiveWeeklyTarget(base: number, status: string): number {
  return status === "WATCH" ? Math.ceil(base * WATCH_MULTIPLIER) : base;
}

/**
 * What a parent may do. Parents can move GOOD <-> WATCH and add a note.
 * They can't set HOLD and can't clear a HOLD (the status stays HOLD; the note still saves).
 */
export function parentNextStatus(current: string, requested: string): AcademicStatus | null {
  if (requested !== "GOOD" && requested !== "WATCH") return null;
  if (current === "HOLD") return "HOLD";
  return requested;
}
