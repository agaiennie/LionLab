import { redirect } from "next/navigation";
import { auth, homeFor, isStaff } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function requireUser() {
  const session = await auth();
  if (!session?.user?.id || !session.user.role) redirect("/signin");
  // Re-check the account on every signed-in page so a disabled or
  // still-pending account can't ride an old session cookie.
  const live = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { status: true, role: true },
  });
  if (!live || live.status !== "ACTIVE") redirect("/signin?status=pending");
  return { ...session.user, role: live.role };
}

export async function requireStaff() {
  const user = await requireUser();
  if (!isStaff(user.role)) redirect(homeFor(user.role));
  return user;
}

export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "ADMIN") redirect(homeFor(user.role));
  return user;
}

export async function requireAthlete() {
  const user = await requireUser();
  if (user.role !== "ATHLETE") redirect(homeFor(user.role));
  return user;
}

export async function requireParent() {
  const user = await requireUser();
  if (user.role !== "PARENT") redirect(homeFor(user.role));
  return user;
}
