/** One-tap demo logins only when DEMO_MODE=true. Keep it off with real families' data. */
export function demoMode(): boolean {
  return process.env.DEMO_MODE === "true";
}
