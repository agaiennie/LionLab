import { prisma } from "@/lib/db";
import {
  acceptedDay,
  complianceStreak,
  lastStudyDay,
  shiftDay,
  studyComplete,
  todayKey,
} from "@/lib/habits";

export type DayView = {
  day: string;
  studyMinutes: number;
  parentOverride: string;
  water: boolean;
  protein: boolean;
  sleep: boolean;
  lightJunk: boolean;
  mobilityDone: boolean;
  mobilityTemplate: string;
  homeTrainDone: boolean;
};

export type HabitSnap = {
  streak: number;
  lastStudy: string | null;
  todayMinutes: number;
  todayStatus: "done" | "note" | "open";
  mobilityDone: boolean;
  homeTrainDone: boolean;
  fuelDone: number;
};

export type PoseRow = {
  id: string;
  movementName: string;
  position: string;
  place: string;
  mode: string;
  overall: number | null;
  band: string;
  cues: string[];
  notes: string;
  recordedOnLabel: string;
  recordedBy: string;
};

export type NoteRow = {
  id: string;
  body: string;
  author: string;
  createdLabel: string;
};

export type SubjectRow = { id: string; name: string };

export type ParentRow = { name: string; email: string };

function blankDay(day: string): DayView {
  return {
    day,
    studyMinutes: 0,
    parentOverride: "",
    water: false,
    protein: false,
    sleep: false,
    lightJunk: false,
    mobilityDone: false,
    mobilityTemplate: "",
    homeTrainDone: false,
  };
}

function mapDay(day: string, row: {
  studyMinutes: number;
  parentOverride: string;
  water: boolean;
  protein: boolean;
  sleep: boolean;
  lightJunk: boolean;
  mobilityDone: boolean;
  mobilityTemplate: string;
  homeTrainDone: boolean;
} | null): DayView {
  if (!row) return blankDay(day);
  return { day, ...row };
}

export function labelDay(day: string): string {
  const [year, month, date] = day.split("-").map(Number);
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(Date.UTC(year, month - 1, date)));
}

export function dateFromKey(day: string): Date {
  const [year, month, date] = day.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, date, 12));
}

export function resolveDay(raw: unknown, now = new Date()): string | null {
  const value = String(raw ?? "").trim();
  if (!value) return todayKey(now);
  return acceptedDay(value, now);
}

export async function getTeam() {
  return prisma.teamSetting.upsert({
    where: { id: "team" },
    update: {},
    create: { id: "team" },
  });
}

export async function readDay(athleteId: string, day: string): Promise<DayView> {
  const row = await prisma.dayLog.findUnique({
    where: { athleteId_day: { athleteId, day } },
  });
  return mapDay(day, row);
}

export async function upsertDay(athleteId: string, day: string) {
  return prisma.dayLog.upsert({
    where: { athleteId_day: { athleteId, day } },
    update: {},
    create: { athleteId, day },
  });
}

export async function habitBoard(athleteIds: string[]) {
  const team = await getTeam();
  const today = todayKey();
  const logs = athleteIds.length
    ? await prisma.dayLog.findMany({ where: { athleteId: { in: athleteIds } } })
    : [];

  const map = new Map<string, HabitSnap>();
  for (const id of athleteIds) {
    const days = logs.filter((row) => row.athleteId === id);
    const todayRow = days.find((row) => row.day === today);
    const trained = days.map((row) => ({
      day: row.day,
      studyMinutes: row.studyMinutes,
      trained: row.mobilityDone || row.homeTrainDone,
    }));
    let todayStatus: HabitSnap["todayStatus"] = "open";
    if (todayRow && studyComplete(todayRow.studyMinutes, team.studyGoalMinutes)) todayStatus = "done";
    else if (todayRow && todayRow.parentOverride.trim()) todayStatus = "note";
    const fuelDone = todayRow
      ? [todayRow.water, todayRow.protein, todayRow.sleep, todayRow.lightJunk].filter(Boolean).length
      : 0;
    map.set(id, {
      streak: complianceStreak(trained, today, team.studyGoalMinutes),
      lastStudy: lastStudyDay(days, team.studyGoalMinutes),
      todayMinutes: todayRow?.studyMinutes ?? 0,
      todayStatus,
      mobilityDone: Boolean(todayRow?.mobilityDone),
      homeTrainDone: Boolean(todayRow?.homeTrainDone),
      fuelDone,
    });
  }

  return { team, today, map };
}

export function weekStudyMinutes(
  logs: { day: string; studyMinutes: number }[],
  today: string,
): number {
  const keys = new Set(Array.from({ length: 7 }, (_, index) => shiftDay(today, -index)));
  return logs.filter((row) => keys.has(row.day)).reduce((sum, row) => sum + row.studyMinutes, 0);
}

export async function loadAthleteDay(athleteId: string) {
  const board = await habitBoard([athleteId]);
  const day = await readDay(athleteId, board.today);
  const [subjects, poses, notes, days] = await Promise.all([
    listSubjects(athleteId),
    recentPoses(athleteId),
    listNotes(athleteId),
    allDays(athleteId),
  ]);
  const snap = board.map.get(athleteId);
  if (!snap) throw new Error("Missing habit row.");
  return { team: board.team, today: board.today, day, subjects, poses, notes, days, snap };
}

export async function recentDays(athleteId: string, today: string) {
  const keys = Array.from({ length: 7 }, (_, index) => shiftDay(today, -6 + index));
  const rows = await prisma.dayLog.findMany({
    where: { athleteId, day: { in: keys } },
  });
  return keys.map((day) => mapDay(day, rows.find((row) => row.day === day) ?? null));
}

export async function allDays(athleteId: string) {
  return prisma.dayLog.findMany({ where: { athleteId }, orderBy: { day: "asc" } });
}

export async function listSubjects(athleteId: string): Promise<SubjectRow[]> {
  return prisma.subject.findMany({
    where: { athleteId },
    orderBy: { name: "asc" },
    select: { id: true, name: true },
  });
}

export async function listNotes(athleteId: string): Promise<NoteRow[]> {
  const notes = await prisma.coachNote.findMany({
    where: { athleteId },
    orderBy: { createdAt: "desc" },
    take: 30,
    include: { author: { select: { name: true } } },
  });
  return notes.map((note) => ({
    id: note.id,
    body: note.body,
    author: note.author.name,
    createdLabel: new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      timeZone: "UTC",
    }).format(note.createdAt),
  }));
}

export async function parentsFor(athleteId: string): Promise<ParentRow[]> {
  const links = await prisma.parentLink.findMany({
    where: { athleteId },
    include: { parent: { select: { name: true, email: true } } },
  });
  return links
    .map((link) => link.parent)
    .sort((a, b) => a.name.localeCompare(b.name));
}

export async function recentPoses(athleteId: string): Promise<PoseRow[]> {
  const rows = await prisma.poseSession.findMany({
    where: { athleteId },
    orderBy: { recordedOn: "desc" },
    take: 8,
    include: { recordedBy: { select: { name: true } } },
  });
  return rows.map((row) => ({
    id: row.id,
    movementName: row.movementName,
    position: row.position,
    place: row.place,
    mode: row.mode,
    overall: row.overall,
    band: row.band,
    cues: parseCues(row.cues),
    notes: row.notes,
    recordedOnLabel: new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      timeZone: "UTC",
    }).format(row.recordedOn),
    recordedBy: row.recordedBy.name,
  }));
}

function parseCues(value: string): string[] {
  try {
    const parsed = JSON.parse(value) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is string => typeof item === "string");
  } catch {
    return [];
  }
}
