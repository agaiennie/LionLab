import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { EXAM_BANK } from "./content/exam-bank";
import { examRequiredFor, gradeAnswers, summarizeAttempts } from "./exams";

const key = [{ answerIndex: 0 }, { answerIndex: 2 }, { answerIndex: 1 }, { answerIndex: 3 }, { answerIndex: 0 }];

describe("gradeAnswers", () => {
  it("scores a perfect exam", () => {
    const graded = gradeAnswers(key, [0, 2, 1, 3, 0], 80);
    assert.equal(graded.correct, 5);
    assert.equal(graded.total, 5);
    assert.equal(graded.percent, 100);
    assert.equal(graded.passed, true);
    assert.deepEqual(graded.results, [true, true, true, true, true]);
  });

  it("passes exactly at the pass percent", () => {
    const graded = gradeAnswers(key, [0, 2, 1, 3, 1], 80);
    assert.equal(graded.correct, 4);
    assert.equal(graded.percent, 80);
    assert.equal(graded.passed, true);
  });

  it("fails below the pass percent and rounds percent", () => {
    const three = [{ answerIndex: 0 }, { answerIndex: 0 }, { answerIndex: 0 }];
    const graded = gradeAnswers(three, [0, 0, 1], 80);
    assert.equal(graded.percent, 67);
    assert.equal(graded.passed, false);
  });

  it("counts missing, null, and out-of-range answers as wrong", () => {
    const graded = gradeAnswers(key, [null, 2, 9, -1], 50);
    assert.equal(graded.correct, 1);
    assert.deepEqual(graded.results, [false, true, false, false, false]);
    assert.equal(graded.percent, 20);
    assert.equal(graded.passed, false);
  });

  it("never passes an empty exam", () => {
    const graded = gradeAnswers([], [], 0);
    assert.equal(graded.percent, 0);
    assert.equal(graded.passed, false);
  });
});

describe("exam bank", () => {
  it("keeps the slugs the position-fit engine reads", () => {
    const slugs = EXAM_BANK.map((exam) => exam.slug);
    assert.deepEqual(slugs.sort(), ["captain-standard", "mlb-fits", "qb-reads"]);
  });

  for (const exam of EXAM_BANK) {
    it(`${exam.slug}: 15 to 20 valid questions`, () => {
      assert.ok(exam.questions.length >= 15 && exam.questions.length <= 20, `${exam.questions.length} questions`);
      assert.equal(exam.passPercent, 80);
      for (const q of exam.questions) {
        assert.ok(q.prompt.trim().length > 0, "prompt is empty");
        assert.ok(q.choices.length >= 2 && q.choices.length <= 5, `${q.prompt}: ${q.choices.length} choices`);
        assert.ok(Number.isInteger(q.answerIndex), q.prompt);
        assert.ok(q.answerIndex >= 0 && q.answerIndex < q.choices.length, `${q.prompt}: answerIndex out of range`);
        assert.equal(new Set(q.choices).size, q.choices.length, `${q.prompt}: duplicate choices`);
        assert.ok(q.explanation.trim().length > 0, `${q.prompt}: missing explanation`);
      }
    });

    it(`${exam.slug}: answer key is not all one letter`, () => {
      const spots = new Set(exam.questions.map((q) => q.answerIndex));
      assert.ok(spots.size >= 3);
    });
  }

  it("grades the answer key as 100%", () => {
    for (const exam of EXAM_BANK) {
      const graded = gradeAnswers(
        exam.questions,
        exam.questions.map((q) => q.answerIndex),
        exam.passPercent,
      );
      assert.equal(graded.percent, 100);
    }
  });
});

describe("audience + summaries", () => {
  it("matches QB and LB positions", () => {
    assert.equal(examRequiredFor("QB", ["QB", "DB"]), true);
    assert.equal(examRequiredFor("QB", ["WR"]), false);
    assert.equal(examRequiredFor("MLB", ["LB", "DL"]), true);
    assert.equal(examRequiredFor("MLB", ["DL"]), false);
    assert.equal(examRequiredFor("ALL", ["K"]), true);
  });

  it("summarizes latest and best", () => {
    const summary = summarizeAttempts([
      { percent: 90, passed: true, createdAt: new Date("2026-09-01") },
      { percent: 70, passed: false, createdAt: new Date("2026-09-10") },
    ]);
    assert.equal(summary?.latestPercent, 70);
    assert.equal(summary?.bestPercent, 90);
    assert.equal(summary?.everPassed, true);
    assert.equal(summary?.attempts, 2);
    assert.equal(summarizeAttempts([]), null);
  });
});
