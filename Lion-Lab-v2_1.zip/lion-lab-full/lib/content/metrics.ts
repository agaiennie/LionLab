// Measurement battery catalog. Source of truth for every number Lion Lab records
// outside the form battery (40 / med ball / stance in lib/scoring.ts).
// Adding a test = add an entry here. No database migration needed.

export type MetricGroup = "SPEED" | "AGILITY" | "POWER" | "STRENGTH" | "FLEX" | "BALANCE" | "SKILL";

export const METRIC_GROUPS: { id: MetricGroup; label: string; why: string }[] = [
  { id: "SPEED", label: "Speed", why: "How fast you cover ground in a straight line." },
  { id: "AGILITY", label: "Change of direction", why: "Stop, plant, and go the other way under control." },
  { id: "POWER", label: "Power", why: "Force in a short burst: jumps and throws." },
  { id: "STRENGTH", label: "Strength", why: "Body-weight strength and trunk control. No max lifts at this age." },
  { id: "FLEX", label: "Flexibility", why: "Range of motion. Tight ankles and hips cost stance, tackles, and cuts." },
  { id: "BALANCE", label: "Balance", why: "Staying on your feet. Poor balance means missed tackles and falls on cuts." },
  { id: "SKILL", label: "Football skill", why: "Position-specific numbers." },
];

export type MetricId =
  | "SPRINT_40"
  | "SPLIT_10"
  | "PRO_AGILITY"
  | "BROAD_JUMP"
  | "VERTICAL"
  | "MEDBALL_CHEST"
  | "PUSHUPS"
  | "PLANK"
  | "SIT_REACH"
  | "KNEE_WALL"
  | "SQUAT_SCORE"
  | "BALANCE_SL"
  | "BALANCE_SWAY"
  | "FOOTBALL_THROW";

export type MetricDef = {
  id: MetricId;
  group: MetricGroup;
  label: string;
  short: string;
  unit: "sec" | "in" | "ft" | "yd" | "reps" | "score" | "%";
  /** Which direction is better. */
  better: "lower" | "higher";
  min: number;
  max: number;
  decimals: number;
  /** Record left and right separately. */
  sided: boolean;
  /** How the number can be captured on a phone. */
  capture: ("manual" | "stopwatch" | "camera")[];
  equipment: string;
  protocol: string[];
  safety?: string;
};

export const METRICS: MetricDef[] = [
  {
    id: "SPRINT_40",
    group: "SPEED",
    label: "40-yard sprint",
    short: "40",
    unit: "sec",
    better: "lower",
    min: 4.2,
    max: 10,
    decimals: 2,
    sided: false,
    capture: ["stopwatch", "manual"],
    equipment: "Cones at 0, 10, and 40 yards. One timer at the finish.",
    protocol: [
      "Three-point or two-point start, athlete's choice. Same start every test day.",
      "Start the clock on first movement. Stop when the chest crosses 40.",
      "Two tries, 2 minutes rest. Record the best.",
      "Tap Split at 10 yards on the stopwatch to get the 10-yard burst for free.",
    ],
  },
  {
    id: "SPLIT_10",
    group: "SPEED",
    label: "10-yard burst",
    short: "10 yd",
    unit: "sec",
    better: "lower",
    min: 1.3,
    max: 4,
    decimals: 2,
    sided: false,
    capture: ["stopwatch", "manual"],
    equipment: "Cones at 0 and 10 yards.",
    protocol: [
      "First 10 yards of the 40, or a stand-alone 10.",
      "This is the first-step number. It matters more than the 40 for linemen and backs.",
    ],
  },
  {
    id: "PRO_AGILITY",
    group: "AGILITY",
    label: "5-10-5 shuttle",
    short: "5-10-5",
    unit: "sec",
    better: "lower",
    min: 3.8,
    max: 10,
    decimals: 2,
    sided: false,
    capture: ["stopwatch", "manual"],
    equipment: "Three cones 5 yards apart in a line.",
    protocol: [
      "Straddle the middle cone, hand down.",
      "Run 5 yards right, touch the line. Run 10 yards left, touch the line. Finish 5 yards through the middle.",
      "One each direction. Record the best.",
    ],
  },
  {
    id: "BROAD_JUMP",
    group: "POWER",
    label: "Standing long jump",
    short: "Long jump",
    unit: "in",
    better: "higher",
    min: 24,
    max: 130,
    decimals: 0,
    sided: false,
    capture: ["manual"],
    equipment: "Tape measure on flat ground or a mat.",
    protocol: [
      "Toes behind the line. Two-foot takeoff, two-foot landing.",
      "Measure from the line to the back of the closest heel.",
      "Must stick the landing. Falling back = measure where the hand or butt landed.",
      "Three tries. Record the best, in inches.",
    ],
  },
  {
    id: "VERTICAL",
    group: "POWER",
    label: "Vertical jump",
    short: "Vertical",
    unit: "in",
    better: "higher",
    min: 3,
    max: 40,
    decimals: 1,
    sided: false,
    capture: ["manual"],
    equipment: "Wall, tape, chalk on the fingers.",
    protocol: [
      "Stand sideways to the wall. Reach up flat-footed and mark. That's the standing reach.",
      "No step. Jump and touch as high as possible.",
      "Vertical = jump mark minus standing reach. Three tries, best counts.",
    ],
  },
  {
    id: "MEDBALL_CHEST",
    group: "POWER",
    label: "Ball toss (seated chest pass, 6 lb)",
    short: "Ball toss",
    unit: "ft",
    better: "higher",
    min: 5,
    max: 40,
    decimals: 1,
    sided: false,
    capture: ["manual"],
    equipment: "6 lb med ball, tape measure, wall for the back.",
    protocol: [
      "Sit with the back flat on a wall, legs straight.",
      "Chest pass for distance. Back stays on the wall.",
      "Measure to where the ball first lands. Three tries, best counts.",
      "This is upper-body power. The 10 lb rotational throw in the form battery is hip power.",
    ],
  },
  {
    id: "PUSHUPS",
    group: "STRENGTH",
    label: "Push-ups in 60 seconds",
    short: "Push-ups",
    unit: "reps",
    better: "higher",
    min: 0,
    max: 100,
    decimals: 0,
    sided: false,
    capture: ["stopwatch", "manual"],
    equipment: "Stopwatch.",
    protocol: [
      "Chest to a fist on the ground, arms fully straight at the top.",
      "Body stays a plank. Sagging hips do not count.",
      "Count clean reps in 60 seconds.",
    ],
  },
  {
    id: "PLANK",
    group: "STRENGTH",
    label: "Plank hold",
    short: "Plank",
    unit: "sec",
    better: "higher",
    min: 0,
    max: 300,
    decimals: 0,
    sided: false,
    capture: ["stopwatch", "manual"],
    equipment: "Stopwatch.",
    protocol: [
      "Forearms down, body straight from head to heels.",
      "Stop the clock when the hips sag or pike and do not come back on the first cue.",
      "Cap at 2 minutes. Past that it is not telling you anything new.",
    ],
  },
  {
    id: "SIT_REACH",
    group: "FLEX",
    label: "Sit and reach",
    short: "Sit & reach",
    unit: "in",
    better: "higher",
    min: -15,
    max: 15,
    decimals: 1,
    sided: false,
    capture: ["manual", "camera"],
    equipment: "Box or a ruler taped to the floor. Zero = the soles of the feet.",
    protocol: [
      "Sit, legs straight, soles flat against the box.",
      "Hands stacked. Reach slowly forward and hold 2 seconds. No bouncing.",
      "Short of the toes is a negative number. Past the toes is positive.",
      "Best of three.",
    ],
    safety: "Stop at a stretch, not pain. Skip with a current hamstring or back injury.",
  },
  {
    id: "KNEE_WALL",
    group: "FLEX",
    label: "Ankle knee-to-wall",
    short: "Ankle",
    unit: "in",
    better: "higher",
    min: 0,
    max: 8,
    decimals: 1,
    sided: true,
    capture: ["manual"],
    equipment: "Wall and a tape measure on the floor.",
    protocol: [
      "Face the wall in a half-kneel. Big toe on the tape.",
      "Drive the knee forward to touch the wall. Heel must stay down.",
      "Slide the foot back until the knee just touches with the heel down.",
      "Record toe-to-wall distance. Both sides. Under 4 inches is a tight ankle.",
    ],
  },
  {
    id: "SQUAT_SCORE",
    group: "FLEX",
    label: "Deep squat check",
    short: "Squat",
    unit: "score",
    better: "higher",
    min: 0,
    max: 100,
    decimals: 0,
    sided: false,
    capture: ["camera", "manual"],
    equipment: "Phone on a stand, side view, whole body in frame.",
    protocol: [
      "Feet shoulder width, arms straight overhead.",
      "Squat as deep as possible, heels down, chest up. Hold 2 seconds. Three reps.",
      "Camera scores depth and trunk angle. By hand: 100 = hips below knees, heels down, arms stay over feet; 70 = parallel; 40 = above parallel or heels lift; 0 = can't squat without falling.",
    ],
    safety: "Pain = stop and tell the ATC. This is a movement check, not an injury screen.",
  },
  {
    id: "BALANCE_SL",
    group: "BALANCE",
    label: "Single-leg balance (eyes closed)",
    short: "Balance",
    unit: "sec",
    better: "higher",
    min: 0,
    max: 60,
    decimals: 1,
    sided: true,
    capture: ["camera", "stopwatch", "manual"],
    equipment: "Flat floor. Phone on a stand facing the athlete, or a stopwatch.",
    protocol: [
      "Hands on hips. Lift one foot off the floor. Close the eyes. Clock starts.",
      "Clock stops when the foot touches down, the hands leave the hips, or the eyes open.",
      "Cap at 30 seconds. Both legs. Two tries each, best counts.",
      "If most of the team can't reach 5 seconds, test eyes open first and note it.",
    ],
    safety: "Spotter close by. Clear space around the athlete.",
  },
  {
    id: "BALANCE_SWAY",
    group: "BALANCE",
    label: "Balance sway (camera)",
    short: "Sway",
    unit: "%",
    better: "lower",
    min: 0,
    max: 100,
    decimals: 1,
    sided: true,
    capture: ["camera"],
    equipment: "Phone on a stand facing the athlete, whole body in frame.",
    protocol: [
      "Recorded by the camera during the single-leg balance test.",
      "How far the hips wander, as a percent of torso length. Lower is steadier.",
    ],
  },
  {
    id: "FOOTBALL_THROW",
    group: "SKILL",
    label: "Football throw for distance",
    short: "Throw",
    unit: "yd",
    better: "higher",
    min: 5,
    max: 80,
    decimals: 0,
    sided: false,
    capture: ["manual"],
    equipment: "Football sized for the level, yard lines.",
    protocol: [
      "Three-step drop. Throw for distance on a line, not a moon ball.",
      "Measure where the ball lands. Three throws, best counts.",
      "Quarterback tryouts only. Accuracy is a separate coach eye test.",
    ],
  },
];

export const METRIC_BY_ID = Object.fromEntries(METRICS.map((m) => [m.id, m])) as Record<MetricId, MetricDef>;

export function isMetricId(value: string): value is MetricId {
  return value in METRIC_BY_ID;
}

export function metricsInGroup(group: MetricGroup): MetricDef[] {
  return METRICS.filter((m) => m.group === group);
}

export function formatMetric(id: MetricId, value: number | null | undefined): string {
  if (value == null || Number.isNaN(value)) return "—";
  const def = METRIC_BY_ID[id];
  if (def.unit === "in" && id === "BROAD_JUMP") {
    const feet = Math.floor(value / 12);
    const inches = Math.round(value - feet * 12);
    return `${feet}'${inches}"`;
  }
  const fixed = value.toFixed(def.decimals);
  switch (def.unit) {
    case "sec":
      return `${fixed}s`;
    case "in":
      return `${value > 0 && id === "SIT_REACH" ? "+" : ""}${fixed} in`;
    case "ft":
      return `${fixed} ft`;
    case "yd":
      return `${fixed} yd`;
    case "reps":
      return `${fixed} reps`;
    case "%":
      return `${fixed}%`;
    default:
      return fixed;
  }
}

/** True when a is a better result than b for this metric. */
export function isBetter(id: MetricId, a: number, b: number): boolean {
  return METRIC_BY_ID[id].better === "lower" ? a < b : a > b;
}

export function validateMetricValue(id: MetricId, value: number): string | null {
  const def = METRIC_BY_ID[id];
  if (!Number.isFinite(value)) return "Enter a number.";
  if (value < def.min || value > def.max) {
    return `${def.label} should be between ${def.min} and ${def.max} ${def.unit}. Check the entry.`;
  }
  return null;
}
