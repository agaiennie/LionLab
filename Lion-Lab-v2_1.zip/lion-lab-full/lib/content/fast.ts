export const FAST = [
  {
    letter: "F",
    word: "First step",
    doThis: "Win the first step. No freeze. Move before you think.",
  },
  {
    letter: "A",
    word: "Attack",
    doThis: "Dip pads. Shoulder through the target. Do not stand up and turn hips or back.",
  },
  {
    letter: "S",
    word: "Shoulder level",
    doThis: "Pads and shoulders ready. Not upright.",
  },
  {
    letter: "T",
    word: "Through",
    doThis:
      "Defense finish: wrap, cheek to the ball, drive the legs. Block finish: hands inside, feet keep moving, drive through contact, whistle plus one. No wrap on a block.",
  },
] as const;

export type FastLetterCode = (typeof FAST)[number]["letter"];

export const FAST_LINE =
  "First step. Attack. Shoulder level. Through — wrap if you’re tackling, drive if you’re blocking.";

export const FAST_BOARD = FAST_LINE;

export const FAST_FINISH = [
  {
    role: "Defense finish",
    detail: "Wrap, cheek to the ball, drive the legs.",
  },
  {
    role: "Block finish",
    detail: "Hands inside, feet keep moving, drive through contact, whistle plus one. No wrap.",
  },
] as const;

export const FAST_COACH_RULE =
  "Volume is for safety, not the lesson. After a miss, restate one letter of FAST and run the next rep.";

export function fastWords(letters: readonly string[]): string {
  return letters
    .map((letter) => {
      const item = FAST.find((entry) => entry.letter === letter);
      return item ? `${item.letter} ${item.word}` : letter;
    })
    .join(" · ");
}
