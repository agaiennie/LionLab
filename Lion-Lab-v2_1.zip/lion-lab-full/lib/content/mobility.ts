export type Drill = {
  id: string;
  name: string;
  purpose: string;
  cue: string;
  steps: string[];
  dose: string;
  stop: string;
};

export const DRILLS: Drill[] = [
  {
    id: "fence-post",
    name: "Fence-Post Ankle",
    purpose: "Ankle control for the plant and the cut.",
    cue: "Knee over mid-foot.",
    steps: [
      "Stand on one foot beside a post. Fingertip touch only.",
      "Draw small circles with the free foot, then bend the standing ankle with the heel down.",
      "Switch feet.",
    ],
    dose: "7–8: 8 circles + 8 bends. 9–12: 10 circles + 8 bends.",
    stop: "Ankle pain after a recent roll, numbness, or an ATC hold.",
  },
  {
    id: "fence-lean",
    name: "Fence Lean",
    purpose: "Calf and ankle length in a standing lean.",
    cue: "Heel seeks dirt.",
    steps: [
      "Hands on a fence at chest height. Back leg straight, heel down.",
      "Lean the hips toward the fence until the calf speaks. Hold.",
      "Bend the back knee slightly, then switch legs.",
    ],
    dose: "7–8: 20 seconds a side. 9–12: 25 seconds, then one gentle rock.",
    stop: "Sharp Achilles pain or a fresh calf strain.",
  },
  {
    id: "rail-walk",
    name: "Rail Walk",
    purpose: "Balance and a quiet foot.",
    cue: "Eyes up field.",
    steps: [
      "Heel-to-toe on a line for 10 yards.",
      "Walk back on the outside edges of the feet, slow.",
      "Finish with short single-leg holds on the line.",
    ],
    dose: "7–8: arms at your sides. 9–12: add a head turn on the holds.",
    stop: "Acute sprain or dizziness. See the ATC.",
  },
  {
    id: "gate-hinge",
    name: "Gate Hinge",
    purpose: "Hip hinge that spares the low back.",
    cue: "Hips back, long spine.",
    steps: [
      "Soft knees. Push the hips back like you are closing a gate with your belt.",
      "Chest stays long. Hands slide down the thighs only as far as the back stays flat.",
      "Stand by driving the hips through.",
    ],
    dose: "7–8: 8 reps. 9–12: 10 reps.",
    stop: "Sharp low-back pain. Hinge smaller or stop.",
  },
  {
    id: "truck-hitch",
    name: "Truck Hitch",
    purpose: "Deeper hinge and hip drive.",
    cue: "Kiss the hitch. Don't crash.",
    steps: [
      "Hinge until the chest would touch a hitch height, spine long.",
      "Pause. Drive the hips forward to stand.",
      "No round back and no yank from the arms.",
    ],
    dose: "Off-day set: 6–8 slow reps after Gate Hinge.",
    stop: "Sharp back or hamstring pain.",
  },
  {
    id: "boot-lace",
    name: "Boot Lace Hinge",
    purpose: "Hamstring length from a hinge, not a curl.",
    cue: "Hinge, don't curl.",
    steps: [
      "One heel forward, toe up.",
      "Hinge the hips until the back of the thigh speaks. Hold.",
      "Switch sides. Keep the spine long.",
    ],
    dose: "7–8: 20 seconds. 9–12: 25 seconds, twice.",
    stop: "Sharp hamstring pain. Ease off.",
  },
  {
    id: "fence-line-lunge",
    name: "Fence-Line Lunge",
    purpose: "Hip flexor and groin open.",
    cue: "Tall post, gentle rocks.",
    steps: [
      "Half-kneeling beside a fence. Back knee down, front heel planted.",
      "Tuck the hips under until the front of the hip speaks. Stay tall.",
      "Small rocks only if the hold is easy.",
    ],
    dose: "7–8: 20-second hold plus 3 rocks. 9–12: 25 seconds plus 5 rocks.",
    stop: "Groin pinch or knee pain on the down knee. Pad the knee.",
  },
  {
    id: "corn-row",
    name: "Corn-Row Plant",
    purpose: "A clean cut plant.",
    cue: "Knee tracks toes.",
    steps: [
      "Jog or walk into a plant. Outside foot sticks, knee over the toes.",
      "Hip stays stacked. No knee collapse inside.",
      "Exit the plant on the next step.",
    ],
    dose: "7–8: jog plant ×5 a side. 9–12: ×6 a side.",
    stop: "Knee pain on the plant. Walk it or stop.",
  },
  {
    id: "mud-boot",
    name: "Mud-Boot Twist",
    purpose: "A controlled trunk turn.",
    cue: "Feet stay glued.",
    steps: [
      "Athletic base. Feet quiet.",
      "Turn the chest like you are looking downfield. Hips stay mostly square.",
      "Return slow. Switch sides.",
    ],
    dose: "LB / TE add-on: 6 a side.",
    stop: "Sharp back pain. Smaller turn.",
  },
  {
    id: "tractor-seat",
    name: "Tractor Seat Squat",
    purpose: "Squat track with heels down.",
    cue: "Knees track toes.",
    steps: [
      "Feet about shoulder width. Sit the hips between the heels.",
      "Knees stay over the toes. Heels stay down.",
      "Stand tall. No bounce at the bottom.",
    ],
    dose: "Off-day: 8 slow reps.",
    stop: "Knee pain that is more than work. Stop and tell a coach.",
  },
  {
    id: "wall-push",
    name: "Wall Push Stance",
    purpose: "Stance shape and the first step.",
    cue: "Push the wall. Don't shrug.",
    steps: [
      "Hands on a wall. Athletic stance, shin slightly forward.",
      "Push the wall for a few seconds without standing up.",
      "Step the front foot back under you, then reset.",
    ],
    dose: "7–8: 5 holds × 5 seconds plus 2 first steps. 9–12: 6 × 5 seconds plus 3 first steps.",
    stop: "Shoulder pain into the wall. Ease the lean.",
  },
  {
    id: "post-drive",
    name: "Post Drive",
    purpose: "Drive-block hip finish.",
    cue: "Hips through, pad steady.",
    steps: [
      "Staggered stance. Hands fit an imaginary post.",
      "Short steps. Hips finish forward. Chest stays down enough to drive.",
      "Stop on balance. Reset.",
    ],
    dose: "OL / DL add-on: 4 finishes.",
    stop: "Neck pain. No yanking the neck to finish.",
  },
  {
    id: "shed-hand",
    name: "Shed-Hand Press",
    purpose: "Hand fight and shoulder-blade set.",
    cue: "Blades in the back pockets.",
    steps: [
      "Stand tall. Press the hands forward like you are shedding a blocker's hands.",
      "Shoulder blades pull down and back.",
      "Return slow. Do not shrug.",
    ],
    dose: "OL / DL add-on: 1 set of 8.",
    stop: "Sharp shoulder or AC pain. Smaller range.",
  },
  {
    id: "gate-latch",
    name: "Gate Latch Reach",
    purpose: "Open the chest without yanking the arm.",
    cue: "Open the chest. Don't yank the arm.",
    steps: [
      "Hand on a post at shoulder height.",
      "Turn the chest away until the front of the shoulder speaks.",
      "Hold. Switch arms.",
    ],
    dose: "7–8: 20 seconds. 9–12: 20 seconds, twice.",
    stop: "Pinch at the tip of the shoulder. Stop.",
  },
  {
    id: "silo-reach",
    name: "Silo Reach",
    purpose: "Overhead reach with quiet ribs.",
    cue: "Reach tall, ribs down.",
    steps: [
      "Reach both hands up like you are touching a silo.",
      "Ribs stay down. Don't flare the low back.",
      "Hold, then one arm at a time for older bands.",
    ],
    dose: "7–8: 5 holds. 9–12: 6 holds plus one arm.",
    stop: "Shoulder pinch overhead. Lower the reach.",
  },
  {
    id: "pass-slot",
    name: "Pass-Slot Shoulder",
    purpose: "Throw-path control.",
    cue: "Elbow glued to the rib.",
    steps: [
      "Throwing elbow stays close on the slot.",
      "Turn the chest, then the arm. Feet stay in an athletic base.",
      "No flying elbow.",
    ],
    dose: "QB add-on: 8–10 slow slots.",
    stop: "Sharp shoulder pain. Stop the set.",
  },
  {
    id: "grain-sack",
    name: "Grain-Sack Carry",
    purpose: "Loaded upright posture.",
    cue: "Don't lean the sack.",
    steps: [
      "Hold a light bag or a med ball at the chest or side.",
      "Walk tall. Ribs down. Eyes up.",
      "Set it down with a hinge, not a round back.",
    ],
    dose: "7–8: light load 15 yards. 9–12: 20 yards, twice.",
    stop: "Back pain under the load. Drop the weight.",
  },
  {
    id: "hay-bale",
    name: "Hay-Bale Brace",
    purpose: "Anti-rotation brace.",
    cue: "Win with belly and glutes.",
    steps: [
      "Athletic stance. A partner or band pushes you off square.",
      "Hips and shoulders stay level. Don't twist to win.",
      "Hold, then switch sides.",
    ],
    dose: "7–8: light band 4 × 8 seconds. 9–12: band plus a step, 4 × 8 seconds.",
    stop: "Sharp back pain. Lighter push.",
  },
  {
    id: "tackle-posture",
    name: "Tackle Posture Brace",
    purpose: "Tackle shape with no live shot.",
    cue: "Hips loaded, neck long.",
    steps: [
      "Hinge into a tackle fit. Head up, neck long.",
      "Arms wrap an imaginary ball. Feet alive.",
      "Hold. No collision.",
    ],
    dose: "After heavy contact, 4 form fits if necks are clear.",
    stop: "Stinger, numbness, neck pain, or dizziness. Stop and get the ATC.",
  },
  {
    id: "bleacher-step",
    name: "Bleacher Step-Up",
    purpose: "Single-leg strength.",
    cue: "Whole foot, slow lower.",
    steps: [
      "Whole foot on a bleacher. Drive up through the heel and mid-foot.",
      "Lower slow. Knee tracks toes.",
      "Switch legs.",
    ],
    dose: "Off-day: 6 a leg.",
    stop: "Knee pain on the way down. Lower the step.",
  },
  {
    id: "get-up-gate",
    name: "Get-Up Gate",
    purpose: "A safe rise back to stance.",
    cue: "Eyes to the field. Stand through the hips.",
    steps: [
      "From a knee, step the front foot through.",
      "Hips drive you up. No hand on the neck.",
      "Finish in an athletic stance, eyes up.",
    ],
    dose: "7–8: 4 a side. 9–12: 5 a side.",
    stop: "Dizziness on the way up. Stay down and tell a coach.",
  },
  {
    id: "barn-door",
    name: "Barn Door Open",
    purpose: "Mid-back turn, standing.",
    cue: "The door opens at the ribs.",
    steps: [
      "Athletic base or half-kneeling.",
      "Open the chest like a barn door. Hips stay quiet.",
      "Return. Switch sides.",
    ],
    dose: "7–8: 8 a side. 9–12: 8 a side, half-kneeling is fine.",
    stop: "Sharp mid-back pain. Smaller open.",
  },
];

const byId = new Map(DRILLS.map((drill) => [drill.id, drill]));

export function drillById(id: string): Drill | undefined {
  return byId.get(id);
}

export const PRE_IDS = [
  "fence-lean",
  "fence-post",
  "gate-hinge",
  "fence-line-lunge",
  "barn-door",
  "wall-push",
  "corn-row",
  "hay-bale",
];

export const PRE_SHORT_IDS = ["fence-lean", "gate-hinge", "wall-push", "corn-row"];

export const POST_IDS = ["boot-lace", "gate-latch", "silo-reach", "get-up-gate", "grain-sack"];

export const OFF_DAY_IDS = [
  "fence-lean",
  "gate-hinge",
  "truck-hitch",
  "tractor-seat",
  "bleacher-step",
  "shed-hand",
  "hay-bale",
  "grain-sack",
  "boot-lace",
];

export function sessionTemplate(day = new Date()): {
  id: string;
  title: string;
  minutes: string;
  drillIds: string[];
} {
  const weekday = day.getDay();
  if (weekday === 0 || weekday === 6) {
    return { id: "off", title: "Off-day session", minutes: "12 min", drillIds: OFF_DAY_IDS };
  }
  if (weekday === 5) {
    return { id: "game", title: "Game-day pre", minutes: "5 min", drillIds: PRE_SHORT_IDS };
  }
  if (weekday === 2 || weekday === 4) {
    return { id: "short", title: "Short pre", minutes: "5–6 min", drillIds: PRE_SHORT_IDS };
  }
  return { id: "pre", title: "Pre-practice", minutes: "8–10 min", drillIds: PRE_IDS };
}

export const POSITION_ADDONS: { positions: string[]; drillIds: string[] }[] = [
  { positions: ["OL", "DL"], drillIds: ["post-drive", "shed-hand"] },
  { positions: ["LB", "TE"], drillIds: ["mud-boot", "tackle-posture"] },
  { positions: ["WR", "DB", "RB", "ATH"], drillIds: ["corn-row", "rail-walk"] },
  { positions: ["QB"], drillIds: ["pass-slot", "barn-door"] },
];
