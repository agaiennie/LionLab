import { latestByType, type AthleteRecord } from "@/lib/data";
import { positionLabel } from "@/lib/scoring";

export type FitNotes = {
  position: string;
  basis: string[];
  strengths: string[];
  gaps: string[];
  drills: { name: string; why: string }[];
};

function fortyTarget(grade: number): number {
  if (grade >= 11) return 5.2;
  if (grade >= 9) return 5.45;
  return 5.7;
}

function medballTarget(grade: number): number {
  if (grade >= 11) return 30;
  if (grade >= 9) return 24;
  return 18;
}

export function fitNotes(athlete: AthleteRecord): FitNotes {
  const primary = athlete.positions[0] ?? "ATH";
  const secondary = athlete.positions[1];
  const forty = latestByType(athlete, "FORTY");
  const med = latestByType(athlete, "MEDBALL");
  const stance = latestByType(athlete, "STANCE");
  const speedJob = ["WR", "DB", "RB", "ATH", "QB", "K"].includes(primary);
  const powerJob = ["OL", "DL", "LB", "TE"].includes(primary);

  const strengths: string[] = [];
  const gaps: string[] = [];
  const drills: { name: string; why: string }[] = [];
  const basis: string[] = [
    `Primary job: ${positionLabel(primary)}${secondary ? `. Secondary: ${positionLabel(secondary)}.` : "."}`,
    `Grade-band targets for this note: 40 adjusted ESTIMATE at or under ${fortyTarget(athlete.grade).toFixed(2)}s, med ball at or over ${medballTarget(athlete.grade).toFixed(0)} ft. These are coaching bands, not a depth chart.`,
  ];

  if (!forty && !med && !stance) {
    return {
      position: positionLabel(primary),
      basis,
      strengths: [],
      gaps: ["No battery yet. Log a 40, a med ball, and a stance before the fit note means anything."],
      drills: [
        { name: "Wall Push Stance", why: "Build the first step while you wait on a timed 40." },
        { name: "Gate Hinge", why: "Learn the hip hinge that shows up in the stance checklist." },
      ],
    };
  }

  if (forty?.scored.estimate.value != null) {
    const estimate = forty.scored.estimate.value;
    const target = fortyTarget(athlete.grade);
    basis.push(
      `Latest 40: raw ${forty.scored.rawLabel}, form ${forty.scored.percent}%, adjusted ESTIMATE ${forty.scored.estimate.display}.`,
    );
    if (estimate <= target && forty.scored.percent >= 70) {
      strengths.push(
        speedJob
          ? "Speed job is in range, and the form index is high enough to trust the clock."
          : "The 40 is inside the grade band. Use it. Do not let it replace the power work.",
      );
    } else if (forty.scored.percent < 70) {
      gaps.push("The clock is ahead of the form. Clean the missed 40 cues before you chase a faster raw time.");
      drills.push({ name: "Wall Push Stance", why: "First step and shin angle, the usual leak on a sloppy 40." });
      drills.push({ name: "Gate Hinge", why: "Hips back so the start is loaded instead of stood up." });
    } else {
      gaps.push(`Adjusted ESTIMATE is ${forty.scored.estimate.display}, slower than the ${target.toFixed(2)}s band for this grade.`);
      drills.push({ name: "Fence-Post Ankle", why: "Stack the plant so the steps after the start stay under you." });
    }
  } else if (speedJob) {
    gaps.push("No 40 on file. A speed job needs a clock, not a guess.");
  }

  if (med?.rawValue != null) {
    const target = medballTarget(athlete.grade);
    basis.push(
      `Latest med ball: raw ${med.scored.rawLabel}, form ${med.scored.percent}%, adjusted ESTIMATE ${med.scored.estimate.display}.`,
    );
    if (med.rawValue >= target && med.scored.percent >= 70) {
      strengths.push(
        powerJob
          ? "Power job shows up in the throw, and the sequence was mostly clean."
          : "The throw is strong for this grade. Keep the hip load so it stays a football throw.",
      );
    } else if (med.scored.percent < 80) {
      gaps.push("The tape is ahead of the throw sequence. Earn the distance with hips, then torso, then arms.");
      drills.push({ name: "Hay-Bale Brace", why: "Brace so the trunk does not spin early." });
    } else {
      gaps.push(`Med ball ${med.rawValue.toFixed(1)} ft is under the ${target} ft band for this grade.`);
      drills.push({ name: "Post Drive", why: "Hips finish forward, the same pattern as a clean throw." });
    }
  } else if (powerJob) {
    gaps.push("No med ball on file. A power job needs a tape measure.");
  }

  if (stance) {
    basis.push(`Latest stance: ${stance.scored.percent}% · ${stance.scored.estimate.display}.`);
    if (stance.scored.percent >= 80) {
      strengths.push("Stance checklist is game-ready. Hold it when you are tired.");
    } else {
      gaps.push(`Stance is ${stance.scored.estimate.display}. The base is the job before the play starts.`);
      drills.push({ name: "Wall Push Stance", why: "Feet, knees, and chest in the shape you need on the snap." });
    }
  }

  if (drills.length < 2) {
    drills.push({ name: "Corn-Row Plant", why: "Knee tracks toes on the cut, whichever position you declared." });
  }
  if (primary === "QB" && !drills.some((drill) => drill.name.includes("Pass"))) {
    drills.push({ name: "Pass-Slot Shoulder", why: "Elbow stays on the rib so the throw does not fly open." });
  }

  return {
    position: positionLabel(primary),
    basis,
    strengths,
    gaps,
    drills: drills.slice(0, 3),
  };
}
