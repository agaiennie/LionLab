// Fuel guide for a junior-high football program. Food first, habits over numbers.
// Guidance, not medical advice. Based on mainstream youth sports nutrition
// (AAP, USDA MyPlate, AASM sleep ranges). No calorie targets, no weight goals,
// no supplements. If a family wants to change weight, that is a conversation
// for the pediatrician or a registered dietitian — not this app.

export const FUEL_DISCLAIMER =
  "Guidance, not medical advice. Food first. If your athlete has a health condition, a food allergy, or you want to change their weight, talk to your pediatrician or a registered dietitian.";

export type FuelItem = { title: string; detail: string };
export type TimelineStep = { when: string; what: string; examples: string[]; cheap?: string };

export type FuelSection = {
  id: "plate" | "school-day" | "game-day" | "water-sleep" | "cheap" | "red-flags" | "parents";
  label: string;
};

export const FUEL_SECTIONS: FuelSection[] = [
  { id: "plate", label: "Plate" },
  { id: "school-day", label: "School day" },
  { id: "game-day", label: "Game day" },
  { id: "water-sleep", label: "Water & sleep" },
  { id: "cheap", label: "Cheap staples" },
  { id: "red-flags", label: "Red flags" },
  { id: "parents", label: "For parents" },
];

/** The daily plate. Same plate for every position. */
export const PLATE = {
  line: "Same plate for everybody. More practice means more of the same plate, not a different plate.",
  parts: [
    {
      title: "Half the plate: fruits and vegetables",
      detail: "Any kind counts: fresh, frozen, or canned (rinse canned veg, pick fruit in juice or water). Color is the goal.",
    },
    {
      title: "A quarter: lean protein",
      detail: "Eggs, chicken, turkey, canned tuna, beans, peanut butter, lean ground beef, pork. A palm-sized piece is a good look.",
    },
    {
      title: "A quarter: grains, mostly whole",
      detail: "Rice, oats, whole-wheat bread or tortillas, pasta, potatoes. This is the fuel for practice. Don't skip it.",
    },
    {
      title: "On the side: dairy or calcium",
      detail: "Milk, yogurt, cheese, or fortified soy milk. Growing bones need it every day.",
    },
  ] satisfies FuelItem[],
  rhythm: [
    "Three meals and one or two snacks. Every day, not just game days.",
    "Breakfast is not optional. School breakfast counts.",
    "Eat until you are satisfied. Listen to hunger — growing athletes are hungry, and that is normal.",
    "No food is 'bad.' Some foods are everyday foods and some are sometimes foods.",
  ],
};

/** A normal school and practice day. */
export const SCHOOL_DAY: TimelineStep[] = [
  {
    when: "Breakfast (before school)",
    what: "Grain + protein + fruit. Something is always better than nothing.",
    examples: [
      "Oatmeal with peanut butter and a banana, glass of milk",
      "Two scrambled eggs on toast, orange juice or an apple",
      "School breakfast: take the milk and the fruit too",
    ],
    cheap: "Oats + peanut butter + banana is one of the cheapest good breakfasts there is.",
  },
  {
    when: "School lunch",
    what: "Take the full tray: main, fruit, vegetable, milk.",
    examples: [
      "School lunch with the milk and both sides",
      "From home: turkey or PB&J sandwich, fruit, carrots, milk or water",
    ],
    cheap: "Ask the school office about free or reduced-price meals. The form is short and private.",
  },
  {
    when: "Pre-practice snack (30–60 minutes before)",
    what: "Small and easy: mostly carbs, a little protein, not greasy.",
    examples: [
      "Banana or an apple",
      "Granola bar or a handful of crackers",
      "Half a PB sandwich",
      "Cereal and milk if practice is later",
    ],
    cheap: "A banana costs about a quarter and does the job.",
  },
  {
    when: "Water during practice",
    what: "Drink at every water break, even if you are not thirsty.",
    examples: ["Bring a full bottle and refill it", "Sports drink only for long, hot, sweaty practices"],
  },
  {
    when: "Post-practice (within about an hour)",
    what: "Carbs + protein to refuel and rebuild.",
    examples: [
      "Chocolate milk",
      "Turkey or tuna sandwich",
      "Yogurt and fruit",
      "Peanut butter on toast and a glass of milk",
    ],
    cheap: "Chocolate milk is one of the best and cheapest recovery drinks around.",
  },
  {
    when: "Dinner",
    what: "The plate: half fruits/veg, quarter protein, quarter grains, plus milk.",
    examples: [
      "Rice and beans with chicken and frozen mixed veg",
      "Spaghetti with meat sauce, green beans, milk",
      "Eggs, potatoes, and peppers (breakfast for dinner counts)",
    ],
  },
];

/** Game day. Nothing new on game day. */
export const GAME_DAY = {
  line: "Nothing new on game day. Eat foods you already know sit well.",
  steps: [
    {
      when: "Night before",
      what: "Normal dinner with extra grains. Water with it. Lights out on time.",
      examples: ["Pasta with meat sauce, salad, milk", "Rice, chicken, veg"],
    },
    {
      when: "Game-day breakfast",
      what: "Normal breakfast. Don't skip it because of nerves — eat something small if the stomach is tight.",
      examples: ["Eggs and toast", "Oatmeal and a banana", "Cereal and milk"],
    },
    {
      when: "Pre-game meal (2–3 hours before)",
      what: "A real meal: grains, some lean protein, low grease, low fiber.",
      examples: ["Turkey sandwich and fruit", "Rice and chicken", "Pasta with a little sauce"],
      cheap: "A PB&J, a banana, and water is a perfectly good pre-game meal.",
    },
    {
      when: "Top-off (30–60 minutes before)",
      what: "Small carb snack and water.",
      examples: ["Banana", "Pretzels or crackers", "Applesauce pouch"],
    },
    {
      when: "Halftime",
      what: "Water. A few orange slices or a sports drink if it's hot.",
      examples: ["Water", "Orange slices"],
    },
    {
      when: "After the game (within about an hour)",
      what: "Carbs + protein, then a normal dinner.",
      examples: ["Chocolate milk", "Sandwich and fruit", "Leftover rice and beans"],
    },
  ] satisfies TimelineStep[],
  avoid: [
    "Energy drinks — not recommended for kids or teens (AAP). They are not sports drinks.",
    "Big greasy fast-food meal right before kickoff.",
    "Trying a new food, bar, or drink for the first time on game day.",
  ],
};

/** Urine color check. Simple words, no chart images needed. */
export const URINE_GUIDE: { color: string; meaning: string; tone: "good" | "ok" | "warn" }[] = [
  { color: "Pale yellow, like lemonade", meaning: "Good. Keep doing what you're doing.", tone: "good" },
  { color: "Yellow, like regular juice", meaning: "Drink a bottle of water in the next hour.", tone: "ok" },
  { color: "Dark yellow or amber, like apple juice", meaning: "You are behind. Drink now and tell a coach before practice.", tone: "warn" },
];

export const HYDRATION = {
  line: "Thirst is late. Drink before you need it.",
  rules: [
    "Before: a bottle of water in the 2 hours before practice.",
    "During: drink at every break, even if you are not thirsty.",
    "After: drink water with your recovery snack and at dinner.",
    "Water is the main drink. Milk counts. Sports drinks are for long, hot, sweaty sessions — not all day.",
    "No energy drinks. The AAP says kids and teens should not have them.",
  ],
};

export const SLEEP = {
  line: "Sleep is when the body builds what practice broke down.",
  ranges: [
    { ages: "Ages 6–12", hours: "9–12 hours a night" },
    { ages: "Teens 13–18", hours: "8–10 hours a night" },
  ],
  source: "Ranges from the American Academy of Sleep Medicine (AASM).",
  tips: [
    "Same lights-out most nights, weekends too.",
    "Phone charges outside the bedroom.",
    "No caffeine in the afternoon or evening.",
    "A short night shows up in the first step and on the test.",
  ],
};

export const HEAT_WARNING = {
  title: "Heat illness — stop and tell a coach or ATC right away",
  signs: [
    "Dizziness or feeling faint",
    "Headache or nausea / throwing up",
    "Very tired, weak, or cramping",
    "Confusion or acting strange",
    "Hot skin that stops sweating",
  ],
  action: "Get to shade, cool down, and get an adult. Confusion or passing out is a 911 call.",
};

/** Budget staples. Rural-PA grocery friendly. */
export const CHEAP_STAPLES: FuelItem[] = [
  { title: "Eggs", detail: "Protein for breakfast or dinner. Scramble, boil, fry." },
  { title: "Peanut butter", detail: "Protein and energy. Toast, oatmeal, bananas, apples, sandwiches." },
  { title: "Milk (white or chocolate)", detail: "Calcium, protein, and a top recovery drink." },
  { title: "Bananas", detail: "The pre-practice snack. Cheap and easy to carry." },
  { title: "Rice", detail: "Cheap fuel. Cook a big pot, eat it all week." },
  { title: "Dry or canned beans", detail: "Protein and fiber. Rinse canned beans." },
  { title: "Canned tuna or chicken", detail: "Shelf-stable protein for sandwiches and rice bowls." },
  { title: "Oats", detail: "Breakfast for pennies. Add peanut butter and fruit." },
  { title: "Frozen vegetables", detail: "As healthy as fresh, lasts longer, no waste." },
  { title: "Potatoes", detail: "Filling fuel. Bake, boil, or mash." },
  { title: "Whole-wheat bread or tortillas", detail: "Sandwiches, wraps, toast." },
  { title: "Apples and oranges", detail: "Keep well. Good for lunches and halftime." },
  { title: "Yogurt", detail: "Buy the big tub, not single cups." },
];

export const CHEAP_VERSION = {
  title: "Can't afford it? Here's the cheap version",
  lines: [
    "Breakfast: oats + peanut butter + banana.",
    "Pre-practice: a banana or a slice of bread with peanut butter.",
    "Post-practice: chocolate milk.",
    "Dinner: rice + beans or eggs + frozen veg + milk.",
    "Take school breakfast and lunch every day — it is free or reduced for many families.",
  ],
  schoolMeals:
    "Ask the school office or cafeteria about free or reduced-price meals. The form is private, and many families qualify. Local food pantries can help the whole household too.",
};

/** Tell a parent, coach, or ATC. */
export const RED_FLAGS: string[] = [
  "Dizziness or lightheaded at practice or at home",
  "Cramps that come with confusion, headache, or throwing up",
  "Fainting or almost fainting",
  "Skipping meals, not eating, or saying they're 'not hungry' day after day",
  "A sudden weight change — up or down — that nobody planned",
  "Dark urine even after drinking",
  "Always tired, even after a full night's sleep",
];

export const RED_FLAG_LINE =
  "If you see any of these, tell a parent, a coach, or the athletic trainer (ATC). You are not in trouble. We want to help.";

/** Position notes are about workload, never about changing body size. */
export const POSITION_FUEL: { group: string; positions: string[]; notes: string[] }[] = [
  {
    group: "Linemen",
    positions: ["OL", "DL", "TE"],
    notes: [
      "Heavy work in the trenches burns a lot. Steady meals — three meals and snacks — keep the tank full.",
      "Don't skip breakfast. Linemen who skip it fade in the fourth quarter.",
      "Same plate as everyone. More work means more of the same good food, not junk.",
    ],
  },
  {
    group: "Skill players",
    positions: ["QB", "RB", "WR", "DB", "ATH", "K"],
    notes: [
      "Lots of running means lots of sweat. Hydration is the first job.",
      "Never practice empty — the pre-practice snack keeps your legs fresh for the last rep.",
      "Same plate as everyone.",
    ],
  },
  {
    group: "Linebackers",
    positions: ["LB"],
    notes: [
      "You run and you hit. Steady meals and water both matter.",
      "Pre-practice snack plus a real post-practice recovery snack.",
      "Same plate as everyone.",
    ],
  },
];

export function positionFuel(code: string | undefined) {
  return POSITION_FUEL.find((row) => row.positions.includes(code ?? "")) ?? POSITION_FUEL[1];
}

export const EVERYONE_LINE =
  "Everyone: same plate, water all day, a snack before practice, a recovery snack after, and 8–10 hours of sleep.";

export const FOR_PARENTS = {
  title: "For parents",
  lines: [
    "You don't need special food. Regular meals, a snack before practice, and chocolate milk after covers most of it.",
    "We never set calorie targets or weight goals for players. Please don't put your athlete on a diet to 'make weight' or 'bulk up.'",
    "If you're thinking about your child's weight, talk to your pediatrician or a registered dietitian first. They can look at growth charts and the whole picture.",
    "Supplements (protein powder, creatine, pre-workout) are not recommended for this age by our program. Food first. Ask your doctor before any supplement.",
    "No energy drinks. The American Academy of Pediatrics says kids and teens should not have them.",
    "Help with sleep: a set lights-out time and phones out of the bedroom make a real difference.",
    "Money tight? Ask the school about free or reduced-price meals, and use the cheap staples list. Good fuel does not have to cost more.",
    "Watch for the red flags above and tell a coach or the ATC. We would rather hear about it early.",
  ],
  bodyTalk:
    "Talk about what food does (energy, recovery, growing strong) — not about how a body looks. No nicknames or jokes about size.",
};
