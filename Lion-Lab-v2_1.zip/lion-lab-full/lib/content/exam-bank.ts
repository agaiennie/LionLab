// Starter exams for leadership roles. Head coach rule: captains, quarterback,
// and middle linebacker take an exam on plays and reads. Football IQ counts.
//
// These are GENERIC. They teach concepts every playbook shares. The coach adds
// his own plays in the editor (/coach/exams). Seeding only creates exams that
// are missing, so coach edits are never overwritten.
//
// Slugs are read by the position-fit engine (lib/fit-data.ts). Do not rename.

export const EXAM_BANK_VERSION = "2026-09-29.1";

export type ExamAudience = "QB" | "MLB" | "CAPTAIN" | "ALL";

export const EXAM_AUDIENCES: { code: ExamAudience; label: string }[] = [
  { code: "QB", label: "Quarterbacks" },
  { code: "MLB", label: "Middle linebackers" },
  { code: "CAPTAIN", label: "Captains" },
  { code: "ALL", label: "Everyone" },
];

export type BankQuestion = {
  topic: string;
  prompt: string;
  choices: string[];
  answerIndex: number;
  explanation: string;
};

export type BankExam = {
  slug: string;
  title: string;
  audience: ExamAudience;
  description: string;
  passPercent: number;
  questions: BankQuestion[];
};

type Draft = {
  topic: string;
  prompt: string;
  correct: string;
  wrong: string[];
  explanation: string;
};

// Authors write the right answer once, plus the wrong ones. The right answer is
// placed at a rotating spot so the key is not "always B".
function build(drafts: Draft[]): BankQuestion[] {
  return drafts.map((draft, i) => {
    const n = draft.wrong.length + 1;
    const at = (i * 5 + 2) % n;
    const choices = [...draft.wrong];
    choices.splice(at, 0, draft.correct);
    return {
      topic: draft.topic,
      prompt: draft.prompt,
      choices,
      answerIndex: at,
      explanation: draft.explanation,
    };
  });
}

const QB: Draft[] = [
  {
    topic: "Coverage",
    prompt: "Before the snap you see ONE safety deep in the middle of the field. What is the defense most likely playing?",
    correct: "Cover 1 or Cover 3",
    wrong: ["Cover 2 or Cover 4", "Cover 0", "It tells you nothing"],
    explanation:
      "One high safety means the deep middle is closed. That is usually Cover 1 (man with a free safety) or Cover 3 (three deep zones).",
  },
  {
    topic: "Coverage",
    prompt: "You see TWO safeties deep, one over each hash. What is the defense most likely playing?",
    correct: "Cover 2 or Cover 4",
    wrong: ["Cover 0", "Cover 1 or Cover 3", "A goal-line defense"],
    explanation:
      "Two high safeties split the deep field. That is usually Cover 2 (two deep halves) or Cover 4 (four deep quarters).",
  },
  {
    topic: "Coverage",
    prompt: "You see NO safeties deep. Everybody is walked up near the line. What should you be thinking?",
    correct: "Blitz is likely. Know your hot route and get the ball out quick.",
    wrong: [
      "Take a deep drop and wait for the long route to open",
      "It is Cover 2, so throw the corner route",
      "Hold the ball and scramble every time",
    ],
    explanation:
      "Zero high is Cover 0: man coverage with no deep help, and extra rushers coming. The ball has to come out fast. One missed tackle by them can be a touchdown for us.",
  },
  {
    topic: "Beat Cover 2",
    prompt: "Against Cover 2, where is a common open spot (a hole)?",
    correct: "Deep along the sideline, between the corner and the safety",
    wrong: [
      "Straight at the corner in the flat",
      "Short, right behind the defensive line",
      "Nowhere. Cover 2 has no holes.",
    ],
    explanation:
      "Cover 2 corners sit shallow in the flat and each safety has a deep half. A route up the sideline behind the corner and in front of the safety hits the hole. The deep middle seam between the two safeties is the other soft spot.",
  },
  {
    topic: "Beat Cover 2",
    prompt: "Against Cover 2, why can a route straight up the MIDDLE of the field get open?",
    correct: "Each safety has a deep half, so the deep middle is split between them",
    wrong: [
      "The middle linebacker always blitzes in Cover 2",
      "Cover 2 has three deep defenders",
      "The corners cover the deep middle",
    ],
    explanation:
      "Two safeties each own half the field. A seam or post splits them. Some Cover 2 teams run the middle linebacker deep to help, so read him too.",
  },
  {
    topic: "Beat Cover 3",
    prompt: "Cover 3 has three deep defenders and four underneath. Which throws usually attack it best?",
    correct: "Quick throws to the flat, and curls or seams between the underneath defenders",
    wrong: [
      "Deep over the top of the free safety",
      "Right at the corner who is bailing deep",
      "None. Always run the ball against Cover 3.",
    ],
    explanation:
      "Three deep defenders leave space underneath. The flats and the curl/seam windows are open for a quick, on-time throw. Four vertical routes can also stretch three deep defenders.",
  },
  {
    topic: "Count the box",
    prompt: "Before the snap you count 7 defenders in the box and you have only 6 blockers. What does that tell you?",
    correct: "They have an extra man to stop the run. Look to throw, or check to a better play if your coach allows it.",
    wrong: [
      "The run is a great call here",
      "The defense is in Cover 2",
      "Nothing. Run it anyway.",
    ],
    explanation:
      "If they have more defenders in the box than we have blockers, one run defender goes unblocked. Numbers win. Take the numbers game to where we have the advantage.",
  },
  {
    topic: "Hot routes",
    prompt: "A linebacker blitzes and there are more rushers than blockers. What is the hot throw?",
    correct: "A quick throw to the receiver running into the spot the blitzer just left",
    wrong: [
      "A throw to the deepest receiver",
      "A throw after you scramble out of the pocket",
      "A pitch to the running back behind you",
    ],
    explanation:
      "The unblocked rusher gets to you fast. The blitzer left a hole in the coverage. Hot receiver and QB both see it and the ball comes out right now.",
  },
  {
    topic: "Cadence",
    prompt: "Why do we use a snap count, like \"Set, hut\"?",
    correct: "The offense moves together, and we know when the ball is snapped and the defense does not",
    wrong: [
      "The rules require the word \"hut\"",
      "It gives the defense time to line up",
      "It is only for show",
    ],
    explanation:
      "The snap count is our head start. Eleven players move on the same sound. Change it up and the defense cannot time it.",
  },
  {
    topic: "Cadence",
    prompt: "During the cadence, what is YOUR job so the line does not move early?",
    correct: "Stay still and use a clear, steady voice. A sudden jerk can pull a lineman early for a false start.",
    wrong: [
      "Bob your head hard on every word",
      "Look back at the sideline during the count",
      "Get louder and faster when the defense shifts",
    ],
    explanation:
      "Once linemen are set, any movement before the snap is a false start. A jerky head or shoulder fake from the QB can draw it. Same voice, same body, every time.",
  },
  {
    topic: "Ball security",
    prompt: "You are in the pocket and defenders are closing in around you. How do you hold the ball?",
    correct: "Two hands on the ball, tight and high to your chest",
    wrong: [
      "One hand, held away from your body so you are ready to throw",
      "Loose, out in front of you",
      "Down at your hip",
    ],
    explanation:
      "Two hands in traffic. Most QB fumbles come from a one-hand ball getting hit from behind. The ball is the season.",
  },
  {
    topic: "Mesh",
    prompt: "On a handoff, how does the QB give the ball to the running back?",
    correct: "Place it firmly into the back's pocket at his belly, with your eyes on the pocket",
    wrong: [
      "Toss it to him from a few yards away",
      "Hold it out and let him grab it",
      "Put it up at his chest and let go early",
    ],
    explanation:
      "The back makes a pocket with his arms. The QB looks the ball in and places it there. Eyes on the target until the ball is his.",
  },
  {
    topic: "Throw it away",
    prompt: "Nothing is open and pressure is coming. What matters most?",
    correct: "Do not turn it over. A sack or a safe throw-away is better than an interception or fumble.",
    wrong: [
      "Make a big play no matter what",
      "Throw it up for grabs into a crowd",
      "Spin backward with the ball in one hand to buy time",
    ],
    explanation:
      "Punting is not losing. A turnover gives them the ball and the field. Live for the next down.",
  },
  {
    topic: "Grounding",
    prompt: "A QB in the pocket throws the ball on purpose to a spot with no eligible receiver near it, just to avoid a sack. What is that called?",
    correct: "Intentional grounding",
    wrong: ["Pass interference", "A spike", "Delay of game"],
    explanation:
      "Intentional grounding is a penalty with loss of down. A legal throw-away goes near an eligible receiver or out of bounds the way your rule book allows. Rules for throwing it away after leaving the pocket differ by level. Learn your league's rule from your coach.",
  },
  {
    topic: "Third down",
    prompt: "It is 3rd and 6. Where should your eyes and the throw go?",
    correct: "To a receiver past the sticks (the line to gain)",
    wrong: [
      "Any open receiver, even 2 yards downfield",
      "Always the deepest route on the play",
      "Always the running back in the flat",
    ],
    explanation:
      "On third down, a catch short of the sticks usually means a punt. Know the line to gain before the snap. Throw to the route that gets past it.",
  },
  {
    topic: "Clock",
    prompt: "You are behind with 40 seconds left and no timeouts. Which throws help save the clock?",
    correct: "Throws toward the sideline, so the receiver can get out of bounds",
    wrong: [
      "Throws over the middle, where he gets tackled in bounds",
      "Handoffs up the middle",
      "Taking a knee",
    ],
    explanation:
      "Out of bounds stops the clock. A tackle in bounds keeps it running. When the clock matters, work the sideline.",
  },
  {
    topic: "Clock",
    prompt: "The clock is running, you have no timeouts, and you need to stop it. What can the QB do, if your league and coach allow it?",
    correct: "Spike the ball into the ground right after the snap",
    wrong: ["Fake an injury", "Run a sweep to the middle of the field", "Take a knee"],
    explanation:
      "The spike costs a down but stops the clock. Everyone must get set first. Practice it so it takes seconds, not a scramble. Faking an injury is cheating. We never do it.",
  },
  {
    topic: "Huddle",
    prompt: "In the huddle, what does a good QB do?",
    correct: "Calls the play clearly and once, with the formation and snap count, then breaks on time",
    wrong: [
      "Lets everyone talk so every idea is heard",
      "Whispers so quietly the line has to ask again",
      "Changes the play the coach sent in",
    ],
    explanation:
      "The huddle is the QB's room. One voice, clear words, eyes up. Ten players are counting on hearing it right the first time.",
  },
  {
    topic: "Pre-snap",
    prompt: "Which is a good pre-snap checklist for a QB?",
    correct: "Down and distance, their personnel, how many safeties are high, and the leverage on your receivers",
    wrong: [
      "Crowd noise, the weather, and the scoreboard of other games",
      "Only the one receiver you want to throw to",
      "Nothing. Snap it as fast as you can every time.",
    ],
    explanation:
      "Down and distance tells you what you need. Personnel and safeties tell you the coverage. Leverage tells you which way your receiver will be open.",
  },
  {
    topic: "Leverage",
    prompt: "The defender on your receiver lines up on the receiver's INSIDE shoulder. What is he trying to take away?",
    correct: "Routes breaking to the inside, like a slant or a dig",
    wrong: ["Routes breaking to the outside", "Only deep routes", "Nothing. Leverage does not matter."],
    explanation:
      "A defender protects the side he lines up on. Inside leverage takes away inside breaks. Throw away from leverage: here, the outside route.",
  },
];

const MLB: Draft[] = [
  {
    topic: "Gaps",
    prompt: "Which gap is between the center and the guard?",
    correct: "A gap",
    wrong: ["B gap", "C gap", "D gap"],
    explanation: "Gaps are lettered from the ball out. A gap: center to guard, on each side.",
  },
  {
    topic: "Gaps",
    prompt: "Which gap is between the guard and the tackle?",
    correct: "B gap",
    wrong: ["A gap", "C gap", "D gap"],
    explanation: "B gap: guard to tackle, on each side.",
  },
  {
    topic: "Gaps",
    prompt: "Where is the C gap?",
    correct: "Just outside the tackle (between the tackle and the tight end, if there is one)",
    wrong: ["Between the center and the guard", "Between the two guards", "Deep behind the safeties"],
    explanation: "C gap is outside the tackle. With a tight end, it is the space between the tackle and the tight end.",
  },
  {
    topic: "Gaps",
    prompt: "Where is the D gap?",
    correct: "Outside the tight end",
    wrong: ["Between the guard and the tackle", "Between the center and the guard", "Right over the center"],
    explanation: "D gap is outside the tight end. No tight end on that side usually means no D gap there.",
  },
  {
    topic: "Run fits",
    prompt: "In a run fit, what is each defender's basic job?",
    correct: "Own ONE gap and fill it on a run, so every gap has a defender",
    wrong: [
      "Chase the ball right away, wherever it goes",
      "Cover two gaps at the same time",
      "Wait for the ball carrier to come to you",
    ],
    explanation:
      "One man, one gap. If a player leaves his gap to chase, the run hits right there. Fill your gap first, then pursue.",
  },
  {
    topic: "Keys",
    prompt: "You read the guard. He fires out low and hard at a defender. What does that usually mean?",
    correct: "Run",
    wrong: ["Pass", "Punt", "Screen, for sure"],
    explanation: "Low hat = run. A lineman who drives low and forward is run blocking. Trigger downhill to your gap.",
  },
  {
    topic: "Keys",
    prompt: "The guard pops up and sets back with his hands up. What does that usually mean?",
    correct: "Pass",
    wrong: ["Run", "Kneel-down", "Field goal"],
    explanation:
      "High hat = pass. Linemen stand up and back to pass block. Get to your drop or your man. Watch for a draw or screen that starts the same way.",
  },
  {
    topic: "Keys",
    prompt: "The guard pulls, running flat down the line to one side. Where do your eyes and feet go?",
    correct: "Follow the pull. He is often leading the play to where it is going.",
    wrong: ["Go the opposite way", "Stay put and only watch the QB", "Drop back into pass coverage"],
    explanation:
      "A pulling guard often leads the ball to the point of attack. Shuffle with him, stay square, and fit your gap.",
  },
  {
    topic: "Keys",
    prompt: "The running back steps up and squares up to block instead of heading for a handoff. What is likely?",
    correct: "Pass",
    wrong: ["Run up the middle", "Punt", "Reverse"],
    explanation:
      "A back who sets up to block is in pass protection. Pass read. If you have him in coverage, he may still release late.",
  },
  {
    topic: "Force",
    prompt: "What is the job of the force (contain) player on a run to his side?",
    correct: "Keep the ball carrier inside. Never let him get outside you.",
    wrong: [
      "Run straight to the ball carrier's back",
      "Drop into a deep zone",
      "Rush the quarterback only",
    ],
    explanation:
      "The force player turns the run back inside, toward the linebackers and pursuit. Outside leverage, always.",
  },
  {
    topic: "Spill",
    prompt: "What does it mean to \"spill\" a run?",
    correct: "Wreck the blocker from the inside so the runner bounces wider, toward your help",
    wrong: [
      "Let the runner cut back inside",
      "Fall down to make a pile",
      "Drop into pass coverage",
    ],
    explanation:
      "Spill pushes the ball outside to fast pursuit and the force player. Box (or squeeze) is the opposite: turn it back inside. Teams use different words. Learn your coach's.",
  },
  {
    topic: "Calls",
    prompt: "Where do many defenses set the strength call?",
    correct: "Toward the tight end, or to the side with more receivers if there is no tight end",
    wrong: ["Always to the offense's left", "Toward our own sideline", "Toward the side with fewer players"],
    explanation:
      "Common rule: strength to the tight end. No tight end: to the passing strength. Your coach's rule wins, so learn it cold.",
  },
  {
    topic: "Formations",
    prompt: "The offense has three receivers to the right and one to the left, no tight end. Which side is the passing strength?",
    correct: "Right",
    wrong: ["Left", "The middle", "There is no strength"],
    explanation: "Passing strength is the side with more receivers. Three to the right means right.",
  },
  {
    topic: "Motion",
    prompt: "A receiver motions from one side to the other before the snap. What does the MLB do?",
    correct: "Recheck the strength and echo any change so the defense adjusts",
    wrong: ["Ignore it", "Call timeout", "Jump offside to stop the play"],
    explanation:
      "Motion can flip the strength. The MLB sees it, makes the new call loud, and makes sure everyone shifts before the snap.",
  },
  {
    topic: "Pursuit",
    prompt: "The ball carrier breaks outside. What pursuit angle do you take?",
    correct: "Aim at a spot in front of him while staying on his inside hip, so he cannot cut back",
    wrong: [
      "Run straight at where he is right now",
      "Stop and let the corner make the play",
      "Sprint to the sideline and wait there",
    ],
    explanation:
      "Leverage the ball, inside-out. Run to where he will be, and keep him on your outside shoulder. Overrun him and he cuts back behind you.",
  },
  {
    topic: "FAST tackle",
    prompt: "In FAST, what does the T (Through) mean on a tackle?",
    correct: "Wrap, cheek to the ball, drive the legs",
    wrong: ["Throw him down by the jersey", "Put your head down and hit", "Touch him and stop"],
    explanation:
      "First step. Attack. Shoulder level. Through. On defense, Through means wrap, cheek to the ball, drive the legs.",
  },
  {
    topic: "FAST tackle",
    prompt: "Why do we tackle with shoulders level, eyes up, and cheek to the ball?",
    correct: "Leading with the top of the head can cause serious head and neck injuries, and it is a penalty",
    wrong: ["It looks better on film", "It is slower, so it is only safer for the runner", "There is no real reason"],
    explanation:
      "Never lead with the crown of the helmet. Eyes up keeps your neck safe. Leading with the head is a foul (spearing / targeting) and it can end your season.",
  },
  {
    topic: "Pass drops",
    prompt: "On a pass read in zone, where does the MLB usually drop?",
    correct: "To the hook/curl area, roughly 10 to 12 yards deep, eyes on the QB",
    wrong: ["Straight back 25 yards to the deep middle", "Out to the flat", "Rush the quarterback every time"],
    explanation:
      "Get depth in the middle hook zone, read the QB's eyes, and feel receivers crossing in front of you. Your coach sets the exact depth for each call.",
  },
  {
    topic: "Communication",
    prompt: "The coach signals the call. What does the MLB do?",
    correct: "Echo the call loud to everyone, then check that all 11 are lined up right",
    wrong: [
      "Keep it to himself",
      "Tell only the defensive line",
      "Wait for the offense to set, then make up his own call",
    ],
    explanation:
      "The MLB is the defense's quarterback. Get the call, say it loud, point, and fix alignments before the snap.",
  },
  {
    topic: "Situations",
    prompt: "It is 4th and goal from the 1. What is the MLB's mindset?",
    correct: "Fill your gap fast and low. Expect a run or a quick throw. Stop it before the goal line.",
    wrong: ["Drop deep in case of a long pass", "Sit back and wait to see the play", "Line up 10 yards deep"],
    explanation:
      "Short yardage is won with low pads and fast feet. There is almost no field behind you. Attack your gap.",
  },
];

const CAPTAIN: Draft[] = [
  {
    topic: "Coin toss",
    prompt: "You win the coin toss before the game. What can you choose?",
    correct: "Kick, receive, which goal to defend, or defer your choice to the second half",
    wrong: ["Only which color jerseys to wear", "Which officials work the game", "Only whether to kick"],
    explanation:
      "The toss winner picks one: receive, kick, or which goal to defend. Or defer, and pick first at the start of the second half.",
  },
  {
    topic: "Coin toss",
    prompt: "What does \"defer\" mean at the coin toss?",
    correct: "You save your choice for the start of the second half, and the other team chooses now",
    wrong: ["You give up your choice for the whole game", "You kick off to start both halves", "The referee picks for you"],
    explanation: "Defer moves your choice to the second half. The other captain picks for the first half.",
  },
  {
    topic: "Coin toss",
    prompt: "Why do many teams defer?",
    correct: "So they get the ball to start the second half",
    wrong: ["The rules require it", "To get extra timeouts", "So they get the ball to start both halves"],
    explanation:
      "Deferring means the ball comes to you right after halftime. Coaches like having the adjustment made at the half and the ball in hand. Your coach tells you his choice before the toss.",
  },
  {
    topic: "Sportsmanship",
    prompt: "An opponent talks trash to you after a play. What do you do?",
    correct: "Walk away and get back to the huddle",
    wrong: ["Talk back louder", "Give him a shove", "Tell the official you are going to get him"],
    explanation:
      "The official usually sees the second guy. Retaliation is how we get the penalty. Captains show the team how to stay calm.",
  },
  {
    topic: "Sportsmanship",
    prompt: "Which of these is an unsportsmanlike conduct foul?",
    correct: "Taunting an opponent or using abusive language",
    wrong: ["Running out of bounds", "Calling a timeout", "Asking the referee a question politely"],
    explanation:
      "Taunting, abusive language, and showing people up are unsportsmanlike fouls. They cost yards, and they can get a player removed from the game.",
  },
  {
    topic: "Academics",
    prompt: "What does it take to stay eligible to play in Pennsylvania?",
    correct: "Passing at least four full-credit subjects, checked weekly",
    wrong: ["Just showing up to practice", "Passing gym class", "Good grades on the final report card only"],
    explanation:
      "In Pennsylvania, PIAA eligibility requires passing at least four full-credit subjects, checked weekly. Your school may set a higher bar. Grades come first.",
  },
  {
    topic: "Academics",
    prompt: "A captain's grade is slipping in one class. What is the captain move?",
    correct: "Tell the coach, talk to the teacher, and use study time to fix it early",
    wrong: ["Hide it from the coach", "Skip that class until it is over", "Copy a friend's homework"],
    explanation:
      "Early is easy. Late is a benched Friday. A captain asks for help before it costs a game.",
  },
  {
    topic: "Warm-ups",
    prompt: "Leading warm-ups, what does a captain do?",
    correct: "Start on time, set the pace, give clear counts, and make sure every rep is done right",
    wrong: [
      "Let the team goof off until a coach shows up",
      "Do only the fun parts",
      "Yell at anyone who is slow",
    ],
    explanation: "Warm-up sets the tone for practice. Loud, clear, on time, every rep.",
  },
  {
    topic: "Teammates",
    prompt: "A teammate fumbles. You are a captain. What do you do?",
    correct: "Pick him up with \"next play.\" Talk details later, one-on-one, if needed.",
    wrong: ["Yell at him in front of everyone", "Tell the coach to bench him", "Ignore him"],
    explanation:
      "Mistakes happen. The next play is what we control. Coaches coach the fix. Captains keep the huddle together.",
  },
  {
    topic: "Officials",
    prompt: "You think the officials got a call wrong. As captain, what can you do?",
    correct: "At a stoppage, calmly and respectfully ask the referee to explain the call or the rule",
    wrong: ["Argue loudly until they change it", "Throw your helmet", "Tell the team to stop playing"],
    explanation:
      "Captains may ask for a clarification, with respect. Arguing gets flags, not changes. Let your coach handle anything more.",
  },
  {
    topic: "Injuries",
    prompt: "A teammate took a hit. He has a headache and feels dizzy but wants to stay in. What do you do?",
    correct: "Tell a coach or the athletic trainer right away",
    wrong: ["Let him play. He is tough.", "Tell him to shake it off for one more series", "Wait until after the game"],
    explanation:
      "Never play through a possible head injury. In Pennsylvania, a player pulled for a possible concussion cannot return until a medical professional clears him in writing. Telling a coach is being a good teammate, not snitching.",
  },
  {
    topic: "Injuries",
    prompt: "Which of these can be a sign of a concussion?",
    correct: "Headache, dizziness, blurry vision, confusion, or feeling foggy",
    wrong: ["Only being knocked out", "Only a bloody nose", "Being hungry after practice"],
    explanation:
      "Most concussions happen without being knocked out. Any of these after a hit means stop and tell a coach or the athletic trainer.",
  },
  {
    topic: "Heat safety",
    prompt: "It is hot and humid. A teammate is confused, stumbling, and his skin feels hot. What do you do?",
    correct: "Get a coach or the athletic trainer right now. This can be a heat emergency.",
    wrong: ["Tell him to drink water and keep going", "Let him sit in the sun and rest", "Nothing. He is just tired."],
    explanation:
      "Confusion in the heat is a red flag for heat stroke. It needs help right away. Do not wait to see if it passes.",
  },
  {
    topic: "Hydration",
    prompt: "What is a smart hydration habit on practice days?",
    correct: "Drink water through the whole day: before, during, and after practice",
    wrong: ["Drink only during practice", "Drink soda before practice for energy", "Skip water so you do not cramp"],
    explanation: "You cannot catch up in one water break. Start the day drinking water and keep going.",
  },
  {
    topic: "On time",
    prompt: "Practice starts at 3:30. When should a captain be there?",
    correct: "Early, dressed and ready before the start",
    wrong: ["3:30 exactly", "3:40. Practice starts slow anyway.", "Whenever he gets there"],
    explanation: "Early is on time. Captains help set up and greet teammates as they walk in.",
  },
  {
    topic: "Representing",
    prompt: "Why does how a captain acts off the field matter?",
    correct: "You represent the team and the school everywhere: class, the halls, online, and around town",
    wrong: ["It does not", "Only when a coach is watching", "Only on game days"],
    explanation: "The title goes with you. Teachers, younger kids, and parents watch captains.",
  },
  {
    topic: "Conflict",
    prompt: "Two teammates start arguing at practice. What does a captain do?",
    correct: "Step in early, calm it down, separate them if needed, and get a coach if it does not stop",
    wrong: ["Pick a side", "Let them fight it out", "Film it"],
    explanation: "Stop it small. A captain cools things off and brings in a coach when it is more than words.",
  },
  {
    topic: "Teammates",
    prompt: "A new 7th grader does not know anyone and stands alone at water breaks. What do you do?",
    correct: "Go talk to him, learn his name, and pair him with someone in drills",
    wrong: ["Leave him alone. He will figure it out.", "Tease him a little. It is tradition.", "Tell the coach he is not ready"],
    explanation: "Every player on this roster is ours. The kid alone today is a starter in two years.",
  },
  {
    topic: "Leading",
    prompt: "What is the best way for a captain to lead?",
    correct: "Do the right thing when no one is watching. Effort, grades, and attitude first, then talk.",
    wrong: ["Be the loudest one on the field", "Get the coach to like you", "Skip the hard drills to save energy for games"],
    explanation: "Players follow what you do more than what you say. Earn the voice.",
  },
];

export const EXAM_BANK: BankExam[] = [
  {
    slug: "qb-reads",
    title: "QB Reads & Rules",
    audience: "QB",
    description:
      "Coverage by safety count, where the holes are, counting the box, hot routes, cadence, ball security, and situational football.",
    passPercent: 80,
    questions: build(QB),
  },
  {
    slug: "mlb-fits",
    title: "MLB Fits & Calls",
    audience: "MLB",
    description:
      "Gap names, run fits, reading keys, force and spill, strength calls, motion, pursuit, FAST tackling, and pass drops.",
    passPercent: 80,
    questions: build(MLB),
  },
  {
    slug: "captain-standard",
    title: "Captain's Standard",
    audience: "CAPTAIN",
    description:
      "Coin toss, sportsmanship, academics first, leading warm-ups, officials, injuries and heat, and taking care of teammates.",
    passPercent: 80,
    questions: build(CAPTAIN),
  },
];

export function bankExam(slug: string): BankExam | undefined {
  return EXAM_BANK.find((exam) => exam.slug === slug);
}
