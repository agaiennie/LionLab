// Flexibility & balance program plus a bodyweight-first weekly plan.
// Farm-plain names, same Drill shape as lib/content/mobility.ts.
// Guidance, not medical advice. Pain is a stop, not a push.
import { METRIC_BY_ID, type MetricId } from "@/lib/content/metrics";
import { DRILLS, type Drill } from "@/lib/content/mobility";
import { ANCHORS, bandForGrade } from "@/lib/position-fit";

/** A few new drills for flexibility and balance. Everything else reuses mobility.ts. */
export const FLEX_DRILLS: Drill[] = [
  {
    id: "hay-loft-reach",
    name: "Hay-Loft Reach",
    purpose: "Hamstring and low-back length for the sit-and-reach.",
    cue: "Reach long, don't bounce.",
    steps: [
      "Sit tall, legs straight, toes up. A towel around the feet if you can't reach.",
      "Hinge forward from the hips and slide the hands toward the toes.",
      "Hold where the back of the legs speak. Breathe out and reach a little farther. No bouncing.",
    ],
    dose: "7–8: 2 × 20 seconds. 9–12: 3 × 25 seconds.",
    stop: "Sharp back pain or pain behind the knee. Bend the knees and ease off.",
  },
  {
    id: "stall-door-rock",
    name: "Stall-Door Ankle Rock",
    purpose: "Ankle bend for the knee-to-wall and a deeper squat.",
    cue: "Heel glued, knee to the door.",
    steps: [
      "Half-kneel facing a wall or door, front toes a few inches away.",
      "Rock the front knee toward the wall over the middle toes. Heel stays down.",
      "Rock back. When the knee touches easily, slide the foot back a little.",
    ],
    dose: "7–8: 10 rocks a side. 9–12: 12 rocks a side, 2-second hold at the wall.",
    stop: "Pinch at the front of the ankle or pain after a recent roll. Stop and tell the ATC.",
  },
  {
    id: "barn-post-squat",
    name: "Barn-Post Squat Hold",
    purpose: "Deep squat shape with help, so the hips and ankles learn the bottom.",
    cue: "Sit between the heels, chest proud.",
    steps: [
      "Hold a post, door frame, or partner's hands.",
      "Sit down as deep as you can with the heels down. Let the post take some weight.",
      "Push the knees out over the toes. Hold, then stand using the legs.",
    ],
    dose: "7–8: 3 × 15 seconds. 9–12: 3 × 20 seconds.",
    stop: "Knee pain that is more than a stretch. Hold higher.",
  },
  {
    id: "stock-tank-stand",
    name: "Stock-Tank Stand",
    purpose: "Single-leg balance that builds to eyes closed.",
    cue: "Quiet hips, soft knee.",
    steps: [
      "Stand on one foot, hands on hips, near a wall for safety.",
      "Level 1: eyes open 30 seconds. Level 2: turn the head slowly side to side. Level 3: eyes closed.",
      "Move up a level only when the last one is steady. Switch legs.",
    ],
    dose: "7–8: 2 × 20 seconds a leg. 9–12: 3 × 30 seconds a leg.",
    stop: "Dizziness. Open the eyes, touch the wall, and tell a coach.",
  },
  {
    id: "feed-bucket-reach",
    name: "Feed-Bucket Reach",
    purpose: "Balance while the body moves — like a plant and reach in a game.",
    cue: "Stand leg steady, reach and return slow.",
    steps: [
      "Stand on one foot. Picture three feed buckets: in front, to the side, and behind.",
      "Reach the free toe to tap each bucket, then return to stand tall between taps.",
      "Standing knee stays over the toes. Switch legs.",
    ],
    dose: "7–8: 2 rounds a leg. 9–12: 3 rounds a leg, reach farther.",
    stop: "Knee or ankle pain. Shorter reach.",
  },
];

const ALL = new Map<string, Drill>([...DRILLS, ...FLEX_DRILLS].map((drill) => [drill.id, drill]));

export function flexDrill(id: string): Drill | undefined {
  return ALL.get(id);
}

export type FlexMetricId = "SIT_REACH" | "KNEE_WALL" | "SQUAT_SCORE" | "BALANCE_SL" | "BALANCE_SWAY";

export const FLEX_METRICS: FlexMetricId[] = ["SIT_REACH", "KNEE_WALL", "SQUAT_SCORE", "BALANCE_SL", "BALANCE_SWAY"];

/** Which drills move which number. First ids are the highest-value ones. */
export const METRIC_DRILLS: Record<FlexMetricId, string[]> = {
  SIT_REACH: ["hay-loft-reach", "boot-lace", "gate-hinge", "fence-line-lunge"],
  KNEE_WALL: ["stall-door-rock", "fence-lean", "fence-post"],
  SQUAT_SCORE: ["barn-post-squat", "tractor-seat", "stall-door-rock", "fence-line-lunge"],
  BALANCE_SL: ["stock-tank-stand", "rail-walk", "fence-post", "feed-bucket-reach"],
  BALANCE_SWAY: ["feed-bucket-reach", "stock-tank-stand", "hay-bale", "rail-walk"],
};

/** Base sessions: 3 per week, 12–15 minutes each, non-consecutive days. */
export const FLEX_SESSIONS: { id: string; title: string; minutes: string; drillIds: string[] }[] = [
  {
    id: "A",
    title: "Session A — hips and hamstrings",
    minutes: "12–15 min",
    drillIds: ["fence-lean", "boot-lace", "fence-line-lunge", "tractor-seat", "rail-walk", "stock-tank-stand"],
  },
  {
    id: "B",
    title: "Session B — ankles and squat",
    minutes: "12–15 min",
    drillIds: ["stall-door-rock", "fence-post", "barn-post-squat", "gate-hinge", "barn-door", "feed-bucket-reach"],
  },
  {
    id: "C",
    title: "Session C — balance and reach",
    minutes: "12–15 min",
    drillIds: ["hay-loft-reach", "fence-lean", "rail-walk", "feed-bucket-reach", "hay-bale", "silo-reach"],
  },
];

const SESSION_SIZE = 6;

/** The "ok" line: midpoint of the position-fit anchors for the athlete's band. */
export function okLine(metric: FlexMetricId, grade: number): number {
  const anchor = ANCHORS[metric]?.[bandForGrade(grade)];
  if (!anchor) return 0;
  return (anchor[0] + anchor[1]) / 2;
}

export function isWeak(metric: FlexMetricId, value: number, grade: number): boolean {
  const line = okLine(metric, grade);
  return METRIC_BY_ID[metric].better === "lower" ? value > line : value < line;
}

export type WeakSpot = { metric: FlexMetricId; label: string; value: number; okLine: number; gap: number };

export type FlexPlan = {
  weak: WeakSpot[];
  missing: FlexMetricId[];
  okCount: number;
  priorityIds: string[];
  sessions: { id: string; title: string; minutes: string; drills: Drill[]; priority: string[] }[];
  note: string;
};

/**
 * Pick priority drills from weak flexibility/balance numbers.
 * Weakest metric (relative gap to the ok line) comes first.
 */
export function programFor(
  latest: Partial<Record<MetricId, { value: number }>>,
  grade: number,
): FlexPlan {
  const weak: WeakSpot[] = [];
  const missing: FlexMetricId[] = [];
  let okCount = 0;
  for (const metric of FLEX_METRICS) {
    const row = latest[metric];
    if (row == null || !Number.isFinite(row.value)) {
      missing.push(metric);
      continue;
    }
    const line = okLine(metric, grade);
    if (isWeak(metric, row.value, grade)) {
      const anchor = ANCHORS[metric]?.[bandForGrade(grade)] ?? [0, 1];
      const span = Math.abs(anchor[1] - anchor[0]) || 1;
      weak.push({
        metric,
        label: METRIC_BY_ID[metric].label,
        value: row.value,
        okLine: line,
        gap: Math.abs(row.value - line) / span,
      });
    } else {
      okCount += 1;
    }
  }
  weak.sort((a, b) => b.gap - a.gap);

  const priorityIds: string[] = [];
  // Round-robin so each weak number gets its best drill first.
  for (let rank = 0; rank < 4 && priorityIds.length < 4; rank += 1) {
    for (const spot of weak) {
      const id = METRIC_DRILLS[spot.metric][rank];
      if (id && !priorityIds.includes(id) && priorityIds.length < 4) priorityIds.push(id);
    }
  }

  const sessions = FLEX_SESSIONS.map((session, index) => {
    // Rotate which priority drills lead each session, max 3 per session.
    const rotated = priorityIds.length
      ? [...priorityIds.slice(index % priorityIds.length), ...priorityIds.slice(0, index % priorityIds.length)]
      : [];
    const priority = rotated.slice(0, 3);
    const ids = [...priority];
    for (const id of session.drillIds) {
      if (ids.length >= SESSION_SIZE) break;
      if (!ids.includes(id)) ids.push(id);
    }
    return {
      id: session.id,
      title: session.title,
      minutes: session.minutes,
      drills: ids.map((id) => flexDrill(id)).filter((drill): drill is Drill => drill != null),
      priority,
    };
  });

  let note: string;
  if (weak.length === 0 && missing.length === FLEX_METRICS.length) {
    note = "No flexibility or balance numbers yet. Run the base plan and ask a coach to measure you.";
  } else if (weak.length === 0) {
    note = "Your numbers are at or past the ok line. Keep the base plan three times a week to hold it.";
  } else {
    note = `Priority drills lead each session for: ${weak.map((spot) => spot.label.toLowerCase()).join(", ")}.`;
  }

  return { weak, missing, okCount, priorityIds, sessions, note };
}

// ---------------------------------------------------------------------------
// Weekly exercise plan — bodyweight first, technique first, no max lifts.

export type Exercise = { id: string; name: string; cue: string; dose: string; stop: string };

type Dose = { jh: string; hs: string };

type ExerciseDef = { id: string; name: string; cue: string; dose: Dose; stop: string };

const EXERCISES: Record<string, ExerciseDef> = {
  pushup: {
    id: "pushup",
    name: "Push-Up",
    cue: "Plank that moves. Chest to a fist, elbows at 45.",
    dose: { jh: "2 × 6–10 (hands on a bench if needed)", hs: "3 × 8–12" },
    stop: "Shoulder or wrist pain. Go to a bench or wall.",
  },
  squat: {
    id: "squat",
    name: "Tractor Seat Squat (bodyweight)",
    cue: "Knees track toes, heels down.",
    dose: { jh: "2 × 10", hs: "3 × 12" },
    stop: "Knee pain that is more than work.",
  },
  lunge: {
    id: "lunge",
    name: "Reverse Lunge",
    cue: "Step back, front knee over the laces, stand tall.",
    dose: { jh: "2 × 6 a leg", hs: "3 × 8 a leg" },
    stop: "Knee pain. Shorter step.",
  },
  stepup: {
    id: "stepup",
    name: "Bleacher Step-Up",
    cue: "Whole foot on the step, slow lower.",
    dose: { jh: "2 × 6 a leg", hs: "3 × 8 a leg" },
    stop: "Knee pain on the way down. Lower step.",
  },
  plank: {
    id: "plank",
    name: "Plank",
    cue: "Straight line, squeeze belly and glutes.",
    dose: { jh: "2 × 20–30 sec", hs: "3 × 30–45 sec" },
    stop: "Low-back pain. Knees down.",
  },
  sideplank: {
    id: "sideplank",
    name: "Side Plank",
    cue: "Hips high, stack the feet or stagger them.",
    dose: { jh: "2 × 15 sec a side", hs: "3 × 20–30 sec a side" },
    stop: "Shoulder pain. Knees down.",
  },
  bridge: {
    id: "bridge",
    name: "Glute Bridge",
    cue: "Drive through the heels, squeeze at the top.",
    dose: { jh: "2 × 10", hs: "3 × 12 (single-leg if easy)" },
    stop: "Hamstring cramp. Feet closer.",
  },
  carry: {
    id: "carry",
    name: "Grain-Sack Carry",
    cue: "Walk tall, ribs down, don't lean.",
    dose: { jh: "2 × 20 yd, light jug or bag", hs: "3 × 20 yd" },
    stop: "Back pain. Lighter load.",
  },
  bearcrawl: {
    id: "bearcrawl",
    name: "Bear Crawl",
    cue: "Knees an inch off the grass, back flat.",
    dose: { jh: "2 × 10 yd", hs: "3 × 15 yd" },
    stop: "Wrist or shoulder pain.",
  },
  pogo: {
    id: "pogo",
    name: "Pogo Hops (small)",
    cue: "Quick, quiet feet. Land soft.",
    dose: { jh: "2 × 10", hs: "3 × 12" },
    stop: "Shin or heel pain. Stop hops for the week.",
  },
  skater: {
    id: "skater",
    name: "Skater Step (stick the landing)",
    cue: "Hop sideways, stick it, knee over toes.",
    dose: { jh: "2 × 4 a side", hs: "3 × 5 a side" },
    stop: "Knee or ankle pain.",
  },
  wallpush: {
    id: "wallpush",
    name: "Wall Push Stance",
    cue: "Push the wall. Don't shrug.",
    dose: { jh: "5 × 5 sec", hs: "6 × 5 sec" },
    stop: "Shoulder pain. Ease the lean.",
  },
  haybale: {
    id: "haybale",
    name: "Hay-Bale Brace",
    cue: "Win with belly and glutes. Don't twist.",
    dose: { jh: "4 × 8 sec a side", hs: "4 × 10 sec a side" },
    stop: "Sharp back pain. Lighter push.",
  },
};

export type PositionGroup = "LINE" | "SKILL" | "LB_TE" | "QB";

export function positionGroup(code: string | undefined): PositionGroup {
  switch (code) {
    case "OL":
    case "DL":
      return "LINE";
    case "LB":
    case "TE":
      return "LB_TE";
    case "QB":
      return "QB";
    default:
      return "SKILL";
  }
}

const GROUP_LABEL: Record<PositionGroup, string> = {
  LINE: "Linemen",
  SKILL: "Skill players",
  LB_TE: "Linebackers and tight ends",
  QB: "Quarterbacks",
};

const GROUP_ADDONS: Record<PositionGroup, string[]> = {
  LINE: ["bearcrawl", "wallpush"],
  SKILL: ["pogo", "skater"],
  LB_TE: ["carry", "haybale"],
  QB: ["sideplank", "haybale"],
};

export const PLAN_RULES = [
  "Technique first. A clean rep beats a fast or heavy one.",
  "Bodyweight first. No max lifts. Add load only when a coach says your form is ready.",
  "Two strength days and three short flexibility & balance sessions a week, on non-consecutive days.",
  "Not the day before a game. Game week, keep it to the flexibility sessions.",
  "Pain is a stop, not a push. Soreness that lasts more than two days means back off.",
  "Guidance, not medical advice.",
];

function toExercise(def: ExerciseDef, grade: number): Exercise {
  return { id: def.id, name: def.name, cue: def.cue, dose: bandForGrade(grade) === "JH" ? def.dose.jh : def.dose.hs, stop: def.stop };
}

export type WeeklyPlan = {
  group: PositionGroup;
  groupLabel: string;
  band: "7–8" | "9–12";
  rules: string[];
  days: { id: string; title: string; focus: string; exercises: Exercise[]; flexSession?: string }[];
};

export function weeklyPlan(positionCode: string | undefined, grade: number): WeeklyPlan {
  const group = positionGroup(positionCode);
  const pick = (ids: string[]) => ids.map((id) => toExercise(EXERCISES[id], grade));
  const addons = GROUP_ADDONS[group];
  const strengthA = ["pushup", "squat", "plank", "carry"];
  const strengthB = ["lunge", "stepup", "bridge", "sideplank"];
  const withAddon = (base: string[], addon: string) => (base.includes(addon) ? base : [...base, addon]);
  return {
    group,
    groupLabel: GROUP_LABEL[group],
    band: bandForGrade(grade) === "JH" ? "7–8" : "9–12",
    rules: PLAN_RULES,
    days: [
      {
        id: "day1",
        title: "Day 1 — Strength A + Flex A",
        focus: "Push, squat, brace, carry. Then flexibility session A.",
        exercises: pick(withAddon(strengthA, addons[0])),
        flexSession: "A",
      },
      {
        id: "day2",
        title: "Day 2 — Flex B (recovery day)",
        focus: "Just the flexibility & balance session. Easy walk or play is fine.",
        exercises: [],
        flexSession: "B",
      },
      {
        id: "day3",
        title: "Day 3 — Strength B + Flex C",
        focus: "Single-leg, hips, side core. Then flexibility session C.",
        exercises: pick(withAddon(strengthB, addons[1])),
        flexSession: "C",
      },
    ],
  };
}
