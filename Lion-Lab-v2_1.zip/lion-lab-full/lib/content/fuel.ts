export const FUEL_HABITS = [
  {
    id: "water",
    field: "water" as const,
    label: "Water through the day",
    tip: "Bottle at breakfast, lunch, and before practice. Thirst is late.",
  },
  {
    id: "protein",
    field: "protein" as const,
    label: "Protein at meals",
    tip: "Eggs, milk, beans, chicken, or yogurt at breakfast and dinner. School lunch counts if it has protein.",
  },
  {
    id: "sleep",
    field: "sleep" as const,
    label: "Sleep window",
    tip: "Same lights-out most nights. A short night shows up in the first step.",
  },
  {
    id: "lightJunk",
    field: "lightJunk" as const,
    label: "No heavy junk before practice",
    tip: "Skip the big soda and candy in the hour before pads. Eat real food earlier.",
  },
] as const;

export const FUEL_NOTE =
  "Habits for the kitchen you live in. Not a meal plan and not a calorie target.";
