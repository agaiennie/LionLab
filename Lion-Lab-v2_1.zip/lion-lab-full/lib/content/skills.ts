import { shiftDay, todayKey } from "@/lib/habits";

export const SKILL_LIBRARY_VERSION = "v1";

export type FastLetter = "F" | "A" | "S" | "T";
export type SkillPhase = "fundamentals" | "position" | "team";
export type SkillTier = "first" | "next";

export type TeachStep = {
  name: string;
  coachSays: string;
  playerDoes: string;
  success: string;
  failFix: string;
};

export type MetricLink = {
  label: string;
  detail: string;
};

export type Skill = {
  id: string;
  name: string;
  phase: SkillPhase;
  positions: string[];
  tier: SkillTier;
  promoteFor: string[];
  fastLetters: FastLetter[];
  metricLinks: MetricLink[];
  what: string;
  why: string;
  demo: { correct: string; eyes: string[]; wrong: string[] };
  breakdown: TeachStep[];
  speedUp: { how: string; stop: string };
  station: { setup: string; reps: string; cue: string; stop: string };
};

export const LIBRARY_POSITIONS: { code: string; label: string; job: string }[] = [
  { code: "QB", label: "Quarterback", job: "Exchange, eyes, and a 1–2–checkdown." },
  { code: "RB", label: "Running back", job: "Secure the ball, hit the crease, and drive through a block." },
  { code: "WR", label: "Wide receiver", job: "Release, catch through contact, and drive through the block." },
  { code: "TE", label: "Tight end", job: "Release, catch, and drive through the block." },
  { code: "OL", label: "Offensive line", job: "Stance, kick-slide, landmark, and through the block." },
  { code: "DL", label: "Defensive line", job: "Get-off, hands, and stay in the gap." },
  { code: "LB", label: "Linebacker", job: "Read step, fit the run, finish in space." },
  { code: "DB", label: "Defensive back", job: "Coverage base, hips, and the ball in the air." },
  { code: "ST", label: "Special teams", job: "Cover through the whistle. Kick unless the call is green." },
  { code: "K", label: "Kicker / punter", job: "Same cover rules, plus kick unless green." },
  { code: "ATH", label: "Athlete", job: "The skills every player on the roster needs first." },
];

const none = "No separate Lion Lab score yet. This skill will tie to position-fit later. Do not invent a number for it.";

function step(name: string, coachSays: string, playerDoes: string, success: string, failFix: string): TeachStep {
  return { name, coachSays, playerDoes, success, failFix };
}

export const SKILLS: Skill[] = [
  {
    id: "athletic-stance",
    name: "Athletic stance",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F", "S"],
    metricLinks: [
      { label: "S is shoulder level", detail: "Pads and shoulders ready, not upright. S is not a square-up." },
      { label: "Stance checklist", detail: "Feet, knees, chest, hands, and the 3-second hold. Bands are Game-ready, Developing, or Rebuild." },
      { label: "Tracker: athletic-stance", detail: "Body tracker movement athletic-stance. Checklist mode works if the camera is off." },
    ],
    what: "The ready position before the snap: feet outside the hips, soft knees, chest up, weight on the middle of the foot.",
    why: "A tall or rocking stance is late and gets the knees hit. The first step cannot be good if the base is already standing up.",
    demo: {
      correct: "Player is still. Knees are bent enough that a coach can see the thigh. Hands are free. Eyes are on the landmark, not the shoes.",
      eyes: ["Feet just outside the hips", "Knees soft, tracking the toes", "Chest tall, back flat", "Weight mid-foot, heels light", "Still for a full second"],
      wrong: ["Knees locked, standing like a hallway", "Weight on the toes, rocking", "Hands on the knees, eyes down"],
    },
    breakdown: [
      step("Walk", "Feet outside hips. Soft knees.", "Step in and freeze the stance for 2 seconds.", "The freeze is quiet. No bounce.", "Heels light. Do not stand up."),
      step("Jog", "Same base. Reset every rep.", "Jog five yards, sink into the stance, hold.", "The sink matches the freeze from the walk.", "Reset the feet before the hold."),
      step("Live", "Hold it until the whistle, not until you feel ready.", "Take a team snap count and move only on the snap.", "No false step and no early lean.", "Get still. The rock is the miss."),
    ],
    speedUp: {
      how: "Add a clap or a snap count. The stance does not get taller when the count gets faster.",
      stop: "Knee pain on the sink, or a player who cannot hold still. Shrink the bend. Do not add contact.",
    },
    station: {
      setup: "One line, cones at the feet width you want. No bags yet.",
      reps: "8 freezes. Then 6 jog-to-freeze.",
      cue: "Soft knees. Eyes up.",
      stop: "If the back rounds, stop and show Gate Hinge. Pain in the knee ends the station.",
    },
  },
  {
    id: "first-step",
    name: "First step",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F"],
    metricLinks: [
      { label: "40-yard form", detail: "The first-step checklist item: explosive, no false step. A messy start moves the adjusted ESTIMATE slower than the raw clock." },
    ],
    what: "The first movement after the snap goes toward the job. It replaces the foot. It does not hop backward.",
    why: "A false step gives the blocker or the ball carrier a free step. Most lost tackles and lost blocks start here, not at full speed.",
    demo: {
      correct: "From a still stance, the back foot or lead foot fires at the target. The body leans from the ankle, not a jump up.",
      eyes: ["No step backward", "Foot replaces, it does not kick the air", "Shin angles toward the target", "Arms move with the step", "Eyes stay on the landmark"],
      wrong: ["Hop back, then go", "Stand up, then step", "First step wider than the base, crossing the feet"],
    },
    breakdown: [
      step("Walk", "Win the first step. No freeze after the snap.", "From stance, one step at a cone 1 yard away. Freeze.", "The step landed toward the cone. The other foot has not recovered past it.", "Replace the foot. Do not hop back."),
      step("Jog", "Same step. Faster feet, same shape.", "Three-step burst to a cone at 5 yards.", "The first step still points at the cone.", "Point the first step. Ignore step three."),
      step("Live", "On the clap, not when you are ready.", "Partner claps. Player fires one step and settles.", "Movement starts on the clap, not after a rock.", "Get still before the clap."),
    ],
    speedUp: {
      how: "Shorten the rest. Do not lengthen the step. Five clean bursts beat twenty sloppy ones.",
      stop: "If the false step returns, go back to the one-step freeze. Hamstring grab or a limp ends the station.",
    },
    station: {
      setup: "Two cones, one yard and five yards. Stance marks on the ground.",
      reps: "6 one-step freezes, 6 bursts.",
      cue: "First step downhill.",
      stop: "False step twice in a row: walk it again. Pain: stop.",
    },
  },
  {
    id: "attack-contact",
    name: "Attack contact",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["A", "S"],
    metricLinks: [
      { label: "Stance and hinge", detail: "S is shoulder level: pads ready, not upright. Tracker movement gate-hinge matches the chest and hip shape." },
    ],
    what: "Into contact, the pads lead. The player dips from the hips and runs the shoulder through the target instead of standing up.",
    why: "Standing up into contact exposes the chin and the ribs, and it loses the block or the tackle. Low does not mean crawling.",
    demo: {
      correct: "Hips back a little, chest long, shoulder on the bag or the partner’s near pad. Feet keep moving. The head is up and to the side, not down.",
      eyes: ["Pads down from a hinge, not a rounded back", "Shoulder through the target", "Eyes up, head out of the middle", "Feet alive under the pads", "No spin to show the back"],
      wrong: ["Stand up and chest-bump", "Drop the head", "Stop the feet at contact"],
    },
    breakdown: [
      step("Walk", "Dip the pads. Shoulder through.", "Walk into a bag or a partner with hands up. Fit and freeze.", "Shoulder is on the target. Back is flat.", "Hips back. Do not round."),
      step("Jog", "Same fit. Feet do not die.", "Three steps into the fit, four short foot-fires.", "The fit holds while the feet move.", "Feet alive."),
      step("Thud", "Thud is a fit, not a knockout.", "Partner gives a thud. Player fits and runs the feet for two steps.", "Contact is on the shoulder. Head stays out.", "Shoulder through. Head out."),
      step("Live", "Only after thud is clean, and only with a coach watching.", "Half-speed fit on a shield. Whistle ends it.", "Player comes off balanced.", "If the head drops, end live and return to walk."),
    ],
    speedUp: {
      how: "Raise the jog speed before you raise the thud. Live is last and short.",
      stop: "Head down, a stinger, neck pain, or dizziness: stop the station and get the athletic trainer. Do not finish the period.",
    },
    station: {
      setup: "One bag or shield. No more than two players. Coach holds the bag if needed.",
      reps: "6 walk fits, 4 thud fits. Live only if thud was clean.",
      cue: "Shoulder through. Head out.",
      stop: "Stinger, numb arm, or a dropped head. Stop.",
    },
  },
  {
    id: "square-up",
    name: "Square up",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "first",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [{ label: "Landmark, not the S", detail: "S in FAST is shoulder level. This page still teaches facing the landmark. It is not the S letter." }],
    what: "The hips and shoulders face the landmark and the path of the ball, not only the spot where the opponent is standing.",
    why: "A turned chest cannot block, catch, or tackle through the target. Players who face the sideline arrive late and sideways.",
    demo: {
      correct: "Toes, hips, and shoulders point at a cone that stands for the landmark. The player can see both the cone and the ball path without twisting the neck alone.",
      eyes: ["Toes aimed at the landmark", "Belt buckle matches the toes", "Shoulders level, not one pad dropped", "Eyes on the path, not the grass", "No extra hop to get square"],
      wrong: ["Hips still facing the sideline", "Only the head turns", "Feet crossed while trying to square"],
    },
    breakdown: [
      step("Walk", "Square to the landmark.", "Coach points. Player hops or steps to face that cone and freezes.", "Toes and hips match the point.", "Turn the hips, not only the head."),
      step("Jog", "Square before you arrive.", "Jog a short arc and finish square to the cone.", "The last step is a brake, body facing the cone.", "Brake with the hips square."),
      step("Live", "The landmark is where they will be.", "Partner moves late. Player squares to the new cone, not the old one.", "The chest faces the new spot before the tag.", "Play the new landmark."),
    ],
    speedUp: {
      how: "Move the point later. Do not add a sprint until the jog finish is square.",
      stop: "Ankle roll on the brake, or dizziness from spinning. Slow the arc.",
    },
    station: {
      setup: "Three cones in a triangle, 5 yards apart.",
      reps: "8 point-and-square. 6 jog finishes.",
      cue: "Hips to the cone.",
      stop: "If they only turn the head twice, go back to the freeze.",
    },
  },
  {
    id: "tackle-wrap",
    name: "Through the tackle (wrap + drive)",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["T"],
    metricLinks: [{ label: "Through, defense finish", detail: "T is Through. This page is the tackle finish: wrap, cheek to the ball, drive the legs. Blockers use Through the block and do not wrap. Lion Lab does not grade hits." }],
    what: "T is Through. On a tackle the finish is a wrap, cheek to the ball, and driving the legs until the whistle. A shoulder with no arms is not a finish.",
    why: "Arm tackles and big hits without a wrap miss in space and put the neck at risk. Blockers do not borrow this wrap. Their Through is a drive to the whistle plus one.",
    demo: {
      correct: "Head to the side, cheek on the ball. Both arms wrap. Legs drive until the whistle. This is the defense finish of Through.",
      eyes: ["Head out, eyes up", "Both arms wrap", "Cheek on the ball", "Legs drive after the wrap", "Release on the whistle"],
      wrong: ["Shoulder only", "Head across the bow", "Stop the legs at contact"],
    },
    breakdown: [
      step("Walk", "Wrap. Cheek to the ball. Drive.", "Fit a bag. Both arms close, cheek on the bag, four leg drives.", "Arms stay closed while the legs drive.", "Both arms. Cheek on the ball."),
      step("Jog", "Same wrap. Do not hunt a highlight.", "Jog to the bag, wrap, cheek on, drive two steps.", "The bag moves because of the legs, not a leap.", "Legs after the wrap."),
      step("Thud", "Thud, wrap, drive to the whistle.", "Partner with a shield. Wrap, cheek, drive to the whistle.", "The wrap and the cheek survive the thud.", "Wrap first."),
      step("Live", "Live angle is short and coached.", "Half-speed angle from 5 yards. Whistle early.", "Wrap and cheek are on before the drive.", "If the head leads, stop live."),
    ],
    speedUp: {
      how: "Add the angle only after the bag wrap is boring. Through on a tackle is wrap, cheek, and legs. A block does not wrap.",
      stop: "Head down, stinger, or a player who leads with the crown. Stop and get the athletic trainer.",
    },
    station: {
      setup: "Bag or shield. One tackler at a time. Whistle in the coach’s mouth.",
      reps: "6 walk wraps, 4 thud drives. Live only if wraps held.",
      cue: "Cheek to the ball. Drive.",
      stop: "Crown of the helmet, numb arm, or neck pain. Stop.",
    },
  },
  {
    id: "secure-ball",
    name: "Secure the ball",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "next",
    promoteFor: ["RB", "QB", "WR", "TE"],
    fastLetters: [],
    metricLinks: [{ label: "No fumble score", detail: none }],
    what: "The ball is pinched to the ribs, nose covered, and the body is between the ball and the nearest tackler.",
    why: "A loose carry turns a 5-yard gain into a turnover. Volunteer coaches can see this without having played: if you see daylight under the elbow, it is wrong.",
    demo: {
      correct: "High and tight. Elbow clamps the top point. Hand covers the nose. The ball does not swing.",
      eyes: ["Ball on the ribs", "Elbow down on the point", "Hand over the nose", "Ball on the side away from the tackle", "No palm-up carry"],
      wrong: ["Ball in one hand away from the body", "Elbow high", "Switching hands in traffic"],
    },
    breakdown: [
      step("Walk", "High and tight.", "Walk 10 yards with the ball clamped. Coach tries a light slap on the ball.", "The ball does not move.", "Elbow on the point."),
      step("Jog", "Same clamp. Change nothing.", "Jog and make one cut. Ball stays.", "The cut does not drop the elbow.", "Clamp before the cut."),
      step("Live", "Finish through a tag.", "Partner tags the shoulder. Carrier keeps the ball and runs to the whistle.", "Ball is still clamped at the whistle.", "Squeeze. Do not switch hands."),
    ],
    speedUp: {
      how: "Add the cut and the tag before you add sprinting. A sprint with a loose ball teaches the wrong habit.",
      stop: "Finger jam or a ball to the face. Check the hand. No pile drills for this skill.",
    },
    station: {
      setup: "One football per carrier. A 10-yard lane.",
      reps: "8 walk clamps, 6 jog cuts.",
      cue: "Elbow on the point.",
      stop: "If the elbow lifts, walk it. Do not add defenders yet.",
    },
  },
  {
    id: "catch-ball",
    name: "Catch the ball",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "next",
    promoteFor: ["WR", "TE", "DB", "QB", "RB"],
    fastLetters: [],
    metricLinks: [{ label: "No catch score", detail: none }],
    what: "Hands attack the ball at the earliest safe point. Eyes stay on the ball through the catch. Then the ball is secured.",
    why: "Body catches and late hands drop balls that were already won. The high point is where the defender has not arrived yet.",
    demo: {
      correct: "Thumbs together above the letters, pinkies together at the waist. Hands extend. The ball is caught in the hands, then put away.",
      eyes: ["Eyes on the ball, not the defender", "Hands out early", "Diamond or pinkies match the height", "Catch away from the body", "Secure after the catch, not during"],
      wrong: ["Basket at the chest", "Running before the ball arrives", "One hand when two were there"],
    },
    breakdown: [
      step("Walk", "Hands first. Eyes through the catch.", "Soft toss from 5 yards. Catch and freeze the hands.", "The ball never touches the chest first.", "Hands out."),
      step("Jog", "Same hands. Move late.", "Jog across. Coach throws to the hands.", "Catch in the hands, then tuck.", "Watch it in."),
      step("Live", "Add a coach’s hand as a distraction, not a hit.", "Catch, tuck, run five yards.", "The tuck happens after two hands have it.", "Tuck after the catch."),
    ],
    speedUp: {
      how: "Move the throw wider before you throw harder. Hard throws with late hands teach drops.",
      stop: "Finger pain or a ball that hits the face because the eyes came off. Go back to the freeze.",
    },
    station: {
      setup: "Coach and one player. Five footballs if you have them.",
      reps: "10 soft catches, 8 on the move.",
      cue: "Hands early. Watch it in.",
      stop: "Two body catches: back to the freeze. No defenders until the hands are early.",
    },
  },
  {
    id: "conditioning-finish",
    name: "Finish through the whistle",
    phase: "fundamentals",
    positions: ["ALL"],
    tier: "next",
    promoteFor: ["ST"],
    fastLetters: ["T"],
    metricLinks: [
      { label: "Through, whistle finish", detail: "T is Through. This page is the running finish: one step past the whistle. It is not the tackle wrap and not the block drive." },
      { label: "40-yard finish", detail: "The 40 checklist includes a finish through the line. Coasting before the line is a missed cue, and it moves the adjusted ESTIMATE." },
    ],
    what: "T is Through on a run. The rep ends on the whistle, one step past the landmark, not when the player feels done.",
    why: "Plays are decided after the player thinks they are over. A coast is how kickoff lanes and the end of a 40 get lazy.",
    demo: {
      correct: "Same effort from the start line to one step past the cone. The player hears the whistle, then stops under control. This Through is a run finish, not a wrap and not a block drive.",
      eyes: ["No upright coast in the last 5 yards", "Arms still driving late", "One step past the landmark", "Stop is a gather, not a fall", "Eyes up through the line"],
      wrong: ["Stand up and glide", "Stop on the cone", "Look at the coach before the whistle"],
    },
    breakdown: [
      step("Walk", "One step past. Then stop.", "Walk a 10-yard lane and stride past the cone.", "The cone is behind the foot that stops.", "Past the cone."),
      step("Jog", "Do not change the finish.", "Jog the lane. Same one-step finish.", "The last three steps are not taller.", "Run the last step."),
      step("Live", "Whistle, not feelings.", "Build to a burst. Whistle is past the cone.", "The burst holds until the whistle.", "Through the whistle."),
    ],
    speedUp: {
      how: "Lengthen the lane only after the short lane finish is clean. Through here is the whistle, not a tackle wrap and not a block drive. Do not use this as punishment sprints.",
      stop: "Cramp, limp, or a player who cannot hear because they are dizzy. End the rep. Water. No extra lap as a lesson.",
    },
    station: {
      setup: "A 15-yard lane and a whistle.",
      reps: "6 finishes. Rest between. This is a skill, not a conditioner.",
      cue: "Through the whistle.",
      stop: "If they coast twice, shorten the lane. Do not add distance.",
    },
  },
  {
    id: "ol-kick-slide",
    name: "Pass-pro kick-slide",
    phase: "position",
    positions: ["OL"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F", "S"],
    metricLinks: [
      { label: "S is shoulder level", detail: "A slide that stands the player up misses S. Facing the quarterback is the landmark. It is not the letter." },
      { label: "Stance", detail: "The stance checklist is the start of the slide. A locked knee cannot kick." },
    ],
    what: "The offensive lineman slides to stay between the rusher and the quarterback. The kick is a short push, not a deep retreat.",
    why: "A deep hop opens the edge and stands the player up. Most youth pressures start with a lineman who ran backward.",
    demo: {
      correct: "Inside foot up, outside foot slides a short step. Hands stay inside the frame. Eyes on the rusher’s near number. Hips stay square to the quarterback’s landmark.",
      eyes: ["Short kick, not a jump", "Inside foot replaces", "Hands ready, elbows in", "Shoulders square to the QB side", "No crossover"],
      wrong: ["Hop straight back three yards", "Cross the feet", "Hands down by the thighs"],
    },
    breakdown: [
      step("Walk", "Short kick. Stay square.", "From stance, two kick-slides along a line. Freeze.", "Both slides are inside one yard. Hips still face the landmark.", "Shorten the kick."),
      step("Jog", "Same slides. A coach walks at you.", "Mirror a walking rusher for three slides.", "The chest stays between rusher and the cone that is the QB.", "Stay between."),
      step("Thud", "Punch after the feet, not before.", "One slide, then a two-hand fit on a shield.", "Feet are set before the hands hit.", "Feet, then hands."),
    ],
    speedUp: {
      how: "Let the rusher walk faster. Do not add a bull rush until the slide path is short.",
      stop: "Ankle roll on the cross-step, or a player who falls backward. Back to two slow slides.",
    },
    station: {
      setup: "A line on the ground for the slide. A cone 3 yards behind as the quarterback.",
      reps: "8 two-slide freezes. 4 slide-and-fit.",
      cue: "Short kick. Stay between.",
      stop: "Crossover twice: walk it. No live rush today if the feet cross.",
    },
  },
  {
    id: "ol-run-landmark",
    name: "Run-block landmark",
    phase: "position",
    positions: ["OL"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["A", "T"],
    metricLinks: [
      { label: "Through, block finish", detail: "T is Through. After the near-hip fit, drive through contact. Hands inside, feet moving. Do not wrap. The whistle-plus-one page is Through the block." },
      { label: "Med ball, later", detail: "A clean med-ball sequence (hips, then torso, then arms) is the same order as a finish. It is not a blocking score." },
    ],
    what: "On a run block the lineman aims for the defender’s near hip, the one closest to the play, and stays on that side. The finish is Through: drive, do not wrap.",
    why: "Blocking the wrong hip opens the gap the back is supposed to hit. The landmark is a hip, not the whole person.",
    demo: {
      correct: "First step to the near hip. Pads under the defender’s pads. After the fit, hands stay inside and the feet drive. No wrap.",
      eyes: ["First step at the near hip", "Helmet on the correct side of the defender", "Pads lower than the defender’s pads", "Feet moving on contact", "No reach that turns the back"],
      wrong: ["Aim at the chest and get washed", "Step away from the play", "Stop feet and shove"],
    },
    breakdown: [
      step("Walk", "Near hip. Play side.", "Walk to a bag. Fit the near hip. Freeze.", "Helmet is on the play-side edge of the bag.", "Near hip."),
      step("Jog", "Same aim. Do not drift.", "Three steps and a fit.", "The fit is still on that hip.", "Aim early."),
      step("Thud", "Fit and drive four steps. No wrap.", "Shield holder gives a thud. Lineman stays on the hip and drives.", "The shield does not cross the lineman’s face. Arms do not wrap.", "Drive. Do not wrap."),
    ],
    speedUp: {
      how: "Move the bag half a man over so the step must be lateral. Through on this block is a drive, not a wrap. Keep the jog until the aim is right.",
      stop: "Head down into the bag, or a stinger. Stop. This is a fit, not a collision contest.",
    },
    station: {
      setup: "One bag. A cone shows the play side so the near hip is obvious.",
      reps: "6 walk fits, 4 thud step-ups.",
      cue: "Near hip.",
      stop: "Wrong hip twice: walk to the cone first. Head down: stop.",
    },
  },
  {
    id: "ol-pull-path",
    name: "Pull path",
    phase: "position",
    positions: ["OL"],
    tier: "next",
    promoteFor: [],
    fastLetters: ["F"],
    metricLinks: [{ label: "No pull score", detail: "Facing the landmark at the end of the pull is the square-up skill. S in FAST is shoulder level, not that turn." }],
    what: "A pulling lineman takes a flat path down the line, then squares up. The path does not loop into the backfield.",
    why: "A deep loop is late and runs into the back. Flat and short is the whole skill.",
    demo: {
      correct: "Open step parallel to the line, shoulders square to the sideline, then hips square up at the landmark. Depth is one yard, not five.",
      eyes: ["First step flat, not back", "Shoulders stay over the toes", "Path stays within a yard of the line", "Square up at the landmark", "Eyes down the path, not at the ground"],
      wrong: ["Drop step into the backfield", "Loop behind the quarterback", "Arrive still facing the sideline"],
    },
    breakdown: [
      step("Walk", "Flat. Then square.", "Walk the pull to a cone at the hole. Square and freeze.", "The path never went more than a yard deep.", "Stay flat."),
      step("Jog", "Same path. No new depth.", "Jog the pull and fit a bag at the cone.", "The jog did not deepen the path.", "Flat, then square."),
      step("Live", "A back walks the same hole.", "Pull, square, and let the back pass on the correct shoulder.", "The back is not tripped by a deep pull.", "Square before the back arrives."),
    ],
    speedUp: {
      how: "Speed comes after the walk path is flat three times. A fast loop is still a miss.",
      stop: "Collision with the back. Reset the depth with a line on the ground.",
    },
    station: {
      setup: "Tape or a chalk line one yard off the ball. Cone at the hole.",
      reps: "6 walk pulls, 4 jog fits.",
      cue: "Flat, then square.",
      stop: "If a foot lands behind the line, walk it again.",
    },
  },
  {
    id: "ol-finish-block",
    name: "Through the block (drive + whistle+1)",
    phase: "position",
    positions: ["OL", "WR", "TE", "RB"],
    tier: "next",
    promoteFor: [],
    fastLetters: ["T"],
    metricLinks: [
      { label: "Through, block finish", detail: "T is Through. Offense finish: hands inside, feet keep moving, drive through contact, whistle plus one. No wrap. The tackle page is the other finish." },
    ],
    what: "T is Through for a blocker on the line, at receiver, tight end, or back. Hands stay inside, feet keep moving, and the player drives through contact until the whistle plus one step.",
    why: "A pop and a look loses the block as the runner arrives. Wrapping is the tackle finish. A block sustains. Whistle-plus-one is a clock a new coach can enforce.",
    demo: {
      correct: "After the fit, short steps keep coming. Hands stay inside. One more step on the whistle, then release. Nobody wraps.",
      eyes: ["Feet chopping after contact", "Hands inside the frame", "Eyes on the defender, not the back", "One step after the whistle", "No wrap around the body"],
      wrong: ["Hit and stand up", "Watch the ball and lose the block", "Wrap the defender like a tackle"],
    },
    breakdown: [
      step("Walk", "Hands inside. Drive. No wrap.", "Fit a bag. Hands inside, feet moving. Whistle, one more step, release.", "The extra step happens after the sound. Arms never wrap.", "Plus one. No wrap."),
      step("Jog", "Feet before you look.", "Jog fit, six foot-fires, whistle, plus one.", "Eyes never left the bag before the whistle.", "Eyes on the block."),
      step("Thud", "Same drive on a shield.", "Thud, feet keep moving, whistle, release. Still no wrap.", "The shield keeps moving until the whistle.", "Drive. Do not wrap."),
    ],
    speedUp: {
      how: "Blow the whistle later, not harder. Through on a block is a drive to whistle plus one. Speed does not add a wrap.",
      stop: "Hands to the face or neck, or a wrap that becomes a tackle. Restart and reset the hands to the chest plate.",
    },
    station: {
      setup: "Bag, whistle, one blocker. OL, WR, TE, or RB can take the same reps.",
      reps: "6 whistle-plus-one drives.",
      cue: "Drive. Plus one. No wrap.",
      stop: "Face, neck, or a wrap. Stop the rep and reset the hands.",
    },
  },
  {
    id: "dl-get-off",
    name: "Get-off",
    phase: "position",
    positions: ["DL"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F", "S"],
    metricLinks: [
      { label: "S is shoulder level", detail: "Pads stay ready in the hinge. Standing up on the get-off misses S." },
      { label: "40 first step", detail: "The 40 first-step cue is the same no-false-step rule. The get-off is that step aimed at a gap, not a finish line." },
    ],
    what: "The defensive lineman moves on the ball, not on the offensive lineman’s movement, and the first step enters the gap.",
    why: "Waiting to see the block is already a lost gap. A false step is a free release for the offense.",
    demo: {
      correct: "Still stance. Ball moves. The near foot replaces into the assigned gap. Pads stay down. Hands come after the foot.",
      eyes: ["Trigger is the ball", "No rocker step", "First step in the gap, not at the blocker", "Pads stay in the hinge", "Hands are second"],
      wrong: ["Jump up", "Step at the blocker’s chest", "Watch the quarterback and miss the snap"],
    },
    breakdown: [
      step("Walk", "Ball moves. You move.", "Coach moves a ball. One step into a chalk gap. Freeze.", "The foot lands in the gap marks.", "Step in the gap."),
      step("Jog", "Same step. Do not stand up.", "Three-step get-off and settle.", "The third step is not taller than the first.", "Stay in the hinge."),
      step("Live", "On the ball only.", "A center snaps to a manager. Get-off on that movement.", "No early go, no late go.", "See the ball."),
    ],
    speedUp: {
      how: "Speed the snap, not the stance height. If they stand up, they are too fast for their hinge.",
      stop: "Groin or hamstring on the first step. Shorten the step. No bull rush until the foot is in the gap.",
    },
    station: {
      setup: "Two cones as the gap. A ball on a stick or in a coach’s hand.",
      reps: "8 one-step get-offs, 4 three-step.",
      cue: "Ball. Then the gap.",
      stop: "False step twice: freeze the stance again.",
    },
  },
  {
    id: "dl-shed",
    name: "Hands and shed",
    phase: "position",
    positions: ["DL"],
    tier: "next",
    promoteFor: [],
    fastLetters: ["A"],
    metricLinks: [{ label: "Tracker, later", detail: "No dedicated shed score yet. The attack-contact skill is the pad shape. Shed is the hand job on top of it." }],
    what: "Hands strike the blocker’s chest plate, then throw that shoulder to open the gap. The lineman does not wrestle.",
    why: "Grabbing cloth in front of the pads stalls the feet. A shed is a push and a step, short enough to teach in five minutes.",
    demo: {
      correct: "Two hands inside, thumbs up, on the chest. One arm locks out and clears. The same-side foot replaces into the gap.",
      eyes: ["Hands inside, not on the shoulders first", "Thumbs up", "Lock out one side", "Foot replaces as the hand clears", "Eyes on the gap after the shed"],
      wrong: ["Bear hug", "Hands outside and wide", "Shed with no step"],
    },
    breakdown: [
      step("Walk", "Hands, then step.", "Fit a bag. Lock out the play-side arm. Step.", "The bag moves aside and the foot is in the gap.", "Step with the shed."),
      step("Jog", "Same hands. Do not hug.", "Jog fit and one shed.", "No grasp left on the bag.", "Lock out."),
      step("Thud", "Thud, shed, find the cone.", "Shield thud, shed, run to a cone 3 yards upfield.", "The cone is reached without a second wrestle.", "One shed. Then go."),
    ],
    speedUp: {
      how: "Add a second step after the shed before you add a harder thud.",
      stop: "Hands to the face. Reset to the chest plate. Neck pain stops the station.",
    },
    station: {
      setup: "Bag or shield. A cone in the gap.",
      reps: "6 walk sheds, 4 thud-and-go.",
      cue: "Lock out. Step.",
      stop: "Face contact or a hug that lasts. Reset.",
    },
  },
  {
    id: "dl-gap",
    name: "Gap integrity",
    phase: "position",
    positions: ["DL"],
    tier: "first",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [{ label: "No gap score", detail: "Owning the gap is the job. S in FAST is shoulder level, not “stay between the cones.”" }],
    what: "The lineman owns one gap. If blocked, they squeeze that gap. They do not chase a ball that left their gap.",
    why: "Two players in one gap leave another gap empty. A new coach can enforce this with cones. The rule is the gap, not the highlight.",
    demo: {
      correct: "The player’s body stays between the two cones that mark the gap until the ball crosses the line of scrimmage in that gap, or the whistle blows.",
      eyes: ["Shoulders between the cones", "No chase across the next cone", "Squeeze if pushed, do not spin out", "Eyes find the ball late, after the fit", "Whistle ends the ownership"],
      wrong: ["Follow the back across two gaps", "Spin out and leave the gap", "Stand up and look"],
    },
    breakdown: [
      step("Walk", "Stay between the cones.", "Walk pressure. A coach points to a fake ball. The player does not leave.", "The body is still in the cone gap.", "Own the gap."),
      step("Jog", "Squeeze, do not spin.", "Partner walks a block. Player squeezes and stays.", "The cones still frame the player.", "Squeeze."),
      step("Live", "The picture lies. The gap does not.", "Back runs away. Player stays until the whistle.", "No chase before the whistle.", "Whistle, then look."),
    ],
    speedUp: {
      how: "Move the fake faster. Leaving early at high speed is still a miss.",
      stop: "A spin that dumps the player. Reset to a walk squeeze.",
    },
    station: {
      setup: "Two cones, one gap, one defender.",
      reps: "6 stay-reps with a fake.",
      cue: "Cones are the job.",
      stop: "If they chase twice, walk the stay again. No tackling in this station.",
    },
  },
  {
    id: "lb-read-step",
    name: "Read step",
    phase: "position",
    positions: ["LB"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F"],
    metricLinks: [
      { label: "First step", detail: "The universal first-step skill is the foot. The read step aims that foot at a fit, after the eyes take a picture. S in FAST is shoulder level, not “shoulders square to the line.”" },
    ],
    what: "The linebacker reads the lineman’s first move, then steps to the fit. The eyes work before the feet commit downhill.",
    why: "A linebacker who runs at the snap without a picture fills the wrong gap. One slow picture beats a fast wrong step.",
    demo: {
      correct: "Still stance. Eyes on a guard or tackle. A short step to the fit that the blocker’s angle shows. Pads stay ready to attack.",
      eyes: ["Eyes on the lineman, not the quarterback first", "One picture, then the step", "Step toward the fit, not backward", "Shoulders square to the line", "No freeze after the picture"],
      wrong: ["Backpedal on a run read", "Guess and abandon the gap", "Watch the quarterback and miss the block"],
    },
    breakdown: [
      step("Walk", "Picture, then step.", "Coach points a hat left or right. Player steps to that cone and squares.", "The step matches the point. One step only.", "Step where it shows."),
      step("Jog", "Same read. Faster picture.", "A lineman walks a release. Linebacker fits the gap that opened.", "The fit is the open gap, not the man.", "Fit the gap."),
      step("Live", "Do not add a blitz.", "Half-speed read and a tag on a cone, not a tackle.", "The tag is on the correct cone.", "Trust the first picture."),
    ],
    speedUp: {
      how: "Shorten the time you hold the hat. If the step is wrong, slow the picture. Do not yell faster.",
      stop: "Collision with the fake blocker because the eyes dropped. Reset the picture.",
    },
    station: {
      setup: "Two cones as gaps. A coach with a hat or a hand.",
      reps: "8 read-and-steps.",
      cue: "See it. Step there.",
      stop: "Two wrong gaps: walk the point again.",
    },
  },
  {
    id: "lb-spill-force",
    name: "Spill and force",
    phase: "position",
    positions: ["LB"],
    tier: "next",
    promoteFor: [],
    fastLetters: ["A"],
    metricLinks: [{ label: "No force score", detail: "Facing the line is the fit. S in FAST is shoulder level, not that turn." }],
    what: "The force player keeps the ball inside. Spill means the ball is bounced outside only when that is the call. The shoulders stay square to the line.",
    why: "A linebacker who turns and runs with the ball gives up the cutback. Force is a landmark, an inside shoulder, not a chase.",
    demo: {
      correct: "The player’s inside shoulder is free. The ball carrier’s path is squeezed to the sideline or spilled to help, matching the call the coach stated before the rep.",
      eyes: ["Inside shoulder is the weapon", "Hips square, not turned upfield early", "Feet beat the ball to the landmark", "No duck inside under the block", "The call matches the path"],
      wrong: ["Turn and run upfield", "Dive inside and get kicked out", "Forget which call was live"],
    },
    breakdown: [
      step("Walk", "Inside shoulder. Stay square.", "Walk to a cone on the edge. Fit an imaginary ball with the inside shoulder.", "The chest still faces the line when the fit happens.", "Stay square."),
      step("Jog", "Beat the cone.", "Jog to the force cone before a walking back arrives.", "The player is there first, inside shoulder free.", "Beat the ball there."),
      step("Thud", "Fit the shield with the inside shoulder.", "Thud and settle. Do not chase upfield.", "The shield stays outside the shoulder.", "Inside shoulder."),
    ],
    speedUp: {
      how: "Let the back walk faster. If the linebacker turns the hips early, slow down.",
      stop: "A thud that becomes a tackle drill. This station ends at the fit.",
    },
    station: {
      setup: "One edge cone. State the call out loud: force inside, or spill.",
      reps: "6 walk fits, 4 jog races to the cone.",
      cue: "Inside shoulder free.",
      stop: "Wrong call: stop and restate it. Do not add a second defender.",
    },
  },
  {
    id: "lb-tackle-space",
    name: "Tackle in space",
    phase: "position",
    positions: ["LB"],
    tier: "next",
    promoteFor: [],
    fastLetters: ["T"],
    metricLinks: [
      { label: "Through the tackle", detail: "T is Through. Use the tackle page for wrap, cheek to the ball, and driving the legs. This page is only the extra problem of space: settle, then that finish." },
    ],
    what: "In space the linebacker settles the feet, squares, and then wraps. They do not dive from five yards away.",
    why: "A dive in space is a miss and a helmet to the ground. Settling looks slow to a new coach. It is the tackle.",
    demo: {
      correct: "The last two steps get shorter. Hips square. Then the wrap from the tackle-wrap skill. The ball carrier is in front, not beside.",
      eyes: ["Steps shorten before contact", "Hips square", "No leap", "Wrap after the settle", "Head out"],
      wrong: ["Full-speed dive", "Arm swipe", "Leave the feet early"],
    },
    breakdown: [
      step("Walk", "Shorten. Then wrap.", "Walk up to a bag. Two short steps. Wrap.", "The short steps are visible.", "Settle first."),
      step("Jog", "Same settle from a longer start.", "Jog 8 yards, settle, wrap the bag.", "Speed drops before the wrap.", "Shorten the last steps."),
      step("Thud", "Settle on a moving shield.", "Shield holder walks. Tackler settles and wraps.", "No dive. The wrap is on.", "Wrap, do not dive."),
    ],
    speedUp: {
      how: "Add distance, not a sprint finish. The last two steps stay short even when the start is faster.",
      stop: "A dive or a head to the ground. End live work. Go back to the bag.",
    },
    station: {
      setup: "Bag at the end of an 8-yard lane.",
      reps: "6 settle-and-wrap.",
      cue: "Short steps, then wrap.",
      stop: "Dive: stop the station’s live piece.",
    },
  },
  {
    id: "db-coverage-base",
    name: "Coverage base",
    phase: "position",
    positions: ["DB"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["S"],
    metricLinks: [
      { label: "S is shoulder level", detail: "Standing tall misses S. Press and off start from the athletic stance. Off coverage is just more space, the same knees and eyes." },
    ],
    what: "A simple coverage base: press is near the receiver with eyes on the hips; off is 7 yards with the same eyes. Youth-safe means no grab and no hand-fighting lesson yet.",
    why: "A backpedal with locked knees and eyes on the quarterback gets beaten on the first step. The base is the skill. The scheme can wait.",
    demo: {
      correct: "Feet alive, knees soft, eyes on the receiver’s hips. Press does not touch. Off is deep enough to see the release and still break.",
      eyes: ["Knees soft", "Eyes on hips, not the sky", "No hands on the receiver", "Weight mid-foot", "Able to turn either way"],
      wrong: ["Hands on the chest at the snap", "Standing tall", "Eyes in the backfield before the release"],
    },
    breakdown: [
      step("Walk", "Eyes on the hips. No hands.", "Mirror a walking receiver for 5 yards. Do not touch.", "The mirror matches without a grab.", "Eyes on the hips."),
      step("Jog", "Same mirror. Off or press, pick one and say it.", "Jog mirror. Coach calls press or off before the rep.", "The starting depth matches the call.", "Match the call."),
      step("Live", "Break on a hat, not a route tree.", "Receiver shows a hat left or right. Defender opens that way.", "The open matches the hat.", "Open to the hat."),
    ],
    speedUp: {
      how: "Faster feet in the mirror before any route. Grabbing is not a way to survive speed.",
      stop: "A hand on the face or a hold. Reset the no-hands rule.",
    },
    station: {
      setup: "A mark at the press spot and a mark at 7 yards.",
      reps: "6 mirrors. State press or off each time.",
      cue: "Hips. No hands.",
      stop: "A grab ends the rep. Walk the mirror.",
    },
  },
  {
    id: "db-hip-turn",
    name: "Hip turn",
    phase: "position",
    positions: ["DB"],
    tier: "next",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [{ label: "No hip score", detail: "The open step is a hip skill. S in FAST is shoulder level, not this turn." }],
    what: "When the receiver leaves, the defender turns the hips to run, then finds the ball. They do not backpedal forever and they do not spin in a circle.",
    why: "A flat-footed turn is a step late. A spin loses the receiver. One open step is the whole skill.",
    demo: {
      correct: "The defender opens the hip to the receiver’s path, runs, and stays on the inside or outside shoulder that the coach named.",
      eyes: ["One open step", "Hips face the path", "No extra spin", "Shoulder relationship stays", "Eyes find the receiver again after the turn"],
      wrong: ["Keep backpedaling after the receiver left", "Spin the wrong way", "Look for the ball and lose the man"],
    },
    breakdown: [
      step("Walk", "Open. Do not spin.", "Coach points. One open step and freeze.", "The chest faces the point. One step only.", "One open."),
      step("Jog", "Open and run three steps.", "Mirror a jog, then open when the receiver leaves.", "The turn is one step, then run.", "Open and go."),
      step("Live", "Find the man again.", "After the turn, point at the receiver.", "The point is immediate.", "Find the man."),
    ],
    speedUp: {
      how: "Delay the leave. A fast wrong turn is the miss we are preventing.",
      stop: "Ankle twist on the spin. Slow down and mark the open foot.",
    },
    station: {
      setup: "One receiver walking. No ball yet.",
      reps: "8 open-and-freeze, 4 jog turns.",
      cue: "One open step.",
      stop: "A spin: walk the freeze again.",
    },
  },
  {
    id: "db-contested",
    name: "Win the contested ball",
    phase: "position",
    positions: ["DB"],
    tier: "next",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [
      { label: "Catch the ball", detail: "Same hands as the catch skill: attack the ball at the high point. The extra rule is playing the ball, not the body." },
    ],
    what: "When the ball is in the air, the defender plays the ball at the high point. They do not grab the receiver to make up for late eyes.",
    why: "Grabbing is a foul and a bad habit. A volunteer coach can see hands on the ball versus hands on the shoulder.",
    demo: {
      correct: "Eyes go to the ball. The near arm extends through the ball. The body is beside the receiver, not on their back.",
      eyes: ["Eyes leave the man for the ball", "Hands attack the ball", "No grab of the jersey", "Feet still under the player", "Secure or knock the ball; do not wrestle"],
      wrong: ["Ride the receiver’s back", "Look at the man the whole way", "Two hands on the shoulder"],
    },
    breakdown: [
      step("Walk", "Play the ball.", "A coach holds a ball up. Defender attacks it with the near hand and catches or rakes.", "The hand hits the ball, not the coach.", "Hands on the ball."),
      step("Jog", "Find it late.", "Jog, coach throws a soft ball, defender plays it.", "Eyes are on the ball before the hands.", "See it."),
      step("Live", "A receiver is nearby, not holding.", "Both players play a soft ball. No grab.", "The ball is the only contact.", "Ball, not body."),
    ],
    speedUp: {
      how: "Throw a bit higher before you throw harder. High point first.",
      stop: "A grab, or a collision with heads. End the pair work. Back to the held ball.",
    },
    station: {
      setup: "One ball. Two players only if the solo catches are clean.",
      reps: "8 attacks on a held ball, 6 throws.",
      cue: "High point. Hands on the ball.",
      stop: "Jersey grab: the rep is over.",
    },
  },
  {
    id: "db-contain",
    name: "Outside contain",
    phase: "position",
    positions: ["DB"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["A"],
    metricLinks: [{ label: "Square up", detail: "Contain uses the square-up skill at the edge. That landmark is not the S in FAST. S is shoulder level." }],
    what: "The force defender on the edge keeps the ball inside. They do not run upfield and open the sideline.",
    why: "One turned shoulder is a 20-yard gain. The job is a landmark on the edge, the same idea as a linebacker force, from a wider spot.",
    demo: {
      correct: "The defender is outside the ball, chest square to the line, inside shoulder ready to fit. The sideline is at their back.",
      eyes: ["Outside leverage", "Chest square", "Inside shoulder free", "No upfield turn", "Fit, do not chase past"],
      wrong: ["Run up the sideline ahead of the ball", "Duck inside", "Turn the hips early"],
    },
    breakdown: [
      step("Walk", "Outside. Stay square.", "Walk to an edge cone and freeze square.", "The cone is outside the inside foot.", "Stay outside."),
      step("Jog", "Beat a walking back to the cone.", "Arrive first. Fit an imaginary shoulder.", "Arrival is before the walker.", "Beat them there."),
      step("Thud", "Inside shoulder on a shield.", "Thud and settle. Do not run upfield.", "The shield is inside.", "Inside shoulder."),
    ],
    speedUp: {
      how: "Faster walk from the back. If the defender turns upfield, slow the rep.",
      stop: "A thud that turns into open-field tackling. End at the fit.",
    },
    station: {
      setup: "One edge cone. Say “force” before each rep.",
      reps: "6 freezes, 4 races to the cone.",
      cue: "Outside. Square.",
      stop: "Upfield turn twice: walk the freeze.",
    },
  },
  {
    id: "wr-release",
    name: "Release",
    phase: "position",
    positions: ["WR", "TE"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F", "S"],
    metricLinks: [
      { label: "S is shoulder level", detail: "The first two steps stay at pad level, not upright. Then the stem rises." },
      { label: "First step", detail: "The release is the first-step skill off the line. A false step at the line is the same miss as a false step in the 40." },
    ],
    what: "The receiver leaves the line on the snap with a plan: a straight stem, or one move. They do not dance.",
    why: "A dance at the line is late and easy to grab. One release a volunteer can see is enough for grades 7–12.",
    demo: {
      correct: "Foot fire on the snap, pads low for two steps, then the stem up the field. One move at most. Eyes come up.",
      eyes: ["Movement on the snap", "No false step", "Two low steps, then rise", "One move, not three", "Hands ready, not pushing off a face"],
      wrong: ["Hop in place", "Two fakes before leaving", "Hands to the defender’s face"],
    },
    breakdown: [
      step("Walk", "Two steps, then the stem.", "Walk the release at a bag. Do not touch the face.", "The path is clear after two steps.", "Leave in two."),
      step("Jog", "Same release on a snap.", "Jog release to a cone 8 yards up.", "The cone is reached without a second move.", "One move."),
      step("Live", "A defender stands. No grab drill.", "Release past a stationary hand. Do not fight.", "The receiver is past without a hand-fight.", "Win with the feet."),
    ],
    speedUp: {
      how: "Speed the stem after the two-step shape is stable. Do not add moves to survive speed.",
      stop: "Hands to the face. Reset. This is not a fighting station.",
    },
    station: {
      setup: "A line and a cone at 8 yards. A bag to the side, not in the face.",
      reps: "8 releases.",
      cue: "Two steps, then go.",
      stop: "A third move or a face push. Walk it.",
    },
  },
  {
    id: "wr-catch-contact",
    name: "Catch through contact",
    phase: "position",
    positions: ["WR", "TE"],
    tier: "first",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [
      { label: "Catch the ball", detail: "Start from the catch skill. This page only adds a legal bump after the hands have the ball." },
    ],
    what: "The receiver catches with the hands, tucks, and stays balanced through a bump. They do not catch with the body because a hit is coming.",
    why: "Expecting a hit makes players basket-catch. The ball comes first. The bump is second.",
    demo: {
      correct: "Hands catch. Tuck to the ribs. A shoulder bump does not open the elbow. Feet stay under the player.",
      eyes: ["Hands catch first", "Tuck before the bump arrives", "Elbow stays down", "Feet do not cross on the bump", "No reach back at the defender"],
      wrong: ["Body catch", "Ball comes out on a light bump", "Turning to look for the hit"],
    },
    breakdown: [
      step("Walk", "Catch, tuck, then a tap.", "Soft catch. Coach taps the shoulder after the tuck.", "The ball stays.", "Tuck first."),
      step("Jog", "Same order on the move.", "Jog, catch, tuck, tap.", "The order does not change.", "Catch, then tuck."),
      step("Thud", "A shield bump after the tuck only.", "Catch, tuck, controlled bump, five yards.", "The ball is clamped at the end.", "Clamp."),
    ],
    speedUp: {
      how: "Harder bump only after the tuck is early. Do not throw harder and hit harder on the same day.",
      stop: "Ball to the face, or a bump before the catch. Separate them again.",
    },
    station: {
      setup: "One receiver, one ball, one coach with a hand or a shield.",
      reps: "8 catch-tuck-tap.",
      cue: "Catch. Tuck. Then the hit.",
      stop: "A drop on the tuck: remove the bump.",
    },
  },
  {
    id: "wr-force-block",
    name: "Force block",
    phase: "position",
    positions: ["WR", "TE"],
    tier: "next",
    promoteFor: [],
    fastLetters: ["A", "S"],
    metricLinks: [
      { label: "Attack contact", detail: "S is shoulder level: pads ready, not a dive and not upright. The force block adds the landmark: outside shoulder, keep the defender inside." },
      { label: "Through the block", detail: "T is Through. The drive to whistle plus one, with no wrap, is the Through the block page." },
    ],
    what: "The receiver blocks the outside force defender by staying in front, outside shoulder to outside shoulder, and keeping the feet moving.",
    why: "A missed stalk block is usually a player who stops the feet or dives. The back needs the edge sealed, not a highlight hit.",
    demo: {
      correct: "The blocker is between the defender and the sideline, chest square, feet chopping, hands inside. The defender’s outside shoulder is occupied.",
      eyes: ["Outside shoulder to outside shoulder", "Feet alive", "Hands inside", "No dive", "Square chest"],
      wrong: ["Stop and lunge", "Block inside and open the edge", "Cut block"],
    },
    breakdown: [
      step("Walk", "Outside shoulder. Feet move.", "Walk with a partner. Stay on the outside shoulder for 5 yards.", "The blocker’s chest stays outside.", "Stay outside."),
      step("Jog", "Same fit. No lunge.", "Jog and fit a bag on the outside edge.", "The bag does not cross the blocker’s face.", "Feet, do not dive."),
      step("Thud", "Thud and run the feet.", "Four foot-fires on the shield.", "The shield stays inside.", "Chop the feet."),
    ],
    speedUp: {
      how: "A walking defender tries to get outside. If the blocker dives, slow down.",
      stop: "A cut block or a block in the back. Stop and restate outside shoulder. No cut blocks in this station.",
    },
    station: {
      setup: "Bag on the edge. Sideline is marked.",
      reps: "6 walk mirrors, 4 thud fits.",
      cue: "Outside shoulder. Feet alive.",
      stop: "A dive or a cut. End the rep.",
    },
  },
  {
    id: "rb-ball-security",
    name: "Ball security",
    phase: "position",
    positions: ["RB"],
    tier: "first",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [
      { label: "Secure the ball", detail: "The universal carry is the clamp. This page is the back’s version: two hands through the hole, then the clamp." },
    ],
    what: "The back takes the handoff with two hands, covers the points, and only then clamps to the ribs. In the hole, two hands stay on the ball.",
    why: "One-handed carries at the mesh are how exchanges hit the ground. Two hands is a rule a new coach can see.",
    demo: {
      correct: "Eyes on the ball at the mesh. Two hands. Elbow clamps after the feet are through the line. The ball is on the side away from the first tackler.",
      eyes: ["Eyes on the ball at the mesh", "Two hands through the hole", "Clamp after the line", "Ball away from contact", "No early one-hand swing"],
      wrong: ["Looking into the hole before the ball is there", "One hand at the mesh", "Clamp so tight they miss the handoff"],
    },
    breakdown: [
      step("Walk", "Two hands. Eyes on the ball.", "Walk the mesh with a coach. Two hands, five yards, then clamp.", "The ball never has one hand in the first five yards.", "Two hands."),
      step("Jog", "Same hands at a jog.", "Jog mesh, two hands, clamp at a cone.", "The cone is where the clamp starts, not before.", "Clamp at the cone."),
      step("Live", "A tag after the clamp.", "Mesh, clamp, tag on the shoulder, finish.", "The ball stays.", "Squeeze on the tag."),
    ],
    speedUp: {
      how: "Faster mesh only after two hands are automatic. Speed does not earn a one-hand carry.",
      stop: "A ball on the ground. Slow the mesh. No pile.",
    },
    station: {
      setup: "A coach as the quarterback. A cone as the line of scrimmage.",
      reps: "8 mesh-and-clamps.",
      cue: "Two hands through the hole.",
      stop: "One hand before the cone: walk it.",
    },
  },
  {
    id: "rb-crease",
    name: "Hit the crease",
    phase: "position",
    positions: ["RB"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F"],
    metricLinks: [
      { label: "40 first step", detail: "Step 2 at the crease is a first-step skill with a landmark. Facing that cone is not the S in FAST. S is shoulder level." },
    ],
    what: "The back’s second step is aimed at the crease, the space the block opened, not at a defender and not three yards wide.",
    why: "Bouncing before step 2 turns a blocked play into a loss. The landmark is a spot on the ground.",
    demo: {
      correct: "Receive, one gather, second step at a cone in the crease. Shoulders square to that cone. No dance in the backfield.",
      eyes: ["Second step at the cone", "No false step sideways", "Shoulders square", "Ball secured while the step happens", "Downhill by step 2"],
      wrong: ["Bounce outside before looking", "Stop and wait", "Aim at a defender"],
    },
    breakdown: [
      step("Walk", "Step 2 at the cone.", "Walk the mesh and put step 2 on a marked spot.", "The foot lands on the mark.", "Step 2."),
      step("Jog", "Same mark. Do not add a move.", "Jog to the mark and through it.", "The path is straight after step 2.", "Downhill."),
      step("Live", "The cone moves one yard. The rule does not.", "Coach sets the cone late. Step 2 finds it.", "The foot adjusts once, then goes.", "One adjustment."),
    ],
    speedUp: {
      how: "Set the cone later. A faster bounce is still a bounce.",
      stop: "Collision with the quarterback because the path looped. Reset the mark closer.",
    },
    station: {
      setup: "Mesh spot and one cone 3 yards ahead.",
      reps: "8 step-2 landings.",
      cue: "Second step at the crease.",
      stop: "A sideways step: walk the mark.",
    },
  },
  {
    id: "rb-pass-pro",
    name: "Pass pro check",
    phase: "position",
    positions: ["RB"],
    tier: "next",
    promoteFor: [],
    fastLetters: ["A", "S"],
    metricLinks: [{ label: "S is shoulder level", detail: "The check uses the same pad level as attack contact. Not upright, and not a dive." }],
    what: "If a defender comes free, the back chips or checks them with a shoulder fit, then looks to release. They do not ignore a free runner.",
    why: "A free runner ends the play. The check is a short fit, the same pad level as attack contact, not a wrestling match.",
    demo: {
      correct: "Eyes see the free player. A short step and a shoulder fit. Feet alive. Then the eyes come back to the quarterback for a release if the coach has taught a release.",
      eyes: ["See the free player first", "Shoulder fit, head out", "Short, not a dive", "Feet under the fit", "Do not turn the back"],
      wrong: ["Look at the quarterback and miss the free runner", "Dive at the knees", "Grab and hold"],
    },
    breakdown: [
      step("Walk", "See him. Fit him.", "A walker comes free. Back fits the shoulder and settles.", "The walker is met, not chased in a circle.", "Fit the free player."),
      step("Jog", "Same fit. Then eyes back.", "Fit, two foot-fires, look to the coach.", "The look happens after the fit.", "Fit, then look."),
      step("Thud", "Thud on a shield only.", "One check. Whistle. Stop.", "The check is one fit.", "One fit."),
    ],
    speedUp: {
      how: "Send the walker later. Do not add a second rusher until one check is clean.",
      stop: "A dive at the knees or a hold. End the rep. Restate shoulder and head out.",
    },
    station: {
      setup: "One free walker. One back. No one else blitzing.",
      reps: "6 checks.",
      cue: "See the free player.",
      stop: "A missed free runner: walk it and point.",
    },
  },
  {
    id: "qb-exchange",
    name: "Center exchange",
    phase: "position",
    positions: ["QB"],
    tier: "first",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [{ label: "No snap score", detail: none }],
    what: "The quarterback receives the ball from the center with the throwing-hand pressure and the off hand closing over the top. Eyes are not required to see the ball if the hands are right.",
    why: "Fumbled snaps are hands, not talent. A new coach can watch the top hand and the seat of the ball.",
    demo: {
      correct: "Top hand presses up. Bottom hand rides under. The ball is brought to the belly. Elbows stay in. The center and quarterback are still.",
      eyes: ["Top hand firm", "Bottom hand closes", "Ball to the belly", "Elbows in, not wide", "No reach back that moves the center"],
      wrong: ["Loose top hand", "Eyes down and a late grab", "Standing up as the ball arrives"],
    },
    breakdown: [
      step("Walk", "Pressure up. Close the bottom.", "Slow snaps into the belly. Freeze.", "The ball is seated. No bobble.", "Top hand firm."),
      step("Jog", "Same hands at a cadence.", "Cadence, snap, seat, two steps.", "The seat happens before the steps.", "Seat it, then step."),
      step("Live", "A wet or fast snap, still the same hands.", "Faster snap. Same seat.", "No drop.", "Same hands."),
    ],
    speedUp: {
      how: "Faster cadence after ten clean seats. Do not add a play-action fake today.",
      stop: "A ball to the chin because the eyes jerked. Slow down. Check the top hand.",
    },
    station: {
      setup: "Center and quarterback. A pile of balls if snaps are wild, so you do not chase.",
      reps: "10 slow seats, 6 cadence seats.",
      cue: "Top hand. Belly.",
      stop: "Two bobbles: slow the snap. Do not add a dropback.",
    },
  },
  {
    id: "qb-eyes",
    name: "Pre-snap eyes",
    phase: "position",
    positions: ["QB"],
    tier: "first",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [{ label: "No eye score", detail: "Chin level is an eye cue. S in FAST is shoulder level, not this look." }],
    what: "Before the snap the quarterback looks at the picture they were told to see. After the snap they do not stare at one sideline. The eyes move on a plan.",
    why: "A stare tells the defense the play and makes the quarterback late. The plan can be as small as: middle, then one side.",
    demo: {
      correct: "Pre-snap look at a coach-named landmark. Snap. Eyes go to landmark one, then landmark two. The feet can be wrong today. The eyes cannot stick.",
      eyes: ["Pre-snap look matches the call", "Eyes move after the snap", "No stare at one sideline", "Chin level, not buried", "The look is a plan, not a panic"],
      wrong: ["Watch one receiver the whole play", "Eyes on the rush and never downfield", "Look at the coach after the snap"],
    },
    breakdown: [
      step("Walk", "Call the look out loud.", "Say “middle, then right.” Eyes do that. No throw.", "A partner can point to where the eyes went.", "Say it, then do it."),
      step("Jog", "Same words. Add a two-step drop.", "Drop and move the eyes. Still no throw.", "The eyes move during the drop.", "Eyes on the drop."),
      step("Live", "One throw only after the eyes moved.", "If the eyes stuck, do not throw. Reset.", "The throw comes after both looks, or not at all.", "No throw on a stare."),
    ],
    speedUp: {
      how: "Shorter time between the two looks. Do not add a third look until two are honest.",
      stop: "A throw into a crowd because the eyes froze. Take the ball out of the rep.",
    },
    station: {
      setup: "Two cones downfield as landmarks. No defense.",
      reps: "8 eye routes with the words out loud.",
      cue: "Middle, then the side. Say it.",
      stop: "A silent stare: they say the words again.",
    },
  },
  {
    id: "qb-progression",
    name: "1–2–checkdown",
    phase: "position",
    positions: ["QB"],
    tier: "next",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [{ label: "Not a playbook", detail: "This is a teaching structure, not a call sheet. Lion Lab does not store plays. One, two, then the short checkdown." }],
    what: "The quarterback looks at a first receiver, a second, then a short checkdown. If none is there, the ball is thrown away safely or tucked. There is no fifth look.",
    why: "New quarterbacks hold the ball because nobody told them the list ends. A three-item list is a skill. A playbook is not.",
    demo: {
      correct: "The coach names 1, 2, and the checkdown before the snap. The quarterback hits the first open one in that order, or throws the ball away past the line, not at a covered body.",
      eyes: ["The order is said before the snap", "1 before 2", "Checkdown is a person, not a panic", "No fifth look", "A throwaway is to the open grass, not a hero throw"],
      wrong: ["Stare at 1 while 2 is open", "Skip to a deep throw that was not in the list", "Dump the ball at a covered back’s feet"],
    },
    breakdown: [
      step("Walk", "Say 1, 2, check.", "Walk the drop. Point at each in order. No ball in the air.", "The point order matches the words.", "Say the order."),
      step("Jog", "Throw only to the one the coach leaves open.", "Coach covers one with a hat. Quarterback throws to the first open.", "The throw matches the first open in the list.", "First open."),
      step("Live", "If all are covered, throw it away.", "All covered. Ball goes to open grass past the line.", "No throw at a body.", "Throw it away."),
    ],
    speedUp: {
      how: "Cover the choice later. Do not add a fourth receiver.",
      stop: "A throw into a hat that means covered. Reset. This is not a scrimmage.",
    },
    station: {
      setup: "Three players or three cones: 1, 2, check. Hats to cover.",
      reps: "6 decisions.",
      cue: "1, 2, check. Then it is over.",
      stop: "A fourth look: take the ball and restart the words.",
    },
  },
  {
    id: "st-cover",
    name: "Cover through the whistle",
    phase: "team",
    positions: ["ST"],
    tier: "first",
    promoteFor: [],
    fastLetters: ["F", "T"],
    metricLinks: [
      { label: "Through, lane finish", detail: "T is Through. Stay in the lane until the whistle. This is not a tackle-only letter. Fit with the tackle finish only if the returner enters the lane." },
    ],
    what: "On a kick the cover player runs their lane through the whistle. They do not peel off to watch the returner in someone else’s lane.",
    why: "Lanes win coverage, not the fastest player to the ball from the wrong angle. A lane is a pair of cones a new coach can set.",
    demo: {
      correct: "The player stays between two cones, runs through the whistle, and fits only if the ball enters that lane. Pad level stays ready.",
      eyes: ["Body stays in the lane", "No early peel", "Through the whistle", "Fit only in the lane", "Head out if they arrive"],
      wrong: ["All players to the ball", "Stop and watch", "Leave the lane for a block"],
    },
    breakdown: [
      step("Walk", "Lane. Whistle. Stop.", "Walk the lane past the end cone.", "They are still in the lane at the whistle.", "Stay in it."),
      step("Jog", "Same lane at a jog.", "Jog and settle only if the coach rolls a ball into the lane.", "A ball outside the lane does not pull them out.", "Your lane only."),
      step("Live", "A returner jogs. Lanes hold.", "Fit only the player who enters the lane.", "Other lanes do not empty.", "Hold the lane."),
    ],
    speedUp: {
      how: "Faster jog after the walk lane is honest. Through means the lane to the whistle. Sprinting out of the lane is a miss.",
      stop: "A pile from abandoned lanes. Reset the cones and walk.",
    },
    station: {
      setup: "Two cones per player. Whistle.",
      reps: "4 walk lanes, 4 jog lanes.",
      cue: "Your lane. Through the whistle.",
      stop: "A peel: walk that player again.",
    },
  },
  {
    id: "st-kick-green",
    name: "Kick unless green",
    phase: "team",
    positions: ["ST", "K"],
    tier: "next",
    promoteFor: [],
    fastLetters: [],
    metricLinks: [{ label: "No punt score", detail: "This is a decision rule, not a distance contest. Do not chart hang time in Lion Lab." }],
    what: "The punter or kicker kicks unless the coach has given a green call to run or throw. Silence means kick.",
    why: "A youth special-teams mistake is a kicker who improvises. Green is a word. No green, no fake.",
    demo: {
      correct: "The player hears the snap and kicks, unless the coach said green before the play. A green call is repeated out loud by the kicker.",
      eyes: ["No green: the kick happens", "Green is said back before the snap", "No last-second fake", "Eyes on the spot, then the kick", "A bad snap is still not a run unless green was live"],
      wrong: ["Fake on a feeling", "Green whispered and not repeated", "Kick when green was clearly live"],
    },
    breakdown: [
      step("Walk", "Say the rule.", "Coach says nothing. Player says “kick” and walks through the motion.", "The word kick matches the silence.", "Silence means kick."),
      step("Jog", "Green is repeated.", "Coach says green. Player repeats it, then walks a keep.", "The repeat happens before the keep.", "Say green back."),
      step("Live", "Mix silence and green. No defense.", "Correct action each time.", "No surprise fake.", "Hear the call."),
    ],
    speedUp: {
      how: "Faster cadence. The rule does not get optional when the snap is faster.",
      stop: "A fake that was not green. Stop and restate the rule. No contact on this station.",
    },
    station: {
      setup: "Kicker and a snapper. No gunners needed.",
      reps: "6 calls, mixed.",
      cue: "Kick unless green.",
      stop: "A wrong action: freeze and say the rule.",
    },
  },
];

const byId = new Map(SKILLS.map((skill) => [skill.id, skill]));

export function skillById(id: string): Skill | undefined {
  return byId.get(id);
}

export function positionLabel(code: string): string {
  return LIBRARY_POSITIONS.find((position) => position.code === code)?.label ?? code;
}

export function appliesToPosition(skill: Skill, code: string): boolean {
  if (code === "ATH") return skill.positions.includes("ALL");
  if (code === "K") {
    return skill.positions.includes("ALL") || skill.positions.includes("ST") || skill.positions.includes("K");
  }
  return skill.positions.includes("ALL") || skill.positions.includes(code);
}

export function skillsForPosition(code: string): Skill[] {
  return SKILLS.filter((skill) => appliesToPosition(skill, code));
}

export function tierFor(skill: Skill, code: string): SkillTier {
  if (skill.promoteFor.includes(code)) return "first";
  if (code === "K" && skill.promoteFor.includes("ST")) return "first";
  return skill.tier;
}

export function positionPlan(code: string): { first: Skill[]; next: Skill[] } {
  const first: Skill[] = [];
  const next: Skill[] = [];
  for (const skill of skillsForPosition(code)) {
    if (tierFor(skill, code) === "first") first.push(skill);
    else next.push(skill);
  }
  return { first, next };
}

export function chipLabels(skill: Skill): string[] {
  if (skill.positions.includes("ALL")) return ["All"];
  return skill.positions.map(positionLabel);
}

export function weekKey(now = new Date()): string {
  const day = todayKey(now);
  const [year, month, date] = day.split("-").map(Number);
  const weekday = new Date(Date.UTC(year, month - 1, date)).getUTCDay();
  const mondayOffset = weekday === 0 ? -6 : 1 - weekday;
  return shiftDay(day, mondayOffset);
}

export const PHASES: { id: SkillPhase | "all"; label: string }[] = [
  { id: "all", label: "All phases" },
  { id: "fundamentals", label: "Fundamentals" },
  { id: "position", label: "Position" },
  { id: "team", label: "Team" },
];
