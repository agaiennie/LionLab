export const GLOSSARY_SECTIONS: { title: string; terms: { term: string; meaning: string }[] }[] = [
  {
    title: "How to read a result",
    terms: [
      {
        term: "Raw",
        meaning: "The stopwatch or the tape. The 40 raw is seconds. The med-ball raw is feet. Stance has no raw number.",
      },
      {
        term: "Form index",
        meaning: "Percent of the checklist that was solid on that rep. Missed items become the coaching cues.",
      },
      {
        term: "Adjusted ESTIMATE",
        meaning:
          "A coaching number that blends raw and form. It is not a second measurement. A clean rep keeps the raw number. A messy rep moves the estimate so a lucky clock does not look more repeatable than it was.",
      },
      {
        term: "Battery",
        meaning: "The 40, the 10 lb med-ball throw, and the athletic stance, read together.",
      },
      {
        term: "Retest target",
        meaning: "The next goal on the card. For a 40, 0.05s faster than the adjusted ESTIMATE after the missed cues are clean.",
      },
      {
        term: "RYG",
        meaning: "Red under 55, yellow 55–79, green 80 or better on a pose score. Tracking weak means the camera could not see the joints. It is not a fake green.",
      },
    ],
  },
  {
    title: "Lion Standard",
    terms: [
      {
        term: "Lion Standard",
        meaning: "Named rules a player can recite and a coach can teach. FAST is the locked snap cue.",
      },
      {
        term: "FAST",
        meaning:
          "First step. Attack. Shoulder level. Through — wrap if you’re tackling, drive if you’re blocking. One letter at a time after a miss. Through on a tackle is wrap, cheek to the ball, and drive the legs. Through on a block is hands inside, feet moving, drive, and whistle plus one.",
      },
      {
        term: "Lion teach method",
        meaning: "Demo, then Break down, then Speed up. Every skill page uses this order. Do not skip to live speed.",
      },
      {
        term: "Demo",
        meaning: "Show the correct look once. Name the coaching eyes and the common wrong looks before players move.",
      },
      {
        term: "Break down",
        meaning: "A numbered progression: walk, jog, thud, then live when the skill needs contact. Each step has one coach line, one player job, a success check, and one fail fix.",
      },
      {
        term: "Speed up",
        meaning: "Add pace only after the slow rep is clean. If the look breaks, slow down. Stop for pain, a stinger, or a whistle the player did not hear.",
      },
      {
        term: "Skill library",
        meaning: "The master list of skills a volunteer coach can teach. One page per skill. Position lists only link to those pages.",
      },
      {
        term: "Demo → rep → cue → reteach",
        meaning: "After a miss in a live period: show it once, run a guided rep, give one short cue, and use the same words when it breaks.",
      },
      {
        term: "Pad level",
        meaning: "Shoulder level, the S in FAST. Pads and shoulders ready, not upright. Technique and hinge, not “just get low.”",
      },
      {
        term: "Declared play",
        meaning: "Your job on this snap. Win your one landmark. Do not play everyone else's assignment.",
      },
    ],
  },
  {
    title: "Bodies and care",
    terms: [
      {
        term: "Mobility",
        meaning: "Controlled range and stability for football tasks. Farm-plain names. Not a yoga class.",
      },
      {
        term: "ATC",
        meaning: "The school athletic trainer. Return-to-play follows their rules. Lion Lab does not clear injuries.",
      },
      {
        term: "Stinger / burner",
        meaning: "Nerve-type arm shock from contact or neck position. Stop. Get the ATC. Do not shake it off as the lesson.",
      },
      {
        term: "COD",
        meaning: "Change of direction. Plant, cut, re-accelerate.",
      },
      {
        term: "Hinge",
        meaning: "Hips back, spine long. The pattern in Gate Hinge and Truck Hitch.",
      },
    ],
  },
  {
    title: "School and home",
    terms: [
      {
        term: "Study block",
        meaning: "The day's school work, timed or checked in minutes. Default goal is 25 minutes.",
      },
      {
        term: "Study gate",
        meaning:
          "To log a finished home athletic session, the study block is done or a parent leaves an override note. Field tests a coach logs are not gated. The line is: Train the body. Train the mind.",
      },
      {
        term: "Fuel habits",
        meaning: "Water, protein at meals, a sleep window, and no heavy junk before practice. Not a meal plan.",
      },
      {
        term: "Fit notes",
        meaning: "A plain read of the battery against the declared position. Strengths, gaps, and drills. Not a medical claim and not a depth chart.",
      },
    ],
  },
];
