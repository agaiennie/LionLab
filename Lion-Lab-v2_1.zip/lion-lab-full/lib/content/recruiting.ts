// Recruiting guide: which sports feed which football roles, what a non-athlete
// who fits looks like, and where girls' teams are a real source of players.
// Written for a school program recruiting inside its own building.
import type { RoleId } from "@/lib/position-fit";
import type { MetricId } from "@/lib/content/metrics";

export type RecruitProfile = {
  role: RoleId;
  headline: string;
  sports: { sport: string; why: string }[];
  girls: string;
  nonAthlete: string;
  tryout: MetricId[];
  tryoutNote: string;
};

export const RECRUIT_RULES = [
  "Recruit inside your own school and feeder programs: other teams' rosters, gym classes, band, clubs, the hallway. That is normal and encouraged.",
  "Do not recruit students from other schools to transfer for football. PIAA rules prohibit recruiting and transfers motivated by athletics, and the penalties land on the kid (lost eligibility), not the coach. Check with your athletic director before any contact that crosses a school line.",
  "Pennsylvania lets girls try out for and play on boys' teams, including football. Treat a girl who comes out like any other player: same tests, same fit engine, same standards. Confirm locker-room and supervision logistics with your athletic director before the first practice.",
  "Talk to the other coach first. A wrestling or basketball coach who feels raided will close the door. Frame it as sharing athletes: fall football builds their winter and spring athletes too.",
  "Academics first. Before a recruit's first practice, confirm they're passing. PIAA eligibility requires passing at least four full-credit subjects, checked weekly.",
];

export const RECRUIT_PROFILES: RecruitProfile[] = [
  {
    role: "QB",
    headline: "Throws well, stays calm, and other kids already listen to them.",
    sports: [
      { sport: "Baseball / softball (pitcher, catcher, shortstop)", why: "Arm action, quick release, and reading the play before it happens." },
      { sport: "Basketball (point guard)", why: "Vision, decisions under pressure, and running an offense." },
      { sport: "Soccer (center midfield)", why: "Scans the field and distributes; comfortable being the hub." },
    ],
    girls: "Softball pitchers and shortstops, basketball point guards.",
    nonAthlete: "The kid who organizes the group project, plays strategy games, or leads a band section. Calm, organized, and can throw a ball on a line in gym class.",
    tryout: ["FOOTBALL_THROW", "PRO_AGILITY", "SPLIT_10"],
    tryoutNote: "Then give them the QB Reads exam. Decision-making matters more than arm strength at this level.",
  },
  {
    role: "RB",
    headline: "Compact, quick, hard to catch, and not afraid of contact.",
    sports: [
      { sport: "Wrestling", why: "Low center of gravity, leg drive, and comfort with contact." },
      { sport: "Soccer (forward)", why: "Vision to find the hole and cut without slowing down." },
      { sport: "Track (100/200 m)", why: "Burst and top-end speed." },
    ],
    girls: "Rugby, wrestling, soccer forwards, sprinters.",
    nonAthlete: "The shorter, quick kid who never gets tagged in gym-class games. Size isn't the point here; balance and burst are.",
    tryout: ["SPLIT_10", "PRO_AGILITY", "BROAD_JUMP"],
    tryoutNote: "Add the single-leg balance test. Running backs who can't balance fall at the first touch.",
  },
  {
    role: "WR",
    headline: "Long, fast, and catches everything thrown at them.",
    sports: [
      { sport: "Basketball (guard / wing)", why: "Hands, jumping, and body position against a defender." },
      { sport: "Baseball / softball (outfield)", why: "Tracks a ball in the air." },
      { sport: "Track (sprints, long jump, high jump)", why: "Speed and jump." },
    ],
    girls: "Basketball guards, volleyball outside hitters (jump and ball tracking), track sprinters and jumpers, softball outfielders.",
    nonAthlete: "Tall, long-armed, and catches easily in gym class. Often a kid who runs well but was never pushed toward a team.",
    tryout: ["SPRINT_40", "VERTICAL", "PRO_AGILITY"],
    tryoutNote: "Add a simple catching station: 10 balls, count clean catches.",
  },
  {
    role: "TE",
    headline: "Big enough to block, athletic enough to catch.",
    sports: [
      { sport: "Basketball (forward / center)", why: "Size with hands and footwork." },
      { sport: "Volleyball", why: "Height and jumping with ball skills." },
      { sport: "Lacrosse", why: "Physical and used to contact while handling a ball." },
    ],
    girls: "Basketball forwards, volleyball middles.",
    nonAthlete: "One of the taller, solidly built kids in the grade who moves well. Might be a growth-spurt kid who stopped playing when they got clumsy — that phase passes.",
    tryout: ["BROAD_JUMP", "SPRINT_40", "VERTICAL"],
    tryoutNote: "Catching station plus the 10 lb rotational throw from the form battery.",
  },
  {
    role: "OL",
    headline: "The biggest kids in the building, with hips that can sit low.",
    sports: [
      { sport: "Wrestling (upper weights)", why: "Leverage, hand fighting, and a mean streak with rules." },
      { sport: "Track (shot put, discus)", why: "Hip power and throwing strength." },
      { sport: "Basketball (center)", why: "Size and footwork in a small space." },
    ],
    girls: "Throwers (shot/discus), wrestlers, rugby forwards.",
    nonAthlete: "Big kids who have never been asked. Farm kids who haul feed and hay every day are already strong. Band percussion carries heavy gear too. Size is the entry ticket; teachable attitude does the rest.",
    tryout: ["SPLIT_10", "MEDBALL_CHEST", "SQUAT_SCORE"],
    tryoutNote: "Add the ankle knee-to-wall test. Tight ankles are the #1 reason big kids can't get into a stance.",
  },
  {
    role: "DT",
    headline: "Heavy, quick off the ball, and strong hands.",
    sports: [
      { sport: "Wrestling", why: "Hand fighting and leverage — the same fight as the line of scrimmage." },
      { sport: "Track (throws)", why: "Explosive hips." },
    ],
    girls: "Wrestlers, throwers, rugby props.",
    nonAthlete: "Same as offensive line, but the kid who moves first. Watch who reacts fastest in a get-off drill.",
    tryout: ["SPLIT_10", "MEDBALL_CHEST", "BROAD_JUMP"],
    tryoutNote: "The 10-yard burst matters more than the 40 here.",
  },
  {
    role: "DE",
    headline: "Long, quick, and can bend around a blocker.",
    sports: [
      { sport: "Basketball (forward)", why: "Length and footwork." },
      { sport: "Wrestling", why: "Hand fighting and hips." },
      { sport: "Lacrosse / hockey", why: "Contact at speed." },
    ],
    girls: "Basketball forwards, lacrosse defenders, wrestlers.",
    nonAthlete: "Tall, lean kid who is quicker than they look. Often all arms and legs in 7th grade.",
    tryout: ["SPLIT_10", "PRO_AGILITY", "BROAD_JUMP"],
    tryoutNote: "Add the single-leg balance test. Edge players need balance to bend.",
  },
  {
    role: "MLB",
    headline: "The defensive quarterback: smart, loud, and a sure tackler.",
    sports: [
      { sport: "Wrestling", why: "Contact, leverage, and toughness." },
      { sport: "Baseball / softball (catcher)", why: "Sees the whole field and calls it out." },
      { sport: "Lacrosse / field hockey", why: "Reads the play and closes space." },
      { sport: "Basketball (defense)", why: "Lateral movement and communication." },
    ],
    girls: "Lacrosse and field hockey defenders, catchers, wrestlers, rugby.",
    nonAthlete: "A leader who talks — the kid other kids follow. Needs to be willing to learn the defense cold.",
    tryout: ["PRO_AGILITY", "SPLIT_10", "BROAD_JUMP"],
    tryoutNote: "Give the MLB Fits exam. This job is half brain.",
  },
  {
    role: "OLB",
    headline: "Runs sideline to sideline and sets the edge.",
    sports: [
      { sport: "Lacrosse", why: "Contact in space." },
      { sport: "Soccer (defender)", why: "Angles and pursuit." },
      { sport: "Wrestling", why: "Tackling mechanics transfer directly." },
    ],
    girls: "Lacrosse, soccer defenders, rugby.",
    nonAthlete: "Wiry, quick kid who likes to chase.",
    tryout: ["PRO_AGILITY", "SPRINT_40", "BROAD_JUMP"],
    tryoutNote: "",
  },
  {
    role: "CB",
    headline: "Fast feet, loose hips, and short memory.",
    sports: [
      { sport: "Soccer", why: "Backpedal, turn, and footwork." },
      { sport: "Basketball (guard defense)", why: "Mirroring an opponent laterally." },
      { sport: "Track (sprints, hurdles)", why: "Speed and hip mobility." },
    ],
    girls: "Soccer, basketball guards, sprinters and hurdlers.",
    nonAthlete: "Fast kid who's competitive about it. Doesn't need size at this level.",
    tryout: ["SPRINT_40", "PRO_AGILITY", "BALANCE_SL"],
    tryoutNote: "Hip mobility matters: run the deep squat check too.",
  },
  {
    role: "S",
    headline: "Range, eyes on the ball, and a sure tackle as the last line.",
    sports: [
      { sport: "Baseball / softball (center field)", why: "Reads the ball off the bat and takes the right angle." },
      { sport: "Basketball", why: "Anticipation and jumping." },
      { sport: "Soccer (sweeper)", why: "Reads the whole field." },
    ],
    girls: "Center fielders, basketball, soccer.",
    nonAthlete: "The quick kid who's also a thinker: anticipates where things are going.",
    tryout: ["SPRINT_40", "PRO_AGILITY", "VERTICAL"],
    tryoutNote: "",
  },
];

export const KICKER_NOTE =
  "Kicker/punter isn't scored by the fit engine — run a kicking tryout. Soccer players (boys and girls) are the obvious source, and many girls who play high school football start as kickers.";

export const PROFILE_BY_ROLE = Object.fromEntries(RECRUIT_PROFILES.map((p) => [p.role, p])) as Record<RoleId, RecruitProfile>;

export const PROSPECT_STATUSES = [
  { id: "NEW", label: "New" },
  { id: "CONTACTED", label: "Contacted" },
  { id: "TRYOUT", label: "Tryout set" },
  { id: "JOINED", label: "Joined" },
  { id: "NOT_NOW", label: "Not now" },
] as const;
