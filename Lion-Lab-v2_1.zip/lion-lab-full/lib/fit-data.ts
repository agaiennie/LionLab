// Loads roster numbers from the database into the shape the position-fit engine wants.
import { prisma } from "@/lib/db";
import { METRIC_BY_ID, isMetricId, type MetricId } from "@/lib/content/metrics";
import {
  DEFAULT_DEPTH_NEEDS,
  rolesWithOverrides,
  type FactorKey,
  type FitAthlete,
  type RoleId,
  type WeightOverrides,
} from "@/lib/position-fit";
import { parsePositions } from "@/lib/scoring";

export const QB_EXAM_SLUG = "qb-reads";
export const MLB_EXAM_SLUG = "mlb-fits";
export const CAPTAIN_EXAM_SLUG = "captain-standard";

export type LatestMetric = {
  metric: MetricId;
  /** Combined value used for fit (sided tests average L and R). */
  value: number;
  left?: number;
  right?: number;
  recordedOn: Date;
  source: string;
};

type Row = { metric: string; value: number; side: string; recordedOn: Date; source: string };

/** Latest value per metric (and per side). Rows must be newest first. */
export function latestMetrics(rows: Row[]): Partial<Record<MetricId, LatestMetric>> {
  const out: Partial<Record<MetricId, LatestMetric>> = {};
  const seen = new Set<string>();
  for (const row of rows) {
    if (!isMetricId(row.metric)) continue;
    const key = `${row.metric}:${row.side}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const def = METRIC_BY_ID[row.metric];
    const current = out[row.metric] ?? { metric: row.metric, value: row.value, recordedOn: row.recordedOn, source: row.source };
    if (def.sided) {
      if (row.side === "L") current.left = row.value;
      else if (row.side === "R") current.right = row.value;
      else current.left = current.right = row.value;
      const sides = [current.left, current.right].filter((v): v is number => v != null);
      current.value = sides.reduce((a, b) => a + b, 0) / sides.length;
    } else {
      current.value = row.value;
    }
    if (row.recordedOn > current.recordedOn) current.recordedOn = row.recordedOn;
    out[row.metric] = current;
  }
  return out;
}

export async function getTeamSetting() {
  return prisma.teamSetting.upsert({ where: { id: "team" }, update: {}, create: { id: "team" } });
}

export function parseJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function loadFitConfig() {
  const team = await getTeamSetting();
  const overrides = parseJson<WeightOverrides>(team.fitWeights, {});
  const needs = { ...DEFAULT_DEPTH_NEEDS, ...parseJson<Partial<Record<RoleId, number>>>(team.depthNeeds, {}) };
  return { team, overrides, needs, roles: rolesWithOverrides(overrides) };
}

export async function loadFitRoster(): Promise<(FitAthlete & { heightInches: number; weightLbs: number; latest: Partial<Record<MetricId, LatestMetric>> })[]> {
  const athletes = await prisma.athleteProfile.findMany({
    where: { user: { status: "ACTIVE" } },
    include: {
      user: { select: { name: true } },
      measurements: { orderBy: { recordedOn: "desc" } },
      sessions: { orderBy: { recordedOn: "desc" } },
      examAttempts: { orderBy: { createdAt: "desc" }, include: { exam: { select: { slug: true } } } },
    },
    orderBy: { user: { name: "asc" } },
  });

  return athletes.map((a) => {
    const latest = latestMetrics(a.measurements);
    const values: Partial<Record<FactorKey, number>> = {
      HEIGHT: a.heightInches,
      WEIGHT: a.weightLbs,
    };
    for (const m of Object.values(latest)) values[m.metric] = m.value;

    // Fold in the older form battery: the 40 clock and the 10 lb rotational throw.
    const forty = a.sessions.find((s) => s.testType === "FORTY" && s.rawValue != null);
    if (forty?.rawValue != null) {
      const measured = latest.SPRINT_40;
      if (!measured || forty.recordedOn > measured.recordedOn) values.SPRINT_40 = forty.rawValue;
    }
    const med = a.sessions.find((s) => s.testType === "MEDBALL" && s.rawValue != null);
    if (med?.rawValue != null) values.MEDBALL_ROT = med.rawValue;

    const qb = a.examAttempts.find((x) => x.exam.slug === QB_EXAM_SLUG);
    if (qb) values.EXAM_QB = qb.percent;
    const mlb = a.examAttempts.find((x) => x.exam.slug === MLB_EXAM_SLUG);
    if (mlb) values.EXAM_MLB = mlb.percent;

    return {
      id: a.id,
      name: a.user.name,
      grade: a.grade,
      positions: parsePositions(a.positions),
      values,
      heightInches: a.heightInches,
      weightLbs: a.weightLbs,
      latest,
    };
  });
}

export async function loadAthleteLatest(athleteId: string) {
  const rows = await prisma.measurement.findMany({
    where: { athleteId },
    orderBy: { recordedOn: "desc" },
  });
  return { rows, latest: latestMetrics(rows) };
}
