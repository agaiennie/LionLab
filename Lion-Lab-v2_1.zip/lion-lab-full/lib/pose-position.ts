const KNOWN = new Set(["General", "OL", "DL", "LB", "DB", "WR", "RB", "QB", "TE", "ST"]);

/** Pose library positions. Kicker and ATH use the General set. */
export function toPosePosition(code: string | undefined): string {
  if (!code || code === "K" || code === "ATH") return "General";
  return KNOWN.has(code) ? code : "General";
}
