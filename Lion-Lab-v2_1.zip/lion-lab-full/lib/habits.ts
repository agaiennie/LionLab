export type DayFlag = {
  day: string;
  studyMinutes: number;
  trained: boolean;
};

export const STUDY_GATE_LINE = "Train the body. Train the mind.";

export const STUDY_GATE_DETAIL =
  "Finish today's study block, or ask a parent to leave a note, before this home session counts.";

export function todayKey(now = new Date()): string {
  return now.toISOString().slice(0, 10);
}

/** Phone-local calendar day, YYYY-MM-DD. */
export function localDay(now = new Date()): string {
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const date = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${date}`;
}

export function shiftDay(day: string, delta: number): string {
  const [year, month, date] = day.split("-").map(Number);
  const utc = new Date(Date.UTC(year, month - 1, date));
  utc.setUTCDate(utc.getUTCDate() + delta);
  return utc.toISOString().slice(0, 10);
}

/** Accept the phone's local date if it is today or yesterday in UTC. */
export function acceptedDay(day: string, now = new Date()): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return null;
  const today = todayKey(now);
  if (day === today || day === shiftDay(today, -1) || day === shiftDay(today, 1)) return day;
  return null;
}

export function studyComplete(minutes: number, goal: number): boolean {
  return minutes >= goal;
}

export function studyGateBlocks(input: {
  enabled: boolean;
  studyMinutes: number;
  goal: number;
  override: string;
}): boolean {
  if (!input.enabled) return false;
  if (input.override.trim().length > 0) return false;
  return !studyComplete(input.studyMinutes, input.goal);
}

export function complianceStreak(days: DayFlag[], today: string, goal: number): number {
  const byDay = new Map(days.map((day) => [day.day, day]));
  const complete = (day: string) => {
    const row = byDay.get(day);
    return Boolean(row && studyComplete(row.studyMinutes, goal) && row.trained);
  };
  let cursor = complete(today) ? today : shiftDay(today, -1);
  let count = 0;
  while (count < 120 && complete(cursor)) {
    count += 1;
    cursor = shiftDay(cursor, -1);
  }
  return count;
}

export function lastStudyDay(days: { day: string; studyMinutes: number }[], goal: number): string | null {
  const done = days.filter((day) => studyComplete(day.studyMinutes, goal)).map((day) => day.day);
  if (done.length === 0) return null;
  return done.sort().at(-1) ?? null;
}
