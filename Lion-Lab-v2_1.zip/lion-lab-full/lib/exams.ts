// Exam helpers. The grading math at the top is pure (unit-tested in
// lib/exams.test.ts). Database helpers import Prisma lazily so the pure part
// can be tested without a database.

import type { ExamAudience } from "@/lib/content/exam-bank";

export const QB_EXAM_SLUG = "qb-reads";
export const MLB_EXAM_SLUG = "mlb-fits";
export const CAPTAIN_EXAM_SLUG = "captain-standard";

export type GradeResult = {
  correct: number;
  total: number;
  percent: number;
  passed: boolean;
  /** One entry per question: true when the chosen answer matched the key. */
  results: boolean[];
};

/**
 * Grade answers against the key. `answers[i]` is the chosen choice index for
 * `questions[i]` (null / missing / out of range counts as wrong).
 * Percent is rounded to a whole number. Passing is percent >= passPercent.
 * An exam with no questions never passes.
 */
export function gradeAnswers(
  questions: readonly { answerIndex: number }[],
  answers: readonly (number | null | undefined)[],
  passPercent: number,
): GradeResult {
  const results = questions.map((question, i) => {
    const chosen = answers[i];
    return typeof chosen === "number" && Number.isInteger(chosen) && chosen === question.answerIndex;
  });
  const correct = results.filter(Boolean).length;
  const total = questions.length;
  const percent = total === 0 ? 0 : Math.round((correct / total) * 100);
  return { correct, total, percent, passed: total > 0 && percent >= passPercent, results };
}

/** Parse the JSON choices column. Bad data comes back as an empty list. */
export function parseChoices(value: string): string[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map((item) => String(item)) : [];
  } catch {
    return [];
  }
}

/** Parse the JSON answers column of an attempt. */
export function parseAnswers(value: string): number[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map((item) => (typeof item === "number" ? item : -1)) : [];
  } catch {
    return [];
  }
}

export const AUDIENCE_LABEL: Record<string, string> = {
  QB: "Quarterbacks",
  MLB: "Middle linebackers",
  CAPTAIN: "Captains",
  ALL: "Everyone",
};

/**
 * Is this exam expected of an athlete with these positions?
 * QB exam -> QBs. MLB exam -> LBs. Captain's exam -> anyone who wants the C.
 */
export function examRequiredFor(audience: ExamAudience | string, positions: readonly string[]): boolean {
  if (audience === "QB") return positions.includes("QB");
  if (audience === "MLB") return positions.includes("LB");
  return audience === "ALL";
}

export type AttemptLite = { percent: number; passed: boolean; createdAt: Date };

export function summarizeAttempts(attempts: readonly AttemptLite[]) {
  if (attempts.length === 0) return null;
  const sorted = [...attempts].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  const latest = sorted[0]!;
  const best = Math.max(...sorted.map((a) => a.percent));
  return {
    latestPercent: latest.percent,
    latestPassed: latest.passed,
    bestPercent: best,
    everPassed: sorted.some((a) => a.passed),
    attempts: sorted.length,
    lastTakenAt: latest.createdAt,
  };
}

export type ExamSummaryRow = {
  examId: string;
  slug: string;
  title: string;
  audience: string;
  passPercent: number;
  latestPercent: number;
  latestPassed: boolean;
  bestPercent: number;
  everPassed: boolean;
  attempts: number;
  lastTakenAt: Date;
};

/** Latest and best per exam for one athlete. Only exams they have taken. */
export async function examSummaryForAthlete(athleteId: string): Promise<ExamSummaryRow[]> {
  const { prisma } = await import("@/lib/db");
  const attempts = await prisma.examAttempt.findMany({
    where: { athleteId },
    orderBy: { createdAt: "desc" },
    include: { exam: { select: { id: true, slug: true, title: true, audience: true, passPercent: true } } },
  });
  const byExam = new Map<string, typeof attempts>();
  for (const attempt of attempts) {
    const list = byExam.get(attempt.examId) ?? [];
    list.push(attempt);
    byExam.set(attempt.examId, list);
  }
  const rows: ExamSummaryRow[] = [];
  for (const list of byExam.values()) {
    const summary = summarizeAttempts(list);
    const exam = list[0]!.exam;
    if (!summary) continue;
    rows.push({
      examId: exam.id,
      slug: exam.slug,
      title: exam.title,
      audience: exam.audience,
      passPercent: exam.passPercent,
      ...summary,
    });
  }
  return rows.sort((a, b) => a.title.localeCompare(b.title));
}

/**
 * Leadership readiness from exams. Percents are the LATEST attempt (same rule
 * the position-fit engine uses); null when never taken. passedSlugs lists
 * exams with at least one passing attempt.
 */
export async function leadershipReadiness(athleteId: string): Promise<{
  captainPercent: number | null;
  qbPercent: number | null;
  mlbPercent: number | null;
  passedSlugs: string[];
}> {
  const rows = await examSummaryForAthlete(athleteId);
  const latest = (slug: string) => rows.find((row) => row.slug === slug)?.latestPercent ?? null;
  return {
    captainPercent: latest(CAPTAIN_EXAM_SLUG),
    qbPercent: latest(QB_EXAM_SLUG),
    mlbPercent: latest(MLB_EXAM_SLUG),
    passedSlugs: rows.filter((row) => row.everPassed).map((row) => row.slug),
  };
}
