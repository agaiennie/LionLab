import { prisma } from "@/lib/db";
import { formatHeight, formatRecordedOn } from "@/lib/format";
import {
  parsePassedIds,
  parsePositions,
  positionLabel,
  scoreTest,
  type TestType,
} from "@/lib/scoring";

const sessionInclude = {
  recordedBy: { select: { name: true } },
} as const;

export type SessionRecord = {
  id: string;
  testType: TestType;
  rawValue: number | null;
  passedIds: string[];
  notes: string;
  recordedOn: string;
  recordedOnLabel: string;
  recordedBy: string;
  scored: ReturnType<typeof scoreTest>;
};

export type AthleteRecord = {
  id: string;
  userId: string;
  name: string;
  email: string;
  grade: number;
  positions: string[];
  positionLabels: string[];
  heightInches: number;
  heightLabel: string;
  weightLbs: number;
  /** GOOD | WATCH | HOLD — academics come first. */
  academicStatus: string;
  sessions: SessionRecord[];
};

function mapSession(session: {
  id: string;
  testType: string;
  rawValue: number | null;
  passedIds: string;
  notes: string;
  recordedOn: Date;
  recordedBy: { name: string };
}): SessionRecord {
  const testType = session.testType as TestType;
  const passedIds = parsePassedIds(session.passedIds);
  return {
    id: session.id,
    testType,
    rawValue: session.rawValue,
    passedIds,
    notes: session.notes,
    recordedOn: session.recordedOn.toISOString(),
    recordedOnLabel: formatRecordedOn(session.recordedOn.toISOString()),
    recordedBy: session.recordedBy.name,
    scored: scoreTest(testType, session.rawValue, passedIds),
  };
}

function mapAthlete(athlete: {
  id: string;
  userId: string;
  grade: number;
  positions: string;
  heightInches: number;
  weightLbs: number;
  academicStatus: string;
  user: { name: string; email: string };
  sessions: {
    id: string;
    testType: string;
    rawValue: number | null;
    passedIds: string;
    notes: string;
    recordedOn: Date;
    recordedBy: { name: string };
  }[];
}): AthleteRecord {
  const positions = parsePositions(athlete.positions);
  return {
    id: athlete.id,
    userId: athlete.userId,
    name: athlete.user.name,
    email: athlete.user.email,
    grade: athlete.grade,
    positions,
    positionLabels: positions.map(positionLabel),
    heightInches: athlete.heightInches,
    heightLabel: formatHeight(athlete.heightInches),
    weightLbs: athlete.weightLbs,
    academicStatus: athlete.academicStatus,
    sessions: athlete.sessions.map(mapSession),
  };
}

const athleteInclude = {
  user: { select: { name: true, email: true } },
  sessions: {
    orderBy: { recordedOn: "desc" as const },
    include: sessionInclude,
  },
};

export async function listAthletes(): Promise<AthleteRecord[]> {
  const athletes = await prisma.athleteProfile.findMany({
    where: { user: { status: "ACTIVE" } },
    include: athleteInclude,
    orderBy: { user: { name: "asc" } },
  });
  return athletes.map(mapAthlete);
}

export async function getAthlete(id: string): Promise<AthleteRecord | null> {
  const athlete = await prisma.athleteProfile.findUnique({
    where: { id },
    include: athleteInclude,
  });
  return athlete ? mapAthlete(athlete) : null;
}

export async function getAthleteByUserId(userId: string): Promise<AthleteRecord | null> {
  const athlete = await prisma.athleteProfile.findUnique({
    where: { userId },
    include: athleteInclude,
  });
  return athlete ? mapAthlete(athlete) : null;
}

export function latestByType(athlete: AthleteRecord, type: TestType) {
  return athlete.sessions.find((session) => session.testType === type) ?? null;
}

export async function getSessionForAthlete(athleteId: string, sessionId: string) {
  const session = await prisma.testSession.findFirst({
    where: { id: sessionId, athleteId },
    include: sessionInclude,
  });
  return session ? mapSession(session) : null;
}
