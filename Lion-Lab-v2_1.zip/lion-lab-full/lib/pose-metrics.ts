// Pure pose math for the camera lab. No DOM, no React: unit-tested in lib/pose-metrics.test.ts.
//
// Landmarks follow MediaPipe Pose (33 points, normalized x/y in 0..1, y grows DOWN the frame).
// Normalized x and y are scaled by different pixel counts, so callers should pass landmarks
// through `toAspect(landmarks, width / height)` before measuring angles or distances.

export type Pt = { x: number; y: number; z?: number; visibility?: number };

export const LM = {
  NOSE: 0,
  L_SHOULDER: 11,
  R_SHOULDER: 12,
  L_ELBOW: 13,
  R_ELBOW: 14,
  L_WRIST: 15,
  R_WRIST: 16,
  L_HIP: 23,
  R_HIP: 24,
  L_KNEE: 25,
  R_KNEE: 26,
  L_ANKLE: 27,
  R_ANKLE: 28,
  L_HEEL: 29,
  R_HEEL: 30,
  L_FOOT: 31,
  R_FOOT: 32,
} as const;

export const MIN_VIS = 0.45;

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

export function vis(p: Pt | undefined | null): number {
  if (!p) return 0;
  return p.visibility ?? 1;
}

export function visible(points: (Pt | undefined | null)[], min = MIN_VIS): boolean {
  return points.every((p) => vis(p) >= min);
}

/** Scale x by width/height so one unit means the same distance on both axes. */
export function toAspect(landmarks: Pt[], aspect: number): Pt[] {
  return landmarks.map((p) => ({ ...p, x: p.x * aspect }));
}

export function dist(a: Pt, b: Pt): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

export function mid(a: Pt, b: Pt): Pt {
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, visibility: Math.min(vis(a), vis(b)) };
}

/** 2D angle at B formed by A-B-C, degrees 0..180. Null when a segment has no length. */
export function angleDeg(a: Pt, b: Pt, c: Pt): number | null {
  const bax = a.x - b.x;
  const bay = a.y - b.y;
  const bcx = c.x - b.x;
  const bcy = c.y - b.y;
  const mag = Math.hypot(bax, bay) * Math.hypot(bcx, bcy);
  if (mag < 1e-9) return null;
  const cos = clamp((bax * bcx + bay * bcy) / mag, -1, 1);
  return (Math.acos(cos) * 180) / Math.PI;
}

/** Angle of the line from `lower` to `upper` away from straight up, degrees 0..180. */
export function leanFromVertical(upper: Pt, lower: Pt): number {
  const dx = upper.x - lower.x;
  const dy = lower.y - upper.y; // positive when upper is above lower
  return (Math.atan2(Math.abs(dx), dy) * 180) / Math.PI;
}

/** Shoulder-mid to hip-mid distance. */
export function torsoLength(lm: Pt[]): number {
  return dist(mid(lm[LM.L_SHOULDER], lm[LM.R_SHOULDER]), mid(lm[LM.L_HIP], lm[LM.R_HIP]));
}

// ---------------------------------------------------------------------------
// Single-leg balance: foot-lift state machine + sway
// ---------------------------------------------------------------------------

export const BALANCE = {
  /** Lifted ankle must be this far above the standing ankle (fraction of leg length) to start. */
  LIFT_ON: 0.12,
  /** Clock stops when the gap falls under this (foot back down). Gap between ON/OFF = hysteresis. */
  LIFT_OFF: 0.05,
  /** Consecutive frames needed to flip state (kills single-frame jitter). */
  FRAMES_ON: 3,
  FRAMES_OFF: 3,
  CAP_MS: 30_000,
  /** Tracking lost this long while lifted = stop the clock. */
  LOST_MS: 1500,
  /** Sway ignores the first moments after lift-off while the athlete settles. */
  SETTLE_MS: 300,
} as const;

export type Side = "L" | "R";

export type BalanceState = {
  phase: "waiting" | "lifted" | "done";
  /** Leg the athlete is STANDING on (what gets saved as the side). */
  standing: Side | null;
  startT: number | null;
  endT: number | null;
  onStreak: number;
  onStreakT: number | null;
  onStreakSide: Side | null;
  offStreak: number;
  offStreakT: number | null;
  lastSeenT: number | null;
  hips: { x: number; y: number; t: number }[];
  torsos: number[];
  /** Latest lift gap (fraction of leg length) for the live meter. */
  gap: number;
  stopReason: "" | "foot-down" | "cap" | "lost";
};

export function newBalanceState(): BalanceState {
  return {
    phase: "waiting",
    standing: null,
    startT: null,
    endT: null,
    onStreak: 0,
    onStreakT: null,
    onStreakSide: null,
    offStreak: 0,
    offStreakT: null,
    lastSeenT: null,
    hips: [],
    torsos: [],
    gap: 0,
    stopReason: "",
  };
}

type FootRead = { gap: number; lifted: Side; hip: Pt; torso: number } | null;

/** Which foot is higher and by how much, as a fraction of leg length. Null if legs not tracked. */
export function readFeet(lm: Pt[]): FootRead {
  const lh = lm[LM.L_HIP];
  const rh = lm[LM.R_HIP];
  const la = lm[LM.L_ANKLE];
  const ra = lm[LM.R_ANKLE];
  if (!visible([lh, rh, la, ra, lm[LM.L_SHOULDER], lm[LM.R_SHOULDER]])) return null;
  // Use the lower of ankle/heel on each side when the heel is tracked: the heel is what leaves the floor.
  const footY = (ankle: Pt, heel: Pt | undefined) => (heel && vis(heel) >= MIN_VIS ? Math.max(ankle.y, heel.y) : ankle.y);
  const ly = footY(la, lm[LM.L_HEEL]);
  const ry = footY(ra, lm[LM.R_HEEL]);
  const legLen = (dist(lh, la) + dist(rh, ra)) / 2;
  if (legLen < 1e-6) return null;
  const lifted: Side = ly < ry ? "L" : "R"; // smaller y = higher in frame
  return { gap: Math.abs(ly - ry) / legLen, lifted, hip: mid(lh, rh), torso: torsoLength(lm) };
}

const other = (s: Side): Side => (s === "L" ? "R" : "L");

/** Feed one frame (landmarks may be null when no body was found). Returns a new state. */
export function stepBalance(prev: BalanceState, lm: Pt[] | null, t: number): BalanceState {
  if (prev.phase === "done") return prev;
  const s: BalanceState = { ...prev, hips: prev.hips, torsos: prev.torsos };
  const read = lm ? readFeet(lm) : null;

  if (s.phase === "lifted" && s.startT != null && t - s.startT >= BALANCE.CAP_MS) {
    return finish(s, s.startT + BALANCE.CAP_MS, "cap");
  }

  if (!read) {
    if (s.phase === "lifted" && s.lastSeenT != null && t - s.lastSeenT > BALANCE.LOST_MS) {
      return finish(s, s.lastSeenT, "lost");
    }
    return s;
  }
  s.lastSeenT = t;
  s.gap = read.gap;

  if (s.phase === "waiting") {
    if (read.gap >= BALANCE.LIFT_ON && (s.onStreakSide === null || s.onStreakSide === read.lifted)) {
      if (s.onStreak === 0) s.onStreakT = t;
      s.onStreak += 1;
      s.onStreakSide = read.lifted;
    } else {
      s.onStreak = 0;
      s.onStreakT = null;
      s.onStreakSide = null;
    }
    if (s.onStreak >= BALANCE.FRAMES_ON && s.onStreakSide) {
      s.phase = "lifted";
      s.startT = s.onStreakT;
      s.standing = other(s.onStreakSide);
      s.hips = [];
      s.torsos = [];
    }
    return s;
  }

  // phase === "lifted"
  const stillUp = read.gap > BALANCE.LIFT_OFF && read.lifted !== s.standing;
  if (stillUp) {
    s.offStreak = 0;
    s.offStreakT = null;
    s.hips = [...s.hips, { x: read.hip.x, y: read.hip.y, t }];
    s.torsos = [...s.torsos, read.torso];
  } else {
    if (s.offStreak === 0) s.offStreakT = t;
    s.offStreak += 1;
    if (s.offStreak >= BALANCE.FRAMES_OFF) return finish(s, s.offStreakT ?? t, "foot-down");
  }
  return s;
}

function finish(s: BalanceState, endT: number, reason: BalanceState["stopReason"]): BalanceState {
  return { ...s, phase: "done", endT, stopReason: reason };
}

export function balanceSeconds(s: BalanceState, now?: number): number {
  if (s.startT == null) return 0;
  const end = s.endT ?? now ?? s.startT;
  return clamp((end - s.startT) / 1000, 0, BALANCE.CAP_MS / 1000);
}

/**
 * Sway = 2 × radial standard deviation of the mid-hip point over the hold,
 * as a percent of mean torso length (shoulder-mid to hip-mid).
 *   sway% = 100 × 2 × sqrt(var(x) + var(y)) / mean(torso)
 * Chosen over max excursion because one bad landmark frame would set the max.
 * The first SETTLE_MS after lift-off is skipped. Null with fewer than 5 samples.
 */
export function swayPercent(hips: { x: number; y: number; t: number }[], torsos: number[], startT?: number | null): number | null {
  const from = startT != null ? startT + BALANCE.SETTLE_MS : -Infinity;
  const pts = hips.filter((p) => p.t >= from);
  const use = pts.length >= 5 ? pts : hips;
  if (use.length < 5 || torsos.length === 0) return null;
  const torso = torsos.reduce((a, b) => a + b, 0) / torsos.length;
  if (torso < 1e-6) return null;
  const mx = use.reduce((a, p) => a + p.x, 0) / use.length;
  const my = use.reduce((a, p) => a + p.y, 0) / use.length;
  const v = use.reduce((a, p) => a + (p.x - mx) ** 2 + (p.y - my) ** 2, 0) / use.length;
  return clamp((100 * 2 * Math.sqrt(v)) / torso, 0, 100);
}

// ---------------------------------------------------------------------------
// Deep squat check (side view, arms overhead)
// ---------------------------------------------------------------------------

export const SQUAT = {
  /** Knee angle under this = a rep has started. */
  DOWN_DEG: 120,
  /** Knee angle back over this = rep done. */
  UP_DEG: 160,
  MAX_REPS: 3,
  /** Trunk lean (deg from vertical) at or under this earns all 25 trunk points; 0 points at TRUNK_ZERO. */
  TRUNK_FULL: 35,
  TRUNK_ZERO: 65,
  /** Heel rise (fraction of shin length) at or under this earns all 15 heel points; 0 at HEEL_ZERO. */
  HEEL_FULL: 0.02,
  HEEL_ZERO: 0.08,
  /** Hip this far below the knee (fraction of thigh length) earns all 60 depth points. */
  DEPTH_FULL: 0.15,
  /** Hip this far ABOVE the knee (fraction of thigh length) earns 0 depth points. */
  DEPTH_ZERO: -0.5,
} as const;

export type SquatFrame = {
  knee: number;
  /** (hip.y - knee.y) / thigh length. Positive = hip below knee. */
  depth: number;
  trunk: number;
  /** Toe-minus-heel height, fraction of shin length (compared to the standing baseline). */
  heelRaw: number;
  /** Hip-shoulder-wrist angle; ~180 = arms straight overhead in line with the trunk. */
  arm: number | null;
};

/** Measure one side-view frame on the side the camera sees best. Null if the leg isn't tracked. */
export function squatFrame(lm: Pt[]): SquatFrame | null {
  const sides = [
    { s: LM.L_SHOULDER, h: LM.L_HIP, k: LM.L_KNEE, a: LM.L_ANKLE, heel: LM.L_HEEL, toe: LM.L_FOOT, w: LM.L_WRIST },
    { s: LM.R_SHOULDER, h: LM.R_HIP, k: LM.R_KNEE, a: LM.R_ANKLE, heel: LM.R_HEEL, toe: LM.R_FOOT, w: LM.R_WRIST },
  ];
  const score = (x: (typeof sides)[number]) => [x.s, x.h, x.k, x.a, x.heel, x.toe].reduce((acc, i) => acc + vis(lm[i]), 0);
  const side = score(sides[0]) >= score(sides[1]) ? sides[0] : sides[1];
  const sh = lm[side.s];
  const hip = lm[side.h];
  const knee = lm[side.k];
  const ankle = lm[side.a];
  if (!visible([sh, hip, knee, ankle])) return null;
  const kneeAngle = angleDeg(hip, knee, ankle);
  const thigh = dist(hip, knee);
  const shin = dist(knee, ankle);
  if (kneeAngle == null || thigh < 1e-6 || shin < 1e-6) return null;
  const heel = lm[side.heel];
  const toe = lm[side.toe];
  const heelRaw = heel && toe && visible([heel, toe]) ? (heel.y - toe.y) : 0;
  const wrist = lm[side.w];
  return {
    knee: kneeAngle,
    depth: (hip.y - knee.y) / thigh,
    trunk: leanFromVertical(sh, hip),
    // heel.y < toe.y means heel is higher than toe; flip so positive = heel up.
    heelRaw: -heelRaw / shin,
    arm: wrist && vis(wrist) >= MIN_VIS ? angleDeg(hip, sh, wrist) : null,
  };
}

export type SquatRep = {
  minKnee: number;
  maxDepth: number;
  trunkAtBottom: number;
  maxHeelLift: number;
  minArm: number | null;
  score: number;
  parts: { depth: number; trunk: number; heels: number };
  cues: string[];
};

/**
 * Score one rep, 0..100:
 *   depth  (60): hip-below-knee ratio d. d <= -0.5 → 0, d = 0 (parallel) → 30, d >= +0.15 → 60, linear between.
 *   trunk  (25): lean from vertical at the deepest frame. <= 35° → 25, >= 65° → 0, linear.
 *   heels  (15): heel rise vs standing baseline (fraction of shin). <= 0.02 → 15, >= 0.08 → 0, linear.
 * So a clean parallel squat is about 70 and a full-depth clean squat is 100, matching the hand protocol.
 */
export function scoreSquatRep(r: Omit<SquatRep, "score" | "parts" | "cues">): SquatRep {
  const d = r.maxDepth;
  const depth =
    d >= SQUAT.DEPTH_FULL
      ? 60
      : d >= 0
        ? 30 + (30 * d) / SQUAT.DEPTH_FULL
        : d <= SQUAT.DEPTH_ZERO
          ? 0
          : 30 * (1 - d / SQUAT.DEPTH_ZERO);
  const trunk = 25 * clamp((SQUAT.TRUNK_ZERO - r.trunkAtBottom) / (SQUAT.TRUNK_ZERO - SQUAT.TRUNK_FULL), 0, 1);
  const heels = 15 * clamp((SQUAT.HEEL_ZERO - r.maxHeelLift) / (SQUAT.HEEL_ZERO - SQUAT.HEEL_FULL), 0, 1);
  const cues: string[] = [];
  if (d < 0) cues.push(d < -0.25 ? "Hips stayed well above the knees. Sit deeper." : "Almost parallel. Sit a little deeper.");
  if (r.trunkAtBottom > 45) cues.push("Chest dropped. Keep the chest up.");
  if (r.maxHeelLift > 0.04) cues.push("Heels came up. Keep the heels down (tight ankles).");
  if (r.minArm != null && r.minArm < 150) cues.push("Arms fell forward. Keep them straight overhead (tight shoulders).");
  return {
    ...r,
    parts: { depth: Math.round(depth), trunk: Math.round(trunk), heels: Math.round(heels) },
    score: Math.round(clamp(depth + trunk + heels, 0, 100)),
    cues,
  };
}

export type SquatState = {
  phase: "up" | "down";
  /** Standing heelRaw baseline (running mean of upright frames). */
  heelBase: number | null;
  heelBaseN: number;
  cur: { minKnee: number; maxDepth: number; trunkAtBottom: number; maxHeelLift: number; minArm: number | null } | null;
  reps: SquatRep[];
  last: SquatFrame | null;
};

export function newSquatState(): SquatState {
  return { phase: "up", heelBase: null, heelBaseN: 0, cur: null, reps: [], last: null };
}

export function squatDone(s: SquatState): boolean {
  return s.reps.length >= SQUAT.MAX_REPS;
}

/** Feed one frame. Rep = knee angle drops under 120° then comes back over 160°. Stops after 3 reps. */
export function stepSquat(prev: SquatState, lm: Pt[] | null): SquatState {
  if (squatDone(prev) || !lm) return prev;
  const f = squatFrame(lm);
  if (!f) return prev;
  const s: SquatState = { ...prev, last: f };
  if (s.phase === "up") {
    if (f.knee >= SQUAT.UP_DEG) {
      s.heelBaseN = prev.heelBaseN + 1;
      s.heelBase = prev.heelBase == null ? f.heelRaw : prev.heelBase + (f.heelRaw - prev.heelBase) / s.heelBaseN;
    }
    if (f.knee < SQUAT.DOWN_DEG) {
      s.phase = "down";
      s.cur = {
        minKnee: f.knee,
        maxDepth: f.depth,
        trunkAtBottom: f.trunk,
        maxHeelLift: Math.max(0, f.heelRaw - (s.heelBase ?? f.heelRaw)),
        minArm: f.arm,
      };
    }
    return s;
  }
  // down
  const c = { ...(s.cur ?? { minKnee: f.knee, maxDepth: f.depth, trunkAtBottom: f.trunk, maxHeelLift: 0, minArm: f.arm }) };
  if (f.depth > c.maxDepth) {
    c.maxDepth = f.depth;
    c.trunkAtBottom = f.trunk;
  }
  c.minKnee = Math.min(c.minKnee, f.knee);
  c.maxHeelLift = Math.max(c.maxHeelLift, f.heelRaw - (s.heelBase ?? f.heelRaw));
  if (f.arm != null) c.minArm = c.minArm == null ? f.arm : Math.min(c.minArm, f.arm);
  s.cur = c;
  if (f.knee > SQUAT.UP_DEG) {
    s.reps = [...prev.reps, scoreSquatRep(c)];
    s.cur = null;
    s.phase = "up";
  }
  return s;
}

export function bestSquat(s: SquatState): SquatRep | null {
  if (s.reps.length === 0) return null;
  return s.reps.reduce((best, r) => (r.score > best.score ? r : best));
}

// ---------------------------------------------------------------------------
// Sit and reach guide (side view)
// ---------------------------------------------------------------------------

export type ReachRead = {
  /** Fingertips (wrist proxy) past the toes, as a fraction of leg length. Negative = short of the toes. */
  ratio: number;
  /** Rough inches ONLY when a shoe length was given. Guide, not the official number. */
  inches: number | null;
};

/**
 * Wrist-past-toe distance along the hip→toe direction, divided by leg length (hip to ankle).
 * With a shoe length (inches), the heel-to-toe distance in the frame calibrates an inch estimate.
 * The wrist sits a few inches short of the fingertips; that offset is left in on purpose and is
 * one reason the tape measure is the number that gets saved.
 */
export function reachRead(lm: Pt[], shoeInches?: number | null): ReachRead | null {
  const sides = [
    { h: LM.L_HIP, a: LM.L_ANKLE, heel: LM.L_HEEL, toe: LM.L_FOOT, w: LM.L_WRIST },
    { h: LM.R_HIP, a: LM.R_ANKLE, heel: LM.R_HEEL, toe: LM.R_FOOT, w: LM.R_WRIST },
  ];
  const score = (x: (typeof sides)[number]) => [x.h, x.a, x.toe, x.w].reduce((acc, i) => acc + vis(lm[i]), 0);
  const side = score(sides[0]) >= score(sides[1]) ? sides[0] : sides[1];
  const hip = lm[side.h];
  const ankle = lm[side.a];
  const toe = lm[side.toe];
  const heel = lm[side.heel];
  // Both wrists: take the one further forward.
  const wrists = [lm[LM.L_WRIST], lm[LM.R_WRIST]].filter((w) => vis(w) >= MIN_VIS);
  if (!visible([hip, ankle, toe]) || wrists.length === 0) return null;
  const legLen = dist(hip, ankle);
  const axisLen = dist(hip, toe);
  if (legLen < 1e-6 || axisLen < 1e-6) return null;
  const ux = (toe.x - hip.x) / axisLen;
  const uy = (toe.y - hip.y) / axisLen;
  const past = Math.max(...wrists.map((w) => (w.x - toe.x) * ux + (w.y - toe.y) * uy));
  let inches: number | null = null;
  if (shoeInches && shoeInches > 0 && heel && vis(heel) >= MIN_VIS) {
    const foot = dist(heel, toe);
    if (foot > 1e-6) inches = (past / foot) * shoeInches;
  }
  return { ratio: past / legLen, inches };
}
