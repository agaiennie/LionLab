import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { FAST, FAST_LINE } from "./content/fast";
import { SKILLS, positionPlan, skillById } from "./content/skills";

const REQUIRED = [
  "athletic-stance",
  "first-step",
  "attack-contact",
  "square-up",
  "tackle-wrap",
  "secure-ball",
  "catch-ball",
  "conditioning-finish",
  "ol-kick-slide",
  "ol-run-landmark",
  "ol-pull-path",
  "ol-finish-block",
  "dl-get-off",
  "dl-shed",
  "dl-gap",
  "lb-read-step",
  "lb-spill-force",
  "lb-tackle-space",
  "db-coverage-base",
  "db-hip-turn",
  "db-contested",
  "db-contain",
  "wr-release",
  "wr-catch-contact",
  "wr-force-block",
  "rb-ball-security",
  "rb-crease",
  "rb-pass-pro",
  "qb-exchange",
  "qb-eyes",
  "qb-progression",
  "st-cover",
  "st-kick-green",
];

describe("skill library", () => {
  it("ships the seed set as full teach pages", () => {
    assert.equal(SKILLS.length, REQUIRED.length);
    for (const id of REQUIRED) {
      const skill = skillById(id);
      assert.ok(skill, id);
      assert.ok(skill.what.length > 40);
      assert.ok(skill.why.length > 40);
      assert.ok(skill.demo.eyes.length >= 3 && skill.demo.eyes.length <= 5);
      assert.ok(skill.demo.wrong.length >= 2);
      assert.ok(skill.breakdown.length >= 3);
      for (const step of skill.breakdown) {
        assert.ok(step.failFix.length > 0);
        assert.equal(step.failFix.split(".").filter(Boolean).length <= 2, true);
      }
      assert.ok(skill.speedUp.stop.length > 0);
      assert.ok(skill.station.cue.length > 0);
    }
  });

  it("puts a position list on the same skill ids", () => {
    const plan = positionPlan("OL");
    const ids = [...plan.first, ...plan.next].map((skill) => skill.id);
    assert.ok(ids.includes("ol-kick-slide"));
    assert.ok(ids.includes("athletic-stance"));
    assert.equal(new Set(ids).size, ids.length);
    assert.ok(plan.first.some((skill) => skill.id === "ol-kick-slide"));
    assert.ok(plan.next.some((skill) => skill.id === "ol-pull-path"));
    assert.ok(plan.next.some((skill) => skill.id === "ol-finish-block"));
  });

  it("uses Shoulder level and Through for FAST", () => {
    assert.equal(FAST.find((item) => item.letter === "S")?.word, "Shoulder level");
    assert.equal(FAST.find((item) => item.letter === "T")?.word, "Through");
    assert.equal(
      FAST_LINE,
      "First step. Attack. Shoulder level. Through — wrap if you’re tackling, drive if you’re blocking.",
    );
    assert.equal(skillById("square-up")?.fastLetters.includes("S"), false);
    assert.deepEqual(skillById("tackle-wrap")?.fastLetters, ["T"]);
    assert.equal(skillById("ol-finish-block")?.name, "Through the block (drive + whistle+1)");
    assert.deepEqual(skillById("ol-finish-block")?.positions, ["OL", "WR", "TE", "RB"]);
    assert.equal(skillById("ol-finish-block")?.fastLetters.includes("T"), true);
    assert.equal(skillById("ol-run-landmark")?.fastLetters.includes("T"), true);
    assert.equal(skillById("conditioning-finish")?.fastLetters.includes("T"), true);
    const expansions = [
      FAST_LINE,
      ...FAST.map((item) => `${item.letter} ${item.word}`),
      ...SKILLS.filter((skill) => skill.fastLetters.includes("T")).map((skill) => skill.what),
    ].join(" ");
    assert.equal(expansions.includes("Tackle wrap"), false);
  });
});
