// Position-fit engine. Pure functions, no database — easy to test and to reuse
// in a bigger system later (import this file, feed it rows, get rankings back).
//
// How it works, in plain words:
// 1. Every number (40, 5-10-5, long jump, height, weight, exam score…) becomes a 0–100
//    "standing". With 8+ teammates measured, standing = percentile on this team
//    (same grade band when possible). With fewer, it falls back to coaching anchors.
// 2. Each role weights the numbers that matter for that job. Some factors are
//    "more is better" (speed), some aim at a target (a running back doesn't need
//    to be the tallest kid; he needs to be compact).
// 3. Role score = weighted average of the factors we actually have.
//    Confidence = share of the role's weight we have data for. Missing tests
//    lower the rank so one lucky number doesn't crown anybody.
//
// These are ESTIMATES for coaching conversations. Junior high bodies change fast;
// a late bloomer can move from WR to TE in a year. Re-run every testing day.

import { METRIC_BY_ID, type MetricId } from "@/lib/content/metrics";

export type FactorKey = MetricId | "HEIGHT" | "WEIGHT" | "MEDBALL_ROT" | "EXAM_QB" | "EXAM_MLB";

export const FACTOR_LABELS: Record<FactorKey, string> = {
  ...(Object.fromEntries(Object.values(METRIC_BY_ID).map((m) => [m.id, m.label])) as Record<MetricId, string>),
  HEIGHT: "Height",
  WEIGHT: "Weight",
  MEDBALL_ROT: "10 lb rotational throw",
  EXAM_QB: "QB reads exam",
  EXAM_MLB: "MLB fits exam",
};

export type RoleId = "QB" | "RB" | "WR" | "TE" | "OL" | "DT" | "DE" | "MLB" | "OLB" | "CB" | "S";

export type Factor = {
  key: FactorKey;
  weight: number;
  /** "high" = more standing is better. "target" = aim at a standing (percentile). */
  mode: "high" | "target";
  target?: number;
};

export type RoleDef = {
  id: RoleId;
  label: string;
  /** Roster position code this role files under (lib/scoring POSITION_CODES). */
  code: "QB" | "RB" | "WR" | "TE" | "OL" | "DL" | "LB" | "DB";
  side: "O" | "D";
  job: string;
  factors: Factor[];
};

const high = (key: FactorKey, weight: number): Factor => ({ key, weight, mode: "high" });
const aim = (key: FactorKey, weight: number, target: number): Factor => ({ key, weight, mode: "target", target });

export const ROLES: RoleDef[] = [
  {
    id: "QB",
    label: "Quarterback",
    code: "QB",
    side: "O",
    job: "Reads, decisions, and a throw. Leadership job: exam required.",
    factors: [high("FOOTBALL_THROW", 3), high("EXAM_QB", 3), high("HEIGHT", 1), high("PRO_AGILITY", 1), high("MEDBALL_CHEST", 0.5), high("BALANCE_SL", 0.5)],
  },
  {
    id: "RB",
    label: "Running back",
    code: "RB",
    side: "O",
    job: "First-step burst, cuts, and a low center of gravity.",
    factors: [high("SPLIT_10", 2.5), high("PRO_AGILITY", 2.5), high("SPRINT_40", 2), high("BROAD_JUMP", 1.5), aim("HEIGHT", 0.75, 40), aim("WEIGHT", 0.75, 55), high("BALANCE_SL", 1)],
  },
  {
    id: "WR",
    label: "Wide receiver",
    code: "WR",
    side: "O",
    job: "Top-end speed, jump, and reach.",
    factors: [high("SPRINT_40", 3), high("VERTICAL", 1.5), high("PRO_AGILITY", 1.5), high("SPLIT_10", 1), high("HEIGHT", 1.5), aim("WEIGHT", 0.5, 35)],
  },
  {
    id: "TE",
    label: "Tight end",
    code: "TE",
    side: "O",
    job: "Big enough to block, athletic enough to catch.",
    factors: [high("HEIGHT", 2), aim("WEIGHT", 1.5, 72), high("BROAD_JUMP", 1), high("MEDBALL_ROT", 1), high("SPRINT_40", 1), high("VERTICAL", 1)],
  },
  {
    id: "OL",
    label: "Offensive line",
    code: "OL",
    side: "O",
    job: "Mass, hip power, and a stance that can sit low (ankles and hips).",
    factors: [high("WEIGHT", 3), high("HEIGHT", 1), high("MEDBALL_ROT", 1.5), high("MEDBALL_CHEST", 1), high("SPLIT_10", 1), high("SQUAT_SCORE", 1), high("KNEE_WALL", 0.5), high("PUSHUPS", 0.5)],
  },
  {
    id: "DT",
    label: "Defensive tackle",
    code: "DL",
    side: "D",
    job: "Heavy, quick off the ball, strong hands.",
    factors: [high("WEIGHT", 2.5), high("SPLIT_10", 2), high("MEDBALL_ROT", 1.5), high("BROAD_JUMP", 1), high("MEDBALL_CHEST", 1), high("SQUAT_SCORE", 0.5)],
  },
  {
    id: "DE",
    label: "Defensive end",
    code: "DL",
    side: "D",
    job: "Long, quick edge player who can bend around a blocker.",
    factors: [high("SPLIT_10", 2), high("PRO_AGILITY", 1.5), high("HEIGHT", 1), aim("WEIGHT", 1.5, 68), high("BROAD_JUMP", 1), high("MEDBALL_ROT", 1), high("BALANCE_SL", 0.5)],
  },
  {
    id: "MLB",
    label: "Middle linebacker",
    code: "LB",
    side: "D",
    job: "Defensive quarterback: makes calls, fills gaps, tackles in the box. Leadership job: exam required.",
    factors: [high("EXAM_MLB", 2.5), high("PRO_AGILITY", 2), high("SPLIT_10", 1.5), aim("WEIGHT", 1, 62), high("BROAD_JUMP", 1), high("MEDBALL_ROT", 1), high("BALANCE_SL", 0.5)],
  },
  {
    id: "OLB",
    label: "Outside linebacker",
    code: "LB",
    side: "D",
    job: "Sets the edge and runs sideline to sideline.",
    factors: [high("PRO_AGILITY", 2), high("SPRINT_40", 1.5), high("SPLIT_10", 1.5), high("BROAD_JUMP", 1), aim("WEIGHT", 1, 52), high("BALANCE_SL", 0.5)],
  },
  {
    id: "CB",
    label: "Cornerback",
    code: "DB",
    side: "D",
    job: "Mirror a receiver: speed, hips, and feet.",
    factors: [high("SPRINT_40", 2.5), high("PRO_AGILITY", 2.5), high("VERTICAL", 1), high("BALANCE_SL", 1), high("KNEE_WALL", 0.5), aim("WEIGHT", 0.5, 30)],
  },
  {
    id: "S",
    label: "Safety",
    code: "DB",
    side: "D",
    job: "Last line: range, eyes, and a sure tackle.",
    factors: [high("SPRINT_40", 2), high("PRO_AGILITY", 1.5), high("VERTICAL", 1), high("HEIGHT", 1), high("BROAD_JUMP", 1), aim("WEIGHT", 0.75, 50)],
  },
];

export const ROLE_BY_ID = Object.fromEntries(ROLES.map((r) => [r.id, r])) as Record<RoleId, RoleDef>;

/** Default players needed per role for an 11-player junior high roster (mostly one-way). */
export const DEFAULT_DEPTH_NEEDS: Record<RoleId, number> = {
  QB: 2,
  RB: 3,
  WR: 4,
  TE: 2,
  OL: 7,
  DT: 3,
  DE: 3,
  MLB: 2,
  OLB: 3,
  CB: 4,
  S: 3,
};

type Band = "JH" | "HS";
export function bandForGrade(grade: number): Band {
  return grade <= 8 ? "JH" : "HS";
}

/**
 * Coaching anchors used when the team pool is too small for percentiles.
 * [poor, great] for each band. These are Lion Lab coaching estimates, not
 * published norms. Tune them after a season of your own data.
 */
export const ANCHORS: Partial<Record<FactorKey, Record<Band, [number, number]>>> = {
  SPRINT_40: { JH: [6.6, 5.2], HS: [6.0, 4.8] },
  SPLIT_10: { JH: [2.2, 1.7], HS: [2.0, 1.6] },
  PRO_AGILITY: { JH: [6.0, 4.7], HS: [5.5, 4.4] },
  BROAD_JUMP: { JH: [60, 96], HS: [72, 110] },
  VERTICAL: { JH: [10, 22], HS: [14, 28] },
  MEDBALL_CHEST: { JH: [10, 20], HS: [14, 26] },
  MEDBALL_ROT: { JH: [14, 28], HS: [20, 34] },
  PUSHUPS: { JH: [8, 40], HS: [15, 50] },
  PLANK: { JH: [30, 120], HS: [30, 120] },
  SIT_REACH: { JH: [-6, 4], HS: [-6, 4] },
  KNEE_WALL: { JH: [2, 5], HS: [2, 5] },
  SQUAT_SCORE: { JH: [30, 90], HS: [30, 90] },
  BALANCE_SL: { JH: [3, 25], HS: [4, 28] },
  BALANCE_SWAY: { JH: [20, 3], HS: [20, 3] },
  FOOTBALL_THROW: { JH: [15, 40], HS: [25, 55] },
  HEIGHT: { JH: [58, 70], HS: [64, 76] },
  WEIGHT: { JH: [90, 190], HS: [130, 260] },
  EXAM_QB: { JH: [0, 100], HS: [0, 100] },
  EXAM_MLB: { JH: [0, 100], HS: [0, 100] },
};

/** For factors where a lower raw number is better. */
function lowerIsBetter(key: FactorKey): boolean {
  if (key in METRIC_BY_ID) return METRIC_BY_ID[key as MetricId].better === "lower";
  return false;
}

export type FitAthlete = {
  id: string;
  name: string;
  grade: number;
  positions: string[];
  values: Partial<Record<FactorKey, number>>;
};

export const MIN_POOL_FOR_PERCENTILE = 8;

/** Percentile rank (0–100) of value inside pool; ties count half. Direction-aware. */
export function percentile(value: number, pool: number[], lowerBetter: boolean): number {
  if (pool.length === 0) return 50;
  let worse = 0;
  let equal = 0;
  for (const other of pool) {
    if (other === value) equal += 1;
    else if (lowerBetter ? other > value : other < value) worse += 1;
  }
  return ((worse + equal * 0.5) / pool.length) * 100;
}

/** Linear 0–100 between poor and great anchors, clamped. */
export function anchorStanding(value: number, [poor, great]: [number, number]): number {
  if (great === poor) return 50;
  const t = (value - poor) / (great - poor);
  return Math.max(0, Math.min(100, t * 100));
}

export type Standing = { value: number; standing: number; basis: "team" | "anchor" };

export function standingsFor(athlete: FitAthlete, roster: FitAthlete[]): Partial<Record<FactorKey, Standing>> {
  const band = bandForGrade(athlete.grade);
  const sameBand = roster.filter((a) => bandForGrade(a.grade) === band);
  const out: Partial<Record<FactorKey, Standing>> = {};
  for (const [key, value] of Object.entries(athlete.values) as [FactorKey, number][]) {
    if (value == null || !Number.isFinite(value)) continue;
    if (key === "EXAM_QB" || key === "EXAM_MLB") {
      out[key] = { value, standing: Math.max(0, Math.min(100, value)), basis: "anchor" };
      continue;
    }
    const bandPool = sameBand.map((a) => a.values[key]).filter((v): v is number => v != null);
    const allPool = roster.map((a) => a.values[key]).filter((v): v is number => v != null);
    const pool = bandPool.length >= MIN_POOL_FOR_PERCENTILE ? bandPool : allPool;
    if (pool.length >= MIN_POOL_FOR_PERCENTILE) {
      out[key] = { value, standing: percentile(value, pool, lowerIsBetter(key)), basis: "team" };
    } else {
      const anchor = ANCHORS[key]?.[band];
      out[key] = { value, standing: anchor ? anchorStanding(value, anchor) : 50, basis: "anchor" };
    }
  }
  return out;
}

export function factorScore(factor: Factor, standing: number): number {
  if (factor.mode === "high") return standing;
  const target = factor.target ?? 50;
  return Math.max(0, 100 - 1.5 * Math.abs(standing - target));
}

export type WeightOverrides = Partial<Record<RoleId, Partial<Record<FactorKey, number>>>>;

export function rolesWithOverrides(overrides: WeightOverrides | null | undefined): RoleDef[] {
  if (!overrides) return ROLES;
  return ROLES.map((role) => {
    const o = overrides[role.id];
    if (!o) return role;
    return {
      ...role,
      factors: role.factors.map((f) => (o[f.key] != null ? { ...f, weight: Math.max(0, Number(o[f.key])) } : f)),
    };
  });
}

export type RoleFit = {
  role: RoleId;
  label: string;
  code: string;
  score: number;
  confidence: number;
  rank: number;
  /** score adjusted for missing data — used for ordering. */
  sortKey: number;
  strengths: string[];
  work: string[];
  missing: string[];
};

function describe(key: FactorKey, s: Standing): string {
  const where = s.basis === "team" ? `${Math.round(s.standing)}th percentile on the team` : `${Math.round(s.standing)}/100 on the coaching scale`;
  return `${FACTOR_LABELS[key]}: ${where}`;
}

export function fitRoles(athlete: FitAthlete, roster: FitAthlete[], roles: RoleDef[] = ROLES): RoleFit[] {
  const standings = standingsFor(athlete, roster);
  const fits = roles.map((role) => {
    let total = 0;
    let have = 0;
    let weighted = 0;
    const scored: { key: FactorKey; weight: number; score: number; s: Standing }[] = [];
    const missing: string[] = [];
    for (const factor of role.factors) {
      total += factor.weight;
      const s = standings[factor.key];
      if (!s) {
        if (factor.weight >= 1) missing.push(FACTOR_LABELS[factor.key]);
        continue;
      }
      const score = factorScore(factor, s.standing);
      have += factor.weight;
      weighted += factor.weight * score;
      scored.push({ key: factor.key, weight: factor.weight, score, s });
    }
    const score = have > 0 ? weighted / have : 0;
    const confidence = total > 0 ? have / total : 0;
    const strengths = scored
      .filter((x) => x.score >= 65 && x.weight >= 1)
      .sort((a, b) => b.score * b.weight - a.score * a.weight)
      .slice(0, 2)
      .map((x) => describe(x.key, x.s));
    const work = scored
      .filter((x) => x.score < 45 && x.weight >= 1)
      .sort((a, b) => a.score * b.weight - b.score * a.weight)
      .slice(0, 2)
      .map((x) => describe(x.key, x.s));
    return {
      role: role.id,
      label: role.label,
      code: role.code,
      score: Math.round(score),
      confidence: Math.round(confidence * 100) / 100,
      rank: 0,
      sortKey: score * (0.4 + 0.6 * confidence),
      strengths,
      work,
      missing,
    };
  });
  fits.sort((a, b) => b.sortKey - a.sortKey);
  fits.forEach((f, i) => (f.rank = i + 1));
  return fits;
}

export function confidenceWord(confidence: number): "High" | "Medium" | "Low" {
  if (confidence >= 0.75) return "High";
  if (confidence >= 0.45) return "Medium";
  return "Low";
}

export type DepthRow = {
  role: RoleId;
  label: string;
  need: number;
  assigned: { id: string; name: string; score: number }[];
  bench: { id: string; name: string; score: number }[];
  gap: number;
  /** Assigned players scoring under the "ready" line (60). */
  thin: number;
};

export const READY_SCORE = 60;

/**
 * Greedy depth chart: best (athlete, role) pairs first, each athlete placed once
 * per side of the ball (O and D), so two-way players show on both sides like
 * they do in junior high. Remaining good fits are listed as "bench".
 */
export function buildDepth(
  roster: FitAthlete[],
  needs: Record<RoleId, number> = DEFAULT_DEPTH_NEEDS,
  roles: RoleDef[] = ROLES,
  minScore = 50,
): DepthRow[] {
  const fitsById = new Map(roster.map((a) => [a.id, fitRoles(a, roster, roles)]));
  const pairs: { athlete: FitAthlete; fit: RoleFit; side: "O" | "D" }[] = [];
  for (const athlete of roster) {
    for (const fit of fitsById.get(athlete.id) ?? []) {
      if (fit.score < minScore || fit.confidence < 0.4) continue;
      pairs.push({ athlete, fit, side: ROLE_BY_ID[fit.role].side });
    }
  }
  pairs.sort((a, b) => b.fit.sortKey - a.fit.sortKey);
  const rows = new Map<RoleId, DepthRow>(
    roles.map((r) => [r.id, { role: r.id, label: r.label, need: needs[r.id] ?? 0, assigned: [], bench: [], gap: 0, thin: 0 }]),
  );
  const placed = new Set<string>();
  for (const { athlete, fit, side } of pairs) {
    const row = rows.get(fit.role)!;
    const key = `${athlete.id}:${side}`;
    const entry = { id: athlete.id, name: athlete.name, score: fit.score };
    if (!placed.has(key) && row.assigned.length < row.need) {
      row.assigned.push(entry);
      placed.add(key);
    } else if (row.bench.length < 4 && !row.assigned.some((a) => a.id === athlete.id)) {
      row.bench.push(entry);
    }
  }
  for (const row of rows.values()) {
    row.gap = Math.max(0, row.need - row.assigned.length);
    row.thin = row.assigned.filter((a) => a.score < READY_SCORE).length;
  }
  return [...rows.values()];
}

/** Value at a percentile of a pool (for "what a recruit should look like"). */
export function valueAtPercentile(pool: number[], pct: number): number | null {
  if (pool.length === 0) return null;
  const sorted = [...pool].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.round((pct / 100) * (sorted.length - 1))));
  return sorted[idx] ?? null;
}
