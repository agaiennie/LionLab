import { z } from "zod";
import {
  GRADES,
  POSITION_CODES,
  TEST_TYPES,
  TESTS,
  isTestType,
  knownPassedIds,
} from "@/lib/scoring";

export const passwordSchema = z
  .string()
  .min(8, "Use at least 8 characters.")
  .max(72, "Passwords must be 72 characters or fewer.");

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email("Enter an email address.");

export const athleteFieldsSchema = z
  .object({
    name: z.string().trim().min(2, "Enter a first and last name.").max(80),
    email: emailSchema,
    grade: z.coerce
      .number()
      .int()
      .refine((grade) => (GRADES as readonly number[]).includes(grade), {
        message: "Pick a grade from 7 to 12.",
      }),
    positions: z
      .array(z.enum(POSITION_CODES))
      .min(1, "Pick at least one position."),
    feet: z.coerce.number().int().min(4, "Feet should be 4 to 7.").max(7),
    inches: z.coerce.number().int().min(0, "Inches should be 0 to 11.").max(11),
    weightLbs: z.coerce
      .number()
      .int()
      .min(60, "Weight should be at least 60 lb.")
      .max(400, "Weight should be 400 lb or less."),
  })
  .superRefine((value, ctx) => {
    const total = value.feet * 12 + value.inches;
    if (total < 48 || total > 84) {
      ctx.addIssue({
        code: "custom",
        path: ["feet"],
        message: 'Height should be between 4\'0" and 7\'0".',
      });
    }
  });

export const staffSchema = z.object({
  name: z.string().trim().min(2, "Enter a name.").max(80),
  email: emailSchema,
  password: passwordSchema,
  role: z.enum(["COACH", "ADMIN"]),
});

export const passwordChangeSchema = z
  .object({
    current: z.string().min(1, "Enter your current password."),
    next: passwordSchema,
    confirm: z.string(),
  })
  .refine((value) => value.next === value.confirm, {
    path: ["confirm"],
    message: "Those passwords don't match.",
  });

export const resetPasswordSchema = z.object({
  password: passwordSchema,
});

const datePattern = /^\d{4}-\d{2}-\d{2}$/;

export const sessionSchema = z
  .object({
    testType: z.enum(TEST_TYPES),
    raw: z.string().trim().optional().default(""),
    recordedOn: z.string().regex(datePattern, "Pick a date."),
    notes: z.string().trim().max(500, "Keep notes under 500 characters."),
    passed: z.array(z.string()),
  })
  .superRefine((value, ctx) => {
    const latest = new Date(Date.now() + 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 10);
    if (value.recordedOn < "2020-01-01" || value.recordedOn > latest) {
      ctx.addIssue({
        code: "custom",
        path: ["recordedOn"],
        message: "Pick a date from this season, not a future date.",
      });
    }

    if (!isTestType(value.testType) || value.testType === "STANCE") return;

    if (!value.raw) {
      ctx.addIssue({
        code: "custom",
        path: ["raw"],
        message:
          value.testType === "FORTY"
            ? "Enter the 40 time in seconds."
            : "Enter the throw distance in feet.",
      });
      return;
    }

    const raw = Number(value.raw);
    if (!Number.isFinite(raw)) {
      ctx.addIssue({
        code: "custom",
        path: ["raw"],
        message: "Enter a number.",
      });
      return;
    }

    if (value.testType === "FORTY" && (raw < 3.5 || raw > 15)) {
      ctx.addIssue({
        code: "custom",
        path: ["raw"],
        message: "40 time should be between 3.50 and 15.00 seconds.",
      });
    }

    if (value.testType === "MEDBALL" && (raw < 1 || raw > 80)) {
      ctx.addIssue({
        code: "custom",
        path: ["raw"],
        message: "Distance should be between 1.0 and 80.0 feet.",
      });
    }
  })
  .transform((value) => {
    const passed = knownPassedIds(value.testType, value.passed);
    const raw =
      value.testType === "STANCE" || !value.raw ? null : Number(value.raw);
    return {
      testType: value.testType,
      raw,
      recordedOn: value.recordedOn,
      notes: value.notes,
      passed,
      total: TESTS[value.testType].items.length,
    };
  });

export type ActionState = {
  error?: string;
  fieldErrors?: Record<string, string>;
  message?: string;
  invite?: {
    athleteId: string;
    name: string;
    email: string;
    temporaryPassword: string;
  };
};

export function fieldErrorsFrom(error: z.ZodError): Record<string, string> {
  const fieldErrors: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path[0];
    if (typeof key === "string" && !fieldErrors[key]) {
      fieldErrors[key] = issue.message;
    }
  }
  return fieldErrors;
}

export function readPositions(formData: FormData): string[] {
  return formData
    .getAll("positions")
    .filter((value): value is string => typeof value === "string");
}

export function readPassed(formData: FormData): string[] {
  return formData
    .getAll("passed")
    .filter((value): value is string => typeof value === "string");
}
