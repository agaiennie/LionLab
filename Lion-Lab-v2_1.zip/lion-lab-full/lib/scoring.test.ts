import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  FORTY_FORM_WEIGHT,
  MEDBALL_FORM_FLOOR,
  TESTS,
  formIndex,
  scoreTest,
} from "./scoring";

const fortyIds = TESTS.FORTY.items.map((item) => item.id);
const medIds = TESTS.MEDBALL.items.map((item) => item.id);
const stanceIds = TESTS.STANCE.items.map((item) => item.id);

describe("40-yard ESTIMATE", () => {
  it("keeps the raw time when every cue is solid", () => {
    const scored = scoreTest("FORTY", 4.92, fortyIds);
    assert.equal(scored.percent, 100);
    assert.equal(scored.estimate.display, "4.92s");
    assert.equal(scored.cues.length, 0);
    assert.match(scored.retest, /4\.87s/);
  });

  it("adds the form weight when the checklist is empty", () => {
    const scored = scoreTest("FORTY", 5, []);
    assert.equal(scored.percent, 0);
    assert.equal(scored.estimate.value, 5 * (1 + FORTY_FORM_WEIGHT));
    assert.equal(scored.estimate.display, "5.50s");
  });

  it("uses the published 60% example", () => {
    const passed = ["stance", "first-step", "arms"];
    assert.equal(formIndex("FORTY", passed), 0.6);
    const scored = scoreTest("FORTY", 5.2, [...passed, "not-a-real-cue"]);
    assert.equal(scored.percent, 60);
    assert.equal(scored.passedCount, 3);
    assert.equal(Number(scored.estimate.value?.toFixed(3)), 5.408);
    assert.equal(scored.estimate.display, "5.41s");
    assert.equal(scored.cues.length, 2);
  });
});

describe("med-ball ESTIMATE", () => {
  it("keeps the full distance at 100% form", () => {
    const scored = scoreTest("MEDBALL", 32.5, medIds);
    assert.equal(scored.estimate.display, "32.5 ft");
    assert.match(scored.retest, /33\.5 ft/);
  });

  it("keeps the floor when form is empty", () => {
    const scored = scoreTest("MEDBALL", 20, []);
    assert.equal(scored.estimate.value, 20 * MEDBALL_FORM_FLOOR);
    assert.equal(scored.estimate.display, "18.0 ft");
  });

  it("uses the published 80% example", () => {
    const passed = medIds.filter((id) => id !== "finish");
    const scored = scoreTest("MEDBALL", 28, passed);
    assert.equal(scored.percent, 80);
    assert.equal(Number(scored.estimate.value?.toFixed(2)), 27.44);
    assert.equal(scored.estimate.display, "27.4 ft");
    assert.match(scored.retest, /28\.0 ft/);
  });
});

describe("stance ESTIMATE", () => {
  it("bands the checklist without inventing a measurement", () => {
    assert.equal(scoreTest("STANCE", null, stanceIds).estimate.display, "Game-ready");
    assert.equal(
      scoreTest("STANCE", null, stanceIds.slice(0, 4)).estimate.display,
      "Game-ready",
    );
    assert.equal(
      scoreTest("STANCE", null, stanceIds.slice(0, 3)).estimate.display,
      "Developing",
    );
    assert.equal(scoreTest("STANCE", null, stanceIds.slice(0, 2)).estimate.display, "Rebuild");
    assert.equal(scoreTest("STANCE", null, stanceIds).estimate.value, null);
    assert.match(scoreTest("STANCE", null, stanceIds.slice(0, 3)).retest, /4 of 5/);
  });
});
