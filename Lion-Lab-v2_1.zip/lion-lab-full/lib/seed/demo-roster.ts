// Fictional junior-high demo squad with realistic-ish battery numbers so the
// position-fit, depth chart, and team-gap screens have something to chew on.
// Deterministic: same names and numbers every seed. Demo only — never real kids.
import type { PrismaClient } from "@prisma/client";
import type { MetricId } from "../content/metrics";

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}

const FIRST = ["Eli", "Mason", "Tyler", "Caleb", "Owen", "Luke", "Isaiah", "Wyatt", "Nate", "Carter", "Jace", "Dominic", "Levi", "Gavin", "Aiden", "Colton", "Ryan", "Micah", "Jalen", "Brody", "Hunter", "Sofia", "Evan", "Xavier"];
const LAST = ["Stauffer", "Keller", "Brenneman", "Hoffman", "Reyes", "Miller", "Snyder", "Diaz", "Frey", "Walker", "Kline", "Nguyen", "Baker", "Gross", "Patel", "Leber", "Shaw", "Ortiz", "Hess", "Wright", "Young", "Garcia", "Moore", "Lehman"];

type Archetype = {
  positions: string;
  height: [number, number];
  weight: [number, number];
  // [best, worst] ranges for junior high
  sprint: [number, number];
  split: [number, number];
  shuttle: [number, number];
  broad: [number, number];
  vert: [number, number];
  toss: [number, number];
  rot: [number, number];
  pushups: [number, number];
  throwYd?: [number, number];
};

const ARCH: Record<string, Archetype> = {
  line: { positions: "OL,DL", height: [62, 70], weight: [150, 215], sprint: [6.2, 7.2], split: [2.0, 2.35], shuttle: [5.5, 6.4], broad: [58, 80], vert: [9, 15], toss: [13, 20], rot: [20, 30], pushups: [8, 25] },
  big: { positions: "TE,DL", height: [65, 71], weight: [135, 175], sprint: [5.7, 6.3], split: [1.85, 2.1], shuttle: [5.0, 5.6], broad: [72, 90], vert: [14, 20], toss: [14, 19], rot: [22, 29], pushups: [15, 32] },
  back: { positions: "RB,LB", height: [59, 65], weight: [105, 140], sprint: [5.4, 6.0], split: [1.72, 1.95], shuttle: [4.7, 5.2], broad: [76, 94], vert: [15, 22], toss: [11, 16], rot: [18, 25], pushups: [18, 38] },
  skill: { positions: "WR,DB", height: [60, 68], weight: [95, 130], sprint: [5.2, 5.9], split: [1.75, 2.0], shuttle: [4.7, 5.3], broad: [74, 96], vert: [16, 24], toss: [9, 14], rot: [15, 22], pushups: [12, 30] },
  qb: { positions: "QB,DB", height: [63, 69], weight: [110, 140], sprint: [5.6, 6.1], split: [1.85, 2.05], shuttle: [4.9, 5.4], broad: [70, 86], vert: [13, 19], toss: [11, 16], rot: [18, 24], pushups: [12, 26], throwYd: [22, 40] },
};

const PLAN: string[] = [
  "line", "line", "line", "line", "line", "line", "line", "line",
  "big", "big", "big",
  "back", "back", "back", "back",
  "skill", "skill", "skill", "skill", "skill",
  "qb", "qb",
];

function pick(r: () => number, [a, b]: [number, number], decimals = 0) {
  const v = a + (b - a) * r();
  const f = 10 ** decimals;
  return Math.round(v * f) / f;
}

export async function seedDemoRoster(prisma: PrismaClient, opts: { passwordHash: string; coachId: string }) {
  const existing = await prisma.user.count({ where: { email: { startsWith: "jh." } } });
  if (existing > 0) return;

  const r = rng(20260929);
  const testDay = new Date("2026-09-15T12:00:00.000Z");
  const earlier = new Date("2026-08-20T12:00:00.000Z");

  for (let i = 0; i < PLAN.length; i++) {
    const arch = ARCH[PLAN[i]!]!;
    const first = FIRST[i]!;
    const last = LAST[i]!;
    const email = `jh.${first.toLowerCase()}.${last.toLowerCase()}@lionlab.local`;
    const grade = r() < 0.5 ? 7 : 8;
    const g = grade === 8 ? 0.35 : 0; // 8th graders a bit bigger/faster on average
    const skew = (range: [number, number], lowerBetter = false): [number, number] => {
      const span = range[1] - range[0];
      return lowerBetter ? [range[0] - span * g * 0.3, range[1] - span * g * 0.3] : [range[0] + span * g * 0.3, range[1] + span * g * 0.3];
    };
    const height = Math.round(pick(r, skew(arch.height)));
    const weight = Math.round(pick(r, skew(arch.weight)));

    const user = await prisma.user.create({
      data: {
        email,
        name: `${first} ${last}`,
        role: "ATHLETE",
        passwordHash: opts.passwordHash,
        athlete: {
          create: {
            grade,
            positions: arch.positions,
            heightInches: height,
            weightLbs: weight,
            academicStatus: i === 3 ? "WATCH" : i === 17 ? "HOLD" : "GOOD",
            academicNote: i === 17 ? "Two missing assignments in Science. Recheck Friday." : "",
          },
        },
      },
      include: { athlete: true },
    });
    const athleteId = user.athlete!.id;

    // The team's known weakness: flexibility and balance run poor across the board.
    const sprint = pick(r, skew([arch.sprint[0], arch.sprint[1]], true), 2);
    const rows: { metric: MetricId; value: number; side?: string; source?: string; recordedOn?: Date }[] = [
      { metric: "SPRINT_40", value: sprint, source: "STOPWATCH" },
      { metric: "SPLIT_10", value: pick(r, arch.split, 2), source: "STOPWATCH" },
      { metric: "PRO_AGILITY", value: pick(r, arch.shuttle, 2), source: "STOPWATCH" },
      { metric: "BROAD_JUMP", value: pick(r, skew(arch.broad)) },
      { metric: "VERTICAL", value: pick(r, skew(arch.vert), 1) },
      { metric: "MEDBALL_CHEST", value: pick(r, skew(arch.toss), 1) },
      { metric: "PUSHUPS", value: pick(r, arch.pushups) },
      { metric: "PLANK", value: pick(r, [25, 110]) },
      { metric: "SIT_REACH", value: pick(r, [-9, 3], 1) },
      { metric: "KNEE_WALL", value: pick(r, [1.5, 4.8], 1), side: "L" },
      { metric: "KNEE_WALL", value: pick(r, [1.5, 4.8], 1), side: "R" },
      { metric: "SQUAT_SCORE", value: pick(r, [25, 85]), source: "CAMERA" },
      { metric: "BALANCE_SL", value: pick(r, [2, 18], 1), side: "L", source: "CAMERA" },
      { metric: "BALANCE_SL", value: pick(r, [2, 18], 1), side: "R", source: "CAMERA" },
      { metric: "BALANCE_SWAY", value: pick(r, [4, 22], 1), side: "L", source: "CAMERA" },
      { metric: "BALANCE_SWAY", value: pick(r, [4, 22], 1), side: "R", source: "CAMERA" },
      // an earlier 40 so the trend line has something to show
      { metric: "SPRINT_40", value: Math.round((sprint + 0.08 + r() * 0.15) * 100) / 100, source: "STOPWATCH", recordedOn: earlier },
    ];
    if (arch.throwYd) rows.push({ metric: "FOOTBALL_THROW", value: pick(r, arch.throwYd) });
    // a few non-QBs who can sling it — the kind of surprise the engine should surface
    if (!arch.throwYd && r() < 0.15) rows.push({ metric: "FOOTBALL_THROW", value: pick(r, [26, 38]) });

    await prisma.measurement.createMany({
      data: rows.map((row) => ({
        athleteId,
        metric: row.metric,
        value: row.value,
        side: row.side ?? "",
        source: row.source ?? "MANUAL",
        recordedOn: row.recordedOn ?? testDay,
        recordedById: opts.coachId,
      })),
    });

    await prisma.testSession.create({
      data: {
        athleteId,
        testType: "MEDBALL",
        rawValue: pick(r, skew(arch.rot), 1),
        passedIds: JSON.stringify(["base", "load", "release"].slice(0, 1 + Math.floor(r() * 3))),
        notes: "",
        recordedOn: testDay,
        recordedById: opts.coachId,
      },
    });
  }
}
