import type { PrismaClient } from "@prisma/client";
import { EXAM_BANK } from "../content/exam-bank";
import { gradeAnswers } from "../exams";

/**
 * Create any starter exam that is missing (matched by slug).
 * Existing exams are left alone so coach edits are never overwritten.
 */
export async function seedExams(prisma: PrismaClient): Promise<{ created: string[]; skipped: string[] }> {
  const created: string[] = [];
  const skipped: string[] = [];
  for (const exam of EXAM_BANK) {
    const existing = await prisma.exam.findUnique({ where: { slug: exam.slug }, select: { id: true } });
    if (existing) {
      skipped.push(exam.slug);
      continue;
    }
    await prisma.exam.create({
      data: {
        slug: exam.slug,
        title: exam.title,
        audience: exam.audience,
        description: exam.description,
        passPercent: exam.passPercent,
        published: true,
        questions: {
          create: exam.questions.map((q, order) => ({
            order,
            topic: q.topic,
            prompt: q.prompt,
            choices: JSON.stringify(q.choices),
            answerIndex: q.answerIndex,
            explanation: q.explanation,
          })),
        },
      },
    });
    created.push(exam.slug);
  }
  return { created, skipped };
}

type Plan = { slug: string; missCount: number; daysAgo: number };

function plansFor(positions: string, index: number): Plan[] {
  const list = positions.split(",").map((p) => p.trim());
  if (list.includes("LB")) {
    // A miss, then a pass after studying.
    return [
      { slug: "mlb-fits", missCount: 7, daysAgo: 9 },
      { slug: "mlb-fits", missCount: 2, daysAgo: 3 },
    ];
  }
  if (list.includes("QB")) return [{ slug: "qb-reads", missCount: 3, daysAgo: 5 }];
  // Everyone else: the captain's exam, mixed results.
  return [{ slug: "captain-standard", missCount: index % 2 === 0 ? 1 : 5, daysAgo: 6 - index }];
}

/**
 * Demo attempts for 2–3 athletes, only when no attempts exist at all.
 * Answers are real choice indexes; scores are graded against the stored key.
 */
export async function seedDemoAttempts(prisma: PrismaClient): Promise<number> {
  if ((await prisma.examAttempt.count()) > 0) return 0;
  const athletes = await prisma.athleteProfile.findMany({
    orderBy: { createdAt: "asc" },
    take: 3,
    select: { id: true, positions: true },
  });
  let made = 0;
  for (const [index, athlete] of athletes.entries()) {
    for (const plan of plansFor(athlete.positions, index)) {
      const exam = await prisma.exam.findUnique({
        where: { slug: plan.slug },
        include: { questions: { orderBy: { order: "asc" } } },
      });
      if (!exam || exam.questions.length === 0) continue;
      const total = exam.questions.length;
      // Spread the misses through the exam so they are not all at the end.
      const step = Math.max(1, Math.floor(total / Math.max(1, plan.missCount)));
      const missAt = new Set<number>();
      for (let k = 0; k < plan.missCount && missAt.size < total; k++) missAt.add((k * step + index) % total);
      const answers = exam.questions.map((q, i) => {
        const count = JSON.parse(q.choices).length as number;
        return missAt.has(i) ? (q.answerIndex + 1) % Math.max(2, count) : q.answerIndex;
      });
      const graded = gradeAnswers(exam.questions, answers, exam.passPercent);
      await prisma.examAttempt.create({
        data: {
          examId: exam.id,
          athleteId: athlete.id,
          answers: JSON.stringify(answers),
          correct: graded.correct,
          total: graded.total,
          percent: graded.percent,
          passed: graded.passed,
          createdAt: new Date(Date.now() - plan.daysAgo * 24 * 60 * 60 * 1000),
        },
      });
      made += 1;
    }
  }
  return made;
}
