import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  effectiveWeeklyTarget,
  parentNextStatus,
  weekStartKey,
  weekStudyTotal,
} from "./academics";

describe("weekStartKey", () => {
  it("finds Monday for any day of the week", () => {
    assert.equal(weekStartKey("2026-09-28"), "2026-09-28"); // Monday
    assert.equal(weekStartKey("2026-09-30"), "2026-09-28"); // Wednesday
    assert.equal(weekStartKey("2026-10-04"), "2026-09-28"); // Sunday
    assert.equal(weekStartKey("2026-10-05"), "2026-10-05"); // next Monday
  });
});

describe("weekStudyTotal", () => {
  const days = [
    { day: "2026-09-27", studyMinutes: 60 }, // prior Sunday — out
    { day: "2026-09-28", studyMinutes: 25 },
    { day: "2026-09-30", studyMinutes: 30 },
    { day: "2026-10-04", studyMinutes: 20 }, // Sunday — in
    { day: "2026-10-05", studyMinutes: 45 }, // next Monday — out
  ];
  it("sums Monday through Sunday only", () => {
    assert.equal(weekStudyTotal(days, "2026-09-28"), 75);
  });
  it("is zero for an empty week", () => {
    assert.equal(weekStudyTotal(days, "2026-09-14"), 0);
  });
});

describe("academic targets and parent rules", () => {
  it("raises the target 1.5x on WATCH", () => {
    assert.equal(effectiveWeeklyTarget(150, "GOOD"), 150);
    assert.equal(effectiveWeeklyTarget(150, "WATCH"), 225);
    assert.equal(effectiveWeeklyTarget(125, "WATCH"), 188);
    assert.equal(effectiveWeeklyTarget(150, "HOLD"), 150);
  });
  it("never lets a parent set or clear HOLD", () => {
    assert.equal(parentNextStatus("GOOD", "WATCH"), "WATCH");
    assert.equal(parentNextStatus("WATCH", "GOOD"), "GOOD");
    assert.equal(parentNextStatus("HOLD", "GOOD"), "HOLD");
    assert.equal(parentNextStatus("GOOD", "HOLD"), null);
  });
});
