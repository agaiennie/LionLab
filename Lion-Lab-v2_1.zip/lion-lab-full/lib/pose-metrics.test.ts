import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  BALANCE,
  LM,
  angleDeg,
  balanceSeconds,
  bestSquat,
  leanFromVertical,
  newBalanceState,
  newSquatState,
  reachRead,
  scoreSquatRep,
  squatDone,
  stepBalance,
  stepSquat,
  swayPercent,
  toAspect,
  type Pt,
} from "./pose-metrics";

function blank(): Pt[] {
  return Array.from({ length: 33 }, () => ({ x: 0.5, y: 0.5, visibility: 0.99 }));
}

/** Front view standing figure. liftL / liftR raise that ankle+heel by the given amount; hipDx shifts hips. */
function front({ liftL = 0, liftR = 0, hipDx = 0, hipDy = 0 } = {}): Pt[] {
  const lm = blank();
  lm[LM.L_SHOULDER] = { x: 0.45, y: 0.3, visibility: 1 };
  lm[LM.R_SHOULDER] = { x: 0.55, y: 0.3, visibility: 1 };
  lm[LM.L_HIP] = { x: 0.47 + hipDx, y: 0.55 + hipDy, visibility: 1 };
  lm[LM.R_HIP] = { x: 0.53 + hipDx, y: 0.55 + hipDy, visibility: 1 };
  lm[LM.L_KNEE] = { x: 0.47, y: 0.72, visibility: 1 };
  lm[LM.R_KNEE] = { x: 0.53, y: 0.72, visibility: 1 };
  lm[LM.L_ANKLE] = { x: 0.47, y: 0.9 - liftL, visibility: 1 };
  lm[LM.R_ANKLE] = { x: 0.53, y: 0.9 - liftR, visibility: 1 };
  lm[LM.L_HEEL] = { x: 0.47, y: 0.92 - liftL, visibility: 1 };
  lm[LM.R_HEEL] = { x: 0.53, y: 0.92 - liftR, visibility: 1 };
  return lm;
}

describe("angles", () => {
  it("right angle and straight line", () => {
    assert.equal(Math.round(angleDeg({ x: 0, y: 1 }, { x: 0, y: 0 }, { x: 1, y: 0 })!), 90);
    assert.equal(Math.round(angleDeg({ x: 0, y: 1 }, { x: 0, y: 0 }, { x: 0, y: -1 })!), 180);
    assert.equal(angleDeg({ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 1, y: 0 }), null);
  });
  it("lean from vertical", () => {
    assert.equal(Math.round(leanFromVertical({ x: 0, y: 0 }, { x: 0, y: 1 })), 0);
    assert.equal(Math.round(leanFromVertical({ x: 1, y: 0 }, { x: 0, y: 1 })), 45);
  });
  it("toAspect scales x only", () => {
    const [p] = toAspect([{ x: 0.5, y: 0.5 }], 4 / 3);
    assert.ok(Math.abs(p.x - 2 / 3) < 1e-9);
    assert.equal(p.y, 0.5);
  });
});

describe("single-leg balance", () => {
  it("starts on a clear lift, stops when the foot comes down, reports standing leg", () => {
    let s = newBalanceState();
    let t = 0;
    for (let i = 0; i < 10; i++) s = stepBalance(s, front(), (t += 33));
    assert.equal(s.phase, "waiting");
    // Lift the LEFT foot 0.1 (leg length ~0.35 → gap ~0.29) for 5 s
    const liftStart = t + 33;
    for (let i = 0; i < 150; i++) s = stepBalance(s, front({ liftL: 0.1, hipDx: i % 2 ? 0.005 : -0.005 }), (t += 33));
    assert.equal(s.phase, "lifted");
    assert.equal(s.standing, "R");
    assert.equal(s.startT, liftStart);
    // A small dip inside the hysteresis band does not stop the clock
    for (let i = 0; i < 5; i++) s = stepBalance(s, front({ liftL: 0.03 }), (t += 33));
    assert.equal(s.phase, "lifted");
    const downAt = t + 33;
    for (let i = 0; i < 5; i++) s = stepBalance(s, front(), (t += 33));
    assert.equal(s.phase, "done");
    assert.equal(s.stopReason, "foot-down");
    assert.equal(s.endT, downAt);
    const secs = balanceSeconds(s);
    assert.ok(secs > 5 && secs < 5.4, `secs ${secs}`);
  });

  it("ignores a one-frame blip", () => {
    let s = newBalanceState();
    s = stepBalance(s, front({ liftR: 0.1 }), 0);
    s = stepBalance(s, front(), 33);
    s = stepBalance(s, front({ liftR: 0.1 }), 66);
    assert.equal(s.phase, "waiting");
  });

  it("caps at 30 seconds", () => {
    let s = newBalanceState();
    let t = 0;
    for (let i = 0; i < 1000 && s.phase !== "done"; i++) s = stepBalance(s, front({ liftR: 0.1 }), (t += 40));
    assert.equal(s.phase, "done");
    assert.equal(s.stopReason, "cap");
    assert.equal(balanceSeconds(s), BALANCE.CAP_MS / 1000);
    assert.equal(s.standing, "L");
  });

  it("stops when tracking is lost", () => {
    let s = newBalanceState();
    let t = 0;
    for (let i = 0; i < 20; i++) s = stepBalance(s, front({ liftL: 0.1 }), (t += 33));
    for (let i = 0; i < 60; i++) s = stepBalance(s, null, (t += 33));
    assert.equal(s.phase, "done");
    assert.equal(s.stopReason, "lost");
  });

  it("sway: steady hips read low, wandering hips read high", () => {
    const torso = 0.25;
    const steady = Array.from({ length: 60 }, (_, i) => ({ x: 0.5 + (i % 2 ? 0.002 : -0.002), y: 0.55, t: i * 33 + 1000 }));
    const wobbly = Array.from({ length: 60 }, (_, i) => ({ x: 0.5 + (i % 2 ? 0.03 : -0.03), y: 0.55, t: i * 33 + 1000 }));
    const torsos = Array(60).fill(torso);
    const a = swayPercent(steady, torsos, 1000)!;
    const b = swayPercent(wobbly, torsos, 1000)!;
    // ±0.002 → sd 0.002 → 2*0.002/0.25 = 1.6 %
    assert.ok(Math.abs(a - 1.6) < 0.01, `steady ${a}`);
    assert.ok(Math.abs(b - 24) < 0.01, `wobbly ${b}`);
    assert.equal(swayPercent(steady.slice(0, 3), torsos), null);
  });
});

/** Side view squat figure facing +x. kneeDeg sets the depth; hipDrop overrides hip height. */
function side({ hipY, trunkDeg = 20, heelUp = 0, armsDown = false }: { hipY: number; trunkDeg?: number; heelUp?: number; armsDown?: boolean }): Pt[] {
  const lm = blank();
  const ankle = { x: 0.5, y: 0.9, visibility: 1 };
  const knee = { x: 0.6, y: 0.72, visibility: 1 };
  // hip sits behind the knee at a thigh length ~0.2
  const thigh = 0.2;
  const dy = hipY - knee.y;
  const dx = -Math.sqrt(Math.max(0, thigh * thigh - dy * dy));
  const hip = { x: knee.x + dx, y: hipY, visibility: 1 };
  const rad = (trunkDeg * Math.PI) / 180;
  const shoulder = { x: hip.x + 0.25 * Math.sin(rad), y: hip.y - 0.25 * Math.cos(rad), visibility: 1 };
  const wrist = armsDown
    ? { x: shoulder.x + 0.2, y: shoulder.y + 0.05, visibility: 1 }
    : { x: shoulder.x + 0.2 * Math.sin(rad), y: shoulder.y - 0.2 * Math.cos(rad), visibility: 1 };
  for (const [s, h, k, a, heel, toe, w] of [
    [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE, LM.L_ANKLE, LM.L_HEEL, LM.L_FOOT, LM.L_WRIST],
    [LM.R_SHOULDER, LM.R_HIP, LM.R_KNEE, LM.R_ANKLE, LM.R_HEEL, LM.R_FOOT, LM.R_WRIST],
  ]) {
    lm[s] = shoulder;
    lm[h] = hip;
    lm[k] = knee;
    lm[a] = ankle;
    lm[heel] = { x: 0.47, y: 0.92 - heelUp, visibility: 1 };
    lm[toe] = { x: 0.6, y: 0.92, visibility: 1 };
    lm[w] = wrist;
  }
  return lm;
}

function standing(): Pt[] {
  const lm = side({ hipY: 0.52, trunkDeg: 0 });
  // straighten the leg: put hip directly over knee-ish so knee angle > 160
  for (const h of [LM.L_HIP, LM.R_HIP]) lm[h] = { x: 0.7, y: 0.52, visibility: 1 };
  for (const s of [LM.L_SHOULDER, LM.R_SHOULDER]) lm[s] = { x: 0.7, y: 0.27, visibility: 1 };
  for (const w of [LM.L_WRIST, LM.R_WRIST]) lm[w] = { x: 0.7, y: 0.07, visibility: 1 };
  return lm;
}

function rep(state: ReturnType<typeof newSquatState>, bottom: Pt[]) {
  let s = state;
  for (let i = 0; i < 5; i++) s = stepSquat(s, standing());
  for (let i = 0; i < 5; i++) s = stepSquat(s, bottom);
  for (let i = 0; i < 5; i++) s = stepSquat(s, standing());
  return s;
}

describe("deep squat", () => {
  it("formula anchors: full depth clean = 100, parallel clean = 70", () => {
    assert.equal(scoreSquatRep({ minKnee: 50, maxDepth: 0.2, trunkAtBottom: 20, maxHeelLift: 0, minArm: 175 }).score, 100);
    assert.equal(scoreSquatRep({ minKnee: 90, maxDepth: 0, trunkAtBottom: 30, maxHeelLift: 0.01, minArm: 175 }).score, 70);
    const bad = scoreSquatRep({ minKnee: 110, maxDepth: -0.4, trunkAtBottom: 60, maxHeelLift: 0.1, minArm: 120 });
    assert.ok(bad.score < 15, `bad ${bad.score}`);
    assert.equal(bad.cues.length, 4);
  });

  it("counts reps from knee angle, scores best of three, flags heels and chest", () => {
    let s = newSquatState();
    s = rep(s, side({ hipY: 0.62, trunkDeg: 30 })); // above parallel
    assert.equal(s.reps.length, 1);
    s = rep(s, side({ hipY: 0.76, trunkDeg: 25 })); // below knee, clean
    s = rep(s, side({ hipY: 0.74, trunkDeg: 55, heelUp: 0.03 })); // deep but chest + heels
    assert.equal(s.reps.length, 3);
    assert.ok(squatDone(s));
    const best = bestSquat(s)!;
    assert.equal(best.score, 100);
    assert.ok(s.reps[0].score < best.score);
    assert.ok(s.reps[0].minKnee < 120);
    const third = s.reps[2];
    assert.ok(third.cues.some((c) => c.startsWith("Heels came up")), third.cues.join("|"));
    assert.ok(third.cues.some((c) => c.startsWith("Chest dropped")), third.cues.join("|"));
    // a fourth rep is ignored
    const after = rep(s, side({ hipY: 0.76 }));
    assert.equal(after.reps.length, 3);
  });

  it("no rep without passing under 120 degrees", () => {
    let s = newSquatState();
    s = rep(s, side({ hipY: 0.53, trunkDeg: 10 }));
    assert.equal(s.reps.length, 0);
  });
});

describe("sit and reach guide", () => {
  function sit(wristX: number): Pt[] {
    const lm = blank();
    // Seated, facing +x. Hip at 0.3, ankle 0.7, toe 0.75 on the same line.
    lm[LM.L_HIP] = { x: 0.3, y: 0.8, visibility: 1 };
    lm[LM.L_ANKLE] = { x: 0.7, y: 0.8, visibility: 1 };
    lm[LM.L_HEEL] = { x: 0.69, y: 0.82, visibility: 1 };
    lm[LM.L_FOOT] = { x: 0.75, y: 0.78, visibility: 1 };
    lm[LM.L_WRIST] = { x: wristX, y: 0.78, visibility: 1 };
    lm[LM.R_WRIST] = { x: wristX - 0.01, y: 0.78, visibility: 1 };
    for (const i of [LM.R_HIP, LM.R_ANKLE, LM.R_HEEL, LM.R_FOOT]) lm[i] = { x: 0, y: 0, visibility: 0.1 };
    return lm;
  }
  it("negative short of toes, positive past", () => {
    const short = reachRead(sit(0.65))!;
    const past = reachRead(sit(0.8))!;
    assert.ok(short.ratio < 0);
    assert.ok(past.ratio > 0);
    assert.equal(short.inches, null);
  });
  it("shoe length calibrates inches", () => {
    const r = reachRead(sit(0.8), 10)!;
    // foot ≈ hypot(0.06, 0.04) ≈ 0.0721; past ≈ 0.05 along hip→toe axis
    assert.ok(r.inches != null && r.inches > 6 && r.inches < 7.5, `inches ${r.inches}`);
  });
});
