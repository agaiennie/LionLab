export const FORMULA_VERSION = "v1";

/** Share of a 40 time added when form is empty. 100% form adds nothing. */
export const FORTY_FORM_WEIGHT = 0.1;

/** Share of med-ball distance kept when form is empty. 100% form keeps all of it. */
export const MEDBALL_FORM_FLOOR = 0.9;

export const POSITION_CODES = [
  "QB",
  "RB",
  "WR",
  "TE",
  "OL",
  "DL",
  "LB",
  "DB",
  "K",
  "ATH",
] as const;

export type PositionCode = (typeof POSITION_CODES)[number];

export const POSITIONS: { code: PositionCode; label: string }[] = [
  { code: "QB", label: "Quarterback" },
  { code: "RB", label: "Running back" },
  { code: "WR", label: "Wide receiver" },
  { code: "TE", label: "Tight end" },
  { code: "OL", label: "Offensive line" },
  { code: "DL", label: "Defensive line" },
  { code: "LB", label: "Linebacker" },
  { code: "DB", label: "Defensive back" },
  { code: "K", label: "Kicker / punter" },
  { code: "ATH", label: "Athlete" },
];

export const GRADES = [7, 8, 9, 10, 11, 12] as const;

export const TEST_TYPES = ["FORTY", "MEDBALL", "STANCE"] as const;
export type TestType = (typeof TEST_TYPES)[number];

export type CheckItem = {
  id: string;
  label: string;
  cue: string;
};

export type TestDefinition = {
  type: TestType;
  label: string;
  short: string;
  unit: "seconds" | "feet" | null;
  rawNoun: string;
  protocol: string;
  items: CheckItem[];
};

export const TESTS: Record<TestType, TestDefinition> = {
  FORTY: {
    type: "FORTY",
    label: "40-yard dash",
    short: "40-yard",
    unit: "seconds",
    rawNoun: "clock",
    protocol:
      "One athlete, one timer. Start the clock on first movement and stop it at 40 yards. Score the form checklist from that same rep.",
    items: [
      {
        id: "stance",
        label: "Start stance is loaded and still",
        cue: "Set your feet, load the hips, and get still before the start. No rocking.",
      },
      {
        id: "first-step",
        label: "First step is explosive, no false step",
        cue: "First step goes down the track. Replace the foot — don't hop backward.",
      },
      {
        id: "arms",
        label: "Arms drive, elbows about 90°",
        cue: "Hands travel hip to cheek. Elbows stay bent so the arms don't swing wide.",
      },
      {
        id: "posture",
        label: "Tall posture, no extra bounce",
        cue: "Run tall. Eyes down the track, chest up, steps under your hips.",
      },
      {
        id: "finish",
        label: "Runs through the line",
        cue: "The clock stops at 40. Your body doesn't. Run through the line.",
      },
    ],
  },
  MEDBALL: {
    type: "MEDBALL",
    label: "10 lb med-ball throw",
    short: "Med ball",
    unit: "feet",
    rawNoun: "tape",
    protocol:
      "Standing rotational throw with a 10 lb med ball. Start sideways to the line, load the back hip, and throw for distance. Measure in feet from the front foot to where the ball first lands.",
    items: [
      {
        id: "base",
        label: "Athletic base before the throw",
        cue: "Start in an athletic base. Feet alive, knees bent, ball in both hands.",
      },
      {
        id: "load",
        label: "Loads the back hip",
        cue: "Coil into the back hip. The throw starts there, not in the arms.",
      },
      {
        id: "sequence",
        label: "Hips, then torso, then arms",
        cue: "Let the hips lead, then the trunk, then the arms. Don't spin the shoulders early.",
      },
      {
        id: "release",
        label: "Release out front, not an arm-only push",
        cue: "Release the ball out front. If only the arms moved, it is not a clean throw.",
      },
      {
        id: "finish",
        label: "Sticks the finish without falling off",
        cue: "Hold the finish. Falling forward means the base wasn't ready for the power.",
      },
    ],
  },
  STANCE: {
    type: "STANCE",
    label: "Athletic stance",
    short: "Stance",
    unit: null,
    rawNoun: "checklist",
    protocol:
      "Three-second athletic stance. No clock and no tape. The coach watches the hold and checks the list. This is a form note, not a timed test.",
    items: [
      {
        id: "feet",
        label: "Feet a bit wider than the hips",
        cue: "Widen the base just outside the hips so you can move either way.",
      },
      {
        id: "knees",
        label: "Knees bent, weight on the balls of the feet",
        cue: "Bend the knees and sit the weight on the balls of the feet. Heels light.",
      },
      {
        id: "chest",
        label: "Chest over knees, back flat",
        cue: "Chest stays over the knees. Flatten the back — no rounded shoulders.",
      },
      {
        id: "hands",
        label: "Hands ready, eyes up",
        cue: "Hands in front, eyes up. Don't stare at the ground.",
      },
      {
        id: "hold",
        label: "Holds about 3 seconds without drifting",
        cue: "Be still for a full three-count. Drifting means the base isn't set.",
      },
    ],
  },
};

export function isTestType(value: string): value is TestType {
  return (TEST_TYPES as readonly string[]).includes(value);
}

export function parsePassedIds(raw: string): string[] {
  try {
    const value = JSON.parse(raw) as unknown;
    if (!Array.isArray(value)) return [];
    return value.filter((item): item is string => typeof item === "string");
  } catch {
    return [];
  }
}

export function knownPassedIds(type: TestType, passedIds: string[]): string[] {
  const known = new Set(TESTS[type].items.map((item) => item.id));
  return passedIds.filter((id) => known.has(id));
}

export function formIndex(type: TestType, passedIds: string[]): number {
  const items = TESTS[type].items;
  const passed = knownPassedIds(type, passedIds);
  return passed.length / items.length;
}

export function roundTo(value: number, places: number): number {
  const scale = 10 ** places;
  return Math.round((value + Number.EPSILON) * scale) / scale;
}

export type Estimate = {
  /** Unrounded coaching number. Null for stance, which is a band. */
  value: number | null;
  display: string;
  math: string;
};

export function adjustedEstimate(
  type: TestType,
  raw: number | null,
  index: number,
): Estimate {
  if (type === "FORTY" && raw != null) {
    const exact = raw * (1 + FORTY_FORM_WEIGHT * (1 - index));
    return {
      value: exact,
      display: `${roundTo(exact, 2).toFixed(2)}s`,
      math: `${raw.toFixed(2)}s × (1 + ${FORTY_FORM_WEIGHT.toFixed(2)} × (1 − ${index.toFixed(2)})) = ${exact.toFixed(3)}s`,
    };
  }

  if (type === "MEDBALL" && raw != null) {
    const exact = raw * (MEDBALL_FORM_FLOOR + (1 - MEDBALL_FORM_FLOOR) * index);
    return {
      value: exact,
      display: `${roundTo(exact, 1).toFixed(1)} ft`,
      math: `${raw.toFixed(1)} ft × (${MEDBALL_FORM_FLOOR.toFixed(2)} + ${(1 - MEDBALL_FORM_FLOOR).toFixed(2)} × ${index.toFixed(2)}) = ${exact.toFixed(2)} ft`,
    };
  }

  const band = stanceBand(index);
  return {
    value: null,
    display: band,
    math: `ESTIMATE band from the checklist (${Math.round(index * 100)}%). 80%+ is Game-ready, 60–79% is Developing, under 60% is Rebuild. Not a timed score.`,
  };
}

export function stanceBand(index: number): "Game-ready" | "Developing" | "Rebuild" {
  if (index >= 0.8) return "Game-ready";
  if (index >= 0.6) return "Developing";
  return "Rebuild";
}

export function formatRaw(type: TestType, raw: number | null): string {
  if (type === "STANCE" || raw == null) return "No tape";
  if (type === "FORTY") return `${raw.toFixed(2)}s`;
  return `${raw.toFixed(1)} ft`;
}

export function missedCues(type: TestType, passedIds: string[]): string[] {
  const passed = new Set(knownPassedIds(type, passedIds));
  return TESTS[type].items.filter((item) => !passed.has(item.id)).map((item) => item.cue);
}

export function retestTarget(
  type: TestType,
  raw: number | null,
  index: number,
  estimate: Estimate,
): string {
  const clean = index >= 0.999;

  if (type === "FORTY" && estimate.value != null) {
    const shown = roundTo(estimate.value, 2);
    const target = roundTo(shown - 0.05, 2).toFixed(2);
    if (clean) {
      return `Retest target: ${target}s. Form was clean, so chase the clock.`;
    }
    return `Retest target: ${target}s on the adjusted ESTIMATE, after the missed cues are clean.`;
  }

  if (type === "MEDBALL" && raw != null) {
    if (!clean) {
      return `Retest target: ${raw.toFixed(1)} ft with the missed cues cleaned. Earn the distance you already threw.`;
    }
    const shown = roundTo(raw, 1);
    const bump = Math.max(1, roundTo(shown * 0.03, 1));
    const target = roundTo(shown + bump, 1).toFixed(1);
    return `Retest target: ${target} ft. Form was clean, so add distance.`;
  }

  const total = TESTS.STANCE.items.length;
  if (clean) return `Retest target: hold ${total} of ${total} again.`;
  if (index >= 0.8) return `Retest target: ${total} of ${total}.`;
  return "Retest target: Game-ready, at least 4 of 5.";
}

export type ScoredTest = {
  testType: TestType;
  passedCount: number;
  totalCount: number;
  index: number;
  percent: number;
  rawLabel: string;
  estimate: Estimate;
  cues: string[];
  retest: string;
};

export function scoreTest(
  type: TestType,
  raw: number | null,
  passedIds: string[],
): ScoredTest {
  const index = formIndex(type, passedIds);
  const passedCount = knownPassedIds(type, passedIds).length;
  const estimate = adjustedEstimate(type, raw, index);
  return {
    testType: type,
    passedCount,
    totalCount: TESTS[type].items.length,
    index,
    percent: Math.round(index * 100),
    rawLabel: formatRaw(type, raw),
    estimate,
    cues: missedCues(type, passedIds),
    retest: retestTarget(type, raw, index, estimate),
  };
}

export function parsePositions(value: string): PositionCode[] {
  return value
    .split(",")
    .map((part) => part.trim())
    .filter((part): part is PositionCode =>
      (POSITION_CODES as readonly string[]).includes(part),
    );
}

export function formatPositions(codes: string[]): string {
  return codes.join(",");
}

export function positionLabel(code: string): string {
  return POSITIONS.find((position) => position.code === code)?.label ?? code;
}
