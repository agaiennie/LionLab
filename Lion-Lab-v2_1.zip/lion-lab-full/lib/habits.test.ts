import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { complianceStreak, studyGateBlocks } from "./habits";

describe("study gate", () => {
  it("blocks a home session until the study block or a parent note", () => {
    assert.equal(
      studyGateBlocks({ enabled: true, studyMinutes: 10, goal: 25, override: "" }),
      true,
    );
    assert.equal(
      studyGateBlocks({ enabled: true, studyMinutes: 25, goal: 25, override: "" }),
      false,
    );
    assert.equal(
      studyGateBlocks({
        enabled: true,
        studyMinutes: 0,
        goal: 25,
        override: "Rode the bus late. Study after dinner.",
      }),
      false,
    );
    assert.equal(
      studyGateBlocks({ enabled: false, studyMinutes: 0, goal: 25, override: "" }),
      false,
    );
  });
});

describe("compliance streak", () => {
  it("counts study-plus-training days and skips an empty today", () => {
    const days = [
      { day: "2026-09-19", studyMinutes: 25, trained: true },
      { day: "2026-09-20", studyMinutes: 30, trained: true },
      { day: "2026-09-21", studyMinutes: 0, trained: false },
    ];
    assert.equal(complianceStreak(days, "2026-09-21", 25), 2);
    assert.equal(complianceStreak(days, "2026-09-20", 25), 2);
  });
});
