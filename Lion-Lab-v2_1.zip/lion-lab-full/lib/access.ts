import { redirect } from "next/navigation";
import { isStaff } from "@/lib/auth";
import { getAthlete, type AthleteRecord } from "@/lib/data";
import { prisma } from "@/lib/db";

export type SessionUser = {
  id: string;
  role: string;
  name?: string | null;
  email?: string | null;
};

export async function athleteIdForUser(userId: string): Promise<string | null> {
  const profile = await prisma.athleteProfile.findUnique({
    where: { userId },
    select: { id: true },
  });
  return profile?.id ?? null;
}

export async function parentAthleteIds(parentId: string): Promise<string[]> {
  const links = await prisma.parentLink.findMany({
    where: { parentId },
    select: { athleteId: true },
  });
  return links.map((link) => link.athleteId);
}

export async function parentKids(parentId: string): Promise<AthleteRecord[]> {
  const ids = await parentAthleteIds(parentId);
  const athletes = await Promise.all(ids.map((id) => getAthlete(id)));
  return athletes
    .filter((athlete): athlete is AthleteRecord => athlete !== null)
    .sort((a, b) => a.name.localeCompare(b.name));
}

export function pickId(ids: string[], requested: string | undefined): string | null {
  if (ids.length === 0) return null;
  if (requested && ids.includes(requested)) return requested;
  return ids[0] ?? null;
}

export async function canViewAthlete(user: SessionUser, athleteId: string): Promise<boolean> {
  if (isStaff(user.role)) return true;
  if (user.role === "ATHLETE") return (await athleteIdForUser(user.id)) === athleteId;
  if (user.role === "PARENT") {
    const link = await prisma.parentLink.findUnique({
      where: { parentId_athleteId: { parentId: user.id, athleteId } },
    });
    return Boolean(link);
  }
  return false;
}

export async function canEditHome(user: SessionUser, athleteId: string): Promise<boolean> {
  if (user.role === "ATHLETE") return (await athleteIdForUser(user.id)) === athleteId;
  if (user.role === "PARENT") {
    const link = await prisma.parentLink.findUnique({
      where: { parentId_athleteId: { parentId: user.id, athleteId } },
    });
    return Boolean(link);
  }
  return false;
}

export async function requireViewAthlete(user: SessionUser, athleteId: string): Promise<AthleteRecord> {
  if (!(await canViewAthlete(user, athleteId))) redirect("/today");
  const athlete = await getAthlete(athleteId);
  if (!athlete) redirect("/today");
  return athlete;
}
