# Lion Lab — contributor conventions

App: Next.js 16 App Router + React 19 + Prisma 6 (driver adapters, SQLite local / Postgres prod) + Auth.js credentials.
House style (see `Lion-Lab-Developer-Handoff.md`): coach UI is simple, large, clinical; brand red `#C8102E` (`text-lion`, `bg-lion`, `bg-ink`, `bg-paper`); farm-plain drill names; "ESTIMATE" wording on computed numbers; not medical advice.

## Conventions (copy existing code)
- Pages are server components. `params`/`searchParams` are Promises: `{ params }: { params: Promise<{ id: string }> }` then `await params`.
- Guards: `requireUser()`, `requireStaff()`, `requireAdmin()`, `requireAthlete()`, `requireParent()` from `@/lib/guards`. Access helpers in `@/lib/access` (`canViewAthlete`, `athleteIdForUser`, `parentKids`).
- Server actions: `"use server"` files under `app/actions/<feature>.ts`. Forms use `useActionState` with `ActionState` from `@/lib/validators` (see `components/note-form.tsx`, `app/actions/daily.ts`). Re-check role inside every action. `revalidatePath` after writes.
- UI: `PageHeader` (`@/components/page-header`), `Button`/`buttonVariants` (`@/components/ui/button`, size "touch" for big phone buttons), Input, Label, Textarea, Select, Checkbox in `components/ui`. Card look: `rounded-xl bg-card p-4 ring-1 ring-foreground/10`. Headings: `font-display text-3xl tracking-wide`.
- Phone first: big tap targets, one column on small screens.
- DB access: `import { prisma } from "@/lib/db"`.
- Roles: ATHLETE, PARENT, COACH, ADMIN. `isStaff(role)` = COACH|ADMIN. User.status: ACTIVE | PENDING | DISABLED.
- Minors' privacy: athletes see only themselves; parents only linked kids; public pages never show individual athlete names or numbers.


## Routes
Athlete: /exams, /fuel. Parent: /fuel. Coach/Admin: /coach/measure, /camera, /coach/fit, /coach/recruit, /coach/exams, /coach/approvals.
Public (no sign-in): /, /signin, /signup, /join, /glossary. Signed-in guard prefixes are in proxy.ts (sign-in page is /signin).
## Security rules
- Every page that reads athlete data must call its own guard (`requireStaff()` etc.) — layouts and pages render in parallel, so a layout-only guard can stream page data before redirecting.
- In server actions, calling `await requireUser()` / `requireStaff()` is preferred over raw `auth()` because it re-checks account status.

## Adding things
- New test: add an entry to `lib/content/metrics.ts` (and an anchor in `lib/position-fit.ts` if it should feed position fit). No migration.
- New role weights: `ROLES` in `lib/position-fit.ts`; coaches can override per team on /coach/fit/weights.
- Offline Prisma (no binary downloads): set `PRISMA_JS_ENGINE=1` to use the WebAssembly schema engine through the SQLite adapter.
