import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const token =
    request.cookies.get("authjs.session-token")?.value ??
    request.cookies.get("__Secure-authjs.session-token")?.value;

  const needsSession = [
    "/athlete",
    "/coach",
    "/admin",
    "/account",
    "/today",
    "/train",
    "/measure",
    "/study",
    "/path",
    "/home",
    "/progress",
    "/notes",
    "/field",
    "/tracker",
    "/standards",
    "/skills",
    "/exams",
    "/fuel",
    "/camera",
  ].some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`));

  if (needsSession && !token) {
    return NextResponse.redirect(new URL("/signin", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/athlete/:path*",
    "/coach/:path*",
    "/admin/:path*",
    "/account/:path*",
    "/today",
    "/train",
    "/measure",
    "/study",
    "/path",
    "/home",
    "/progress",
    "/notes",
    "/field",
    "/tracker",
    "/standards",
    "/skills",
    "/skills/:path*",
    "/exams/:path*",
    "/exams",
    "/fuel",
    "/camera/:path*",
    "/camera",
  ],
};
