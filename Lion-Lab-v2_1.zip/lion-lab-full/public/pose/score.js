/**
 * Red Lion Pose Coach — angle math + RYG timeline scoring
 */
(function (global) {
  'use strict';

  const MIN_VIS = 0.45;
  const RED_MAX = 54;
  const YELLOW_MAX = 79;
  // green ≥ 80

  function dist(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = (a.z || 0) - (b.z || 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  /** Angle at point B formed by A–B–C, in degrees (0–180). */
  function angleDeg(a, b, c) {
    const ba = { x: a.x - b.x, y: a.y - b.y, z: (a.z || 0) - (b.z || 0) };
    const bc = { x: c.x - b.x, y: c.y - b.y, z: (c.z || 0) - (b.z || 0) };
    const dot = ba.x * bc.x + ba.y * bc.y + ba.z * bc.z;
    const mag = Math.sqrt(ba.x * ba.x + ba.y * ba.y + ba.z * ba.z) *
                Math.sqrt(bc.x * bc.x + bc.y * bc.y + bc.z * bc.z);
    if (mag < 1e-8) return null;
    const cos = Math.max(-1, Math.min(1, dot / mag));
    return (Math.acos(cos) * 180) / Math.PI;
  }

  /** Absolute tilt from horizontal in degrees (for level checks). */
  function levelDeg(a, b) {
    return (Math.abs(Math.atan2(b.y - a.y, b.x - a.x)) * 180) / Math.PI;
  }

  function lmVis(lm) {
    if (!lm) return 0;
    return lm.visibility != null ? lm.visibility : (lm.presence != null ? lm.presence : 1);
  }

  function getLm(landmarks, idx) {
    if (!landmarks || idx == null || idx < 0 || idx >= landmarks.length) return null;
    return landmarks[idx];
  }

  /**
   * Score one criterion against landmarks.
   * Returns { id, label, score, band, angle, ideal, weak, cue }
   */
  function scoreCriterion(crit, landmarks, issuesMap) {
    const issues = (issuesMap && issuesMap[crit.id]) || {};
    let angle = null;
    let weak = false;
    let used = [];

    if (crit.type === 'level') {
      const a = getLm(landmarks, crit.a);
      const b = getLm(landmarks, crit.b);
      used = [a, b];
      if (!a || !b) {
        weak = true;
      } else {
        const va = lmVis(a);
        const vb = lmVis(b);
        if (va < MIN_VIS || vb < MIN_VIS) weak = true;
        angle = levelDeg(a, b);
      }
    } else {
      const [ia, ib, ic] = crit.joints;
      const a = getLm(landmarks, ia);
      const b = getLm(landmarks, ib);
      const c = getLm(landmarks, ic);
      used = [a, b, c];
      if (!a || !b || !c) {
        weak = true;
      } else {
        const vs = used.map(lmVis);
        if (vs.some((v) => v < MIN_VIS)) weak = true;
        angle = angleDeg(a, b, c);
        if (angle == null) weak = true;
      }
    }

    if (weak || angle == null) {
      return {
        id: crit.id,
        label: crit.label,
        score: null,
        band: 'weak',
        angle: null,
        ideal: crit.ideal,
        weak: true,
        cue: 'Tracking weak — adjust lighting, distance, or view.',
        weight: crit.weight || 1
      };
    }

    const err = Math.abs(angle - crit.ideal);
    const tol = crit.tol || 20;
    // Full score inside half-tol; linear drop to 0 at 2.5× tol
    let score;
    if (err <= tol * 0.5) {
      score = 100;
    } else if (err >= tol * 2.5) {
      score = 0;
    } else {
      const t = (err - tol * 0.5) / (tol * 2);
      score = Math.round(100 * (1 - t));
    }
    score = Math.max(0, Math.min(100, score));

    const band = bandFor(score);
    let cue = null;
    if (score < 80) {
      if (angle < crit.ideal) cue = issues.low || null;
      else cue = issues.high || null;
    }

    return {
      id: crit.id,
      label: crit.label,
      score,
      band,
      angle: Math.round(angle * 10) / 10,
      ideal: crit.ideal,
      weak: false,
      cue,
      weight: crit.weight || 1
    };
  }

  function bandFor(score) {
    if (score == null) return 'weak';
    if (score < 55) return 'red';
    if (score < 80) return 'yellow';
    return 'green';
  }

  /**
   * Score a full movement for one frame.
   * Returns { overall, band, weak, criteria[], issues[], fixes[], timestamp }
   */
  function scoreFrame(movement, landmarks, timestampMs) {
    if (!movement || !landmarks || !landmarks.length) {
      return {
        overall: null,
        band: 'weak',
        weak: true,
        criteria: [],
        issues: ['Tracking weak'],
        fixes: ['Get full body in frame with good light.'],
        timestamp: timestampMs || 0
      };
    }

    const results = movement.criteria.map((c) =>
      scoreCriterion(c, landmarks, movement.issues)
    );

    const usable = results.filter((r) => !r.weak && r.score != null);
    const weakCount = results.length - usable.length;
    const mostlyWeak = weakCount > results.length / 2 || usable.length === 0;

    let overall = null;
    if (!mostlyWeak) {
      let wSum = 0;
      let sSum = 0;
      usable.forEach((r) => {
        wSum += r.weight;
        sSum += r.score * r.weight;
      });
      overall = wSum > 0 ? Math.round(sSum / wSum) : null;
    }

    const issues = [];
    const fixes = [];
    results.forEach((r) => {
      if (r.weak) {
        if (!issues.includes('Tracking weak')) issues.push('Tracking weak');
      } else if (r.score != null && r.score < 80 && r.cue) {
        issues.push(r.label + ': ' + Math.round(r.angle) + '° (ideal ~' + r.ideal + '°)');
        fixes.push(r.cue);
      }
    });

    return {
      overall,
      band: mostlyWeak ? 'weak' : bandFor(overall),
      weak: mostlyWeak,
      criteria: results,
      issues,
      fixes,
      timestamp: timestampMs || 0
    };
  }

  /**
   * Timeline sample for RYG playtrack.
   * samples: array of { t, overall, band, weak }
   */
  function buildTimeline(samples, durationMs) {
    return {
      durationMs: durationMs || 0,
      samples: samples || []
    };
  }

  function sampleAt(timeline, tMs) {
    if (!timeline || !timeline.samples.length) return null;
    const s = timeline.samples;
    let best = s[0];
    let bestD = Math.abs(s[0].t - tMs);
    for (let i = 1; i < s.length; i++) {
      const d = Math.abs(s[i].t - tMs);
      if (d < bestD) {
        bestD = d;
        best = s[i];
      }
    }
    return best;
  }

  /** Aggregate session score from timeline (ignore weak). */
  function sessionAggregate(timeline) {
    if (!timeline || !timeline.samples.length) {
      return { overall: null, band: 'weak', greenPct: 0, yellowPct: 0, redPct: 0, weakPct: 0 };
    }
    const s = timeline.samples;
    let g = 0, y = 0, r = 0, w = 0;
    let sum = 0, n = 0;
    s.forEach((x) => {
      if (x.weak || x.overall == null) {
        w++;
      } else {
        sum += x.overall;
        n++;
        if (x.band === 'green') g++;
        else if (x.band === 'yellow') y++;
        else r++;
      }
    });
    const total = s.length || 1;
    return {
      overall: n ? Math.round(sum / n) : null,
      band: n ? bandFor(Math.round(sum / n)) : 'weak',
      greenPct: Math.round((g / total) * 100),
      yellowPct: Math.round((y / total) * 100),
      redPct: Math.round((r / total) * 100),
      weakPct: Math.round((w / total) * 100)
    };
  }

  /** Ideal ghost angles for overlay labels. */
  function idealAngles(movement) {
    if (!movement) return [];
    return movement.criteria.map((c) => ({
      id: c.id,
      label: c.label,
      ideal: c.ideal,
      joints: c.joints || [c.a, c.b],
      type: c.type || 'angle'
    }));
  }

  global.RLScore = {
    MIN_VIS,
    RED_MAX,
    YELLOW_MAX,
    angleDeg,
    levelDeg,
    dist,
    scoreCriterion,
    scoreFrame,
    bandFor,
    buildTimeline,
    sampleAt,
    sessionAggregate,
    idealAngles
  };
})(typeof window !== 'undefined' ? window : globalThis);
