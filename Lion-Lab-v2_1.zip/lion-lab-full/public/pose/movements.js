/**
 * Red Lion Pose Coach — seed movement library
 * Ideal angle targets (degrees) and cue text for browser prototype scoring.
 * Landmark indices follow MediaPipe Pose (33 landmarks).
 * Each movement lists `positions: string[]` (not a single position field).
 */
(function (global) {
  'use strict';

  const LM = {
    NOSE: 0,
    L_SHOULDER: 11, R_SHOULDER: 12,
    L_ELBOW: 13, R_ELBOW: 14,
    L_WRIST: 15, R_WRIST: 16,
    L_HIP: 23, R_HIP: 24,
    L_KNEE: 25, R_KNEE: 26,
    L_ANKLE: 27, R_ANKLE: 28,
    L_HEEL: 29, R_HEEL: 30,
    L_FOOT: 31, R_FOOT: 32
  };

  /**
   * Each criterion: { id, label, joints: [a,b,c], ideal, tol, weight, side? }
   * Angle at landmark b between a–b–c.
   * Optional: minVis — minimum visibility to trust measurement.
   */
  const MOVEMENTS = [
    // —— Football · shared (General + relevant positions) ——
    {
      id: 'gate-hinge',
      sport: 'football',
      positions: ['General', 'LB', 'DB', 'RB', 'WR', 'TE', 'ST'],
      name: 'Gate Hinge',
      shortName: 'Gate Hinge',
      view: 'side',
      description: 'Tackle posture: hip hinge with flat back, soft knees, eyes up.',
      setupTips: [
        'Side view, full body in frame',
        '8–12 ft back, good light',
        'Pads off for clean landmarks'
      ],
      criteria: [
        { id: 'hip_hinge', label: 'Hip hinge', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 135, tol: 20, weight: 1.2 },
        { id: 'knee_soft', label: 'Soft knees', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 150, tol: 25, weight: 1.0 },
        { id: 'torso_angle', label: 'Torso lean', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 155, tol: 25, weight: 0.8 }
      ],
      issues: {
        hip_hinge: { low: 'Hips too high — sit back into the hinge.', high: 'Over-folded — lift chest slightly.' },
        knee_soft: { low: 'Knees over-bent — lengthen slightly.', high: 'Knees locked — soften 10–15°.' },
        torso_angle: { low: 'Rounded / chin tucked — eyes up, long spine.', high: 'Upright — tip from hips more.' }
      },
      idealCues: ['Hinge at hips, not waist', 'Shoulders over mid-foot', 'Eyes forward', 'Hands ready']
    },
    {
      id: 'athletic-stance',
      sport: 'football',
      positions: ['General', 'OL', 'DL', 'LB', 'DB', 'WR', 'RB', 'QB', 'TE', 'ST'],
      name: 'Athletic Stance',
      shortName: 'Athletic Stance',
      view: 'front',
      description: 'Ready base: feet outside hips, soft knees, chest up, weight mid-foot.',
      setupTips: [
        'Front or slight ¾ view',
        'Full body including feet',
        'Stand 8–12 ft from camera'
      ],
      criteria: [
        { id: 'knee_flex', label: 'Knee flex', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 145, tol: 20, weight: 1.0 },
        { id: 'knee_flex_r', label: 'Knee flex (R)', joints: [LM.R_HIP, LM.R_KNEE, LM.R_ANKLE], ideal: 145, tol: 20, weight: 1.0 },
        { id: 'hip_level', label: 'Hip stack', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 165, tol: 20, weight: 0.9 }
      ],
      issues: {
        knee_flex: { low: 'Too deep — rise slightly.', high: 'Too tall — drop into athletic base.' },
        knee_flex_r: { low: 'Right side too deep.', high: 'Right side too tall — match left.' },
        hip_level: { low: 'Forward lean — chest up.', high: 'Hips locked — soft bend.' }
      },
      idealCues: ['Feet outside hips', 'Knees soft, tracking toes', 'Chest tall', 'Weight mid-foot']
    },
    {
      id: 'fence-post',
      sport: 'football',
      positions: ['General', 'DB', 'WR', 'RB', 'TE', 'LB', 'ST'],
      name: 'Fence-Post Ankle Plant',
      shortName: 'Fence-Post',
      view: 'side',
      description: 'Plant foot stacked: ankle under knee under hip for COD / cut base.',
      setupTips: [
        'Side view of plant leg',
        'Pause in plant position',
        'Full leg + torso visible'
      ],
      criteria: [
        { id: 'ankle_knee', label: 'Ankle–knee stack', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 155, tol: 18, weight: 1.3 },
        { id: 'shin_angle', label: 'Shin angle', joints: [LM.L_KNEE, LM.L_ANKLE, LM.L_FOOT], ideal: 100, tol: 20, weight: 1.0 },
        { id: 'trunk', label: 'Trunk over plant', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 160, tol: 22, weight: 0.9 }
      ],
      issues: {
        ankle_knee: { low: 'Knee collapsing / soft plant — stiffen fence-post.', high: 'Knee locked back — slight flex OK.' },
        shin_angle: { low: 'Heel heavy — drive into ball of foot.', high: 'Too much dorsiflex — plant flatter.' },
        trunk: { low: 'Leaning past plant — stack torso over foot.', high: 'Leaving plant behind — stay over base.' }
      },
      idealCues: ['Knee over ankle', 'Hip stacked above', 'Short ground contact', 'Eyes on next step']
    },
    {
      id: 'wall-push',
      sport: 'football',
      positions: ['General', 'OL', 'DL', 'LB', 'TE'],
      name: 'Wall Push First-Step',
      shortName: 'Wall Push',
      view: 'side',
      description: 'First-step drive: lean into shin angle, push the ground back.',
      setupTips: [
        'Side view of drive leg',
        'Hold start / first-step freeze',
        'Room for lean in frame'
      ],
      criteria: [
        { id: 'drive_knee', label: 'Drive knee', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 120, tol: 22, weight: 1.2 },
        { id: 'body_lean', label: 'Body lean', joints: [LM.L_ANKLE, LM.L_HIP, LM.L_SHOULDER], ideal: 145, tol: 20, weight: 1.2 },
        { id: 'rear_ext', label: 'Trail hip', joints: [LM.R_SHOULDER, LM.R_HIP, LM.R_KNEE], ideal: 170, tol: 25, weight: 0.8 }
      ],
      issues: {
        drive_knee: { low: 'Drive knee too closed — open slightly.', high: 'Drive knee tall — punch shin forward.' },
        body_lean: { low: 'Upright — fall into the push.', high: 'Over-lean / falling — control posture.' },
        rear_ext: { low: 'Trail hip bent — extend trail leg.', high: 'OK — keep trail long.' }
      },
      idealCues: ['Shin angled forward', 'Push wall / ground back', 'Low first step', 'Arms drive opposite']
    },
    {
      id: 'hay-bale-brace',
      sport: 'football',
      positions: ['General', 'OL', 'DL', 'LB', 'TE', 'ST'],
      name: 'Hay-Bale Brace',
      shortName: 'Hay-Bale Brace',
      view: 'front',
      description: 'Anti-rotation hold: square hips/shoulders, braced core, no twist.',
      setupTips: [
        'Front view, full torso + hips',
        'Static hold 5–10 s',
        'Pads off for mobility holds'
      ],
      criteria: [
        { id: 'shoulder_level', label: 'Shoulder level', type: 'level', a: LM.L_SHOULDER, b: LM.R_SHOULDER, ideal: 0, tol: 8, weight: 1.2 },
        { id: 'hip_level', label: 'Hip level', type: 'level', a: LM.L_HIP, b: LM.R_HIP, ideal: 0, tol: 8, weight: 1.2 },
        { id: 'torso_square', label: 'Torso upright', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 175, tol: 15, weight: 1.0 }
      ],
      issues: {
        shoulder_level: { low: 'Shoulders tilting — level the yoke.', high: 'Shoulders tilting — level the yoke.' },
        hip_level: { low: 'Hips dumping — square the belt line.', high: 'Hips dumping — square the belt line.' },
        torso_square: { low: 'Leaning / twisting — brace tall.', high: 'OK — stay tall.' }
      },
      idealCues: ['Hips square', 'Shoulders level', 'Ribs down, brace', 'Breathe without twisting']
    },
    {
      id: 'grain-sack',
      sport: 'football',
      positions: ['General', 'RB', 'TE', 'OL'],
      name: 'Grain-Sack Carry',
      shortName: 'Grain-Sack',
      view: 'side',
      description: 'Upright loaded carry posture: tall torso, soft knees, no collapse.',
      setupTips: [
        'Side view while holding posture',
        'Full body from feet to head',
        'Good light on silhouette'
      ],
      criteria: [
        { id: 'torso_upright', label: 'Torso upright', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 172, tol: 12, weight: 1.3 },
        { id: 'knee_soft', label: 'Soft knees', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 165, tol: 15, weight: 0.9 },
        { id: 'hip_stack', label: 'Hip–shoulder stack', joints: [LM.L_ANKLE, LM.L_HIP, LM.L_SHOULDER], ideal: 168, tol: 15, weight: 1.0 }
      ],
      issues: {
        torso_upright: { low: 'Rounding forward — pack the sack, chest tall.', high: 'Leaning back — stack over mid-foot.' },
        knee_soft: { low: 'Knees too bent — stand taller.', high: 'Knees locked — soften slightly.' },
        hip_stack: { low: 'Hips behind — step under the load.', high: 'Hips forward — pull hips under.' }
      },
      idealCues: ['Tall through crown', 'Soft knees', 'Load close to body', 'Short steps']
    },

    // —— Football · OL ——
    {
      id: 'pass-pro-kick-slide',
      sport: 'football',
      positions: ['OL'],
      name: 'Pass-Pro Kick-Slide Base',
      shortName: 'Kick-Slide Base',
      view: 'front',
      description: 'Pass-protection set: wide base, soft knees, chest tall, weight ready to kick-slide.',
      setupTips: [
        'Front or ¾ view',
        'Full body including feet',
        'Hold set posture 3–5 s'
      ],
      criteria: [
        { id: 'knee_flex', label: 'Knee flex', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 140, tol: 20, weight: 1.2 },
        { id: 'knee_flex_r', label: 'Knee flex (R)', joints: [LM.R_HIP, LM.R_KNEE, LM.R_ANKLE], ideal: 140, tol: 20, weight: 1.2 },
        { id: 'torso', label: 'Chest tall', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 165, tol: 18, weight: 1.0 }
      ],
      issues: {
        knee_flex: { low: 'Too deep — rise into set.', high: 'Too tall — sit into kick-slide base.' },
        knee_flex_r: { low: 'Right too deep — match left.', high: 'Right too tall — drop into base.' },
        torso: { low: 'Folding — chest up, eyes on rusher.', high: 'Leaning back — stack over mid-foot.' }
      },
      idealCues: ['Wide base', 'Soft knees', 'Hands ready inside', 'Weight on inside edges']
    },
    {
      id: 'drive-block-set',
      sport: 'football',
      positions: ['OL', 'TE'],
      name: 'Drive-Block Set',
      shortName: 'Drive-Block Set',
      view: 'side',
      description: 'Run-block start: low pad level, forward lean, hips loaded to drive.',
      setupTips: [
        'Side view of set',
        'Full body from feet to head',
        'Freeze in contact-ready posture'
      ],
      criteria: [
        { id: 'pad_level', label: 'Pad / torso lean', joints: [LM.L_ANKLE, LM.L_HIP, LM.L_SHOULDER], ideal: 140, tol: 22, weight: 1.3 },
        { id: 'knee_load', label: 'Loaded knees', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 125, tol: 22, weight: 1.2 },
        { id: 'hip_hinge', label: 'Hip load', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 120, tol: 22, weight: 1.0 }
      ],
      issues: {
        pad_level: { low: 'Too upright — tip into drive lean.', high: 'Over-bent — lift eyes, keep spine long.' },
        knee_load: { low: 'Knees too closed — open slightly.', high: 'Knees tall — load for first step.' },
        hip_hinge: { low: 'Hips high — sit load into hips.', high: 'Over-folded — keep chest toward target.' }
      },
      idealCues: ['Low pads', 'Hips behind hands', 'Short first step', 'Eyes through target']
    },

    // —— Football · DL ——
    {
      id: 'get-off-stance',
      sport: 'football',
      positions: ['DL'],
      name: 'Get-Off Stance',
      shortName: 'Get-Off Stance',
      view: 'side',
      description: 'Defensive line start: loaded front leg, hips coiled, weight ready to fire.',
      setupTips: [
        'Side view of stance',
        'Full body including down hand if used',
        'Hold stance freeze'
      ],
      criteria: [
        { id: 'front_knee', label: 'Front knee load', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 115, tol: 22, weight: 1.3 },
        { id: 'hip_coil', label: 'Hip coil', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 110, tol: 22, weight: 1.2 },
        { id: 'torso', label: 'Torso lean', joints: [LM.L_ANKLE, LM.L_HIP, LM.L_SHOULDER], ideal: 135, tol: 22, weight: 1.0 }
      ],
      issues: {
        front_knee: { low: 'Front knee collapsed — stiffen shin.', high: 'Front knee tall — load for get-off.' },
        hip_coil: { low: 'Hips high — coil hips down.', high: 'Over-sat — keep hips behind hands.' },
        torso: { low: 'Upright — tip into the gap.', high: 'Over-lean — control posture.' }
      },
      idealCues: ['Weight on front foot', 'Hips coiled', 'Eyes on ball', 'Explode first step']
    },
    {
      id: 'shed-posture',
      sport: 'football',
      positions: ['DL', 'LB'],
      name: 'Shed Posture',
      shortName: 'Shed Posture',
      view: 'front',
      description: 'Contact shed: square hips, tall chest, soft knees, ready to press and escape.',
      setupTips: [
        'Front view at contact height',
        'Full torso + hips + knees',
        'Static hold of shed frame'
      ],
      criteria: [
        { id: 'knee_soft', label: 'Soft base', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 145, tol: 20, weight: 1.1 },
        { id: 'torso', label: 'Chest tall', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 165, tol: 18, weight: 1.2 },
        { id: 'hip_level', label: 'Hips square', type: 'level', a: LM.L_HIP, b: LM.R_HIP, ideal: 0, tol: 10, weight: 1.0 }
      ],
      issues: {
        knee_soft: { low: 'Too deep — rise to shed height.', high: 'Too tall — drop into power base.' },
        torso: { low: 'Folding into blocker — chest up.', high: 'Leaning back — stay into contact.' },
        hip_level: { low: 'Hips tilted — square the belt.', high: 'Hips tilted — square the belt.' }
      },
      idealCues: ['Square hips', 'Hands inside', 'Press then escape', 'Eyes on ball carrier']
    },

    // —— Football · LB ——
    {
      id: 'flow-stance',
      sport: 'football',
      positions: ['LB'],
      name: 'Flow Stance',
      shortName: 'Flow Stance',
      view: 'front',
      description: 'Linebacker flow: athletic base, hips square to flow, ready to plant and redirect.',
      setupTips: [
        'Front or ¾ view',
        'Full body including feet',
        'Hold flow-ready posture'
      ],
      criteria: [
        { id: 'knee_flex', label: 'Knee flex', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 142, tol: 20, weight: 1.2 },
        { id: 'knee_flex_r', label: 'Knee flex (R)', joints: [LM.R_HIP, LM.R_KNEE, LM.R_ANKLE], ideal: 142, tol: 20, weight: 1.2 },
        { id: 'torso', label: 'Chest tall', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 168, tol: 18, weight: 1.0 }
      ],
      issues: {
        knee_flex: { low: 'Too deep — rise for flow speed.', high: 'Too tall — drop into flow base.' },
        knee_flex_r: { low: 'Right too deep — match left.', high: 'Right too tall — match left.' },
        torso: { low: 'Rounded — chest up, eyes on backfield.', high: 'OK — stay balanced.' }
      },
      idealCues: ['Hips square to flow', 'Soft knees', 'Hands free', 'Plant then redirect']
    },

    // —— Football · DB ——
    {
      id: 'backpedal-posture',
      sport: 'football',
      positions: ['DB'],
      name: 'Backpedal Posture',
      shortName: 'Backpedal',
      view: 'side',
      description: 'DB backpedal: slight hip hinge, soft knees, chest up, weight mid-foot.',
      setupTips: [
        'Side view of backpedal freeze',
        'Full body head to feet',
        'Pause mid-pedal'
      ],
      criteria: [
        { id: 'hip_hinge', label: 'Hip hinge', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 150, tol: 20, weight: 1.2 },
        { id: 'knee_soft', label: 'Soft knees', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 148, tol: 20, weight: 1.1 },
        { id: 'torso', label: 'Chest up', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 160, tol: 20, weight: 1.0 }
      ],
      issues: {
        hip_hinge: { low: 'Too upright — tip from hips.', high: 'Over-folded — lift chest for vision.' },
        knee_soft: { low: 'Knees too bent — lengthen for speed.', high: 'Knees locked — soften for pedal.' },
        torso: { low: 'Chin tucked — eyes on QB.', high: 'Leaning back — stack over mid-foot.' }
      },
      idealCues: ['Hips under you', 'Short pedal steps', 'Eyes on QB', 'Plant to break']
    },

    // —— Football · WR / TE ——
    {
      id: 'release-stance',
      sport: 'football',
      positions: ['WR', 'TE'],
      name: 'Release Stance',
      shortName: 'Release Stance',
      view: 'side',
      description: 'Receiver release: staggered feet, soft front knee, torso stacked to explode off line.',
      setupTips: [
        'Side view of stance',
        'Full body including feet',
        'Hold pre-snap freeze'
      ],
      criteria: [
        { id: 'front_knee', label: 'Front knee', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 135, tol: 22, weight: 1.2 },
        { id: 'hip_load', label: 'Hip load', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 145, tol: 20, weight: 1.1 },
        { id: 'torso', label: 'Torso stack', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 165, tol: 18, weight: 0.9 }
      ],
      issues: {
        front_knee: { low: 'Front knee collapsed — stiffen shin.', high: 'Front knee tall — load for release.' },
        hip_load: { low: 'Hips locked — soft hinge ready.', high: 'Over-sat — stay coiled to fire.' },
        torso: { low: 'Rounded — chest up through contact.', high: 'OK — keep eyes on landmark.' }
      },
      idealCues: ['Staggered feet', 'Weight on front foot', 'Hands ready', 'Explode first step']
    },

    // —— Football · RB ——
    {
      id: 'mesh-path-posture',
      sport: 'football',
      positions: ['RB'],
      name: 'Mesh / Path Posture',
      shortName: 'Mesh/Path',
      view: 'side',
      description: 'Mesh/path carry posture: compact torso, soft knees, ball high, ready to press or cut.',
      setupTips: [
        'Side view at mesh depth',
        'Full body including ball arm if held',
        'Freeze in path posture'
      ],
      criteria: [
        { id: 'knee_soft', label: 'Soft knees', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 140, tol: 20, weight: 1.2 },
        { id: 'torso', label: 'Compact torso', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 160, tol: 18, weight: 1.1 },
        { id: 'hip_stack', label: 'Hip stack', joints: [LM.L_ANKLE, LM.L_HIP, LM.L_SHOULDER], ideal: 155, tol: 20, weight: 1.0 }
      ],
      issues: {
        knee_soft: { low: 'Too deep — rise for path speed.', high: 'Too tall — drop into mesh base.' },
        torso: { low: 'Folding — keep eyes up through hole.', high: 'Upright / exposed — tip slightly.' },
        hip_stack: { low: 'Hips behind — step under path.', high: 'Hips forward — pull hips under.' }
      },
      idealCues: ['Ball high and tight', 'Eyes through hole', 'Soft knees', 'One cut then north']
    },

    // —— Football · QB ——
    {
      id: 'throw-posture',
      sport: 'football',
      positions: ['QB'],
      name: 'Throw Posture',
      shortName: 'Throw Posture',
      view: 'side',
      description: 'Throw finish posture: front foot plant, hips open to target, tall torso, arm path high.',
      setupTips: [
        'Side / slight front of throw finish',
        'Full body plant foot to ball hand',
        'Hold finish freeze'
      ],
      criteria: [
        { id: 'front_knee', label: 'Front plant', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 150, tol: 20, weight: 1.2 },
        { id: 'torso', label: 'Tall torso', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 168, tol: 18, weight: 1.1 },
        { id: 'trail_hip', label: 'Trail hip', joints: [LM.R_SHOULDER, LM.R_HIP, LM.R_KNEE], ideal: 165, tol: 22, weight: 0.9 }
      ],
      issues: {
        front_knee: { low: 'Front knee soft / collapsing — plant firm.', high: 'Front knee locked — soft flex OK.' },
        torso: { low: 'Falling off — finish tall to target.', high: 'Leaning back — drive through plant.' },
        trail_hip: { low: 'Trail hip stuck — rotate through.', high: 'OK — finish hips to target.' }
      },
      idealCues: ['Plant toe to target', 'Hips clear', 'Elbow above shoulder', 'Finish tall']
    },
    {
      id: 'drop-set',
      sport: 'football',
      positions: ['QB'],
      name: 'Drop / Set',
      shortName: 'Drop/Set',
      view: 'side',
      description: 'Dropback set: balanced base, soft knees, chest tall, ready to throw or escape.',
      setupTips: [
        'Side view at set depth',
        'Full body including feet',
        'Hold platform freeze'
      ],
      criteria: [
        { id: 'knee_flex', label: 'Knee flex', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 148, tol: 20, weight: 1.1 },
        { id: 'knee_flex_r', label: 'Knee flex (R)', joints: [LM.R_HIP, LM.R_KNEE, LM.R_ANKLE], ideal: 148, tol: 20, weight: 1.1 },
        { id: 'torso', label: 'Chest tall', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 170, tol: 15, weight: 1.2 }
      ],
      issues: {
        knee_flex: { low: 'Too deep — rise into platform.', high: 'Too tall — soft set for throw.' },
        knee_flex_r: { low: 'Right too deep — even the base.', high: 'Right too tall — even the base.' },
        torso: { low: 'Rounded — chest up, eyes downfield.', high: 'OK — stay balanced.' }
      },
      idealCues: ['Even base', 'Ball ready at chest', 'Eyes downfield', 'Quiet feet in set']
    },

    // —— Football · ST ——
    {
      id: 'gunner-cover-start',
      sport: 'football',
      positions: ['ST'],
      name: 'Gunner / Cover Start',
      shortName: 'Gunner Start',
      view: 'side',
      description: 'Special-teams start: low lean, loaded front leg, eyes up the field for cover.',
      setupTips: [
        'Side view of start stance',
        'Full body head to feet',
        'Hold pre-snap freeze'
      ],
      criteria: [
        { id: 'front_knee', label: 'Front knee', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 120, tol: 22, weight: 1.3 },
        { id: 'body_lean', label: 'Body lean', joints: [LM.L_ANKLE, LM.L_HIP, LM.L_SHOULDER], ideal: 140, tol: 22, weight: 1.2 },
        { id: 'torso', label: 'Eyes up', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 155, tol: 22, weight: 0.9 }
      ],
      issues: {
        front_knee: { low: 'Front knee collapsed — stiffen shin.', high: 'Front knee tall — load for takeoff.' },
        body_lean: { low: 'Upright — fall into first step.', high: 'Over-lean — control start.' },
        torso: { low: 'Chin tucked — eyes up the field.', high: 'OK — stay long through spine.' }
      },
      idealCues: ['Low start', 'First step violent', 'Eyes on returner', 'Stack then shed']
    },

    // —— Lifts (General only) ——
    {
      id: 'tractor-seat',
      sport: 'lifts',
      positions: ['General'],
      name: 'Tractor Seat Squat',
      shortName: 'Tractor Seat',
      view: 'side',
      description: 'Squat to depth with upright torso and knees tracking — “sit into the tractor seat.”',
      setupTips: [
        'Side view for hinge/squat depth',
        'Full body, bar path clear if loaded',
        '8–12 ft back'
      ],
      criteria: [
        { id: 'knee_depth', label: 'Knee depth', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 95, tol: 20, weight: 1.3 },
        { id: 'hip_depth', label: 'Hip crease', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 85, tol: 20, weight: 1.2 },
        { id: 'torso', label: 'Torso angle', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 155, tol: 20, weight: 1.0 }
      ],
      issues: {
        knee_depth: { low: 'Too deep / collapsing — control bottom.', high: 'High squat — sit deeper into the seat.' },
        hip_depth: { low: 'Hips dumping under — brace and sit back.', high: 'Hips high — drop crease below parallel.' },
        torso: { low: 'Folding forward — chest up.', high: 'Too upright for your build — slight lean OK.' }
      },
      idealCues: ['Sit back and down', 'Knees track toes', 'Chest proud', 'Drive floor away']
    },
    {
      id: 'truck-hitch',
      sport: 'lifts',
      positions: ['General'],
      name: 'Truck Hitch RDL',
      shortName: 'Truck Hitch',
      view: 'side',
      description: 'Romanian deadlift hinge: soft knees, hips back, long spine (“hitch the truck”).',
      setupTips: [
        'Side view critical for hinge',
        'Full body including bar/hands',
        'Good light on back line'
      ],
      criteria: [
        { id: 'hip_hinge', label: 'Hip hinge', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 100, tol: 20, weight: 1.4 },
        { id: 'knee_soft', label: 'Soft knees', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 155, tol: 18, weight: 1.0 },
        { id: 'spine', label: 'Spine line', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 165, tol: 18, weight: 1.1 }
      ],
      issues: {
        hip_hinge: { low: 'Not hinging enough — push hips back.', high: 'Over-hinged / rounded — shorten range.' },
        knee_soft: { low: 'Squatting the RDL — keep shin more vertical.', high: 'Knees locked — unlock 10°.' },
        spine: { low: 'Rounding — pack lats, long neck.', high: 'Hyperextending — ribs down.' }
      },
      idealCues: ['Hips back like closing a door', 'Bar close to legs', 'Soft knees fixed', 'Feel hamstrings']
    },
    {
      id: 'feed-bucket-squat',
      sport: 'lifts',
      positions: ['General'],
      name: 'Feed-Bucket Squat',
      shortName: 'Feed-Bucket Squat',
      view: 'side',
      description: 'Goblet squat: hold the weight at the chest like a feed bucket, sit between the heels, chest tall.',
      setupTips: [
        'Side view, whole body and the weight in frame',
        '8–10 ft back, phone at hip height',
        'Light weight or none. Form first'
      ],
      criteria: [
        { id: 'knee_depth', label: 'Knee depth', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 85, tol: 20, weight: 1.3 },
        { id: 'hip_depth', label: 'Hip crease', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 75, tol: 20, weight: 1.0 },
        { id: 'torso', label: 'Chest tall', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 165, tol: 18, weight: 1.2 },
        { id: 'elbow_hold', label: 'Bucket at chest', joints: [LM.L_SHOULDER, LM.L_ELBOW, LM.L_WRIST], ideal: 45, tol: 25, weight: 0.6 }
      ],
      issues: {
        knee_depth: { low: 'Very deep — stay in control at the bottom.', high: 'High squat — sit down between the heels.' },
        hip_depth: { low: 'Tail tucking under — stop just above that point.', high: 'Hips high — drop the crease below the knee.' },
        torso: { low: 'Chest dropping — hold the bucket up, chest tall.', high: 'OK — stay tall.' },
        elbow_hold: { low: 'OK — weight tight to the chest.', high: 'Arms drifting out — pull the bucket to the chest.' }
      },
      idealCues: ['Weight tight to the chest', 'Sit between the heels', 'Elbows inside the knees', 'Heels down, chest tall']
    },
    {
      id: 'barn-floor-hinge',
      sport: 'lifts',
      positions: ['General'],
      name: 'Barn-Floor Hinge',
      shortName: 'Barn-Floor Hinge',
      view: 'side',
      description: 'Hip hinge (RDL pattern) with a dowel or no weight: push the hips back to the barn wall, flat back, shins nearly vertical.',
      setupTips: [
        'Side view — the back line must be visible',
        'Dowel along the spine is a good self-check',
        'No weight until the pattern is clean'
      ],
      criteria: [
        { id: 'hip_hinge', label: 'Hip hinge', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 95, tol: 20, weight: 1.4 },
        { id: 'knee_soft', label: 'Soft knees', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 160, tol: 15, weight: 1.0 },
        { id: 'spine', label: 'Flat back', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 165, tol: 18, weight: 1.2 }
      ],
      issues: {
        hip_hinge: { low: 'Folded past your hamstrings — shorten the range.', high: 'Not hinging — push the hips back to the wall.' },
        knee_soft: { low: 'Squatting it — keep the shins still.', high: 'Knees locked — unlock them a little.' },
        spine: { low: 'Back rounding — chest long, neck long.', high: 'Arching — ribs down.' }
      },
      idealCues: ['Hips back to the barn wall', 'Flat back, long neck', 'Shins stay still', 'Feel the hamstrings, then stand tall']
    },
    {
      id: 'glute-bridge',
      sport: 'lifts',
      positions: ['General'],
      name: 'Glute Bridge',
      shortName: 'Glute Bridge',
      view: 'side',
      description: 'Supine bridge: hips up, ribs down, knees ~90°, squeeze glutes at top.',
      setupTips: [
        'Side view on floor',
        'Camera at hip height if possible',
        'Full body from shoulders to feet'
      ],
      criteria: [
        { id: 'hip_ext', label: 'Hip extension', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 165, tol: 18, weight: 1.4 },
        { id: 'knee_angle', label: 'Knee angle', joints: [LM.L_HIP, LM.L_KNEE, LM.L_ANKLE], ideal: 90, tol: 20, weight: 1.0 },
        { id: 'rib_stack', label: 'Rib stack', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 170, tol: 15, weight: 0.9 }
      ],
      issues: {
        hip_ext: { low: 'Hips low — drive through heels, squeeze.', high: 'Overextending lumbar — posterior tilt.' },
        knee_angle: { low: 'Feet too close — scoot heels out.', high: 'Feet too far — bring heels under knees.' },
        rib_stack: { low: 'Ribs flaring — exhale and stack.', high: 'OK — keep chin soft.' }
      },
      idealCues: ['Drive heels', 'Squeeze glutes at top', 'Ribs down', 'Hold 1–2 s']
    },
    {
      id: 'pushup-plank',
      sport: 'lifts',
      positions: ['General'],
      name: 'Push-Up Plank Line',
      shortName: 'Plank Line',
      view: 'side',
      description: 'High plank / push-up support: ear–shoulder–hip–ankle in one line.',
      setupTips: [
        'Side view of plank',
        'Full body head to heels',
        'Hold static or bottom of push-up'
      ],
      criteria: [
        { id: 'body_line', label: 'Body line', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_ANKLE], ideal: 175, tol: 12, weight: 1.5 },
        { id: 'hip_sag', label: 'Hip height', joints: [LM.L_SHOULDER, LM.L_HIP, LM.L_KNEE], ideal: 170, tol: 15, weight: 1.1 },
        { id: 'head', label: 'Head/neck', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 165, tol: 18, weight: 0.7 }
      ],
      issues: {
        body_line: { low: 'Hips piked or sagging — find one long line.', high: 'OK — stay tight.' },
        hip_sag: { low: 'Hips dropping — brace glutes and abs.', high: 'Hips too high — lower to plank.' },
        head: { low: 'Head dropping — look slightly ahead of hands.', high: 'Looking up — neutral neck.' }
      },
      idealCues: ['One long line', 'Brace as if punched', 'Elbows soft lock', 'Hands under shoulders']
    },
    {
      id: 'oh-reach',
      sport: 'lifts',
      positions: ['General'],
      name: 'OH Reach / Press Pattern',
      shortName: 'OH Reach',
      view: 'side',
      description: 'Overhead reach or press finish: arms vertical, ribs stacked, no lumbar dump (form only).',
      setupTips: [
        'Side or slight front view',
        'Arms and torso fully visible',
        'Form check only — no load required'
      ],
      criteria: [
        { id: 'arm_vertical', label: 'Arm vertical', joints: [LM.L_HIP, LM.L_SHOULDER, LM.L_WRIST], ideal: 165, tol: 18, weight: 1.3 },
        { id: 'rib_stack', label: 'Rib stack', joints: [LM.L_HIP, LM.L_SHOULDER, LM.NOSE], ideal: 170, tol: 15, weight: 1.2 },
        { id: 'elbow', label: 'Elbow lock', joints: [LM.L_SHOULDER, LM.L_ELBOW, LM.L_WRIST], ideal: 170, tol: 15, weight: 0.9 }
      ],
      issues: {
        arm_vertical: { low: 'Arms forward — finish over mid-foot.', high: 'Arms behind — soft overextension.' },
        rib_stack: { low: 'Ribs flaring / lumbar dump — exhale, stack.', high: 'OK — keep pelvis neutral.' },
        elbow: { low: 'Soft elbows — finish the lockout.', high: 'Hyperextending elbows — soft finish OK.' }
      },
      idealCues: ['Finish over mid-foot', 'Ribs down', 'Biceps by ears', 'Glutes lightly on']
    }
  ];

  const POSITIONS = {
    football: ['General', 'OL', 'DL', 'LB', 'DB', 'WR', 'RB', 'QB', 'TE', 'ST'],
    lifts: ['General']
  };

  const SPORTS = [
    { id: 'football', label: 'Football' },
    { id: 'lifts', label: 'Weightlifting' }
  ];

  function bySport(sportId) {
    return MOVEMENTS.filter((m) => m.sport === sportId);
  }

  /** Filter by sport and position — movement.positions must include the selected position. */
  function bySportAndPosition(sportId, position) {
    var pos = position || 'General';
    return MOVEMENTS.filter(function (m) {
      return m.sport === sportId && Array.isArray(m.positions) && m.positions.indexOf(pos) !== -1;
    });
  }

  function byId(id) {
    return MOVEMENTS.find((m) => m.id === id) || null;
  }

  function positionsFor(sportId) {
    return POSITIONS[sportId] || ['General'];
  }

  global.RLMovements = {
    LM,
    MOVEMENTS,
    SPORTS,
    POSITIONS,
    bySport,
    bySportAndPosition,
    byId,
    positionsFor
  };
})(typeof window !== 'undefined' ? window : globalThis);
