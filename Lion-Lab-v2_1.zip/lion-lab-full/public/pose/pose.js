/** Red Lion Pose Coach - landmarker + draw */
(function (global) {
  'use strict';
  var CONNECTIONS = [[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[27,29],[27,31],[24,26],[26,28],[28,30],[28,32],[0,11],[0,12]];
  var WASM_CDN = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
  var MODEL_URL = "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task";
  var landmarker = null;
  var initPromise = null;
  var lastVideoTime = -1;
  var runningMode = 'VIDEO';

  async function ensureVision() {
    if (global.PoseLandmarker && global.FilesetResolver) return;
    await new Promise(function (resolve, reject) {
      var tries = 0;
      function check() {
        if (global.PoseLandmarker && global.FilesetResolver) return resolve();
        tries += 1;
        if (tries > 200) return reject(new Error('Vision tasks CDN not loaded. Check script tag.'));
        setTimeout(check, 50);
      }
      window.addEventListener('rl-vision-ready', function () { resolve(); }, { once: true });
      check();
    });
    if (!global.PoseLandmarker || !global.FilesetResolver) {
      throw new Error('Vision tasks CDN not loaded. Check script tag.');
    }
  }

  async function init() {
    if (landmarker) return landmarker;
    if (initPromise) return initPromise;
    initPromise = (async function () {
      await ensureVision();
      var vision = await global.FilesetResolver.forVisionTasks(WASM_CDN);
      var opts = {
        baseOptions: { modelAssetPath: MODEL_URL, delegate: 'GPU' },
        runningMode: 'VIDEO',
        numPoses: 1,
        minPoseDetectionConfidence: 0.5,
        minPosePresenceConfidence: 0.5,
        minTrackingConfidence: 0.5
      };
      try {
        landmarker = await global.PoseLandmarker.createFromOptions(vision, opts);
      } catch (err) {
        console.warn('GPU init failed, retrying CPU', err);
        opts.baseOptions.delegate = 'CPU';
        landmarker = await global.PoseLandmarker.createFromOptions(vision, opts);
      }
      runningMode = 'VIDEO';
      return landmarker;
    })();
    return initPromise;
  }

  async function setRunningMode(mode) {
    var pl = await init();
    if (runningMode !== mode) {
      await pl.setOptions({ runningMode: mode });
      runningMode = mode;
      lastVideoTime = -1;
    }
    return pl;
  }

  async function detect(videoEl, timestampMs) {
    var pl = await init();
    if (!videoEl || videoEl.readyState < 2) return null;
    var t = timestampMs != null ? timestampMs : performance.now();
    if (videoEl.currentTime !== undefined && videoEl.currentTime === lastVideoTime) return null;
    if (videoEl.currentTime !== undefined) lastVideoTime = videoEl.currentTime;
    try {
      await setRunningMode('VIDEO');
      var result = pl.detectForVideo(videoEl, t);
      if (!result || !result.landmarks || !result.landmarks.length) {
        return { landmarks: null, worldLandmarks: null, timestamp: t };
      }
      return {
        landmarks: result.landmarks[0],
        worldLandmarks: result.worldLandmarks ? result.worldLandmarks[0] : null,
        timestamp: t
      };
    } catch (e) {
      console.warn('detect error', e);
      return null;
    }
  }

  function resetClock() { lastVideoTime = -1; }

  function drawSkeleton(ctx, canvas, landmarks, opts) {
    opts = opts || {};
    var w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    if (!landmarks || !landmarks.length) return;
    var mirror = !!opts.mirror;
    var band = opts.band || 'green';
    var colors = { green: '#2ecc71', yellow: '#f1c40f', red: '#C8102E', weak: '#888888' };
    var stroke = colors[band] || colors.green;
    function pt(lm) {
      var x = lm.x * w;
      if (mirror) x = w - x;
      return { x: x, y: lm.y * h, v: lm.visibility != null ? lm.visibility : 1 };
    }
    ctx.lineWidth = Math.max(3, Math.round(w / 200));
    ctx.lineCap = 'round';
    ctx.strokeStyle = stroke;
    CONNECTIONS.forEach(function (pair) {
      var a = landmarks[pair[0]], b = landmarks[pair[1]];
      if (!a || !b) return;
      var pa = pt(a), pb = pt(b);
      if (pa.v < 0.3 || pb.v < 0.3) return;
      ctx.globalAlpha = Math.min(pa.v, pb.v, 0.95);
      ctx.beginPath();
      ctx.moveTo(pa.x, pa.y);
      ctx.lineTo(pb.x, pb.y);
      ctx.stroke();
    });
    ctx.globalAlpha = 1;
    var r = Math.max(4, Math.round(w / 120));
    landmarks.forEach(function (lm, idx) {
      if (!lm || (lm.visibility != null && lm.visibility < 0.3)) return;
      if (idx > 0 && idx < 11) return;
      var p = pt(lm);
      ctx.beginPath();
      ctx.fillStyle = '#ffffff';
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 2;
      ctx.stroke();
    });
    if (opts.ghostAngles && opts.ghostAngles.length) {
      ctx.font = 'bold ' + Math.max(11, Math.round(w / 45)) + 'px system-ui,sans-serif';
      ctx.textAlign = 'left';
      opts.ghostAngles.forEach(function (g, gi) {
        var joints = g.joints || [];
        var midIdx = joints[1] != null ? joints[1] : joints[0];
        var lm = landmarks[midIdx];
        if (!lm) return;
        var p = pt(lm);
        var label = g.label + ' ~' + g.ideal + '\u00b0';
        var tx = Math.min(w - 8, p.x + 10);
        var ty = Math.max(14, p.y - 8 - gi * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        var tw = ctx.measureText(label).width;
        ctx.fillRect(tx - 4, ty - 12, tw + 8, 16);
        ctx.fillStyle = '#fff';
        ctx.fillText(label, tx, ty);
      });
    }
  }

  function syncCanvasSize(canvas, video) {
    var vw = video.videoWidth || video.clientWidth || 640;
    var vh = video.videoHeight || video.clientHeight || 480;
    if (canvas.width !== vw || canvas.height !== vh) {
      canvas.width = vw;
      canvas.height = vh;
    }
  }

  global.RLPose = {
    init: init,
    detect: detect,
    drawSkeleton: drawSkeleton,
    syncCanvasSize: syncCanvasSize,
    resetClock: resetClock,
    CONNECTIONS: CONNECTIONS,
    get MODEL_URL() { return MODEL_URL; },
    get WASM_CDN() { return WASM_CDN; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
