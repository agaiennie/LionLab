import { FilesetResolver, PoseLandmarker } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs";
window.FilesetResolver = FilesetResolver;
window.PoseLandmarker = PoseLandmarker;
window.dispatchEvent(new Event("rl-vision-ready"));
