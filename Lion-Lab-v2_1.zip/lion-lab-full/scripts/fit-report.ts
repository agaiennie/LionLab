// Prints the position-fit ranking for the whole roster: `npx tsx scripts/fit-report.ts`
import "dotenv/config";
import { buildDepth, confidenceWord, fitRoles } from "../lib/position-fit";
import { loadFitConfig, loadFitRoster } from "../lib/fit-data";

async function main() {
  const { roles, needs } = await loadFitConfig();
  const roster = await loadFitRoster();
  for (const a of roster) {
    const fits = fitRoles(a, roster, roles).slice(0, 3);
    console.log(`${a.name.padEnd(20)} g${a.grade} ${a.heightInches}in ${a.weightLbs}lb [${a.positions.join(",")}] -> ` +
      fits.map((f) => `${f.role} ${f.score} (${confidenceWord(f.confidence)})`).join(" | "));
  }
  console.log("\nDepth:");
  for (const row of buildDepth(roster, needs, roles)) {
    console.log(`${row.role.padEnd(4)} need ${row.need} have ${row.assigned.length} gap ${row.gap}: ${row.assigned.map((x) => `${x.name} ${x.score}`).join(", ")}`);
  }
}
main().then(() => process.exit(0));
