// Create (or reset) the first real admin account for a production database.
//   DATABASE_URL="postgres://..." npx tsx scripts/create-admin.ts you@school.org "Your Name" 'a-long-password'
// Also loads the starter leadership exams and team settings. Does NOT create demo accounts.
import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";
import { makeAdapter } from "../lib/db-adapter";
import { seedExams } from "../lib/seed/exams";

async function main() {
  const [email, name, password] = process.argv.slice(2);
  if (!email || !name || !password || password.length < 10) {
    console.error('Usage: npx tsx scripts/create-admin.ts email "Full Name" "password (10+ chars)"');
    process.exit(1);
  }
  const prisma = new PrismaClient({ adapter: makeAdapter() });
  const passwordHash = await hash(password, 10);
  const user = await prisma.user.upsert({
    where: { email: email.toLowerCase() },
    update: { name, role: "ADMIN", status: "ACTIVE", passwordHash },
    create: { email: email.toLowerCase(), name, role: "ADMIN", status: "ACTIVE", passwordHash },
  });
  const code = Math.random().toString(36).slice(2, 8).toUpperCase();
  const team = await prisma.teamSetting.upsert({
    where: { id: "team" },
    update: {},
    create: { id: "team", joinCode: code },
  });
  await seedExams(prisma);
  console.log(`Admin ready: ${user.email}`);
  console.log(`Team join code: ${team.joinCode}  (change it on the Standards page; give it only to your families)`);
  await prisma.$disconnect();
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
