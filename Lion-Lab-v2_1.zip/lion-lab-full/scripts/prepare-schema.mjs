// Sets the Prisma datasource provider from DATABASE_URL so one schema file
// serves both local SQLite and production Postgres. Run before generate/push.
import { readFileSync, writeFileSync } from "node:fs";
import "dotenv/config";

const url = process.env.DATABASE_URL ?? "";
const provider = /^postgres(ql)?:\/\//i.test(url) ? "postgresql" : "sqlite";
const file = new URL("../prisma/schema.prisma", import.meta.url);
const src = readFileSync(file, "utf8");
const next = src.replace(/(datasource db \{\s*provider\s*=\s*)"(sqlite|postgresql)"/, `$1"${provider}"`);
if (next !== src) writeFileSync(file, next);
console.log(`[prepare-schema] provider = ${provider}`);
