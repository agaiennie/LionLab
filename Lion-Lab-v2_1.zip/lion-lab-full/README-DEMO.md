# Lion Lab — box demo

Red Lion Football field-and-home toolkit (grades 7–12). This folder is the full Next.js app. `node_modules` and `.next` are not included.

Requires Node.js 20+.

```bash
cp .env.example .env
npm i
npm run db:setup
npm run dev -- -H 0.0.0.0 -p 43123
```

Open http://127.0.0.1:43123

`npm run db:setup` creates SQLite at `prisma/dev.db` and loads the demo roster. The password on every demo account is `LionLab2026!`.

| Role | Name | Email |
| --- | --- | --- |
| Coach | Dana Ruiz | `coach@lionlab.local` |
| Parent | Pat Hale | `parent@lionlab.local` |
| Athlete | Marcus Hale | `marcus@lionlab.local` |
| Athlete | Avery Chen | `avery@lionlab.local` |
| Athlete | Jordan Brooks | `jordan@lionlab.local` |
| Admin | Sam Okonkwo | `admin@lionlab.local` |

Pat Hale is linked only to Marcus. Sign in as Dana Ruiz (`coach@lionlab.local`) and open **Field** and **Standards** for the FAST card:

First step. Attack. Shoulder level. Through — wrap if you’re tackling, drive if you’re blocking.

SQLite is for this box. A public Vercel deploy needs a published Origin repo and Postgres. See the main `README.md` section “Deploy on Vercel or Origin”.
