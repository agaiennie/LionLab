import "dotenv/config";
import path from "node:path";
import { defineConfig } from "prisma/config";
import { makeAdapter } from "./lib/db-adapter";

// Normal machines (and Vercel) use Prisma's standard schema engine for `db push`.
// PRISMA_JS_ENGINE=1 switches the CLI to the engine-free WebAssembly path through
// the SQLite driver adapter — only needed where Prisma's binaries can't be downloaded.
// The app itself always runs engine-free through driver adapters (lib/db.ts).
const jsEngine = process.env.PRISMA_JS_ENGINE === "1";

const base = {
  schema: path.join("prisma", "schema.prisma"),
  migrations: { seed: "tsx prisma/seed.ts" },
};

export default jsEngine
  ? defineConfig({
      ...base,
      experimental: { adapter: true },
      engine: "js",
      async adapter() {
        return makeAdapter();
      },
    })
  : defineConfig(base);
