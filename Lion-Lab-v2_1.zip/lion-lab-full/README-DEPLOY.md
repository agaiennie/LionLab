# Put Lion Lab on the internet (phones included)

About 30–45 minutes, free tiers, no server to babysit. You end up with a real `https://` address that works on any phone. The camera tests need `https`, and this setup gives you that.

**What you need:** a GitHub account, a Vercel account (sign in with GitHub), and a Neon account (free Postgres). Node.js 20+ on one computer for step 3.

---

## 1. Database (Neon)

1. Go to neon.tech → **New project** → name it `lion-lab` → region **US East**.
2. Copy the **connection string**. It looks like `postgresql://user:pass@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require`.
   Treat it like a password.

## 2. Code (GitHub)

1. Create a **private** repository named `lion-lab`.
2. Upload the contents of the `lion-lab-full` folder (not the zip itself). With git:
   ```bash
   cd lion-lab-full
   git init && git add . && git commit -m "Lion Lab"
   git branch -M main
   git remote add origin https://github.com/<you>/lion-lab.git
   git push -u origin main
   ```
   `.env` and `prisma/dev.db` are ignored on purpose. Never commit them.

## 3. Create the tables and your admin (one time, from your computer)

```bash
cd lion-lab-full
npm install
# Mac/Linux:
export DATABASE_URL="postgresql://...your Neon string..."
# Windows PowerShell:  $env:DATABASE_URL="postgresql://..."
npm run db:push
npm run create-admin -- you@yourschool.org "Your Name" "a-long-password-here"
```

This creates the tables, **your** admin login, the starter QB, MLB, and Captain exams, and prints the **team join code**.
It does **not** create the demo kids or the shared demo password.

> Can't run commands? Open Neon → **SQL Editor**, paste all of `prisma/postgres-init.sql`, and run it. Then the admin still has to come from `create-admin` on some computer, or ask whoever helps you with tech.

## 4. Website (Vercel)

1. vercel.com → **Add New → Project** → import the `lion-lab` repo.
2. Under **Environment Variables**, add:

   | Name | Value |
   | --- | --- |
   | `DATABASE_URL` | your Neon connection string |
   | `AUTH_SECRET` | a long random string. Generate one with `openssl rand -base64 32`, or type 40+ random characters |
   | `AUTH_TRUST_HOST` | `true` |
   | `DEMO_MODE` | `false` ← this matters. `true` puts one-tap demo logins on the sign-in page |

3. Click **Deploy**. When it's done you get a URL like `lion-lab.vercel.app`. You can attach a custom domain later (Settings → Domains).

## 5. First day

1. Sign in at `/signin` with your admin account.
2. **Standards:** set the team name, level, public blurb, season, weekly study minutes, and **change the join code**.
3. Add coaches: **Users** (admin), or have them sign up at `/signup` with the join code and approve them under **Approvals**.
4. Families: give out the site address and the join code (a flyer, the team group text). Parents and athletes sign up. You approve them and link each parent to their kid under **Approvals**.
5. Test day: **Test day** → pick a test → type the whole roster's numbers → **Save all**. Use the camera for balance and the squat check.
6. **Positions** fills in once most kids have 5–6 tests on file.

## Phone on a stand

- Open the site in Safari or Chrome → **Share → Add to Home Screen**. It then opens like an app.
- Camera tests: phone at hip height, 8–10 feet away, whole body in frame, plain background, good light. Front view for balance, side view for the squat.
- The camera runs on the phone. Video is never uploaded. Only the numbers are saved.
- A laptop with a USB webcam works the same way in Chrome.

## Updating later

Push to GitHub and Vercel redeploys on its own. If the database schema changed (`prisma/schema.prisma`), run `npm run db:push` with the Neon `DATABASE_URL` first.

## Costs and limits

The free tiers of Vercel (Hobby) and Neon cover a single team's usage. Vercel's Hobby plan is meant for personal and non-commercial use. If this becomes a paid product, or when GeoMarket runs it for a district, move to Vercel Pro or another host. The app is standard Next.js + Postgres, so it runs anywhere.

## Privacy checklist (minors' data)

- [ ] `DEMO_MODE=false` in production
- [ ] Join code changed and shared only with families
- [ ] Coaches approve every account. Parents are linked only to their own kid
- [ ] Athletic director / district has seen what's collected: height, weight, test numbers, study minutes, academic status, exam scores
- [ ] Ask the district whether its student-data or photo/video policy needs a parent form. Video never leaves the phone, but ask anyway
- [ ] For athletes under 13, get parent sign-off through the district's process before the kid creates an account. Parent-led sign-up is the safest path
