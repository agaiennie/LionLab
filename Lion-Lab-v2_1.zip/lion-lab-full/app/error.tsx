"use client";

import { Button } from "@/components/ui/button";

export default function ErrorPage({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="mx-auto flex min-h-full max-w-lg flex-col justify-center gap-3 px-4 py-16">
      <p className="font-display text-sm tracking-[0.18em] text-lion">LION LAB</p>
      <h1 className="font-display text-4xl tracking-wide">Something went wrong</h1>
      <p className="text-muted-foreground">The page did not load. Try it again.</p>
      <Button type="button" size="touch" className="w-fit" onClick={() => reset()}>
        Try again
      </Button>
    </div>
  );
}
