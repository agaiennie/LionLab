"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { AuthError } from "next-auth";
import { auth, homeFor, isStaff, signIn, signOut } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { hashPassword, verifyPassword } from "@/lib/password";
import { formatPositions } from "@/lib/scoring";
import {
  athleteFieldsSchema,
  fieldErrorsFrom,
  passwordChangeSchema,
  readPassed,
  readPositions,
  resetPasswordSchema,
  sessionSchema,
  staffSchema,
  type ActionState,
} from "@/lib/validators";

function isNextRedirect(error: unknown) {
  return (
    typeof error === "object" &&
    error !== null &&
    "digest" in error &&
    typeof error.digest === "string" &&
    error.digest.startsWith("NEXT_REDIRECT")
  );
}

function refreshAthlete(athleteId?: string) {
  revalidatePath("/coach");
  revalidatePath("/athlete");
  revalidatePath("/admin");
  revalidatePath("/today");
  revalidatePath("/measure");
  revalidatePath("/path");
  revalidatePath("/progress");
  revalidatePath("/tracker");
  if (athleteId) {
    revalidatePath(`/coach/athletes/${athleteId}`);
  }
}

export async function login(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");

  const pending = await prisma.user.findUnique({ where: { email }, select: { status: true } });
  if (pending?.status === "PENDING") {
    return { error: "Your account is waiting for a coach to approve it. You'll be able to sign in once they do." };
  }
  if (pending?.status === "DISABLED") {
    return { error: "This account is turned off. Talk to a coach." };
  }

  try {
    const result = await signIn("credentials", { email, password, redirect: false });
    if (typeof result === "string" && result.includes("error=")) {
      return { error: "That email and password don't match a Lion Lab account." };
    }
  } catch (error) {
    if (isNextRedirect(error)) throw error;
    if (error instanceof AuthError) {
      return { error: "That email and password don't match a Lion Lab account." };
    }
    return { error: "That email and password don't match a Lion Lab account." };
  }

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    return { error: "That email and password don't match a Lion Lab account." };
  }
  redirect(homeFor(user.role));
}

export async function loginDirect(formData: FormData) {
  await login({}, formData);
}

export async function logout() {
  await signOut({ redirectTo: "/signin" });
}

export async function createAthlete(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await auth();
  if (!user?.user || !isStaff(user.user.role)) {
    return { error: "Only coaches can add athletes." };
  }

  const parsed = athleteFieldsSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    grade: formData.get("grade"),
    positions: readPositions(formData),
    feet: formData.get("feet"),
    inches: formData.get("inches"),
    weightLbs: formData.get("weightLbs"),
  });
  const password = String(formData.get("password") ?? "");
  const passwordCheck = resetPasswordSchema.safeParse({ password });

  if (!parsed.success || !passwordCheck.success) {
    return {
      fieldErrors: {
        ...(parsed.success ? {} : fieldErrorsFrom(parsed.error)),
        ...(passwordCheck.success
          ? {}
          : { password: passwordCheck.error.issues[0]?.message ?? "Check the password." }),
      },
    };
  }

  const existing = await prisma.user.findUnique({
    where: { email: parsed.data.email },
  });
  if (existing) {
    return { fieldErrors: { email: "That email is already on the roster." } };
  }

  const created = await prisma.user.create({
    data: {
      name: parsed.data.name,
      email: parsed.data.email,
      passwordHash: await hashPassword(password),
      role: "ATHLETE",
      athlete: {
        create: {
          grade: parsed.data.grade,
          positions: formatPositions(parsed.data.positions),
          heightInches: parsed.data.feet * 12 + parsed.data.inches,
          weightLbs: parsed.data.weightLbs,
        },
      },
    },
    include: { athlete: true },
  });

  refreshAthlete(created.athlete?.id);
  return {
    message: "Athlete added.",
    invite: {
      athleteId: created.athlete?.id ?? "",
      name: created.name,
      email: created.email,
      temporaryPassword: password,
    },
  };
}

export async function updateAthlete(
  athleteId: string,
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const session = await auth();
  if (!session?.user) return { error: "Sign in again." };

  const athlete = await prisma.athleteProfile.findUnique({
    where: { id: athleteId },
    include: { user: true },
  });
  if (!athlete) return { error: "That athlete is not on the roster." };

  const staff = isStaff(session.user.role);
  if (!staff && session.user.id !== athlete.userId) {
    return { error: "You can only edit your own profile." };
  }

  const parsed = athleteFieldsSchema.safeParse({
    name: formData.get("name"),
    email: staff ? formData.get("email") : athlete.user.email,
    grade: formData.get("grade"),
    positions: readPositions(formData),
    feet: formData.get("feet"),
    inches: formData.get("inches"),
    weightLbs: formData.get("weightLbs"),
  });
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  if (parsed.data.email !== athlete.user.email) {
    const existing = await prisma.user.findUnique({
      where: { email: parsed.data.email },
    });
    if (existing) return { fieldErrors: { email: "That email is already in use." } };
  }

  await prisma.user.update({
    where: { id: athlete.userId },
    data: {
      name: parsed.data.name,
      email: parsed.data.email,
      athlete: {
        update: {
          grade: parsed.data.grade,
          positions: formatPositions(parsed.data.positions),
          heightInches: parsed.data.feet * 12 + parsed.data.inches,
          weightLbs: parsed.data.weightLbs,
        },
      },
    },
  });

  refreshAthlete(athleteId);
  return { message: "Profile saved." };
}

export async function saveSession(
  athleteId: string,
  sessionId: string | null,
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const session = await auth();
  if (!session?.user || !isStaff(session.user.role)) {
    return { error: "Only coaches can log tests." };
  }

  const athlete = await prisma.athleteProfile.findUnique({ where: { id: athleteId } });
  if (!athlete) return { error: "That athlete is not on the roster." };

  const parsed = sessionSchema.safeParse({
    testType: formData.get("testType"),
    raw: formData.get("raw"),
    recordedOn: formData.get("recordedOn"),
    notes: formData.get("notes") ?? "",
    passed: readPassed(formData),
  });
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  const data = {
    testType: parsed.data.testType,
    rawValue: parsed.data.raw,
    passedIds: JSON.stringify(parsed.data.passed),
    notes: parsed.data.notes,
    recordedOn: new Date(`${parsed.data.recordedOn}T12:00:00.000Z`),
    recordedById: session.user.id,
  };

  if (sessionId) {
    const existing = await prisma.testSession.findFirst({
      where: { id: sessionId, athleteId },
    });
    if (!existing) return { error: "That test is no longer on file." };
    await prisma.testSession.update({ where: { id: sessionId }, data });
  } else {
    await prisma.testSession.create({ data: { ...data, athleteId } });
  }

  refreshAthlete(athleteId);
  redirect(`/coach/athletes/${athleteId}`);
}

export async function deleteSession(athleteId: string, sessionId: string) {
  const session = await auth();
  if (!session?.user || !isStaff(session.user.role)) redirect("/");
  await prisma.testSession.deleteMany({ where: { id: sessionId, athleteId } });
  refreshAthlete(athleteId);
  redirect(`/coach/athletes/${athleteId}`);
}

export async function resetAthletePassword(
  athleteId: string,
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const session = await auth();
  if (!session?.user || !isStaff(session.user.role)) {
    return { error: "Only coaches can reset an athlete password." };
  }

  const athlete = await prisma.athleteProfile.findUnique({
    where: { id: athleteId },
    include: { user: true },
  });
  if (!athlete || athlete.user.role !== "ATHLETE") {
    return { error: "That athlete is not on the roster." };
  }

  const parsed = resetPasswordSchema.safeParse({
    password: formData.get("password"),
  });
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  await prisma.user.update({
    where: { id: athlete.userId },
    data: { passwordHash: await hashPassword(parsed.data.password) },
  });

  return {
    message: "Password updated. Share it in person. Lion Lab does not email passwords.",
    invite: {
      athleteId,
      name: athlete.user.name,
      email: athlete.user.email,
      temporaryPassword: parsed.data.password,
    },
  };
}

export async function changePassword(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const session = await auth();
  if (!session?.user?.id) return { error: "Sign in again." };

  const parsed = passwordChangeSchema.safeParse({
    current: formData.get("current"),
    next: formData.get("next"),
    confirm: formData.get("confirm"),
  });
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user) return { error: "Sign in again." };

  const matches = await verifyPassword(parsed.data.current, user.passwordHash);
  if (!matches) return { fieldErrors: { current: "That is not your current password." } };

  await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash: await hashPassword(parsed.data.next) },
  });

  return { message: "Password updated." };
}

export async function createStaff(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const session = await auth();
  if (session?.user?.role !== "ADMIN") {
    return { error: "Only an admin can add coaches." };
  }

  const parsed = staffSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    password: formData.get("password"),
    role: formData.get("role"),
  });
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  const existing = await prisma.user.findUnique({
    where: { email: parsed.data.email },
  });
  if (existing) return { fieldErrors: { email: "That email is already in use." } };

  await prisma.user.create({
    data: {
      name: parsed.data.name,
      email: parsed.data.email,
      role: parsed.data.role,
      passwordHash: await hashPassword(parsed.data.password),
    },
  });

  revalidatePath("/admin");
  return {
    message: `${parsed.data.name} can sign in. Share the password in person.`,
    invite: {
      athleteId: "",
      name: parsed.data.name,
      email: parsed.data.email,
      temporaryPassword: parsed.data.password,
    },
  };
}
