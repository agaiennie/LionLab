import Link from "next/link";
import { PublicHeader } from "@/components/shell";
import { SignupForm } from "@/components/signup-form";
import { getTeam } from "@/lib/days";

export const metadata = { title: "Create an account" };

export default async function SignupPage() {
  const team = await getTeam();
  return (
    <div className="flex min-h-svh flex-col bg-paper">
      <PublicHeader />
      <main className="mx-auto grid w-full max-w-lg gap-6 px-4 py-8">
        <header>
          <p className="font-display text-sm font-semibold tracking-[0.18em] text-lion">
            {team.teamName.toUpperCase()} · {team.levelLabel.toUpperCase()}
          </p>
          <h1 className="font-display text-4xl tracking-wide sm:text-5xl">Create an account</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Everyone signs up, then a coach approves you. Who sees what depends on your job: players see themselves,
            parents see their own kid, coaches see the team.
          </p>
        </header>
        <SignupForm />
        <p className="text-base">
          Already approved?{" "}
          <Link href="/signin" className="font-semibold text-lion">
            Sign in
          </Link>
          {" · "}
          <Link href="/join" className="font-semibold text-lion">
            Just interested in playing?
          </Link>
        </p>
      </main>
    </div>
  );
}
