import Link from "next/link";
import { redirect } from "next/navigation";
import { loginDirect, logout } from "@/app/actions";
import { LoginForm } from "@/components/login-form";
import { Wordmark } from "@/components/wordmark";
import { auth, homeFor } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { DEMO_PASSWORD } from "@/lib/demo-accounts";
import { demoMode } from "@/lib/demo-mode";

export const metadata = { title: "Sign in" };

const QUICK = [
  {
    label: "Coach",
    email: "coach@lionlab.local",
    hint: "Run the field",
  },
  {
    label: "Parent",
    email: "parent@lionlab.local",
    hint: "See your kid",
  },
  {
    label: "Athlete",
    email: "marcus@lionlab.local",
    hint: "Train and study",
  },
  {
    label: "Admin",
    email: "admin@lionlab.local",
    hint: "Users and season",
  },
] as const;

export default async function SignInPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status } = await searchParams;
  const session = await auth();
  let staleSession = false;
  if (session?.user?.id && session.user.role) {
    // Only bounce ACTIVE accounts. A pending/disabled account with an old cookie
    // lands here from requireUser and must not loop back to /today.
    const live = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { status: true },
    });
    if (live?.status === "ACTIVE") redirect(homeFor(session.user.role));
    staleSession = true;
  }

  const demo = demoMode();

  return (
    <div className="grid min-h-svh lg:grid-cols-[1fr_1.1fr]">
      <section className="flex flex-col justify-between bg-ink px-6 py-8 text-white sm:px-10">
        <Link href="/">
          <Wordmark tone="light" />
        </Link>
        <div className="my-10 max-w-lg">
          <p className="font-display text-sm tracking-[0.2em] text-lion">RED LION FOOTBALL</p>
          <h1 className="mt-2 font-display text-4xl leading-tight font-semibold tracking-wide sm:text-5xl">
            Lion Lab
          </h1>
          <p className="mt-4 text-base text-white/80">
            Players train and study. Parents see their own kid. Coaches run the field.
          </p>
          <p className="mt-3 text-sm text-white/60">
            First step · Attack · Shoulder level · Through
          </p>
        </div>
        <p className="flex flex-wrap gap-4 text-sm text-white/60">
          <Link href="/" className="underline-offset-2 hover:underline">
            ← Program home
          </Link>
          <Link href="/glossary" className="underline-offset-2 hover:underline">
            Word list
          </Link>
        </p>
      </section>
      <section className="flex items-center bg-paper px-6 py-8 sm:px-10">
        <div className="mx-auto grid w-full max-w-md gap-6">
          {status === "pending" ? (
            <div className="rounded-xl border-2 border-lion bg-card px-4 py-3" role="status">
              <p className="font-display text-xl tracking-wide text-lion">Waiting for approval</p>
              <p className="mt-1 text-sm">
                Your account is waiting for approval. A coach checks new accounts before anyone can see team
                information. You can sign in once they approve you.
              </p>
              {staleSession ? (
                <form action={logout} className="mt-3">
                  <button type="submit" className="text-sm font-semibold text-lion underline-offset-2 hover:underline">
                    Sign out of this device
                  </button>
                </form>
              ) : null}
            </div>
          ) : null}
          <div>
            <h2 className="font-display text-3xl tracking-wide">Sign in</h2>
            <p className="mt-1 text-muted-foreground">
              {demo ? "Demo mode: tap a job. One tap signs you in." : "Use the email and password you signed up with."}
            </p>
          </div>
          {demo ? (
            <>
              <div className="grid gap-3">
                {QUICK.map((account) => (
                  <form key={account.email} action={loginDirect}>
                    <input type="hidden" name="email" value={account.email} />
                    <input type="hidden" name="password" value={DEMO_PASSWORD} />
                    <button
                      type="submit"
                      className="flex w-full flex-col items-start gap-1 rounded-xl border-2 border-border bg-card px-4 py-4 text-left hover:border-lion active:bg-lion/5"
                    >
                      <span className="font-display text-2xl tracking-wide text-lion">{account.label}</span>
                      <span className="text-sm text-muted-foreground">{account.hint}</span>
                      <span className="mt-1 font-mono text-xs break-all text-foreground/70">
                        {account.email} / {DEMO_PASSWORD}
                      </span>
                    </button>
                  </form>
                ))}
              </div>
              <details className="rounded-lg border border-border bg-card p-3">
                <summary className="cursor-pointer text-sm font-semibold">Type email instead</summary>
                <div className="mt-3">
                  <LoginForm />
                </div>
              </details>
            </>
          ) : (
            <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <LoginForm />
            </div>
          )}
          <p className="text-base">
            New here?{" "}
            <Link href="/signup" className="font-semibold text-lion">
              Create an account
            </Link>
          </p>
        </div>
      </section>
    </div>
  );
}
