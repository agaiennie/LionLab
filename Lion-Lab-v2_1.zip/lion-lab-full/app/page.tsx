import Link from "next/link";
import { PublicHeader } from "@/components/shell";
import { buttonVariants } from "@/components/ui/button";
import { auth } from "@/lib/auth";
import { FAST } from "@/lib/content/fast";
import { prisma } from "@/lib/db";
import { getTeam } from "@/lib/days";
import { shiftDay, todayKey } from "@/lib/habits";

export const metadata = { title: "Program" };

const CULTURE = "We cannot ask for better players. We need to be better coaches.";

const MEASURES = [
  { name: "Speed", detail: "Short sprints with a stopwatch or phone camera." },
  { name: "Change of direction", detail: "Cone drills: plant, cut, go." },
  { name: "Power", detail: "Jumps and a medicine-ball throw." },
  { name: "Flexibility", detail: "Simple reach and hip checks." },
  { name: "Balance", detail: "Single-leg holds, both sides." },
];

function weekStart(today: string): string {
  const [y, m, d] = today.split("-").map(Number);
  const dow = new Date(Date.UTC(y, m - 1, d)).getUTCDay(); // 0 = Sunday
  return shiftDay(today, -((dow + 6) % 7)); // back to Monday
}

function seasonStart(now = new Date()): Date {
  const year = now.getUTCMonth() >= 6 ? now.getUTCFullYear() : now.getUTCFullYear() - 1;
  return new Date(Date.UTC(year, 6, 1)); // July 1
}

/** Team-wide counts only. Never names, never per-athlete numbers. */
async function teamStats() {
  const monday = weekStart(todayKey());
  const since = seasonStart();
  const [roster, study, tests, measures] = await Promise.all([
    prisma.athleteProfile.count({ where: { user: { status: "ACTIVE" } } }),
    prisma.dayLog.aggregate({ _sum: { studyMinutes: true }, where: { day: { gte: monday } } }),
    prisma.testSession.count({ where: { recordedOn: { gte: since } } }),
    prisma.measurement.count({ where: { recordedOn: { gte: since } } }),
  ]);
  return { roster, studyMinutes: study._sum.studyMinutes ?? 0, tests: tests + measures };
}

const dateLabel = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", timeZone: "UTC" });

export default async function LandingPage() {
  const [session, team, stats, posts] = await Promise.all([
    auth(),
    getTeam(),
    teamStats(),
    prisma.publicPost.findMany({
      orderBy: [{ pinned: "desc" }, { createdAt: "desc" }],
      take: 20,
      select: { id: true, title: true, body: true, pinned: true, createdAt: true },
    }),
  ]);
  const signedIn = Boolean(session?.user?.id);
  const blurb =
    team.publicBlurb.trim() ||
    "A junior high football program that teaches the game from the first step. New players are welcome every season. We coach effort, safe technique, and school first.";

  return (
    <div className="flex min-h-svh flex-col bg-paper">
      <PublicHeader />
      <main className="flex-1">
        {/* Hero */}
        <section className="bg-ink text-white">
          <div className="mx-auto grid w-full max-w-3xl gap-5 px-4 py-10 sm:py-14">
            <p className="font-display text-base font-semibold tracking-[0.2em] text-lion">
              {team.levelLabel.toUpperCase()} · {team.seasonLabel.toUpperCase()}
            </p>
            <h1 className="font-display text-5xl leading-none font-semibold tracking-wide sm:text-6xl">
              {team.teamName}
            </h1>
            <p className="text-xl text-white/85">{blurb}</p>
            <div className="grid gap-3 sm:grid-cols-2">
              {signedIn ? (
                <Link href="/today" className={buttonVariants({ size: "touch", className: "h-14 bg-lion text-lg text-white hover:bg-lion/90" })}>
                  Go to my Lion Lab
                </Link>
              ) : (
                <Link href="/signin" className={buttonVariants({ size: "touch", className: "h-14 bg-lion text-lg text-white hover:bg-lion/90" })}>
                  Sign in
                </Link>
              )}
              <Link
                href="/join"
                className={buttonVariants({
                  size: "touch",
                  variant: "outline",
                  className: "h-14 border-white/40 bg-transparent text-lg text-white hover:bg-white/10 hover:text-white",
                })}
              >
                Interested in playing?
              </Link>
            </div>
            {!signedIn ? (
              <p className="text-base text-white/70">
                Player, parent, or coach on the team?{" "}
                <Link href="/signup" className="font-semibold text-white underline underline-offset-4">
                  Create an account
                </Link>
              </p>
            ) : null}
          </div>
          <div className="h-1 bg-lion" />
        </section>

        <div className="mx-auto grid w-full max-w-3xl gap-10 px-4 py-10">
          {/* Culture */}
          <section>
            <p className="font-display text-sm font-semibold tracking-[0.18em] text-lion">OUR CULTURE</p>
            <blockquote className="mt-2 border-l-4 border-lion pl-4 font-display text-3xl leading-tight tracking-wide sm:text-4xl">
              {CULTURE}
            </blockquote>
          </section>

          {/* Academics first */}
          <section className="rounded-xl bg-card p-5 ring-1 ring-foreground/10">
            <h2 className="font-display text-3xl tracking-wide">Train the body. Train the mind.</h2>
            <p className="mt-2 text-lg">
              <span className="font-semibold">Grades come first.</span> Every player has a study requirement — about{" "}
              {team.weeklyStudyMinutes} minutes a week, logged in Lion Lab. A player who falls behind in school sits until
              the grades are fixed. Good players are smart students.
            </p>
          </section>

          {/* FAST */}
          <section>
            <h2 className="font-display text-3xl tracking-wide">
              <span className="text-lion">FAST</span> — how we hit and block
            </h2>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {FAST.map((item) => (
                <li key={item.letter} className="rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
                  <p className="font-display text-2xl tracking-wide">
                    <span className="text-lion">{item.letter}</span> {item.word}
                  </p>
                  <p className="mt-1 text-base text-muted-foreground">{item.doThis}</p>
                </li>
              ))}
            </ul>
          </section>

          {/* What we measure */}
          <section>
            <h2 className="font-display text-3xl tracking-wide">What we measure</h2>
            <p className="mt-1 text-lg text-muted-foreground">
              Each player is compared to their own last test, not to other kids. Results stay private to the player,
              their parents, and coaches.
            </p>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {MEASURES.map((item) => (
                <li key={item.name} className="rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
                  <p className="font-display text-xl tracking-wide">{item.name}</p>
                  <p className="text-base text-muted-foreground">{item.detail}</p>
                </li>
              ))}
            </ul>
          </section>

          {/* Team-wide counts */}
          <section>
            <h2 className="font-display text-3xl tracking-wide">The team this season</h2>
            <p className="mt-1 text-sm text-muted-foreground">Team totals only. No player names or numbers.</p>
            <dl className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
              <Stat label="Athletes on the roster" value={stats.roster} />
              <Stat label="Study minutes logged this week" value={stats.studyMinutes} />
              <Stat label="Tests logged this season" value={stats.tests} />
            </dl>
          </section>

          {/* Public board */}
          <section>
            <h2 className="font-display text-3xl tracking-wide">Team board</h2>
            {posts.length === 0 ? (
              <p className="mt-2 text-lg text-muted-foreground">No posts yet. Check back for the schedule and news.</p>
            ) : (
              <ul className="mt-3 grid gap-3">
                {posts.map((post) => (
                  <li
                    key={post.id}
                    className={`rounded-xl bg-card p-4 ring-1 ${post.pinned ? "ring-2 ring-lion" : "ring-foreground/10"}`}
                  >
                    <p className="text-sm text-muted-foreground">
                      {post.pinned ? <span className="mr-2 font-semibold text-lion">PINNED</span> : null}
                      {dateLabel.format(post.createdAt)}
                    </p>
                    <h3 className="font-display text-2xl tracking-wide">{post.title}</h3>
                    <p className="mt-1 text-lg whitespace-pre-line">{post.body}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Links */}
          <nav className="grid gap-2 text-lg sm:grid-cols-2" aria-label="Program links">
            {signedIn ? (
              <Link href="/today" className="font-semibold text-lion">Go to my Lion Lab →</Link>
            ) : (
              <>
                <Link href="/signin" className="font-semibold text-lion">Sign in →</Link>
                <Link href="/signup" className="font-semibold text-lion">Create an account →</Link>
              </>
            )}
            <Link href="/join" className="font-semibold text-lion">Interested in playing? →</Link>
            <Link href="/glossary" className="font-semibold text-lion">Word list →</Link>
          </nav>
        </div>
      </main>
      <footer className="border-t border-border px-4 py-4 text-center text-sm text-muted-foreground">
        The public site never shows individual players. Estimates in Lion Lab are coaching tools, not medical advice.
      </footer>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex flex-col-reverse rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
      <dt className="text-base text-muted-foreground">{label}</dt>
      <dd className="font-display text-4xl tracking-wide text-lion">{value.toLocaleString("en-US")}</dd>
    </div>
  );
}
