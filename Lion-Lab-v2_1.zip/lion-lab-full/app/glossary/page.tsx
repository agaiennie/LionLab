import Link from "next/link";
import { PublicHeader, Shell } from "@/components/shell";
import { auth } from "@/lib/auth";
import { GLOSSARY_SECTIONS } from "@/lib/content/glossary-terms";
import {
  FORTY_FORM_WEIGHT,
  FORMULA_VERSION,
  MEDBALL_FORM_FLOOR,
  TESTS,
  scoreTest,
} from "@/lib/scoring";

export const metadata = { title: "Glossary" };

const fortySample = scoreTest("FORTY", 5.2, ["stance", "first-step", "arms"]);
const medSample = scoreTest("MEDBALL", 28, ["base", "load", "sequence", "release"]);
const stanceSample = scoreTest("STANCE", null, ["feet", "knees", "hands"]);

export default async function GlossaryPage() {
  const session = await auth();
  const body = (
    <article className="mx-auto grid w-full max-w-3xl gap-8 px-4 py-8">
      <header>
        <p className="font-display text-sm font-semibold tracking-[0.18em] text-lion">LION LAB</p>
        <h1 className="font-display text-5xl tracking-wide">Glossary</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          How to read a result. The same words show up on athlete cards and the coach roster.
        </p>
      </header>

      <section className="grid gap-4">
        <Term
          title="Raw"
          body="The number from the test itself. For the 40, raw is the stopwatch in seconds. For the 10 lb med-ball throw, raw is the tape in feet. Stance has no raw number."
        />
        <Term
          title="Form index"
          body={`How much of the checklist was solid, as a percent. Each test has ${TESTS.FORTY.items.length} items. 4 checked items is 80%. Missed items become the coaching cues.`}
        />
        <Term
          title="Adjusted ESTIMATE"
          body="A coaching number that blends the raw result with the form index. It is labeled ESTIMATE because nobody measured it with a clock or a tape. A clean rep keeps the raw number. A messy rep moves the estimate so the raw result does not look more repeatable than it was."
        />
        <Term
          title="Battery"
          body="The set of tests Lion Lab keeps together: 40-yard dash, 10 lb med-ball throw, and athletic stance. Speed, power, and a position-ready base. One test is not the whole picture."
        />
        <Term
          title="RYG"
          body="Red under 55, yellow 55–79, green 80 or better on a pose score. Tracking weak means the camera could not see the joints. It is not a fake green."
        />
      </section>

      <section className="grid gap-4">
        <h2 className="font-display text-3xl tracking-wide">Formulas · {FORMULA_VERSION}</h2>
        <Formula
          title="40-yard dash"
          formula={`adjusted seconds = raw seconds × (1 + ${FORTY_FORM_WEIGHT.toFixed(2)} × (1 − form index))`}
          why="At 100% form the estimate matches the clock. At 0% form it is 10% slower. The penalty is small on purpose: bad posture should not erase a real time, and a lucky clock should not hide a rep that will not show up on Friday."
          example={`Example: 5.20s with 3 of 5 cues (form index 0.60). ${fortySample.estimate.math}. Shown as ${fortySample.estimate.display}.`}
        />
        <Formula
          title="10 lb med-ball throw"
          formula={`adjusted feet = raw feet × (${MEDBALL_FORM_FLOOR.toFixed(2)} + ${(1 - MEDBALL_FORM_FLOOR).toFixed(2)} × form index)`}
          why="At 100% form the estimate matches the tape. At 0% form it keeps 90% of the distance. Arm-only throws still moved the ball, but they do not get full credit."
          example={`Example: 28.0 ft with 4 of 5 cues (form index 0.80). ${medSample.estimate.math}. Shown as ${medSample.estimate.display}.`}
        />
        <Formula
          title="Athletic stance"
          formula="80% or better = Game-ready. 60–79% = Developing. Under 60% = Rebuild."
          why="There is no fake time and no fake distance. The band is only the checklist, so it stays an ESTIMATE of readiness, not a measurement."
          example={`Example: 3 of 5 is ${stanceSample.percent}% · ${stanceSample.estimate.display}.`}
        />
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Retest target</h2>
        <p>
          The next goal on the card. For a 40, it is 0.05s faster than the adjusted ESTIMATE, after missed cues are clean. For a med ball with form mistakes, the target is to match the raw distance with a clean throw. For stance, the target is the next band, then 5 of 5.
        </p>
      </section>

      {GLOSSARY_SECTIONS.filter((section) => section.title !== "How to read a result").map((section) => (
        <section key={section.title} className="grid gap-4">
          <h2 className="font-display text-3xl tracking-wide">{section.title}</h2>
          {section.terms.map((term) => (
            <Term key={term.term} title={term.term} body={term.meaning} />
          ))}
        </section>
      ))}

      <section className="rounded-xl bg-ink px-4 py-4 text-white">
        <h2 className="font-display text-2xl tracking-wide">What Lion Lab will not tell you</h2>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-white/80">
          <li>It is not a medical exam, an injury screen, or a return-to-play decision.</li>
          <li>It is not a college recruiting score and it does not predict a future 40.</li>
          <li>It does not publish athletes on the internet. A coach creates the account and shares the password in person.</li>
        </ul>
      </section>

      {!session?.user ? (
        <Link href="/" className="font-semibold text-lion">
          Back to home
        </Link>
      ) : null}
    </article>
  );

  if (!session?.user) {
    return (
      <div className="min-h-full bg-paper">
        <PublicHeader />
        {body}
      </div>
    );
  }

  return (
    <Shell role={session.user.role} name={session.user.name ?? "Lion Lab"}>
      {body}
    </Shell>
  );
}

function Term({ title, body }: { title: string; body: string }) {
  return (
    <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <h2 className="font-display text-2xl tracking-wide">{title}</h2>
      <p className="mt-1 text-muted-foreground">{body}</p>
    </section>
  );
}

function Formula({
  title,
  formula,
  why,
  example,
}: {
  title: string;
  formula: string;
  why: string;
  example: string;
}) {
  return (
    <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <h3 className="font-display text-2xl tracking-wide">{title}</h3>
      <p className="mt-2 rounded-lg bg-muted px-3 py-2 font-mono text-sm">{formula}</p>
      <p className="mt-2">{why}</p>
      <p className="mt-2 text-sm text-muted-foreground">{example}</p>
    </section>
  );
}
