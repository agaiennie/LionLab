import Link from "next/link";
import { deletePost, togglePin } from "@/app/actions/board";
import { BoardPostForm } from "@/components/board-post-form";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { prisma } from "@/lib/db";
import { requireStaff } from "@/lib/guards";

export const metadata = { title: "Public board" };

const dateLabel = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });

export default async function BoardPage() {
  await requireStaff();
  const posts = await prisma.publicPost.findMany({
    orderBy: [{ pinned: "desc" }, { createdAt: "desc" }],
    include: { author: { select: { name: true } } },
  });

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Coach"
        title="Public board"
        description="Schedule changes and news for families. Shows on the public program page with no sign-in."
        action={
          <>
            <Link href="/" className="text-sm font-semibold text-lion">View public page</Link>
            <Link href="/coach/approvals" className="text-sm font-semibold text-lion">Approvals</Link>
          </>
        }
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_22rem]">
        <section className="grid content-start gap-3">
          {posts.length === 0 ? (
            <p className="text-lg text-muted-foreground">No posts yet.</p>
          ) : (
            posts.map((post) => (
              <article
                key={post.id}
                className={`rounded-xl bg-card p-4 ring-1 ${post.pinned ? "ring-2 ring-lion" : "ring-foreground/10"}`}
              >
                <p className="text-sm text-muted-foreground">
                  {post.pinned ? <span className="mr-2 font-semibold text-lion">PINNED</span> : null}
                  {dateLabel.format(post.createdAt)} · {post.author.name}
                </p>
                <h2 className="font-display text-2xl tracking-wide">{post.title}</h2>
                <p className="mt-1 text-base whitespace-pre-line">{post.body}</p>
                <div className="mt-3 flex flex-wrap gap-3">
                  <form action={togglePin}>
                    <input type="hidden" name="postId" value={post.id} />
                    <Button type="submit" variant="outline" size="touch">
                      {post.pinned ? "Unpin" : "Pin"}
                    </Button>
                  </form>
                  <form action={deletePost}>
                    <input type="hidden" name="postId" value={post.id} />
                    <Button type="submit" variant="destructive" size="touch">
                      Delete
                    </Button>
                  </form>
                </div>
              </article>
            ))
          )}
        </section>
        <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <h2 className="mb-3 font-display text-2xl tracking-wide">New post</h2>
          <BoardPostForm />
        </section>
      </div>
    </div>
  );
}
