import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { buttonVariants } from "@/components/ui/button";
import { loadFitConfig, loadFitRoster } from "@/lib/fit-data";
import { buildDepth, confidenceWord, FACTOR_LABELS, fitRoles, READY_SCORE, ROLE_BY_ID, type DepthRow } from "@/lib/position-fit";
import { requireStaff } from "@/lib/guards";
import { cn } from "cn";

export const metadata = { title: "Positions" };

export default async function FitBoardPage({ searchParams }: { searchParams: Promise<{ view?: string }> }) {
  await requireStaff();
  const { view } = await searchParams;
  const [{ roles, needs }, roster] = await Promise.all([loadFitConfig(), loadFitRoster()]);
  const depth = buildDepth(roster, needs, roles);
  const offense = depth.filter((row) => ROLE_BY_ID[row.role].side === "O");
  const defense = depth.filter((row) => ROLE_BY_ID[row.role].side === "D");
  const shortRoles = depth.filter((row) => row.gap > 0 || row.thin > 0);
  const rows = roster.map((athlete) => ({ athlete, fits: fitRoles(athlete, roster, roles) }));
  const showTable = view === "players";

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Position fit · ESTIMATE"
        title="Positions"
        description="Test numbers, height, weight, and leadership exams, weighted by what each job needs. A starting point for the conversation — you make the call."
        action={
          <div className="flex flex-wrap gap-2">
            <Link href="/coach/fit/weights" className={cn(buttonVariants({ variant: "outline", size: "touch" }))}>
              Weights & needs
            </Link>
            <Link href="/coach/recruit" className={cn(buttonVariants({ size: "touch" }))}>
              Recruit for gaps
            </Link>
          </div>
        }
      />

      <div className="flex gap-2">
        <Link href="/coach/fit" className={cn("rounded-full px-4 py-2 text-sm font-semibold", !showTable ? "bg-ink text-white" : "bg-card ring-1 ring-foreground/10")}>
          Depth board
        </Link>
        <Link href="/coach/fit?view=players" className={cn("rounded-full px-4 py-2 text-sm font-semibold", showTable ? "bg-ink text-white" : "bg-card ring-1 ring-foreground/10")}>
          Every player
        </Link>
      </div>

      {!showTable ? (
        <>
          <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
            <h2 className="font-display text-2xl tracking-wide">Needs</h2>
            {shortRoles.length === 0 ? (
              <p className="mt-1 text-sm">Every role has enough players scoring {READY_SCORE}+ on the current numbers.</p>
            ) : (
              <ul className="mt-2 grid gap-1 text-sm">
                {shortRoles.map((row) => (
                  <li key={row.role}>
                    <span className="font-semibold">{row.label}:</span>{" "}
                    {row.gap > 0 ? `${row.gap} open spot${row.gap > 1 ? "s" : ""}` : null}
                    {row.gap > 0 && row.thin > 0 ? " · " : null}
                    {row.thin > 0 ? `${row.thin} placed under ${READY_SCORE}` : null}
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-2 text-xs text-muted-foreground">
              Each player fills at most one offensive and one defensive spot, best fits first. {roster.length} active athletes.
            </p>
          </section>
          <Side title="Offense" rows={offense} />
          <Side title="Defense" rows={defense} />
          <p className="text-sm text-muted-foreground">
            Kicker/punter isn&apos;t scored — run a kicking tryout. Captains: see the Captain&apos;s Standard results on{" "}
            <Link href="/coach/exams" className="font-semibold text-lion">
              Exams
            </Link>
            .
          </p>
        </>
      ) : (
        <section className="grid gap-2">
          <ul className="grid gap-2">
            {rows.map(({ athlete, fits }) => (
              <li key={athlete.id} className="grid gap-1 rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10 md:grid-cols-[14rem_1fr] md:items-center">
                <div>
                  <Link href={`/coach/athletes/${athlete.id}`} className="font-semibold">
                    {athlete.name}
                  </Link>
                  <p className="text-xs text-muted-foreground">
                    Gr {athlete.grade} · {Math.floor(athlete.heightInches / 12)}&apos;{athlete.heightInches % 12}&quot; · {athlete.weightLbs} lb · declared {athlete.positions.join(", ")}
                    {athlete.values.EXAM_QB != null ? ` · QB exam ${athlete.values.EXAM_QB}%` : ""}
                    {athlete.values.EXAM_MLB != null ? ` · MLB exam ${athlete.values.EXAM_MLB}%` : ""}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {fits.slice(0, 3).map((fit) => (
                    <span
                      key={fit.role}
                      className={cn(
                        "rounded-full px-3 py-1 text-sm ring-1",
                        athlete.positions.includes(fit.code as never) ? "ring-lion" : "ring-foreground/15",
                      )}
                      title={fit.strengths.join(" · ")}
                    >
                      <span className="font-semibold">{fit.role}</span> {fit.score}
                      <span className="text-muted-foreground"> · {confidenceWord(fit.confidence)}</span>
                    </span>
                  ))}
                </div>
              </li>
            ))}
          </ul>
          <p className="text-xs text-muted-foreground">Red outline = matches a position the player declared.</p>
        </section>
      )}

      <details className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <summary className="cursor-pointer font-display text-xl tracking-wide">How the score works</summary>
        <div className="mt-3 grid gap-3 text-sm">
          <p>
            Every number becomes a 0–100 standing. With 8 or more teammates tested (same grade band when possible) the standing is the
            team percentile. With fewer, it uses coaching anchors for junior high or high school. Exams count as their percent.
          </p>
          <p>
            Each role weights the numbers that matter for that job. &quot;Aim&quot; factors target a size range instead of more-is-better
            (a running back should be compact, not the biggest kid). Missing tests lower confidence and push the role down the list.
          </p>
          <ul className="grid gap-1">
            {roles.map((role) => (
              <li key={role.id}>
                <span className="font-semibold">{role.label}:</span>{" "}
                {role.factors
                  .filter((f) => f.weight > 0)
                  .map((f) => `${FACTOR_LABELS[f.key]} ×${f.weight}${f.mode === "target" ? ` (aim ${f.target}th pct)` : ""}`)
                  .join(", ")}
              </li>
            ))}
          </ul>
        </div>
      </details>
    </div>
  );
}

function Side({ title, rows }: { title: string; rows: DepthRow[] }) {
  return (
    <section className="grid gap-3">
      <h2 className="font-display text-3xl tracking-wide">{title}</h2>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {rows.map((row) => (
          <div key={row.role} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
            <div className="flex items-baseline justify-between gap-2">
              <p className="font-display text-xl tracking-wide">{row.label}</p>
              <p className={cn("text-sm font-semibold", row.gap > 0 ? "text-lion" : row.thin > 0 ? "text-amber-700" : "text-muted-foreground")}>
                {row.assigned.length}/{row.need}
                {row.gap > 0 ? " · short" : row.thin > 0 ? " · thin" : ""}
              </p>
            </div>
            <ol className="mt-2 grid gap-1 text-sm">
              {row.assigned.map((a) => (
                <li key={a.id} className="flex justify-between gap-2">
                  <Link href={`/coach/athletes/${a.id}`}>{a.name}</Link>
                  <span className={cn(a.score < READY_SCORE ? "text-amber-700" : "")}>{a.score}</span>
                </li>
              ))}
              {Array.from({ length: row.gap }).map((_, i) => (
                <li key={`gap-${i}`} className="text-muted-foreground">
                  — open —
                </li>
              ))}
            </ol>
            {row.bench.length ? (
              <p className="mt-2 text-xs text-muted-foreground">
                Also fits: {row.bench.map((b) => `${b.name} ${b.score}`).join(", ")}
              </p>
            ) : null}
          </div>
        ))}
      </div>
    </section>
  );
}
