import Link from "next/link";
import { resetFitSettings } from "@/app/actions/fit";
import { FitWeightsForm } from "@/components/fit-weights-form";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { loadFitConfig } from "@/lib/fit-data";
import { FACTOR_LABELS, ROLES } from "@/lib/position-fit";
import { requireStaff } from "@/lib/guards";

export const metadata = { title: "Fit weights" };

export default async function FitWeightsPage() {
  await requireStaff();
  const { roles, needs } = await loadFitConfig();
  const rows = roles.map((role) => {
    const base = ROLES.find((r) => r.id === role.id)!;
    return {
      id: role.id,
      label: role.label,
      need: needs[role.id],
      factors: role.factors.map((f) => ({
        key: f.key,
        label: FACTOR_LABELS[f.key],
        weight: f.weight,
        defaultWeight: base.factors.find((b) => b.key === f.key)?.weight ?? f.weight,
        note: f.mode === "target" ? `aims at ${f.target}th pct` : "",
      })),
    };
  });

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Positions"
        title="Weights & needs"
        description="How much each number counts for each job, and how many players you need there. 0 turns a factor off. Your offense and defense may want different things than the defaults."
        action={
          <Link href="/coach/fit" className="text-sm font-semibold text-lion">
            Back to board
          </Link>
        }
      />
      <FitWeightsForm roles={rows} />
      <form action={resetFitSettings}>
        <Button type="submit" variant="outline" size="touch">
          Reset to defaults
        </Button>
      </form>
    </div>
  );
}
