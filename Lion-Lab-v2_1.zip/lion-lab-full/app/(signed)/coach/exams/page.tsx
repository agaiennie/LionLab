import Link from "next/link";
import { PassBadge } from "@/components/exam-badges";
import { ExamMetaForm } from "@/components/exam-editor-forms";
import { PageHeader } from "@/components/page-header";
import { prisma } from "@/lib/db";
import { AUDIENCE_LABEL, examRequiredFor, summarizeAttempts } from "@/lib/exams";
import { requireStaff } from "@/lib/guards";
import { parsePositions } from "@/lib/scoring";

export const metadata = { title: "Exams" };

export default async function CoachExamsPage({ searchParams }: { searchParams: Promise<{ exam?: string }> }) {
  await requireStaff();
  const { exam: filter } = await searchParams;

  const [exams, athletes] = await Promise.all([
    prisma.exam.findMany({
      orderBy: { title: "asc" },
      include: {
        _count: { select: { questions: true } },
        attempts: { select: { athleteId: true, percent: true, passed: true, createdAt: true } },
      },
    }),
    prisma.athleteProfile.findMany({
      where: { user: { status: "ACTIVE" } },
      select: { id: true, positions: true, user: { select: { name: true } } },
      orderBy: { user: { name: "asc" } },
    }),
  ]);

  const selected = exams.find((exam) => exam.id === filter);
  const shown = selected ? [selected] : exams;

  type Row = {
    key: string;
    athleteId: string;
    name: string;
    examTitle: string;
    required: boolean;
    passPercent: number;
    summary: ReturnType<typeof summarizeAttempts>;
  };
  const rows: Row[] = [];
  for (const exam of shown) {
    for (const athlete of athletes) {
      const mine = exam.attempts.filter((a) => a.athleteId === athlete.id);
      const required = examRequiredFor(exam.audience, parsePositions(athlete.positions));
      // All exams view: only athletes who took it. One exam view: whole roster.
      if (!selected && mine.length === 0) continue;
      rows.push({
        key: `${exam.id}-${athlete.id}`,
        athleteId: athlete.id,
        name: athlete.user.name,
        examTitle: exam.title,
        required,
        passPercent: exam.passPercent,
        summary: summarizeAttempts(mine),
      });
    }
  }

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Football IQ"
        title="Exams"
        description="Leadership jobs take an exam on plays and reads: captains, quarterback, and middle linebacker. Position fit reads each athlete's latest QB and MLB score."
      />

      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Exams</h2>
        {exams.length === 0 ? <p className="text-muted-foreground">No exams yet. Create one below.</p> : null}
        <ul className="grid gap-3 sm:grid-cols-2">
          {exams.map((exam) => {
            const takers = new Set(exam.attempts.map((a) => a.athleteId));
            const passers = new Set(exam.attempts.filter((a) => a.passed).map((a) => a.athleteId));
            return (
              <li key={exam.id} className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-muted px-3 py-1 text-xs font-semibold">
                    {AUDIENCE_LABEL[exam.audience] ?? exam.audience}
                  </span>
                  {exam.published ? null : (
                    <span className="rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-ink">Draft</span>
                  )}
                </div>
                <h3 className="font-display text-2xl tracking-wide">{exam.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {exam._count.questions} questions · pass at {exam.passPercent}% · {exam.attempts.length} attempts
                </p>
                <p className="text-sm">
                  {takers.size === 0
                    ? "No one has taken it yet."
                    : `${passers.size} of ${takers.size} athletes passed (${Math.round((passers.size / takers.size) * 100)}%).`}
                </p>
                <div className="flex flex-wrap gap-4 text-sm font-semibold">
                  <Link href={`/coach/exams/${exam.id}`} className="inline-flex min-h-11 items-center text-lion">
                    Edit exam
                  </Link>
                  <Link href={`/coach/exams?exam=${exam.id}#results`} className="inline-flex min-h-11 items-center text-lion">
                    See results
                  </Link>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <section id="results" className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">Results</h2>
        <nav className="flex flex-wrap gap-2" aria-label="Filter by exam">
          <FilterChip href="/coach/exams#results" active={!selected} label="All exams" />
          {exams.map((exam) => (
            <FilterChip key={exam.id} href={`/coach/exams?exam=${exam.id}#results`} active={selected?.id === exam.id} label={exam.title} />
          ))}
        </nav>
        {rows.length === 0 ? (
          <p className="text-muted-foreground">No attempts yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[34rem] text-left text-sm">
              <thead>
                <tr className="border-b text-xs text-muted-foreground">
                  <th className="py-2 pr-2">Athlete</th>
                  {selected ? null : <th className="py-2 pr-2">Exam</th>}
                  <th className="py-2 pr-2 text-right">Latest</th>
                  <th className="py-2 pr-2 text-right">Best</th>
                  <th className="py-2 pr-2 text-right">Tries</th>
                  <th className="py-2">Passed?</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.key} className="border-b last:border-0">
                    <td className="py-2 pr-2">
                      <Link href={`/coach/athletes/${row.athleteId}`} className="font-semibold hover:text-lion">
                        {row.name}
                      </Link>
                      {row.required ? <span className="ml-2 text-xs font-bold text-lion">required</span> : null}
                    </td>
                    {selected ? null : <td className="py-2 pr-2">{row.examTitle}</td>}
                    <td className="py-2 pr-2 text-right font-display text-lg">{row.summary ? `${row.summary.latestPercent}%` : "—"}</td>
                    <td className="py-2 pr-2 text-right">{row.summary ? `${row.summary.bestPercent}%` : "—"}</td>
                    <td className="py-2 pr-2 text-right">{row.summary?.attempts ?? 0}</td>
                    <td className="py-2">
                      {row.summary ? <PassBadge passed={row.summary.everPassed} label={row.summary.everPassed ? "Passed" : "Not yet"} /> : <span className="text-muted-foreground">Not taken</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="text-xs text-muted-foreground">
          Passed = at least one attempt at or above the pass mark. Latest is what position fit uses.
        </p>
      </section>

      <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">New exam</h2>
        <p className="text-sm text-muted-foreground">
          Starts as a draft. Add questions, then check Published. Good first one: your base plays, written in words.
        </p>
        <ExamMetaForm />
      </section>
    </div>
  );
}

function FilterChip({ href, active, label }: { href: string; active: boolean; label: string }) {
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      className={`inline-flex min-h-11 items-center rounded-full px-4 text-sm font-semibold ${
        active ? "bg-ink text-white" : "bg-muted hover:bg-muted/70"
      }`}
    >
      {label}
    </Link>
  );
}
