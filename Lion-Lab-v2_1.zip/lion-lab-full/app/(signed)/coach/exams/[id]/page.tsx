import Link from "next/link";
import { notFound } from "next/navigation";
import { moveQuestion } from "@/app/actions/exams";
import { DeleteExamForm, DeleteQuestionButton, ExamMetaForm, QuestionForm } from "@/components/exam-editor-forms";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { prisma } from "@/lib/db";
import { parseChoices } from "@/lib/exams";
import { requireStaff } from "@/lib/guards";

const LETTERS = ["A", "B", "C", "D", "E"];

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const exam = await prisma.exam.findUnique({ where: { id: (await params).id }, select: { title: true } });
  return { title: exam ? `Edit ${exam.title}` : "Exam" };
}

export default async function ExamEditorPage({ params }: { params: Promise<{ id: string }> }) {
  await requireStaff();
  const { id } = await params;
  const exam = await prisma.exam.findUnique({
    where: { id },
    include: {
      questions: { orderBy: [{ order: "asc" }, { id: "asc" }] },
      _count: { select: { attempts: true } },
    },
  });
  if (!exam) notFound();

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow={`Exam editor · ${exam.published ? "Published" : "Draft"}`}
        title={exam.title}
        description={`${exam.questions.length} questions · ${exam._count.attempts} attempts · link: /exams/${exam.slug}`}
        action={
          <Link href="/coach/exams" className="text-sm font-semibold text-lion">
            All exams
          </Link>
        }
      />

      <p className="rounded-xl bg-ink p-4 text-white">
        Add your own plays: describe the formation and the read in words. Diagrams can come later.
      </p>

      <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">Details</h2>
        <ExamMetaForm
          exam={{
            id: exam.id,
            title: exam.title,
            audience: exam.audience,
            description: exam.description,
            passPercent: exam.passPercent,
            published: exam.published,
          }}
        />
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Questions</h2>
        {exam._count.attempts > 0 ? (
          <p className="text-sm text-muted-foreground">
            Athletes have taken this exam. Their scores stay as graded. Edits apply to the next attempt.
          </p>
        ) : null}
        {exam.questions.length === 0 ? <p className="text-muted-foreground">No questions yet. Add the first one below.</p> : null}
        <ol className="grid gap-3">
          {exam.questions.map((q, i) => {
            const choices = parseChoices(q.choices);
            return (
              <li key={q.id} className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
                <div className="flex items-start justify-between gap-3">
                  <div className="grid gap-1">
                    <p className="text-sm font-semibold text-muted-foreground">
                      {i + 1}. {q.topic || "No topic"}
                    </p>
                    <p className="font-semibold">{q.prompt}</p>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <form action={moveQuestion}>
                      <input type="hidden" name="questionId" value={q.id} />
                      <input type="hidden" name="direction" value="up" />
                      <Button type="submit" variant="outline" size="touch" disabled={i === 0} aria-label={`Move question ${i + 1} up`}>
                        ↑
                      </Button>
                    </form>
                    <form action={moveQuestion}>
                      <input type="hidden" name="questionId" value={q.id} />
                      <input type="hidden" name="direction" value="down" />
                      <Button
                        type="submit"
                        variant="outline"
                        size="touch"
                        disabled={i === exam.questions.length - 1}
                        aria-label={`Move question ${i + 1} down`}
                      >
                        ↓
                      </Button>
                    </form>
                  </div>
                </div>
                <ul className="grid gap-1 text-sm">
                  {choices.map((choice, c) => (
                    <li key={c} className={c === q.answerIndex ? "font-semibold text-emerald-700" : ""}>
                      {LETTERS[c]}. {choice}
                      {c === q.answerIndex ? " ✓" : ""}
                    </li>
                  ))}
                </ul>
                <details className="rounded-lg bg-muted/50 p-3">
                  <summary className="min-h-11 cursor-pointer content-center font-semibold text-lion">Edit question</summary>
                  <div className="mt-3 grid gap-4">
                    <QuestionForm
                      key={`${q.id}-${q.prompt}-${q.choices}-${q.answerIndex}`}
                      examId={exam.id}
                      question={{
                        id: q.id,
                        topic: q.topic,
                        prompt: q.prompt,
                        choices,
                        answerIndex: q.answerIndex,
                        explanation: q.explanation,
                      }}
                    />
                    <DeleteQuestionButton questionId={q.id} />
                  </div>
                </details>
              </li>
            );
          })}
        </ol>
      </section>

      <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">Add a question</h2>
        <QuestionForm examId={exam.id} />
      </section>

      <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-destructive/30">
        <h2 className="font-display text-3xl tracking-wide">Delete exam</h2>
        <p className="text-sm text-muted-foreground">
          This removes the exam and every athlete attempt. To hide it instead, uncheck Published above.
        </p>
        <DeleteExamForm examId={exam.id} attempts={exam._count.attempts} />
      </section>
    </div>
  );
}
