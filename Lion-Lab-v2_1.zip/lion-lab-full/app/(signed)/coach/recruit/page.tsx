import Link from "next/link";
import { deleteProspect, updateProspect } from "@/app/actions/recruit";
import { PageHeader } from "@/components/page-header";
import { ProspectForm } from "@/components/prospect-form";
import { Button } from "@/components/ui/button";
import { METRIC_BY_ID, formatMetric } from "@/lib/content/metrics";
import { KICKER_NOTE, PROFILE_BY_ROLE, PROSPECT_STATUSES, RECRUIT_PROFILES, RECRUIT_RULES } from "@/lib/content/recruiting";
import { prisma } from "@/lib/db";
import { loadFitConfig, loadFitRoster } from "@/lib/fit-data";
import { formatHeight } from "@/lib/format";
import { buildDepth, READY_SCORE, ROLE_BY_ID, valueAtPercentile, type RoleId } from "@/lib/position-fit";
import { requireStaff } from "@/lib/guards";

export const metadata = { title: "Recruit" };

type Roster = Awaited<ReturnType<typeof loadFitRoster>>;

/** "What a recruit should look like" numbers for one role, from this roster. */
function lookFor(role: RoleId, roster: Roster, roles: Awaited<ReturnType<typeof loadFitConfig>>["roles"]) {
  const def = roles.find((r) => r.id === role)!;
  const lines: string[] = [];
  const heights = roster.map((a) => a.heightInches);
  const weights = roster.map((a) => a.weightLbs);
  for (const f of def.factors) {
    if (f.key !== "HEIGHT" && f.key !== "WEIGHT") continue;
    const pool = f.key === "HEIGHT" ? heights : weights;
    const fmt = (v: number | null) => (v == null ? "?" : f.key === "HEIGHT" ? formatHeight(Math.round(v)) : `${Math.round(v)} lb`);
    if (f.mode === "target") {
      const lo = valueAtPercentile(pool, Math.max(0, (f.target ?? 50) - 20));
      const hi = valueAtPercentile(pool, Math.min(100, (f.target ?? 50) + 20));
      lines.push(`${f.key === "HEIGHT" ? "Height" : "Weight"} about ${fmt(lo)}–${fmt(hi)}`);
    } else if (f.weight >= 1) {
      lines.push(`${f.key === "HEIGHT" ? "Height" : "Weight"} ${fmt(valueAtPercentile(pool, 60))}+`);
    }
  }
  const profile = PROFILE_BY_ROLE[role];
  for (const metric of profile.tryout) {
    const m = METRIC_BY_ID[metric];
    const pool = roster.map((a) => a.values[metric]).filter((v): v is number => v != null);
    if (pool.length < 3) continue;
    const line = valueAtPercentile(pool, m.better === "lower" ? 40 : 60);
    lines.push(`${m.short} ${m.better === "lower" ? "at or under" : "at or over"} ${formatMetric(metric, line)}`);
  }
  return lines;
}

export default async function RecruitPage() {
  await requireStaff();
  const [{ roles, needs }, roster, prospects] = await Promise.all([
    loadFitConfig(),
    loadFitRoster(),
    prisma.prospect.findMany({ orderBy: [{ status: "asc" }, { createdAt: "desc" }] }),
  ]);
  const depth = buildDepth(roster, needs, roles);
  const targets = depth
    .filter((row) => row.gap > 0 || row.thin > 0)
    .sort((a, b) => b.gap * 2 + b.thin - (a.gap * 2 + a.thin));
  const open = prospects.filter((p) => p.status !== "JOINED" && p.status !== "NOT_NOW");
  const closed = prospects.filter((p) => p.status === "JOINED" || p.status === "NOT_NOW");

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow="Recruiting"
        title="Recruit"
        description="Where the depth board is short, what a kid who fits looks like, and where to find them in your own building."
        action={
          <Link href="/coach/fit" className="text-sm font-semibold text-lion">
            Depth board
          </Link>
        }
      />

      <section className="rounded-xl border-2 border-lion/40 bg-card p-4">
        <h2 className="font-display text-2xl tracking-wide">Rules of the road</h2>
        <ul className="mt-2 grid list-disc gap-1 pl-5 text-sm">
          {RECRUIT_RULES.map((rule) => (
            <li key={rule}>{rule}</li>
          ))}
        </ul>
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Needs right now</h2>
        {targets.length === 0 ? (
          <p className="rounded-xl bg-card p-4 text-sm ring-1 ring-foreground/10">
            No open or thin roles on the current numbers. Keep recruiting depth anyway: junior high rosters lose kids to injuries, grades, and growth.
          </p>
        ) : (
          <div className="grid gap-3 lg:grid-cols-2">
            {targets.map((row) => {
              const profile = PROFILE_BY_ROLE[row.role];
              return (
                <article key={row.role} className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
                  <div className="flex items-baseline justify-between gap-2">
                    <h3 className="font-display text-2xl tracking-wide">{row.label}</h3>
                    <p className="text-sm font-semibold text-lion">
                      {row.gap > 0 ? `${row.gap} open` : ""}
                      {row.gap > 0 && row.thin > 0 ? " · " : ""}
                      {row.thin > 0 ? `${row.thin} under ${READY_SCORE}` : ""}
                    </p>
                  </div>
                  <p className="text-sm">{profile.headline}</p>
                  <RoleDetail role={row.role} roster={roster} roles={roles} />
                </article>
              );
            })}
          </div>
        )}
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Prospects</h2>
        <p className="text-sm text-muted-foreground">
          From the public &quot;Interested in playing?&quot; form and your own list. Parent contact goes through the school&apos;s normal channels.
        </p>
        {open.length === 0 ? <p className="text-sm text-muted-foreground">No open prospects.</p> : null}
        <ul className="grid gap-2">
          {open.map((p) => (
            <ProspectRow key={p.id} p={p} />
          ))}
        </ul>
        <details className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <summary className="cursor-pointer font-semibold">Add a prospect</summary>
          <div className="mt-3">
            <ProspectForm />
          </div>
        </details>
        {closed.length ? (
          <details>
            <summary className="cursor-pointer text-sm font-semibold">Joined / not now ({closed.length})</summary>
            <ul className="mt-2 grid gap-2">
              {closed.map((p) => (
                <ProspectRow key={p.id} p={p} />
              ))}
            </ul>
          </details>
        ) : null}
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Where every role comes from</h2>
        <p className="text-sm text-muted-foreground">Sports that transfer, girls&apos; teams to ask, and what a non-athlete who fits looks like.</p>
        <div className="grid gap-2">
          {RECRUIT_PROFILES.map((profile) => (
            <details key={profile.role} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <summary className="cursor-pointer font-display text-xl tracking-wide">
                {ROLE_BY_ID[profile.role].label} <span className="font-sans text-sm text-muted-foreground">— {profile.headline}</span>
              </summary>
              <div className="mt-2">
                <RoleDetail role={profile.role} roster={roster} roles={roles} />
              </div>
            </details>
          ))}
          <p className="text-sm">{KICKER_NOTE}</p>
        </div>
      </section>
    </div>
  );
}

function RoleDetail({ role, roster, roles }: { role: RoleId; roster: Roster; roles: Awaited<ReturnType<typeof loadFitConfig>>["roles"] }) {
  const profile = PROFILE_BY_ROLE[role];
  const look = lookFor(role, roster, roles);
  return (
    <div className="grid gap-2 text-sm">
      {look.length ? (
        <p>
          <span className="font-semibold">Look for (vs. your roster):</span> {look.join(" · ")}
        </p>
      ) : null}
      <div>
        <p className="font-semibold">Sports that feed it</p>
        <ul className="list-disc pl-5">
          {profile.sports.map((s) => (
            <li key={s.sport}>
              {s.sport} — {s.why}
            </li>
          ))}
        </ul>
      </div>
      <p>
        <span className="font-semibold">Girls&apos; teams:</span> {profile.girls}
      </p>
      <p>
        <span className="font-semibold">Non-athlete who fits:</span> {profile.nonAthlete}
      </p>
      <p>
        <span className="font-semibold">3-station tryout:</span> {profile.tryout.map((m) => METRIC_BY_ID[m].label).join(", ")}.{" "}
        {profile.tryoutNote}
      </p>
    </div>
  );
}

function ProspectRow({
  p,
}: {
  p: {
    id: string;
    name: string;
    grade: number | null;
    school: string;
    sportsNow: string;
    interest: string;
    parentName: string;
    parentEmail: string;
    heightInches: number | null;
    weightLbs: number | null;
    notes: string;
    status: string;
    source: string;
    createdAt: Date;
  };
}) {
  return (
    <li className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="font-semibold">
          {p.name}
          {p.grade ? <span className="text-muted-foreground"> · Gr {p.grade}</span> : null}
        </p>
        <p className="text-xs text-muted-foreground">
          {p.source === "PUBLIC_FORM" ? "Interest form" : "Coach list"} · {p.createdAt.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
        </p>
      </div>
      <p className="text-sm">
        {[
          p.sportsNow && `Plays: ${p.sportsNow}`,
          p.heightInches && `${formatHeight(p.heightInches)}`,
          p.weightLbs && `${p.weightLbs} lb`,
          p.interest,
          p.parentName && `Parent: ${p.parentName}${p.parentEmail ? ` (${p.parentEmail})` : ""}`,
        ]
          .filter(Boolean)
          .join(" · ")}
      </p>
      <form action={updateProspect} className="flex flex-wrap items-end gap-2">
        <input type="hidden" name="id" value={p.id} />
        <select name="status" defaultValue={p.status} className="rounded-lg border border-input bg-card px-3 py-2 text-base">
          {PROSPECT_STATUSES.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
        <input
          name="notes"
          defaultValue={p.notes}
          placeholder="Notes"
          className="min-w-0 flex-1 rounded-lg border border-input bg-card px-3 py-2 text-base"
        />
        <Button type="submit" variant="outline">
          Save
        </Button>
      </form>
      <form action={deleteProspect}>
        <input type="hidden" name="id" value={p.id} />
        <button type="submit" className="text-xs text-muted-foreground underline">
          Remove
        </button>
      </form>
    </li>
  );
}
