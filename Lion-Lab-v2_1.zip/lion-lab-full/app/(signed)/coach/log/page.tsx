import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { listAthletes } from "@/lib/data";
import { requireStaff } from "@/lib/guards";

export const metadata = { title: "Log tests" };

export default async function LogTestsPage() {
  await requireStaff();
  const athletes = await listAthletes();

  return (
    <div className="grid gap-4">
      <PageHeader
        eyebrow="Coach"
        title="Log tests"
        description="40, 10 lb med ball, and stance. A coach log on the field is not blocked by the study gate. Raw, form, and adjusted ESTIMATE save to that athlete."
      />
      {athletes.length === 0 ? (
        <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">
          No athletes yet. Add one from the roster.
        </p>
      ) : (
        <ul className="grid gap-2">
          {athletes.map((athlete) => (
            <li key={athlete.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
              <div>
                <p className="font-semibold">{athlete.name}</p>
                <p className="text-sm text-muted-foreground">
                  Grade {athlete.grade} · {athlete.positions.join(" ")}
                </p>
              </div>
              <Link href={`/coach/athletes/${athlete.id}/tests/new`} className="text-sm font-semibold text-lion">
                Log a test
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
