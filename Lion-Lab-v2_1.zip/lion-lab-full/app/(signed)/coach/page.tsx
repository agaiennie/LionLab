import { requireStaff } from "@/lib/guards";
import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { RosterBoard, type RosterRow } from "@/components/roster-board";
import { buttonVariants } from "@/components/ui/button";
import { latestByType, listAthletes, type AthleteRecord } from "@/lib/data";
import { habitBoard, labelDay } from "@/lib/days";
import { cn } from "cn";

export const metadata = { title: "Roster" };

function cell(session: AthleteRecord["sessions"][number] | null) {
  if (!session) return "—";
  if (session.testType === "STANCE") {
    return `${session.scored.percent}% · ${session.scored.estimate.display}`;
  }
  return `${session.scored.rawLabel} · ${session.scored.percent}% · ${session.scored.estimate.display}`;
}

export default async function CoachRosterPage() {
  // Guard here too: layouts and pages render in parallel, so a layout-only guard can leak page data.
  await requireStaff();
  const athletes = await listAthletes();
  const habits = await habitBoard(athletes.map((athlete) => athlete.id));
  const rows: RosterRow[] = athletes.map((athlete) => {
    const snap = habits.map.get(athlete.id);
    const studyStatus =
      snap?.todayStatus === "done" ? "today done" : snap?.todayStatus === "note" ? "today parent note" : "today not yet";
    return {
    id: athlete.id,
    name: athlete.name,
    email: athlete.email,
    grade: athlete.grade,
    positions: athlete.positions,
    heightLabel: athlete.heightLabel,
    weightLbs: athlete.weightLbs,
    forty: cell(latestByType(athlete, "FORTY")),
    medball: cell(latestByType(athlete, "MEDBALL")),
    stance: cell(latestByType(athlete, "STANCE")),
    updated: athlete.sessions[0]?.recordedOnLabel ?? "No tests",
    academicStatus: athlete.academicStatus,
    study: `${snap?.streak ?? 0}-day streak · last ${snap?.lastStudy ? labelDay(snap.lastStudy) : "none"} · ${studyStatus}`,
  };
  });

  return (
    <div>
      <PageHeader
        eyebrow="Coach"
        title="Roster"
        description="Study streak sits next to the battery. Open an athlete to log a test, link a parent, or leave a home note."
        action={
          <div className="flex flex-wrap gap-2">
            <a href="/api/export/roster" className={cn(buttonVariants({ variant: "outline", size: "touch" }))}>
              Export CSV
            </a>
            <Link href="/coach/athletes/new" className={cn(buttonVariants({ size: "touch" }))}>
              Add athlete
            </Link>
          </div>
        }
      />
      <RosterBoard rows={rows} />
    </div>
  );
}
