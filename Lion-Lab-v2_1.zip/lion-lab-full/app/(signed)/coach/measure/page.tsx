import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { TeamGaps } from "@/components/team-gaps";
import { TestDay, type TestDayAthlete } from "@/components/test-day";
import { METRIC_BY_ID, METRIC_GROUPS, formatMetric, isMetricId, metricsInGroup } from "@/lib/content/metrics";
import { prisma } from "@/lib/db";
import { requireStaff } from "@/lib/guards";
import { todayKey } from "@/lib/habits";
import { parsePositions } from "@/lib/scoring";
import { DeleteMeasurementButton } from "@/components/delete-measurement-button";

export const metadata = { title: "Test day" };

export default async function CoachMeasurePage({
  searchParams,
}: {
  searchParams: Promise<{ metric?: string }>;
}) {
  await requireStaff();
  const requested = (await searchParams).metric ?? "";
  const metric = isMetricId(requested) ? requested : null;
  const def = metric ? METRIC_BY_ID[metric] : null;

  let athletes: TestDayAthlete[] = [];
  let recent: { id: string; name: string; value: number; side: string; source: string; day: string; notes: string }[] = [];
  if (metric) {
    const rows = await prisma.athleteProfile.findMany({
      where: { user: { status: "ACTIVE" } },
      select: {
        id: true,
        grade: true,
        positions: true,
        user: { select: { name: true } },
        measurements: {
          where: { metric },
          orderBy: [{ recordedOn: "desc" }, { createdAt: "desc" }],
          select: { value: true, side: true, recordedOn: true },
        },
      },
      orderBy: { user: { name: "asc" } },
    });
    athletes = rows.map((a) => {
      const last: TestDayAthlete["last"] = {};
      for (const m of a.measurements) {
        if (!last[m.side]) last[m.side] = { value: m.value, day: m.recordedOn.toISOString().slice(0, 10) };
      }
      return { id: a.id, name: a.user.name, grade: a.grade, positions: parsePositions(a.positions), last };
    });
    const recentRows = await prisma.measurement.findMany({
      where: { metric },
      orderBy: [{ createdAt: "desc" }],
      take: 15,
      select: {
        id: true,
        value: true,
        side: true,
        source: true,
        notes: true,
        recordedOn: true,
        athlete: { select: { user: { select: { name: true } } } },
      },
    });
    recent = recentRows.map((r) => ({
      id: r.id,
      name: r.athlete.user.name,
      value: r.value,
      side: r.side,
      source: r.source,
      notes: r.notes,
      day: r.recordedOn.toISOString().slice(0, 10),
    }));
  }

  const stopwatchCapable = Boolean(def?.capture.includes("stopwatch"));

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Coach"
        title="Test day"
        description="Pick a test, read the setup, then type every athlete's number and save once. Only filled rows save."
        action={
          <Link href="/camera" className="text-sm font-semibold text-lion">
            Camera tests
          </Link>
        }
      />

      {!metric ? <TeamGaps /> : null}

      <section className="grid gap-4" aria-label="Pick a test">
        {METRIC_GROUPS.map((group) => (
          <div key={group.id} className="grid gap-2">
            <h2 className="font-display text-xl tracking-wide">
              {group.label}
              <span className="ml-2 font-sans text-sm font-normal text-muted-foreground">{group.why}</span>
            </h2>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {metricsInGroup(group.id).map((m) => (
                <Link
                  key={m.id}
                  href={`/coach/measure?metric=${m.id}`}
                  aria-current={m.id === metric ? "page" : undefined}
                  className={`flex min-h-16 flex-col justify-center rounded-xl px-3 py-2 ring-1 ring-foreground/10 ${
                    m.id === metric ? "bg-ink text-white" : "bg-card hover:bg-muted"
                  }`}
                >
                  <span className="font-display text-xl leading-tight tracking-wide">{m.short}</span>
                  <span className={`text-xs ${m.id === metric ? "text-white/70" : "text-muted-foreground"}`}>
                    {m.unit}
                    {m.sided ? " · L/R" : ""}
                    {m.capture.includes("stopwatch") ? " · stopwatch" : ""}
                    {m.capture.includes("camera") ? " · camera" : ""}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </section>

      {def && metric ? (
        <>
          <section className="grid gap-2 rounded-xl bg-ink p-4 text-white" id="protocol">
            <h2 className="font-display text-3xl tracking-wide">{def.label}</h2>
            <p className="text-sm text-white/80">
              <strong className="text-white">Equipment:</strong> {def.equipment}
            </p>
            <ol className="list-decimal space-y-1 pl-5 text-base">
              {def.protocol.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            {def.safety ? <p className="rounded-lg bg-lion px-3 py-2 text-sm font-semibold">Safety: {def.safety}</p> : null}
            <p className="text-sm text-white/70">
              {def.better === "lower" ? "Lower is better." : "Higher is better."} Range {def.min} to {def.max} {def.unit}.
              {def.capture.includes("camera") ? (
                <>
                  {" "}
                  <Link href="/camera" className="font-semibold text-white underline">
                    Camera version
                  </Link>
                  .
                </>
              ) : null}
            </p>
          </section>

          {athletes.length === 0 ? (
            <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">
              No active athletes yet. Add them from the roster.
            </p>
          ) : (
            <TestDay key={metric} metric={metric} athletes={athletes} today={todayKey()} stopwatchCapable={stopwatchCapable} />
          )}

          <section className="grid gap-2">
            <h2 className="font-display text-2xl tracking-wide">Recent {def.short} entries</h2>
            {recent.length === 0 ? (
              <p className="text-sm text-muted-foreground">None yet.</p>
            ) : (
              <ul className="divide-y divide-border overflow-hidden rounded-xl bg-card text-sm ring-1 ring-foreground/10" data-testid="recent-entries">
                {recent.map((r) => (
                  <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
                    <span>
                      {r.day} · <strong>{r.name}</strong> · {r.side ? `${r.side} ` : ""}
                      {formatMetric(metric, r.value)} · {r.source.toLowerCase()}
                      {r.notes ? ` · ${r.notes}` : ""}
                    </span>
                    <DeleteMeasurementButton id={r.id} label={`${r.name} ${formatMetric(metric, r.value)}`} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          <TeamGaps />
        </>
      ) : null}
    </div>
  );
}
