import { requireStaff } from "@/lib/guards";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AcademicCard } from "@/components/academic-card";
import { PageHeader } from "@/components/page-header";
import { ProfileForm } from "@/components/profile-form";
import { getAthlete } from "@/lib/data";
import { splitHeight } from "@/lib/format";

export const metadata = { title: "Edit athlete" };

export default async function EditAthletePage({ params }: { params: Promise<{ id: string }> }) {
  // Guard here too: layouts and pages render in parallel, so a layout-only guard can leak page data.
  await requireStaff();
  const { id } = await params;
  const athlete = await getAthlete(id);
  if (!athlete) notFound();
  const height = splitHeight(athlete.heightInches);

  return (
    <div>
      <PageHeader
        eyebrow="Roster"
        title={`Edit ${athlete.name}`}
        description="Coaches can correct the email if it was typed wrong. Athletes sign in with that email."
      />
      <ProfileForm
        athleteId={athlete.id}
        includeEmail
        values={{
          name: athlete.name,
          email: athlete.email,
          grade: athlete.grade,
          positions: athlete.positions,
          feet: height.feet,
          inches: height.inches,
          weightLbs: athlete.weightLbs,
        }}
      />
      <div className="mt-8 max-w-xl">
        <AcademicCard athleteId={athlete.id} canEdit="staff" />
      </div>
      <Link href={`/coach/athletes/${athlete.id}`} className="mt-6 inline-block font-semibold text-lion">
        Back to {athlete.name}
      </Link>
    </div>
  );
}
