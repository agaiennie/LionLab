import { auth, isStaff } from "@/lib/auth";
import { requireStaff } from "@/lib/guards";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AcademicCard } from "@/components/academic-card";
import { Battery } from "@/components/battery";
import { ExamSummary } from "@/components/exam-summary";
import { FitCard } from "@/components/fit-card";
import { MeasureSummary } from "@/components/measure-summary";
import { NoteForm } from "@/components/note-form";
import { PageHeader } from "@/components/page-header";
import { ParentInviteForm } from "@/components/parent-invite-form";
import { ResetPasswordForm } from "@/components/password-forms";
import { buttonVariants } from "@/components/ui/button";
import { getAthlete } from "@/lib/data";
import { SkillTaughtButton } from "@/components/skill-taught-button";
import { positionPlan, weekKey } from "@/lib/content/skills";
import { labelDay, loadAthleteDay, parentsFor } from "@/lib/days";
import { prisma } from "@/lib/db";
import { TESTS, type TestType } from "@/lib/scoring";
import { cn } from "cn";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user || !isStaff(session.user.role)) return { title: "Athlete" };
  const { id } = await params;
  const athlete = await getAthlete(id);
  return { title: athlete?.name ?? "Athlete" };
}

function testLabel(type: TestType) {
  return TESTS[type].short;
}

export default async function CoachAthletePage({ params }: { params: Promise<{ id: string }> }) {
  // Guard here too: layouts and pages render in parallel, so a layout-only guard can leak page data.
  await requireStaff();
  const { id } = await params;
  const athlete = await getAthlete(id);
  if (!athlete) notFound();
  const pack = await loadAthleteDay(athlete.id);
  const parents = await parentsFor(athlete.id);
  const week = weekKey();
  const marks = await prisma.skillMark.findMany({
    where: { athleteId: athlete.id, weekKey: week },
    select: { skillId: true },
  });
  const taught = new Set(marks.map((mark) => mark.skillId));
  const positionSkills = athlete.positions.flatMap((code) => {
    const plan = positionPlan(code);
    return [...plan.first, ...plan.next];
  });
  const uniqueSkills = [...new Map(positionSkills.map((skill) => [skill.id, skill])).values()];
  const studyWord =
    pack.snap.todayStatus === "done"
      ? "Study done"
      : pack.snap.todayStatus === "note"
        ? "Parent note on file"
        : "Study not done";

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow={`Grade ${athlete.grade} · ${athlete.positionLabels.join(", ")}`}
        title={athlete.name}
        description={`${athlete.heightLabel} · ${athlete.weightLbs} lb · ${athlete.email}`}
        action={
          <div className="flex flex-wrap gap-2">
            <Link href={`/coach/athletes/${athlete.id}/edit`} className={cn(buttonVariants({ variant: "outline", size: "touch" }))}>
              Edit profile
            </Link>
            <Link href={`/coach/athletes/${athlete.id}/tests/new`} className={cn(buttonVariants({ size: "touch" }))}>
              Log a test
            </Link>
          </div>
        }
      />
      <AcademicCard athleteId={athlete.id} canEdit="staff" />
      <FitCard athleteId={athlete.id} audience="staff" />
      <MeasureSummary athleteId={athlete.id} title="Measurement battery" showEmpty />
      <p className="-mt-4 text-sm">
        <Link href="/coach/measure" className="font-semibold text-lion">Test day entry</Link> ·{" "}
        <Link href="/camera" className="font-semibold text-lion">Camera balance & flexibility</Link>
      </p>
      <ExamSummary athleteId={athlete.id} />
      <Battery athlete={athlete} logHref={`/coach/athletes/${athlete.id}/tests/new`} />
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Test history</h2>
        {athlete.sessions.length === 0 ? (
          <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">
            No tests yet. Log a 40, med ball, or stance.
          </p>
        ) : (
          <ul className="divide-y divide-border overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
            {athlete.sessions.map((session) => (
              <li key={session.id} className="grid gap-1 px-4 py-3 sm:grid-cols-[8rem_1fr_auto] sm:items-center">
                <div>
                  <p className="font-semibold">{testLabel(session.testType)}</p>
                  <p className="text-sm text-muted-foreground">{session.recordedOnLabel}</p>
                </div>
                <p className="text-sm">
                  {session.scored.rawLabel} · form {session.scored.percent}% · ESTIMATE{" "}
                  {session.scored.estimate.display}
                  {session.notes ? ` · ${session.notes}` : ""}
                </p>
                <Link
                  href={`/coach/athletes/${athlete.id}/tests/${session.id}`}
                  className="text-sm font-semibold text-lion"
                >
                  Edit
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Skills this week</h2>
        <p className="text-sm text-muted-foreground">
          Week of {week}. Mark a skill when you taught it.{" "}
          <Link href="/skills" className="font-semibold text-lion">
            Open the library
          </Link>
        </p>
        <ul className="grid gap-2">
          {uniqueSkills.map((skill) => (
            <li key={skill.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
              <Link href={`/skills/${skill.id}`} className="font-semibold">
                {skill.name}
              </Link>
              <SkillTaughtButton athleteId={athlete.id} skillId={skill.id} taught={taught.has(skill.id)} />
            </li>
          ))}
        </ul>
      </section>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-2xl tracking-wide">Study</h2>
        <p className="mt-1 text-sm">
          {studyWord} · {pack.day.studyMinutes} / {pack.team.studyGoalMinutes} min · {pack.snap.streak}-day streak · last{" "}
          {pack.snap.lastStudy ? labelDay(pack.snap.lastStudy) : "none"}
        </p>
        <Link href={`/tracker?athlete=${athlete.id}`} className="mt-2 inline-block text-sm font-semibold text-lion">
          Open body tracker
        </Link>
      </section>
      <section className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <h2 className="font-display text-2xl tracking-wide">Parents</h2>
          {parents.length === 0 ? (
            <p className="mt-1 text-sm text-muted-foreground">No parent linked yet.</p>
          ) : (
            <ul className="mt-2 text-sm">
              {parents.map((parent) => (
                <li key={parent.email}>
                  {parent.name} · {parent.email}
                </li>
              ))}
            </ul>
          )}
          <div className="mt-4">
            <ParentInviteForm athletes={[{ id: athlete.id, name: athlete.name }]} />
          </div>
        </div>
        <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <h2 className="font-display text-2xl tracking-wide">Note for home</h2>
          <ul className="mt-2 mb-3 grid gap-2 text-sm">
            {pack.notes.length === 0 ? <li className="text-muted-foreground">No notes yet.</li> : null}
            {pack.notes.slice(0, 3).map((note) => (
              <li key={note.id}>
                {note.body} <span className="text-muted-foreground">· {note.createdLabel}</span>
              </li>
            ))}
          </ul>
          <NoteForm athleteId={athlete.id} />
        </div>
      </section>
      <section className="max-w-md rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-2xl tracking-wide">Reset sign-in</h2>
        <p className="mt-1 mb-3 text-sm text-muted-foreground">
          Use this if they forget the password. Share the new one in person.
        </p>
        <ResetPasswordForm athleteId={athlete.id} />
      </section>
      <Link href="/coach" className="font-semibold text-lion">
        Back to roster
      </Link>
    </div>
  );
}
