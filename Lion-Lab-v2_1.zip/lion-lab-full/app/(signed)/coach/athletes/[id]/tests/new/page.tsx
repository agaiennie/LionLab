import { requireStaff } from "@/lib/guards";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { TestForm } from "@/components/test-form";
import { getAthlete } from "@/lib/data";
import { todayDateInput } from "@/lib/format";

export const metadata = { title: "Log a test" };

export default async function NewTestPage({ params }: { params: Promise<{ id: string }> }) {
  // Guard here too: layouts and pages render in parallel, so a layout-only guard can leak page data.
  await requireStaff();
  const { id } = await params;
  const athlete = await getAthlete(id);
  if (!athlete) notFound();

  return (
    <div>
      <PageHeader
        eyebrow={athlete.name}
        title="Log a test"
        description="Enter the raw measurement, then check only the form items that were solid. The adjusted number is an ESTIMATE and updates before you save."
      />
      <TestForm
        athleteId={athlete.id}
        sessionId={null}
        initial={{
          testType: "FORTY",
          rawValue: null,
          passedIds: [],
          notes: "",
          recordedOn: todayDateInput(),
        }}
      />
      <Link href={`/coach/athletes/${athlete.id}`} className="mt-4 inline-block font-semibold text-lion">
        Cancel
      </Link>
    </div>
  );
}
