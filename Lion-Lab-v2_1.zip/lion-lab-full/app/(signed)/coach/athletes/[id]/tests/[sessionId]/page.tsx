import { requireStaff } from "@/lib/guards";
import Link from "next/link";
import { notFound } from "next/navigation";
import { deleteSession } from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { TestForm } from "@/components/test-form";
import { Button } from "@/components/ui/button";
import { getAthlete, getSessionForAthlete } from "@/lib/data";
import { toDateInput } from "@/lib/format";

export const metadata = { title: "Edit test" };

export default async function EditTestPage({
  params,
}: {
  params: Promise<{ id: string; sessionId: string }>;
}) {
  // Guard here too: layouts and pages render in parallel, so a layout-only guard can leak page data.
  await requireStaff();
  const { id, sessionId } = await params;
  const athlete = await getAthlete(id);
  const session = athlete ? await getSessionForAthlete(id, sessionId) : null;
  if (!athlete || !session) notFound();

  return (
    <div className="grid gap-8">
      <div>
        <PageHeader
          eyebrow={athlete.name}
          title="Edit test"
          description="Fix a clock, a distance, or a checklist mark. Saving recalculates the ESTIMATE from formula v1."
        />
        <TestForm
          athleteId={athlete.id}
          sessionId={session.id}
          initial={{
            testType: session.testType,
            rawValue: session.rawValue,
            passedIds: session.passedIds,
            notes: session.notes,
            recordedOn: toDateInput(session.recordedOn),
          }}
        />
        <Link href={`/coach/athletes/${athlete.id}`} className="mt-4 inline-block font-semibold text-lion">
          Back to {athlete.name}
        </Link>
      </div>
      <form
        action={deleteSession.bind(null, athlete.id, session.id)}
        className="max-w-md rounded-xl border border-destructive/30 bg-card p-4"
      >
        <h2 className="font-semibold">Delete this test</h2>
        <p className="mt-1 mb-3 text-sm text-muted-foreground">
          Removes it from the athlete&apos;s history. This cannot be undone.
        </p>
        <Button type="submit" variant="destructive">
          Delete test
        </Button>
      </form>
    </div>
  );
}
