import { CreateAthleteForm } from "@/components/create-athlete-form";
import { PageHeader } from "@/components/page-header";

export const metadata = { title: "Add athlete" };

export default function NewAthletePage() {
  return (
    <div>
      <PageHeader
        eyebrow="Roster"
        title="Add an athlete"
        description="Create their sign-in here. Hand them the email and password in person. Athletes can also request an account at /signup; those land in Approvals. There is no public roster."
      />
      <CreateAthleteForm />
    </div>
  );
}
