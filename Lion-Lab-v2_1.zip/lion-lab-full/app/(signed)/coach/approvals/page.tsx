import Link from "next/link";
import { approveUser, denyUser, linkParent } from "@/app/actions/signup";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { prisma } from "@/lib/db";
import { requireStaff } from "@/lib/guards";

export const metadata = { title: "Approvals" };

const roleLabel: Record<string, string> = {
  PARENT: "Parent",
  ATHLETE: "Athlete",
  COACH: "Coach",
  ADMIN: "Admin",
};

const when = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  hour: "numeric",
  minute: "2-digit",
  timeZone: "America/New_York",
});

type RosterOption = { id: string; name: string; grade: number };

function guessMatches(kidNames: string, roster: RosterOption[]): Set<string> {
  const typed = kidNames.toLowerCase();
  return new Set(roster.filter((kid) => typed.includes(kid.name.toLowerCase())).map((kid) => kid.id));
}

export default async function ApprovalsPage({
  searchParams,
}: {
  searchParams: Promise<{ approved?: string; denied?: string; linked?: string; error?: string }>;
}) {
  const staff = await requireStaff();
  const params = await searchParams;
  const isAdmin = staff.role === "ADMIN";

  const [pending, recent, rosterRows, justApproved] = await Promise.all([
    prisma.user.findMany({
      where: { status: "PENDING" },
      orderBy: { createdAt: "desc" },
      include: { accessRequest: true, athlete: { select: { id: true } } },
    }),
    prisma.user.findMany({
      where: { status: "ACTIVE", accessRequest: { isNot: null } },
      orderBy: { updatedAt: "desc" },
      take: 10,
      include: {
        accessRequest: true,
        athlete: { select: { id: true } },
        parentLinks: { include: { athlete: { include: { user: { select: { name: true } } } } } },
      },
    }),
    prisma.athleteProfile.findMany({
      where: { user: { status: "ACTIVE" } },
      orderBy: { user: { name: "asc" } },
      select: { id: true, grade: true, user: { select: { name: true } } },
    }),
    params.approved
      ? prisma.user.findUnique({
          where: { id: params.approved },
          select: { name: true, role: true, athlete: { select: { id: true } } },
        })
      : Promise.resolve(null),
  ]);
  const roster: RosterOption[] = rosterRows.map((row) => ({ id: row.id, name: row.user.name, grade: row.grade }));

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow="Coach"
        title="Approvals"
        description="Everyone signs up, then a coach checks them. Approve people you know. Deny anyone you don't."
        action={
          <Link href="/coach/board" className="text-sm font-semibold text-lion">
            Public board
          </Link>
        }
      />

      {justApproved ? (
        <div className="rounded-xl border-2 border-lion bg-card px-4 py-3" role="status">
          <p className="font-semibold">
            {justApproved.name} is approved ({roleLabel[justApproved.role] ?? justApproved.role}). They can sign in now.
          </p>
          {justApproved.athlete ? (
            <p className="mt-1">
              Height, weight, and positions are placeholders.{" "}
              <Link href={`/coach/athletes/${justApproved.athlete.id}/edit`} className="font-semibold text-lion">
                Edit their profile →
              </Link>
            </p>
          ) : null}
        </div>
      ) : null}
      {params.denied ? <p className="rounded-lg bg-accent px-3 py-2">Request denied. The account stays turned off.</p> : null}
      {params.linked ? <p className="rounded-lg bg-accent px-3 py-2">Parent linked.</p> : null}
      {params.error === "admin" ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-destructive">Only an admin can approve or deny a coach.</p>
      ) : null}

      <section className="grid gap-4">
        <h2 className="flex items-center gap-3 font-display text-3xl tracking-wide">
          Waiting
          <span className="inline-flex min-w-10 items-center justify-center rounded-full bg-lion px-3 py-0.5 text-2xl text-white">
            {pending.length}
          </span>
        </h2>
        {pending.length === 0 ? (
          <p className="text-lg text-muted-foreground">Nobody is waiting. New sign-ups show up here.</p>
        ) : (
          <ul className="grid gap-4">
            {pending.map((user) => {
              const req = user.accessRequest;
              const staffRequest = user.role === "COACH" || user.role === "ADMIN";
              const blocked = staffRequest && !isAdmin;
              const guesses = req ? guessMatches(req.kidNames, roster) : new Set<string>();
              const formId = `approve-${user.id}`;
              return (
                <li key={user.id} className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <p className="font-display text-2xl tracking-wide">
                      {user.name}{" "}
                      <span className="rounded-full bg-muted px-2 py-0.5 align-middle font-sans text-sm font-semibold">
                        {roleLabel[user.role] ?? user.role}
                      </span>
                    </p>
                    <p className="text-sm text-muted-foreground">{when.format(user.createdAt)}</p>
                  </div>
                  <dl className="grid gap-1 text-base sm:grid-cols-[10rem_1fr]">
                    <dt className="text-muted-foreground">Email</dt>
                    <dd className="break-all">{user.email}</dd>
                    {user.phone ? (
                      <>
                        <dt className="text-muted-foreground">Phone</dt>
                        <dd>{user.phone}</dd>
                      </>
                    ) : null}
                    {req?.kidNames ? (
                      <>
                        <dt className="text-muted-foreground">Their player(s)</dt>
                        <dd>{req.kidNames}</dd>
                      </>
                    ) : null}
                    {req?.grade ? (
                      <>
                        <dt className="text-muted-foreground">Grade</dt>
                        <dd>{req.grade}</dd>
                      </>
                    ) : null}
                    {req?.parentName || req?.parentEmail ? (
                      <>
                        <dt className="text-muted-foreground">Parent/guardian</dt>
                        <dd className="break-all">
                          {req.parentName}
                          {req.parentEmail ? ` · ${req.parentEmail}` : ""}
                        </dd>
                      </>
                    ) : null}
                    {req?.note ? (
                      <>
                        <dt className="text-muted-foreground">Note</dt>
                        <dd>{req.note}</dd>
                      </>
                    ) : null}
                  </dl>

                  {user.role === "ATHLETE" ? (
                    <p className="text-sm text-muted-foreground">
                      Approving adds them to the roster with placeholder height 5&apos;0&quot;, 100 lb, position ATH. Fix those
                      right after. Check with the parent above first.
                    </p>
                  ) : null}

                  {user.role === "PARENT" ? (
                    <fieldset form={formId} className="grid gap-2 rounded-lg bg-muted/40 p-3">
                      <legend className="px-1 text-sm font-semibold">Link to their kid(s) on the roster</legend>
                      {roster.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No athletes on the roster yet.</p>
                      ) : (
                        <div className="grid gap-1 sm:grid-cols-2">
                          {roster.map((kid) => (
                            <label key={kid.id} className="flex min-h-10 items-center gap-2 text-base">
                              <input
                                type="checkbox"
                                name="athleteId"
                                value={kid.id}
                                form={formId}
                                defaultChecked={guesses.has(kid.id)}
                                className="size-5 accent-[#C8102E]"
                              />
                              {kid.name} <span className="text-sm text-muted-foreground">· {kid.grade}th</span>
                            </label>
                          ))}
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground">
                        A parent sees only the kids you link here. Names typed on the form are pre-checked when they match.
                      </p>
                    </fieldset>
                  ) : null}

                  {blocked ? (
                    <p className="text-sm text-muted-foreground">Only an admin can approve a coach account.</p>
                  ) : null}
                  <div className="flex flex-wrap gap-3">
                    <form id={formId} action={approveUser}>
                      <input type="hidden" name="userId" value={user.id} />
                      <Button type="submit" size="touch" disabled={blocked} className="min-w-32">
                        Approve
                      </Button>
                    </form>
                    <form action={denyUser}>
                      <input type="hidden" name="userId" value={user.id} />
                      <Button type="submit" size="touch" variant="outline" disabled={blocked} className="min-w-32">
                        Deny
                      </Button>
                    </form>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-2xl tracking-wide">Recently approved</h2>
        {recent.length === 0 ? (
          <p className="text-muted-foreground">No sign-ups approved yet.</p>
        ) : (
          <ul className="grid gap-2">
            {recent.map((user) => {
              const linked = new Set(user.parentLinks.map((link) => link.athleteId));
              return (
                <li key={user.id} className="rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <p>
                      <span className="font-semibold">{user.name}</span>{" "}
                      <span className="text-sm text-muted-foreground">
                        · {roleLabel[user.role] ?? user.role} · {user.email}
                      </span>
                    </p>
                    {user.athlete ? (
                      <Link href={`/coach/athletes/${user.athlete.id}/edit`} className="text-sm font-semibold text-lion">
                        Edit profile
                      </Link>
                    ) : null}
                  </div>
                  {user.role === "PARENT" ? (
                    <details className="mt-1">
                      <summary className="cursor-pointer text-sm">
                        {user.parentLinks.length > 0
                          ? `Linked to ${user.parentLinks.map((link) => link.athlete.user.name).join(", ")}`
                          : "Not linked to a player yet"}{" "}
                        · <span className="font-semibold text-lion">Link more</span>
                      </summary>
                      <form action={linkParent} className="mt-2 grid gap-2">
                        <input type="hidden" name="userId" value={user.id} />
                        <div className="grid gap-1 sm:grid-cols-2">
                          {roster
                            .filter((kid) => !linked.has(kid.id))
                            .map((kid) => (
                              <label key={kid.id} className="flex min-h-10 items-center gap-2 text-base">
                                <input type="checkbox" name="athleteId" value={kid.id} className="size-5 accent-[#C8102E]" />
                                {kid.name}
                              </label>
                            ))}
                        </div>
                        <Button type="submit" variant="outline" size="touch" className="w-fit">
                          Link
                        </Button>
                      </form>
                    </details>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
