import { FieldDeck } from "@/components/field-deck";
import { PageHeader } from "@/components/page-header";
import { DRILLS, drillById, sessionTemplate } from "@/lib/content/mobility";
import { dateFromKey } from "@/lib/days";
import { requireUser } from "@/lib/guards";
import { todayKey } from "@/lib/habits";

export const metadata = { title: "Field cards" };

export default async function FieldPage() {
  await requireUser();
  const today = todayKey();
  const template = sessionTemplate(dateFromKey(today));
  const drills = template.drillIds
    .map((id) => drillById(id))
    .filter((drill) => drill != null)
    .map((drill) => ({ name: drill.name, cue: drill.cue, dose: drill.dose, stop: drill.stop }));

  return (
    <div className="grid gap-4">
      <PageHeader
        eyebrow="Field"
        title="Cards"
        description="One screen at a time. Phone or tablet, landscape if the card is FAST. Print hides the menu."
      />
      <FieldDeck
        drills={drills}
        catalog={DRILLS.map((drill) => ({ name: drill.name, cue: drill.cue }))}
      />
    </div>
  );
}
