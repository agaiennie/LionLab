import { Shell } from "@/components/shell";
import { requireUser } from "@/lib/guards";

export const dynamic = "force-dynamic";

export default async function SignedInLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  return (
    <Shell role={user.role} name={user.name ?? "Lion Lab"}>
      {children}
    </Shell>
  );
}
