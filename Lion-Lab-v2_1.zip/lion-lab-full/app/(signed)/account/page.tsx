import { PageHeader } from "@/components/page-header";
import { ChangePasswordForm } from "@/components/password-forms";

export const metadata = { title: "Password" };

export default function AccountPage() {
  return (
    <div>
      <PageHeader
        eyebrow="Account"
        title="Change password"
        description="Use a password you can remember. Coaches reset athlete passwords from the athlete page."
      />
      <ChangePasswordForm />
    </div>
  );
}
