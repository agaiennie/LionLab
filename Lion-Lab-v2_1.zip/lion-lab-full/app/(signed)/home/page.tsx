import Link from "next/link";
import { AcademicCard } from "@/components/academic-card";
import { GateBanner } from "@/components/gate-banner";
import { KidSwitch } from "@/components/kid-switch";
import {
  FuelBoard,
  HomeTrainComplete,
  MobilityComplete,
  ParentOverrideForm,
  StudyMinutesForm,
  SubjectEditor,
} from "@/components/habit-controls";
import { PageHeader } from "@/components/page-header";
import { StudyTimer } from "@/components/study-timer";
import { WeeklyStudy } from "@/components/weekly-study";
import { parentKids, pickId } from "@/lib/access";
import { FUEL_NOTE } from "@/lib/content/fuel";
import { drillById, sessionTemplate } from "@/lib/content/mobility";
import { dateFromKey, loadAthleteDay } from "@/lib/days";
import { prisma } from "@/lib/db";
import { requireParent } from "@/lib/guards";
import { studyGateBlocks } from "@/lib/habits";

export const metadata = { title: "Home plan" };

export default async function HomePlanPage({
  searchParams,
}: {
  searchParams: Promise<{ athlete?: string }>;
}) {
  const user = await requireParent();
  const kids = await parentKids(user.id);
  const current = pickId(
    kids.map((kid) => kid.id),
    (await searchParams).athlete,
  );
  if (!current) {
    return (
      <PageHeader
        eyebrow="Home"
        title="No athlete linked"
        description="Ask a coach to invite your email and link it to your athlete."
      />
    );
  }
  const pack = await loadAthleteDay(current);
  const template = sessionTemplate(dateFromKey(pack.today));
  const drills = template.drillIds.map((id) => drillById(id)).filter((drill) => drill != null);
  const blocked = studyGateBlocks({
    enabled: pack.team.studyGateEnabled,
    studyMinutes: pack.day.studyMinutes,
    goal: pack.team.studyGoalMinutes,
    override: pack.day.parentOverride,
  });
  const name = kids.find((kid) => kid.id === current)?.name ?? "Home plan";
  const profile = await prisma.athleteProfile.findUnique({
    where: { id: current },
    select: { academicStatus: true },
  });

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow="Home plan"
        title={name}
        description={`${template.title}, ${template.minutes}. Study sits next to the training, not after a lecture.`}
      />
      <KidSwitch athletes={kids.map((kid) => ({ id: kid.id, name: kid.name }))} current={current} path="/home" />
      <GateBanner blocked={blocked} enabled={pack.team.studyGateEnabled} />
      <AcademicCard athleteId={current} canEdit="parent" />
      <section className="grid gap-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 className="font-display text-3xl tracking-wide">Mobility</h2>
          <MobilityComplete athleteId={current} template={template.id} done={pack.day.mobilityDone} />
        </div>
        <ul className="grid gap-3">
          {drills.map((drill) => (
            <li key={drill.id} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <p className="font-display text-2xl tracking-wide">{drill.name}</p>
              <p className="font-semibold">{drill.cue}</p>
              <p className="mt-1 text-sm">{drill.dose}</p>
              <p className="text-sm">Stop: {drill.stop}</p>
            </li>
          ))}
        </ul>
        <HomeTrainComplete athleteId={current} done={pack.day.homeTrainDone} />
      </section>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="mb-3 font-display text-3xl tracking-wide">Study</h2>
        <div className="mb-4">
          <WeeklyStudy
            days={pack.days}
            today={pack.today}
            baseTarget={pack.team.weeklyStudyMinutes}
            status={profile?.academicStatus ?? "GOOD"}
          />
        </div>
        <StudyTimer
          athleteId={current}
          workMinutes={pack.team.workMinutes}
          breakMinutes={pack.team.breakMinutes}
          logged={pack.day.studyMinutes}
        />
        <div className="mt-4">
          <StudyMinutesForm athleteId={current} goal={pack.team.studyGoalMinutes} minutes={pack.day.studyMinutes} />
        </div>
        <div className="mt-4">
          <SubjectEditor athleteId={current} subjects={pack.subjects} />
        </div>
      </section>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Fuel</h2>
        <p className="text-sm text-muted-foreground">
          {FUEL_NOTE}{" "}
          <Link href={`/fuel?athlete=${current}`} className="font-semibold text-lion">
            Full fuel guide
          </Link>
        </p>
        <FuelBoard athleteId={current} values={pack.day} editable />
      </section>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="mb-2 font-display text-3xl tracking-wide">If study has to move</h2>
        <ParentOverrideForm athleteId={current} note={pack.day.parentOverride} />
      </section>
    </div>
  );
}
