import { AcademicCard } from "@/components/academic-card";
import { GateBanner } from "@/components/gate-banner";
import { KidSwitch } from "@/components/kid-switch";
import { PageHeader } from "@/components/page-header";
import { ParentOverrideForm, StudyMinutesForm, SubjectEditor } from "@/components/habit-controls";
import { StudyTimer } from "@/components/study-timer";
import { WeeklyStudy } from "@/components/weekly-study";
import { athleteIdForUser, parentKids, pickId } from "@/lib/access";
import { prisma } from "@/lib/db";
import { loadAthleteDay } from "@/lib/days";
import { requireUser } from "@/lib/guards";
import { studyGateBlocks } from "@/lib/habits";

export const metadata = { title: "Study" };

export default async function StudyPage({
  searchParams,
}: {
  searchParams: Promise<{ athlete?: string }>;
}) {
  const user = await requireUser();
  if (user.role === "ATHLETE") {
    const athleteId = await athleteIdForUser(user.id);
    if (!athleteId) {
      return <PageHeader eyebrow="Study" title="Profile missing" description="Ask your coach to finish your profile." />;
    }
    return <StudyBody athleteId={athleteId} parent={false} kids={[]} />;
  }
  if (user.role === "PARENT") {
    const kids = await parentKids(user.id);
    const current = pickId(
      kids.map((kid) => kid.id),
      (await searchParams).athlete,
    );
    if (!current) {
      return (
        <PageHeader
          eyebrow="Study"
          title="No athlete linked"
          description="A coach links your email before study shows up here."
        />
      );
    }
    return (
      <StudyBody
        athleteId={current}
        parent
        kids={kids.map((kid) => ({ id: kid.id, name: kid.name }))}
      />
    );
  }
  return (
    <PageHeader
      eyebrow="Study"
      title="Roster shows the streak"
      description="Athletes and parents log the study block. You see streak and last study date on the roster."
    />
  );
}

async function StudyBody({
  athleteId,
  parent,
  kids,
}: {
  athleteId: string;
  parent: boolean;
  kids: { id: string; name: string }[];
}) {
  const pack = await loadAthleteDay(athleteId);
  const profile = await prisma.athleteProfile.findUnique({
    where: { id: athleteId },
    select: { academicStatus: true },
  });
  const blocked = studyGateBlocks({
    enabled: pack.team.studyGateEnabled,
    studyMinutes: pack.day.studyMinutes,
    goal: pack.team.studyGoalMinutes,
    override: pack.day.parentOverride,
  });
  const name = kids.find((kid) => kid.id === athleteId)?.name;

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Study Lab"
        title={name ?? "Study"}
        description="Train the body. Train the mind. A block before or after home training. Default 25 on, 5 off."
      />
      {parent ? <KidSwitch athletes={kids} current={athleteId} path="/study" /> : null}
      <AcademicCard athleteId={athleteId} canEdit={parent ? "parent" : "none"} />
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <WeeklyStudy
          days={pack.days}
          today={pack.today}
          baseTarget={pack.team.weeklyStudyMinutes}
          status={profile?.academicStatus ?? "GOOD"}
        />
      </section>
      <GateBanner blocked={blocked} enabled={pack.team.studyGateEnabled} />
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <StudyTimer
          athleteId={athleteId}
          workMinutes={pack.team.workMinutes}
          breakMinutes={pack.team.breakMinutes}
          logged={pack.day.studyMinutes}
        />
      </section>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="mb-3 font-display text-3xl tracking-wide">Or log minutes</h2>
        <StudyMinutesForm athleteId={athleteId} goal={pack.team.studyGoalMinutes} minutes={pack.day.studyMinutes} />
        <p className="mt-3 text-sm text-muted-foreground">
          The daily goal ({pack.team.studyGoalMinutes} min) opens home training. Every minute also counts toward the weekly requirement above.
        </p>
      </section>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="mb-3 font-display text-3xl tracking-wide">Subjects</h2>
        <SubjectEditor athleteId={athleteId} subjects={pack.subjects} />
      </section>
      {parent ? (
        <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <h2 className="font-display text-3xl tracking-wide">Parent note</h2>
          <p className="mt-1 mb-3 text-sm text-muted-foreground">
            Use this when the study block cannot happen before training. It is a note, not a punishment.
          </p>
          <ParentOverrideForm athleteId={athleteId} note={pack.day.parentOverride} />
        </section>
      ) : null}
    </div>
  );
}
