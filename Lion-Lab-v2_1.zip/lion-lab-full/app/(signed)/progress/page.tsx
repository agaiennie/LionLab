import Link from "next/link";
import { ExamSummary } from "@/components/exam-summary";
import { FitCard } from "@/components/fit-card";
import { MeasureSummary } from "@/components/measure-summary";
import { KidSwitch } from "@/components/kid-switch";
import { PageHeader } from "@/components/page-header";
import { parentKids, pickId } from "@/lib/access";
import { positionLabel } from "@/lib/content/skills";
import { getAthlete } from "@/lib/data";
import { labelDay, loadAthleteDay, recentDays } from "@/lib/days";
import { requireParent } from "@/lib/guards";
import { TESTS, type TestType } from "@/lib/scoring";

export const metadata = { title: "Progress" };

export default async function ProgressPage({
  searchParams,
}: {
  searchParams: Promise<{ athlete?: string }>;
}) {
  const user = await requireParent();
  const kids = await parentKids(user.id);
  const current = pickId(
    kids.map((kid) => kid.id),
    (await searchParams).athlete,
  );
  if (!current) {
    return (
      <PageHeader
        eyebrow="Progress"
        title="No athlete linked"
        description="Ask a coach to link your email to your athlete."
      />
    );
  }
  const athlete = await getAthlete(current);
  if (!athlete) {
    return <PageHeader eyebrow="Progress" title="Athlete missing" description="Ask a coach to check the roster." />;
  }
  const pack = await loadAthleteDay(current);
  const week = await recentDays(current, pack.today);
  const name = kids.find((kid) => kid.id === current)?.name ?? athlete.name;

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Progress"
        title={name}
        description="School habits next to the battery. Trends, not a ranking."
      />
      <KidSwitch athletes={kids.map((kid) => ({ id: kid.id, name: kid.name }))} current={current} path="/progress" />
      <section className="grid gap-2">
        <h2 className="font-display text-3xl tracking-wide">Last 7 days</h2>
        <ul className="divide-y divide-border overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
          {week.map((day) => (
            <li key={day.day} className="grid gap-1 px-4 py-3 text-sm sm:grid-cols-[6rem_1fr]">
              <p className="font-semibold">{labelDay(day.day)}</p>
              <p>
                Study {day.studyMinutes} min · mobility {day.mobilityDone ? "yes" : "no"} · training{" "}
                {day.homeTrainDone ? "yes" : "no"} · fuel{" "}
                {[day.water, day.protein, day.sleep, day.lightJunk].filter(Boolean).length}/4
                {day.parentOverride ? " · parent note" : ""}
              </p>
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground">
          Streak {pack.snap.streak}. Last study {pack.snap.lastStudy ? labelDay(pack.snap.lastStudy) : "none"}.
        </p>
      </section>
      <section className="grid gap-2">
        <h2 className="font-display text-3xl tracking-wide">Battery</h2>
        {athlete.sessions.length === 0 ? (
          <p className="text-sm text-muted-foreground">No tests yet.</p>
        ) : (
          <ul className="divide-y divide-border overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
            {athlete.sessions.slice(0, 8).map((session) => (
              <li key={session.id} className="px-4 py-3 text-sm">
                <span className="font-semibold">{TESTS[session.testType as TestType].short}</span> · {session.recordedOnLabel} ·{" "}
                {session.scored.rawLabel} · form {session.scored.percent}% · ESTIMATE {session.scored.estimate.display}
              </li>
            ))}
          </ul>
        )}
      </section>
      <MeasureSummary athleteId={current} title="Numbers" />
      <FitCard athleteId={current} audience="family" />
      <ExamSummary athleteId={current} />
      <section className="grid gap-2">
        <h2 className="font-display text-3xl tracking-wide">Skills the coach is teaching</h2>
        <div className="flex flex-wrap gap-2">
          {athlete.positions.map((code) => (
            <Link key={code} href={`/skills/positions/${code}`} className="h-11 rounded-full bg-card px-4 py-2 text-sm font-semibold ring-1 ring-foreground/10">
              {positionLabel(code)}
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
