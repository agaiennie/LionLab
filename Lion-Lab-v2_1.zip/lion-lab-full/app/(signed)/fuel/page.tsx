import Link from "next/link";
import { KidSwitch } from "@/components/kid-switch";
import { PageHeader } from "@/components/page-header";
import { athleteIdForUser, parentKids, pickId } from "@/lib/access";
import { isStaff } from "@/lib/auth";
import {
  CHEAP_STAPLES,
  CHEAP_VERSION,
  EVERYONE_LINE,
  FOR_PARENTS,
  FUEL_DISCLAIMER,
  FUEL_SECTIONS,
  GAME_DAY,
  HEAT_WARNING,
  HYDRATION,
  PLATE,
  RED_FLAGS,
  RED_FLAG_LINE,
  SCHOOL_DAY,
  SLEEP,
  URINE_GUIDE,
  positionFuel,
  type TimelineStep,
} from "@/lib/content/fuel-guide";
import { FLEX_METRICS, programFor, weeklyPlan } from "@/lib/content/flex-balance-program";
import { formatMetric, METRIC_BY_ID } from "@/lib/content/metrics";
import type { Drill } from "@/lib/content/mobility";
import { getAthlete, type AthleteRecord } from "@/lib/data";
import { loadAthleteLatest } from "@/lib/fit-data";
import { requireUser } from "@/lib/guards";

export const metadata = { title: "Fuel" };

const card = "rounded-xl bg-card p-4 ring-1 ring-foreground/10";
const h2 = "font-display text-3xl tracking-wide";

export default async function FuelPage({
  searchParams,
}: {
  searchParams: Promise<{ athlete?: string }>;
}) {
  const user = await requireUser();
  let athlete: AthleteRecord | null = null;
  let kids: { id: string; name: string }[] = [];
  let habitsHref = "/today";

  if (user.role === "ATHLETE") {
    const id = await athleteIdForUser(user.id);
    athlete = id ? await getAthlete(id) : null;
  } else if (user.role === "PARENT") {
    const linked = await parentKids(user.id);
    kids = linked.map((kid) => ({ id: kid.id, name: kid.name }));
    const current = pickId(
      kids.map((kid) => kid.id),
      (await searchParams).athlete,
    );
    athlete = linked.find((kid) => kid.id === current) ?? null;
    habitsHref = current ? `/home?athlete=${current}` : "/home";
  }
  const staff = isStaff(user.role);

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow="Fuel"
        title="Fuel the work"
        description="Diet, water, sleep, and a flexibility & balance plan. Habits for the kitchen you live in — not a meal plan and not a calorie target."
      />
      <p className="rounded-xl bg-ink px-4 py-3 text-sm text-white">{FUEL_DISCLAIMER}</p>

      {user.role === "PARENT" && kids.length > 1 && athlete ? (
        <KidSwitch athletes={kids} current={athlete.id} path="/fuel" />
      ) : null}

      {athlete ? (
        <PersonalPlan athlete={athlete} parent={user.role === "PARENT"} habitsHref={habitsHref} />
      ) : !staff ? (
        <p className={card}>
          {user.role === "PARENT"
            ? "No athlete linked yet. A coach links your email, then the personal plan shows up here."
            : "Ask your coach to finish your profile to see your personal plan."}
        </p>
      ) : (
        <p className={card}>
          Coach view: athletes and parents see a personal flexibility & balance plan here, built from the athlete&apos;s latest
          sit-and-reach, ankle, squat, and balance numbers.
        </p>
      )}

      <nav aria-label="Fuel sections" className="flex flex-wrap gap-2">
        {FUEL_SECTIONS.map((section) => (
          <a
            key={section.id}
            href={`#${section.id}`}
            className="inline-flex h-11 items-center rounded-full bg-card px-4 text-sm font-semibold ring-1 ring-foreground/15 hover:ring-lion"
          >
            {section.label}
          </a>
        ))}
      </nav>

      <section id="plate" className="grid gap-3 scroll-mt-20">
        <h2 className={h2}>The plate</h2>
        <p className="font-semibold">{PLATE.line}</p>
        <ul className="grid gap-3 sm:grid-cols-2">
          {PLATE.parts.map((part) => (
            <li key={part.title} className={card}>
              <p className="font-semibold">{part.title}</p>
              <p className="mt-1 text-sm">{part.detail}</p>
            </li>
          ))}
        </ul>
        <ul className="grid list-disc gap-1 pl-5 text-sm">
          {PLATE.rhythm.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground">{EVERYONE_LINE}</p>
      </section>

      <section id="school-day" className="grid gap-3 scroll-mt-20">
        <h2 className={h2}>A school and practice day</h2>
        <Timeline steps={SCHOOL_DAY} />
      </section>

      <section id="game-day" className="grid gap-3 scroll-mt-20">
        <h2 className={h2}>Game day</h2>
        <p className="font-semibold">{GAME_DAY.line}</p>
        <Timeline steps={GAME_DAY.steps} />
        <div className={card}>
          <p className="font-semibold">Skip these</p>
          <ul className="mt-1 grid list-disc gap-1 pl-5 text-sm">
            {GAME_DAY.avoid.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </div>
      </section>

      <section id="water-sleep" className="grid gap-4 scroll-mt-20">
        <h2 className={h2}>Water &amp; sleep</h2>
        <div className={card}>
          <p className="font-display text-2xl tracking-wide">Water</p>
          <p className="font-semibold">{HYDRATION.line}</p>
          <ul className="mt-2 grid list-disc gap-1 pl-5 text-sm">
            {HYDRATION.rules.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
          <p className="mt-3 font-semibold">Pee check</p>
          <ul className="mt-1 grid gap-2">
            {URINE_GUIDE.map((row) => (
              <li
                key={row.color}
                className={`rounded-lg px-3 py-2 text-sm ring-1 ${
                  row.tone === "good"
                    ? "bg-yellow-50 ring-yellow-200 dark:bg-yellow-950/40 dark:ring-yellow-900"
                    : row.tone === "ok"
                      ? "bg-yellow-100 ring-yellow-300 dark:bg-yellow-900/40 dark:ring-yellow-800"
                      : "bg-amber-200 ring-amber-400 dark:bg-amber-900/60 dark:ring-amber-700"
                }`}
              >
                <span className="font-semibold">{row.color}:</span> {row.meaning}
              </li>
            ))}
          </ul>
        </div>
        <div className={card}>
          <p className="font-display text-2xl tracking-wide">Sleep</p>
          <p className="font-semibold">{SLEEP.line}</p>
          <ul className="mt-2 grid gap-1 text-sm">
            {SLEEP.ranges.map((range) => (
              <li key={range.ages}>
                <span className="font-semibold">{range.ages}:</span> {range.hours}
              </li>
            ))}
          </ul>
          <p className="mt-1 text-xs text-muted-foreground">{SLEEP.source}</p>
          <ul className="mt-2 grid list-disc gap-1 pl-5 text-sm">
            {SLEEP.tips.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </div>
        <div className="rounded-xl bg-red-50 p-4 ring-1 ring-red-300 dark:bg-red-950/40 dark:ring-red-800">
          <p className="font-semibold text-red-900 dark:text-red-100">{HEAT_WARNING.title}</p>
          <ul className="mt-1 grid list-disc gap-1 pl-5 text-sm">
            {HEAT_WARNING.signs.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
          <p className="mt-2 text-sm font-semibold">{HEAT_WARNING.action}</p>
        </div>
      </section>

      <section id="cheap" className="grid gap-3 scroll-mt-20">
        <h2 className={h2}>Cheap staples</h2>
        <div className={card}>
          <p className="font-display text-2xl tracking-wide">{CHEAP_VERSION.title}</p>
          <ul className="mt-2 grid list-disc gap-1 pl-5 text-sm">
            {CHEAP_VERSION.lines.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
          <p className="mt-3 text-sm font-semibold">{CHEAP_VERSION.schoolMeals}</p>
        </div>
        <ul className="grid gap-2 sm:grid-cols-2">
          {CHEAP_STAPLES.map((item) => (
            <li key={item.title} className="rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
              <span className="font-semibold">{item.title}.</span> <span className="text-sm">{item.detail}</span>
            </li>
          ))}
        </ul>
      </section>

      <section id="red-flags" className="grid gap-3 scroll-mt-20">
        <h2 className={h2}>Red flags</h2>
        <div className="rounded-xl bg-red-50 p-4 ring-1 ring-red-300 dark:bg-red-950/40 dark:ring-red-800">
          <p className="font-semibold">{RED_FLAG_LINE}</p>
          <ul className="mt-2 grid list-disc gap-1 pl-5 text-sm">
            {RED_FLAGS.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </div>
      </section>

      <section id="parents" className="grid gap-3 scroll-mt-20">
        <h2 className={h2}>{FOR_PARENTS.title}</h2>
        <ul className={`${card} grid list-disc gap-2 pl-8 text-sm`}>
          {FOR_PARENTS.lines.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
        <p className="text-sm font-semibold">{FOR_PARENTS.bodyTalk}</p>
        <p className="text-xs text-muted-foreground">{FUEL_DISCLAIMER}</p>
      </section>
    </div>
  );
}

function Timeline({ steps }: { steps: TimelineStep[] }) {
  return (
    <ol className="grid gap-3">
      {steps.map((step) => (
        <li key={step.when} className={card}>
          <p className="font-display text-2xl tracking-wide">{step.when}</p>
          <p className="font-semibold">{step.what}</p>
          <ul className="mt-1 grid list-disc gap-0.5 pl-5 text-sm">
            {step.examples.map((example) => (
              <li key={example}>{example}</li>
            ))}
          </ul>
          {step.cheap ? <p className="mt-2 text-sm text-muted-foreground">Cheap version: {step.cheap}</p> : null}
        </li>
      ))}
    </ol>
  );
}

async function PersonalPlan({
  athlete,
  parent,
  habitsHref,
}: {
  athlete: AthleteRecord;
  parent: boolean;
  habitsHref: string;
}) {
  const { latest } = await loadAthleteLatest(athlete.id);
  const plan = programFor(latest, athlete.grade);
  const week = weeklyPlan(athlete.positions[0], athlete.grade);
  const fuel = positionFuel(athlete.positions[0]);
  const who = parent ? `${athlete.name}'s` : "Your";
  const sessionById = new Map(plan.sessions.map((session) => [session.id, session]));

  return (
    <section className="grid gap-4" aria-label="Personal plan">
      <div className={card}>
        <p className="font-display text-sm font-semibold tracking-[0.18em] text-lion">
          {fuel.group} · {athlete.positions.join(" ") || "no position yet"} · grade {athlete.grade}
        </p>
        <h2 className={h2}>{who} fuel notes</h2>
        <ul className="mt-2 grid list-disc gap-1 pl-5 text-sm">
          {fuel.notes.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
        <p className="mt-3 text-sm">
          Check off today&apos;s four fuel habits (water, protein, sleep, no heavy junk) on{" "}
          <Link href={habitsHref} className="font-semibold text-lion">
            {parent ? "Home" : "Today"}
          </Link>
          .
        </p>
      </div>

      <div className="grid gap-3">
        <h2 className={h2}>{who} flexibility &amp; balance plan</h2>
        <p className="text-sm">
          Three times a week, 12–15 minutes, on non-consecutive days. {plan.note}
        </p>
        <ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
          {FLEX_METRICS.map((metric) => {
            const row = latest[metric];
            const weak = plan.weak.find((spot) => spot.metric === metric);
            return (
              <li
                key={metric}
                className={`rounded-xl px-3 py-2 text-sm ring-1 ${
                  weak ? "bg-amber-50 ring-amber-300 dark:bg-amber-950/40 dark:ring-amber-800" : "bg-card ring-foreground/10"
                }`}
              >
                <p className="font-semibold">{METRIC_BY_ID[metric].short}</p>
                <p>{row ? formatMetric(metric, row.value) : "Not measured"}</p>
                <p className="text-xs text-muted-foreground">
                  {row ? (weak ? `Below the ok line (${formatMetric(metric, weak.okLine)})` : "At or past the ok line") : "Ask a coach"}
                </p>
              </li>
            );
          })}
        </ul>
        <p className="text-xs text-muted-foreground">
          The ok line is a Lion Lab coaching ESTIMATE for your grade band, not a medical norm.
        </p>
        <div className="grid gap-3 lg:grid-cols-3">
          {plan.sessions.map((session) => (
            <div key={session.id} className={card}>
              <p className="font-display text-2xl tracking-wide">{session.title}</p>
              <p className="text-sm text-muted-foreground">{session.minutes}</p>
              <ol className="mt-2 grid gap-2">
                {session.drills.map((drill) => (
                  <DrillRow key={drill.id} drill={drill} priority={session.priority.includes(drill.id)} />
                ))}
              </ol>
            </div>
          ))}
        </div>
      </div>

      <div className="grid gap-3">
        <h2 className={h2}>{who} week — {week.groupLabel.toLowerCase()}</h2>
        <ul className="grid list-disc gap-1 pl-5 text-sm">
          {week.rules.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
        <div className="grid gap-3 lg:grid-cols-3">
          {week.days.map((day) => (
            <div key={day.id} className={card}>
              <p className="font-display text-2xl tracking-wide">{day.title}</p>
              <p className="text-sm text-muted-foreground">{day.focus}</p>
              {day.exercises.length ? (
                <ul className="mt-2 grid gap-2">
                  {day.exercises.map((exercise) => (
                    <li key={exercise.id} className="text-sm">
                      <p className="font-semibold">
                        {exercise.name} <span className="font-normal text-muted-foreground">· {exercise.dose}</span>
                      </p>
                      <p>{exercise.cue}</p>
                      <p className="text-xs text-muted-foreground">Stop: {exercise.stop}</p>
                    </li>
                  ))}
                </ul>
              ) : null}
              {day.flexSession ? (
                <p className="mt-2 text-sm font-semibold">
                  Then: {sessionById.get(day.flexSession)?.title ?? `Session ${day.flexSession}`}
                </p>
              ) : null}
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">Dose band: grades {week.band}. Guidance, not medical advice.</p>
      </div>
    </section>
  );
}

function DrillRow({ drill, priority }: { drill: Drill; priority: boolean }) {
  return (
    <li className="rounded-lg bg-background/60 p-2 ring-1 ring-foreground/10">
      <details>
        <summary className="cursor-pointer list-none">
          <span className="font-semibold">{drill.name}</span>
          {priority ? (
            <span className="ml-2 rounded-full bg-lion px-2 py-0.5 text-xs font-semibold text-white">Priority</span>
          ) : null}
          <span className="block text-sm">{drill.cue}</span>
          <span className="block text-xs text-muted-foreground">{drill.dose}</span>
        </summary>
        <p className="mt-2 text-sm text-muted-foreground">{drill.purpose}</p>
        <ol className="mt-1 grid list-decimal gap-0.5 pl-5 text-sm">
          {drill.steps.map((step) => (
            <li key={step}>{step}</li>
          ))}
        </ol>
        <p className="mt-1 text-sm">Stop: {drill.stop}</p>
      </details>
    </li>
  );
}
