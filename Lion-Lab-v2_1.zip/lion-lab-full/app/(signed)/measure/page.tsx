import Link from "next/link";
import { Battery } from "@/components/battery";
import { MeasureSummary } from "@/components/measure-summary";
import { PageHeader } from "@/components/page-header";
import { getAthleteByUserId } from "@/lib/data";
import { requireAthlete } from "@/lib/guards";
import { TESTS, type TestType } from "@/lib/scoring";

export const metadata = { title: "Measure" };

function testLabel(type: TestType) {
  return TESTS[type].short;
}

export default async function MeasurePage() {
  const user = await requireAthlete();
  const athlete = await getAthleteByUserId(user.id);
  if (!athlete) {
    return <PageHeader eyebrow="Measure" title="Profile missing" description="Ask your coach to finish your profile." />;
  }

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow={`Grade ${athlete.grade} · ${athlete.positionLabels.join(", ")}`}
        title="Measure"
        description="Raw is the clock or the tape. Form is the checklist. Adjusted is an ESTIMATE. Your coach logs the official rep. Camera assist is optional."
        action={
          <Link href="/train#tracker" className="text-sm font-semibold text-lion">
            Camera assist
          </Link>
        }
      />
      <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Fact label="Height" value={athlete.heightLabel} />
        <Fact label="Weight" value={`${athlete.weightLbs} lb`} />
        <Fact label="Grade" value={String(athlete.grade)} />
        <Fact label="Positions" value={athlete.positions.join(" · ") || "—"} />
      </dl>
      <Battery athlete={athlete} />
      <MeasureSummary athleteId={athlete.id} />
      <Link
        href="/camera"
        className="flex min-h-14 items-center justify-between rounded-xl bg-ink px-4 py-3 font-semibold text-white"
      >
        <span>Balance &amp; flexibility self-test</span>
        <span aria-hidden>→</span>
      </Link>
      <p className="text-sm text-muted-foreground">
        Stance and Gate Hinge can be checked on camera from Train. A denied camera still leaves the checklist.{" "}
        <Link href="/athlete/profile" className="font-semibold text-lion">
          Edit size and position
        </Link>
        .
      </p>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">History</h2>
        {athlete.sessions.length === 0 ? (
          <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">
            No tests yet. When your coach logs a 40, med ball, or stance, it shows up here.
          </p>
        ) : (
          <ul className="divide-y divide-border overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
            {athlete.sessions.map((session) => (
              <li key={session.id} className="grid gap-1 px-4 py-3 sm:grid-cols-[8rem_1fr]">
                <div>
                  <p className="font-semibold">{testLabel(session.testType)}</p>
                  <p className="text-sm text-muted-foreground">{session.recordedOnLabel}</p>
                </div>
                <p className="text-sm">
                  {session.scored.rawLabel} · form {session.scored.percent}% · ESTIMATE {session.scored.estimate.display}
                  {session.notes ? ` · ${session.notes}` : ""}
                </p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card px-3 py-3 ring-1 ring-foreground/10">
      <dt className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{label}</dt>
      <dd className="font-display text-2xl tracking-wide">{value}</dd>
    </div>
  );
}
