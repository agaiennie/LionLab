import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { StandardsForm } from "@/components/standards-form";
import { FAST, FAST_FINISH, FAST_LINE } from "@/lib/content/fast";
import { getTeam } from "@/lib/days";
import { requireStaff } from "@/lib/guards";

export const metadata = { title: "Standards" };

export default async function StandardsPage() {
  const user = await requireStaff();
  const team = await getTeam();

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_22rem]">
      <div className="grid gap-4">
        <PageHeader
          eyebrow={team.seasonLabel}
          title="Lion Standard"
          description="FAST is the snap cue. The study gate is the home rule: train the body, train the mind."
        />
        <p className="rounded-xl bg-ink px-4 py-4 font-display text-2xl leading-tight tracking-wide text-white sm:text-3xl">
          {FAST_LINE}
        </p>
        <ul className="grid gap-2 sm:grid-cols-2">
          {FAST.map((item) => (
            <li key={item.letter} className="rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
              <p className="font-display text-2xl tracking-wide">
                <span className="text-lion">{item.letter}</span> {item.word}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{item.doThis}</p>
            </li>
          ))}
        </ul>
        <ul className="grid gap-2 text-sm">
          {FAST_FINISH.map((finish) => (
            <li key={finish.role}>
              <span className="font-semibold">{finish.role}.</span> {finish.detail}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground">
          The phone card is on <Link href="/field" className="font-semibold text-lion">Field</Link>. Teach the letters from the{" "}
          <Link href="/skills" className="font-semibold text-lion">skill library</Link>. Volume is for safety. After a miss, restate one letter and run the next rep.
        </p>
      </div>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="mb-3 font-display text-2xl tracking-wide">Season, study gate, public page</h2>
        <StandardsForm
          seasonLabel={team.seasonLabel}
          studyGateEnabled={team.studyGateEnabled}
          studyGoalMinutes={team.studyGoalMinutes}
          workMinutes={team.workMinutes}
          breakMinutes={team.breakMinutes}
          weeklyStudyMinutes={team.weeklyStudyMinutes}
          publicSite={{
            teamName: team.teamName,
            levelLabel: team.levelLabel,
            publicBlurb: team.publicBlurb,
            joinCode: team.joinCode,
            canEditJoinCode: user.role === "ADMIN",
          }}
        />
      </section>
    </div>
  );
}
