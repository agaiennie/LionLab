import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { LIBRARY_POSITIONS, skillsForPosition } from "@/lib/content/skills";
import { requireUser } from "@/lib/guards";

export const metadata = { title: "Skills by position" };

export default async function SkillPositionsPage() {
  await requireUser();

  return (
    <div className="grid gap-4">
      <PageHeader
        eyebrow="Skills"
        title="By position"
        description="Each list opens the same skill pages. Nothing here is a second copy of the teach guide."
        action={
          <Link href="/skills" className="text-sm font-semibold text-lion">
            All skills
          </Link>
        }
      />
      <ul className="grid gap-3 sm:grid-cols-2">
        {LIBRARY_POSITIONS.map((position) => {
          const count = skillsForPosition(position.code).length;
          return (
            <li key={position.code}>
              <Link href={`/skills/positions/${position.code}`} className="block rounded-xl bg-card p-4 ring-1 ring-foreground/10">
                <p className="font-display text-3xl tracking-wide">
                  {position.code} · {position.label}
                </p>
                <p className="mt-1 text-sm">{position.job}</p>
                <p className="mt-2 text-sm font-semibold text-lion">{count} skills</p>
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
