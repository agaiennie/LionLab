import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { fastWords } from "@/lib/content/fast";
import { LIBRARY_POSITIONS, positionLabel, positionPlan, type Skill } from "@/lib/content/skills";
import { requireUser } from "@/lib/guards";

export function generateStaticParams() {
  return LIBRARY_POSITIONS.map((position) => ({ pos: position.code }));
}

export async function generateMetadata({ params }: { params: Promise<{ pos: string }> }) {
  const { pos } = await params;
  return { title: `${positionLabel(pos.toUpperCase())} skills` };
}

export default async function PositionSkillsPage({ params }: { params: Promise<{ pos: string }> }) {
  await requireUser();
  const code = (await params).pos.toUpperCase();
  const position = LIBRARY_POSITIONS.find((item) => item.code === code);
  if (!position) notFound();
  const plan = positionPlan(code);

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Position skills"
        title={position.label}
        description={position.job}
        action={
          <Link href="/skills/positions" className="text-sm font-semibold text-lion">
            All positions
          </Link>
        }
      />
      <SkillGroup title="Must teach first" skills={plan.first} />
      <SkillGroup title="Next" skills={plan.next} />
    </div>
  );
}

function SkillGroup({ title, skills }: { title: string; skills: Skill[] }) {
  if (skills.length === 0) return null;
  return (
    <section className="grid gap-3">
      <h2 className="font-display text-3xl tracking-wide">{title}</h2>
      <ul className="grid gap-2">
        {skills.map((skill) => (
          <li key={skill.id}>
            <Link
              href={`/skills/${skill.id}`}
              className="flex min-h-11 items-center justify-between gap-3 rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10"
            >
              <span>
                <span className="block font-semibold">{skill.name}</span>
                <span className="text-sm text-muted-foreground">
                  {skill.fastLetters.length > 0 ? `FAST ${fastWords(skill.fastLetters)}` : "No FAST letter"}
                </span>
              </span>
              <span className="text-sm font-semibold text-lion">Open</span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
