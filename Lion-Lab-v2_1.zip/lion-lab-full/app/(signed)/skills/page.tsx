import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { SkillBrowser } from "@/components/skill-browser";
import { LIBRARY_POSITIONS, SKILLS, SKILL_LIBRARY_VERSION } from "@/lib/content/skills";
import { requireUser } from "@/lib/guards";
import { isStaff } from "@/lib/auth";

export const metadata = { title: "Skills" };

export default async function SkillsPage() {
  const user = await requireUser();
  const staff = isStaff(user.role);

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow={`Skill library ${SKILL_LIBRARY_VERSION}`}
        title="Skills"
        description={
          staff
            ? "Every skill a volunteer coach should be able to teach. Demo, break it down, then speed it up. Position pages use these same guides."
            : "What your coach is teaching. Open a skill for the overview. The step-by-step script stays with the coach."
        }
        action={
          <Link href="/skills/positions" className="text-sm font-semibold text-lion">
            By position
          </Link>
        }
      />
      <div className="flex gap-2 overflow-x-auto">
        {LIBRARY_POSITIONS.map((position) => (
          <Link
            key={position.code}
            href={`/skills/positions/${position.code}`}
            className="h-11 shrink-0 rounded-full bg-card px-4 py-2 text-sm font-semibold ring-1 ring-foreground/10"
          >
            {position.code}
          </Link>
        ))}
      </div>
      <SkillBrowser
        skills={SKILLS.map((skill) => ({
          id: skill.id,
          name: skill.name,
          phase: skill.phase,
          positions: skill.positions,
          fastLetters: skill.fastLetters,
          what: skill.what,
        }))}
      />
    </div>
  );
}
