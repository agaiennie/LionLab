import Link from "next/link";
import { notFound } from "next/navigation";
import { SkillTaughtButton } from "@/components/skill-taught-button";
import { PageHeader } from "@/components/page-header";
import { isStaff } from "@/lib/auth";
import { FAST_LINE, fastWords } from "@/lib/content/fast";
import {
  LIBRARY_POSITIONS,
  SKILLS,
  chipLabels,
  positionPlan,
  skillById,
  weekKey,
  type Skill,
} from "@/lib/content/skills";
import { listAthletes } from "@/lib/data";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/guards";

export function generateStaticParams() {
  return SKILLS.map((skill) => ({ skillId: skill.id }));
}

export async function generateMetadata({ params }: { params: Promise<{ skillId: string }> }) {
  const skill = skillById((await params).skillId);
  return { title: skill?.name ?? "Skill" };
}

export default async function SkillPage({ params }: { params: Promise<{ skillId: string }> }) {
  const user = await requireUser();
  const skill = skillById((await params).skillId);
  if (!skill) notFound();
  const staff = isStaff(user.role);
  const related = LIBRARY_POSITIONS.filter((position) => positionPlan(position.code).first.concat(positionPlan(position.code).next).some((item) => item.id === skill.id));

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Lion teach method"
        title={skill.name}
        description="Demo. Break down. Speed up. One page for this skill. Position lists only link here."
        action={
          <Link href="/skills" className="text-sm font-semibold text-lion">
            All skills
          </Link>
        }
      />
      <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">What it is</h2>
        <p>{skill.what}</p>
        <div className="flex flex-wrap gap-2">
          {chipLabels(skill).map((label) => (
            <span key={label} className="rounded-full bg-muted px-3 py-1 text-sm font-semibold">
              {label}
            </span>
          ))}
        </div>
        <h3 className="font-display text-2xl tracking-wide">Why it matters</h3>
        <p>{skill.why}</p>
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">1 · Demo</h2>
        <p>{skill.demo.correct}</p>
        {staff ? (
          <>
            <h3 className="font-semibold">Coaching eyes</h3>
            <ul className="grid gap-1 text-sm">
              {skill.demo.eyes.map((eye) => (
                <li key={eye}>{eye}</li>
              ))}
            </ul>
          </>
        ) : null}
        <h3 className="font-semibold">Wrong looks</h3>
        <ul className="grid gap-1 text-sm">
          {skill.demo.wrong.map((wrong) => (
            <li key={wrong}>{wrong}</li>
          ))}
        </ul>
      </section>

      {staff ? <CoachScript skill={skill} /> : (
        <p className="rounded-xl bg-accent px-4 py-3 text-sm text-accent-foreground">
          The break-down and the 5-minute station card are the coach’s script. Ask what “done” looks like, then do that look.
        </p>
      )}

      <section className="grid gap-2">
        <h2 className="font-display text-3xl tracking-wide">FAST</h2>
        {skill.fastLetters.length === 0 ? (
          <p className="text-sm">No FAST letter. This skill still uses Demo, Break down, Speed up.</p>
        ) : (
          <>
            <p className="font-display text-4xl tracking-wide text-lion">{fastWords(skill.fastLetters)}</p>
            {skill.fastLetters.includes("T") ? <p className="text-sm">{FAST_LINE}</p> : null}
          </>
        )}
        <Link href="/field" className="text-sm font-semibold text-lion">
          Open the FAST card
        </Link>
      </section>

      <section className="grid gap-2">
        <h2 className="font-display text-3xl tracking-wide">Measure</h2>
        <ul className="grid gap-2 text-sm">
          {skill.metricLinks.map((metric) => (
            <li key={metric.label} className="rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
              <p className="font-semibold">{metric.label}</p>
              <p className="text-muted-foreground">{metric.detail}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="flex flex-wrap gap-2 text-sm font-semibold">
        {related.map((position) => (
          <Link key={position.code} href={`/skills/positions/${position.code}`} className="text-lion">
            {position.code} list
          </Link>
        ))}
      </section>

      {staff ? <TaughtRow skillId={skill.id} /> : null}
    </div>
  );
}

function CoachScript({ skill }: { skill: Skill }) {
  return (
    <>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">2 · Break down</h2>
        <ol className="grid gap-3">
          {skill.breakdown.map((item, index) => (
            <li key={item.name} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                {index + 1} · {item.name}
              </p>
              <p className="mt-1"><span className="font-semibold">Coach says.</span> {item.coachSays}</p>
              <p className="mt-1"><span className="font-semibold">Player does.</span> {item.playerDoes}</p>
              <p className="mt-1"><span className="font-semibold">Success.</span> {item.success}</p>
              <p className="mt-1"><span className="font-semibold">Fail fix.</span> {item.failFix}</p>
            </li>
          ))}
        </ol>
      </section>
      <section className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">3 · Speed up</h2>
        <p>{skill.speedUp.how}</p>
        <p className="text-sm"><span className="font-semibold">Stop.</span> {skill.speedUp.stop}</p>
      </section>
      <section className="grid min-h-[70vh] content-start gap-3 rounded-xl bg-ink p-5 text-white">
        <p className="text-sm font-semibold tracking-[0.18em] text-lion">5-MINUTE STATION</p>
        <h2 className="font-display text-5xl tracking-wide">{skill.name}</h2>
        <p className="text-lg">{skill.station.setup}</p>
        <p className="font-display text-3xl tracking-wide">{skill.station.reps}</p>
        <p className="text-2xl">{skill.station.cue}</p>
        <p className="text-sm text-white/80">Stop: {skill.station.stop}</p>
      </section>
    </>
  );
}

async function TaughtRow({ skillId }: { skillId: string }) {
  const athletes = await listAthletes();
  const week = weekKey();
  const marks = await prisma.skillMark.findMany({
    where: { weekKey: week, skillId },
    select: { athleteId: true },
  });
  const taught = new Set(marks.map((mark) => mark.athleteId));
  const skill = skillById(skillId);
  const relevant = athletes.filter((athlete) =>
    athlete.positions.some((code) => skill && (skill.positions.includes("ALL") || skill.positions.includes(code) || (code === "K" && skill.positions.includes("ST")))),
  );

  return (
    <section className="grid gap-3">
      <h2 className="font-display text-3xl tracking-wide">Taught this week</h2>
      <p className="text-sm text-muted-foreground">Week of {week}. A mark is a reminder, not a grade.</p>
      {relevant.length === 0 ? (
        <p className="text-sm text-muted-foreground">No athlete on the roster lists a position for this skill.</p>
      ) : (
        <ul className="grid gap-2">
          {relevant.map((athlete) => (
            <li key={athlete.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
              <Link href={`/coach/athletes/${athlete.id}`} className="font-semibold">
                {athlete.name}
              </Link>
              <SkillTaughtButton athleteId={athlete.id} skillId={skillId} taught={taught.has(athlete.id)} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
