import Link from "next/link";
import { BandPill, BodyTracker } from "@/components/body-tracker";
import { GateBanner } from "@/components/gate-banner";
import { HomeTrainComplete, MobilityComplete } from "@/components/habit-controls";
import { PageHeader } from "@/components/page-header";
import { athleteIdForUser } from "@/lib/access";
import { getAthlete } from "@/lib/data";
import { dateFromKey, loadAthleteDay } from "@/lib/days";
import { requireAthlete } from "@/lib/guards";
import { studyGateBlocks } from "@/lib/habits";
import { DRILLS, POSITION_ADDONS, drillById, sessionTemplate } from "@/lib/content/mobility";
import { toPosePosition } from "@/lib/pose-position";

export const metadata = { title: "Train" };

export default async function TrainPage() {
  const user = await requireAthlete();
  const athleteId = await athleteIdForUser(user.id);
  const athlete = athleteId ? await getAthlete(athleteId) : null;
  if (!athlete || !athleteId) {
    return <PageHeader eyebrow="Train" title="Profile missing" description="Ask your coach to finish your profile." />;
  }
  const pack = await loadAthleteDay(athlete.id);
  const template = sessionTemplate(dateFromKey(pack.today));
  const drills = template.drillIds.map((id) => drillById(id)).filter((drill) => drill != null);
  const addonIds =
    POSITION_ADDONS.find((row) => row.positions.includes(athlete.positions[0] ?? ""))?.drillIds ?? [];
  const addons = addonIds.map((id) => drillById(id)).filter((drill) => drill != null);
  const blocked = studyGateBlocks({
    enabled: pack.team.studyGateEnabled,
    studyMinutes: pack.day.studyMinutes,
    goal: pack.team.studyGoalMinutes,
    override: pack.day.parentOverride,
  });

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow="Athlete"
        title="Train"
        description={`${template.title}, ${template.minutes}. Then the body tracker if you want a camera score. Home saves follow the study gate.`}
        action={
          <Link href="/field" className="text-sm font-semibold text-lion">
            Field cards
          </Link>
        }
      />
      <GateBanner blocked={blocked} enabled={pack.team.studyGateEnabled} />
      <section className="grid gap-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 className="font-display text-3xl tracking-wide">{template.title}</h2>
          <MobilityComplete athleteId={athlete.id} template={template.id} done={pack.day.mobilityDone} />
        </div>
        <ol className="grid gap-3">
          {drills.map((drill, index) => (
            <li key={drill.id} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{index + 1}</p>
              <p className="font-display text-2xl tracking-wide">{drill.name}</p>
              <p className="font-semibold">{drill.cue}</p>
              <p className="mt-1 text-sm text-muted-foreground">{drill.purpose}</p>
              <ol className="mt-2 list-decimal pl-5 text-sm">
                {drill.steps.map((step) => (
                  <li key={step}>{step}</li>
                ))}
              </ol>
              <p className="mt-2 text-sm">{drill.dose}</p>
              <p className="text-sm">Stop: {drill.stop}</p>
            </li>
          ))}
        </ol>
        {addons.length > 0 ? (
          <div>
            <h3 className="font-display text-2xl tracking-wide">Position add-on</h3>
            <ul className="mt-2 grid gap-2 text-sm">
              {addons.map((drill) => (
                <li key={drill.id}>
                  <span className="font-semibold">{drill.name}.</span> {drill.cue}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </section>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">Extra home training</h2>
        <p className="mt-1 mb-3 text-sm text-muted-foreground">
          Throws, routes, or a lift at home. This is the session the study gate covers. Practice at the field is logged by a coach.
        </p>
        <HomeTrainComplete athleteId={athlete.id} done={pack.day.homeTrainDone} />
      </section>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Body tracker</h2>
        <BodyTracker
          athleteId={athlete.id}
          athleteName={athlete.name}
          initialPosition={toPosePosition(athlete.positions[0])}
          placeDefault="home"
          allowFieldToggle
          studyBlocked={blocked}
        />
        <PoseList poses={pack.poses} />
      </section>
      <section className="grid gap-2">
        <h2 className="font-display text-3xl tracking-wide">Library</h2>
        {DRILLS.map((drill) => (
          <details key={drill.id} className="rounded-xl bg-card px-4 py-3 ring-1 ring-foreground/10">
            <summary className="cursor-pointer font-semibold">{drill.name}</summary>
            <p className="mt-2 text-sm">{drill.cue}</p>
            <p className="mt-1 text-sm text-muted-foreground">{drill.purpose}</p>
            <p className="mt-1 text-sm">{drill.dose}</p>
            <p className="text-sm">Stop: {drill.stop}</p>
          </details>
        ))}
      </section>
    </div>
  );
}

function PoseList({
  poses,
}: {
  poses: {
    id: string;
    movementName: string;
    place: string;
    mode: string;
    overall: number | null;
    band: string;
    recordedOnLabel: string;
  }[];
}) {
  if (poses.length === 0) {
    return <p className="text-sm text-muted-foreground">No body-tracker sessions yet.</p>;
  }
  return (
    <ul className="grid gap-2">
      {poses.map((pose) => (
        <li key={pose.id} className="flex flex-wrap items-center justify-between gap-2 text-sm">
          <span>
            {pose.recordedOnLabel} · {pose.movementName} · {pose.place} · {pose.mode}
          </span>
          <BandPill band={pose.band} score={pose.overall} />
        </li>
      ))}
    </ul>
  );
}
