import { redirect } from "next/navigation";
import { CameraLab } from "@/components/camera-lab";
import { PageHeader } from "@/components/page-header";
import { athleteIdForUser } from "@/lib/access";
import { isStaff } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/guards";

export const metadata = { title: "Camera tests" };

export default async function CameraPage() {
  const user = await requireUser();
  const staff = isStaff(user.role);
  if (!staff && user.role !== "ATHLETE") redirect("/today");

  let athletes: { id: string; name: string }[] = [];
  let selfAthleteId: string | null = null;
  if (staff) {
    const rows = await prisma.athleteProfile.findMany({
      where: { user: { status: "ACTIVE" } },
      select: { id: true, user: { select: { name: true } } },
      orderBy: { user: { name: "asc" } },
    });
    athletes = rows.map((r) => ({ id: r.id, name: r.user.name }));
  } else {
    selfAthleteId = await athleteIdForUser(user.id);
    if (selfAthleteId) athletes = [{ id: selfAthleteId, name: user.name ?? "Me" }];
  }

  return (
    <div className="grid gap-4">
      <PageHeader
        eyebrow={staff ? "Field station" : "Home self-test"}
        title="Camera tests"
        description={
          staff
            ? "Balance, deep squat, and sit-and-reach measured by the phone camera. Pick the athlete, run the test, save the number."
            : "Practice your balance and flexibility at home. Your coach runs the official test on test day."
        }
      />
      <CameraLab staff={staff} athletes={athletes} selfAthleteId={selfAthleteId} trackerHref={staff ? "/tracker" : "/train#tracker"} />
    </div>
  );
}
