import { KidSwitch } from "@/components/kid-switch";
import { PageHeader } from "@/components/page-header";
import { parentKids, pickId } from "@/lib/access";
import { loadAthleteDay } from "@/lib/days";
import { requireParent } from "@/lib/guards";

export const metadata = { title: "Notes" };

export default async function NotesPage({
  searchParams,
}: {
  searchParams: Promise<{ athlete?: string }>;
}) {
  const user = await requireParent();
  const kids = await parentKids(user.id);
  const current = pickId(
    kids.map((kid) => kid.id),
    (await searchParams).athlete,
  );
  if (!current) {
    return (
      <PageHeader
        eyebrow="Notes"
        title="No athlete linked"
        description="Notes from coaches show up after your email is linked."
      />
    );
  }
  const pack = await loadAthleteDay(current);
  const name = kids.find((kid) => kid.id === current)?.name ?? "Notes";

  return (
    <div className="grid gap-4">
      <PageHeader
        eyebrow="From coaches"
        title={name}
        description="Short notes for home. Not a message thread."
      />
      <KidSwitch athletes={kids.map((kid) => ({ id: kid.id, name: kid.name }))} current={current} path="/notes" />
      {pack.notes.length === 0 ? (
        <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">
          No notes yet. When a coach writes one on the athlete page, it shows up here.
        </p>
      ) : (
        <ul className="grid gap-3">
          {pack.notes.map((note) => (
            <li key={note.id} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <p>{note.body}</p>
              <p className="mt-2 text-sm text-muted-foreground">
                {note.author} · {note.createdLabel}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
