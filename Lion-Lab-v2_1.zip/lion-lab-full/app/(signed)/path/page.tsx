import Link from "next/link";
import { ExamSummary } from "@/components/exam-summary";
import { FitCard } from "@/components/fit-card";
import { PageHeader } from "@/components/page-header";
import { athleteIdForUser } from "@/lib/access";
import { fitNotes } from "@/lib/content/fit";
import { positionLabel, positionPlan } from "@/lib/content/skills";
import { getAthlete } from "@/lib/data";
import { requireAthlete } from "@/lib/guards";

export const metadata = { title: "My path" };

export default async function PathPage() {
  const user = await requireAthlete();
  const athleteId = await athleteIdForUser(user.id);
  const athlete = athleteId ? await getAthlete(athleteId) : null;
  if (!athlete) {
    return <PageHeader eyebrow="My path" title="Profile missing" description="Ask your coach to finish your profile." />;
  }
  const notes = fitNotes(athlete);

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="My path"
        title="Where you fit"
        description="Your test numbers, size, and exams against what each job needs. An ESTIMATE for talking with your coach — not a depth chart and not a medical claim."
      />
      <FitCard athleteId={athlete.id} audience="family" />
      <ExamSummary athleteId={athlete.id} />
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-2xl tracking-wide">Form battery notes · {notes.position}</h2>
        <ul className="mt-2 grid gap-1 text-sm">
          {notes.basis.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
      </section>
      <section className="grid gap-3 sm:grid-cols-2">
        <List title="Strengths" items={notes.strengths} empty="Nothing to call a strength until the battery is on file." />
        <List title="Gaps" items={notes.gaps} empty="No gap called yet." />
      </section>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Skills for your positions</h2>
        <p className="text-sm text-muted-foreground">
          What your coach wants. The teach script stays with the coach. These links open the same skill pages.
        </p>
        {athlete.positions.map((code) => {
          const plan = positionPlan(code);
          const preview = [...plan.first, ...plan.next].slice(0, 4);
          return (
            <div key={code} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <Link href={`/skills/positions/${code}`} className="font-display text-2xl tracking-wide text-lion">
                {positionLabel(code)}
              </Link>
              <ul className="mt-2 grid gap-1 text-sm">
                {preview.map((skill) => (
                  <li key={skill.id}>
                    <Link href={`/skills/${skill.id}`}>{skill.name}</Link>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </section>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">This week</h2>
        <ul className="grid gap-3">
          {notes.drills.map((drill) => (
            <li key={drill.name} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <p className="font-display text-2xl tracking-wide">{drill.name}</p>
              <p className="text-sm">{drill.why}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function List({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <h2 className="font-display text-2xl tracking-wide">{title}</h2>
      {items.length === 0 ? (
        <p className="mt-2 text-sm text-muted-foreground">{empty}</p>
      ) : (
        <ul className="mt-2 grid gap-2 text-sm">
          {items.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      )}
    </section>
  );
}
