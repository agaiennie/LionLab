import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { ParentInviteForm } from "@/components/parent-invite-form";
import { StaffForm } from "@/components/staff-form";
import { StandardsForm } from "@/components/standards-form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { listAthletes } from "@/lib/data";
import { getTeam } from "@/lib/days";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/guards";

export const metadata = { title: "Users" };

const roleLabel: Record<string, string> = {
  ADMIN: "Admin",
  COACH: "Coach",
  ATHLETE: "Athlete",
  PARENT: "Parent",
};

export default async function AdminPage() {
  await requireAdmin();
  const [users, athletes, team] = await Promise.all([
    prisma.user.findMany({
      orderBy: [{ role: "asc" }, { name: "asc" }],
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        parentLinks: { include: { athlete: { include: { user: { select: { name: true } } } } } },
      },
    }),
    listAthletes(),
    getTeam(),
  ]);

  return (
    <div className="grid gap-8">
      <PageHeader
        eyebrow="Admin"
        title="Users"
        description={`Season ${team.seasonLabel}. Add coaches here. Invite a parent by email and link them to an athlete. Families and coaches can also request an account at /signup with the team join code; approve them under Approvals.`}
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
        <div className="overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-semibold">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    {roleLabel[user.role] ?? user.role}
                    {user.role === "PARENT" && user.parentLinks.length > 0
                      ? ` · ${user.parentLinks.map((link) => link.athlete.user.name).join(", ")}`
                      : ""}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="grid gap-6">
          <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
            <h2 className="mb-3 font-display text-2xl tracking-wide">Add staff</h2>
            <StaffForm />
          </div>
          <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
            <h2 className="mb-3 font-display text-2xl tracking-wide">Invite a parent</h2>
            <ParentInviteForm athletes={athletes.map((athlete) => ({ id: athlete.id, name: athlete.name }))} />
          </div>
        </div>
      </div>
      <section className="max-w-xl rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="mb-1 font-display text-2xl tracking-wide">Season</h2>
        <p className="mb-3 text-sm text-muted-foreground">
          The same controls sit on <Link href="/standards" className="font-semibold text-lion">Standards</Link> for coaches.
        </p>
        <StandardsForm
          seasonLabel={team.seasonLabel}
          studyGateEnabled={team.studyGateEnabled}
          studyGoalMinutes={team.studyGoalMinutes}
          workMinutes={team.workMinutes}
          breakMinutes={team.breakMinutes}
        />
      </section>
    </div>
  );
}
