import { BandPill, BodyTracker } from "@/components/body-tracker";
import { PageHeader } from "@/components/page-header";
import { listAthletes } from "@/lib/data";
import { loadAthleteDay } from "@/lib/days";
import { requireStaff } from "@/lib/guards";
import { studyGateBlocks } from "@/lib/habits";
import { toPosePosition } from "@/lib/pose-position";

export const metadata = { title: "Body tracker" };

export default async function TrackerPage({
  searchParams,
}: {
  searchParams: Promise<{ athlete?: string }>;
}) {
  await requireStaff();
  const athletes = await listAthletes();
  if (athletes.length === 0) {
    return (
      <PageHeader
        eyebrow="Field station"
        title="No athletes"
        description="Add an athlete on the roster before you run the body tracker."
      />
    );
  }
  const requested = (await searchParams).athlete;
  const athlete = athletes.find((item) => item.id === requested) ?? athletes[0];
  if (!athlete) {
    return <PageHeader eyebrow="Field station" title="No athletes" description="Add an athlete first." />;
  }
  const pack = await loadAthleteDay(athlete.id);
  const blocked = studyGateBlocks({
    enabled: pack.team.studyGateEnabled,
    studyMinutes: pack.day.studyMinutes,
    goal: pack.team.studyGoalMinutes,
    override: pack.day.parentOverride,
  });

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Field station"
        title="Body tracker"
        description="Pick the athlete, filter by position, and save the summary to their history. This station logs a field session."
      />
      <form action="/tracker" className="flex flex-wrap items-end gap-2">
        <label className="grid gap-1 text-sm font-semibold" htmlFor="tracker-athlete">
          Athlete
          <select
            id="tracker-athlete"
            name="athlete"
            defaultValue={athlete.id}
            className="h-11 rounded-lg border border-input bg-card px-3 text-base font-normal"
          >
            {athletes.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
        <button type="submit" className="h-11 rounded-lg bg-lion px-4 font-semibold text-white">
          Open
        </button>
      </form>
      <BodyTracker
        key={athlete.id}
        athleteId={athlete.id}
        athleteName={athlete.name}
        initialPosition={toPosePosition(athlete.positions[0])}
        placeDefault="field"
        allowFieldToggle={false}
        studyBlocked={blocked}
      />
      <section className="grid gap-2">
        <h2 className="font-display text-2xl tracking-wide">Recent sessions</h2>
        {pack.poses.length === 0 ? (
          <p className="text-sm text-muted-foreground">None saved yet for {athlete.name}.</p>
        ) : (
          <ul className="grid gap-2 text-sm">
            {pack.poses.map((pose) => (
              <li key={pose.id} className="flex flex-wrap items-center justify-between gap-2">
                <span>
                  {pose.recordedOnLabel} · {pose.movementName} · {pose.place} · {pose.mode} · {pose.recordedBy}
                </span>
                <BandPill band={pose.band} score={pose.overall} />
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
