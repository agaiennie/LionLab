import { PageHeader } from "@/components/page-header";
import { ProfileForm } from "@/components/profile-form";
import { getAthleteByUserId } from "@/lib/data";
import { splitHeight } from "@/lib/format";
import { requireAthlete } from "@/lib/guards";

export const metadata = { title: "Profile" };

export default async function AthleteProfilePage() {
  const user = await requireAthlete();
  const athlete = await getAthleteByUserId(user.id);
  if (!athlete) {
    return (
      <PageHeader
        eyebrow="Profile"
        title="Profile missing"
        description="Ask your coach to finish your roster spot."
      />
    );
  }
  const height = splitHeight(athlete.heightInches);

  return (
    <div>
      <PageHeader
        eyebrow="Profile"
        title="Your info"
        description="Update height, weight, grade, and positions when they change. Your coach can see this too."
      />
      <ProfileForm
        athleteId={athlete.id}
        includeEmail={false}
        values={{
          name: athlete.name,
          email: athlete.email,
          grade: athlete.grade,
          positions: athlete.positions,
          feet: height.feet,
          inches: height.inches,
          weightLbs: athlete.weightLbs,
        }}
      />
    </div>
  );
}
