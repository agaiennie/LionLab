import { redirect } from "next/navigation";

export default function AthleteIndexPage() {
  redirect("/measure");
}
