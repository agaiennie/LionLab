import { requireAthlete } from "@/lib/guards";

export default async function AthleteLayout({ children }: { children: React.ReactNode }) {
  await requireAthlete();
  return children;
}
