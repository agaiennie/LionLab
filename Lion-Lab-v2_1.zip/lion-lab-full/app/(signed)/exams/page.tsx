import Link from "next/link";
import { redirect } from "next/navigation";
import { PageHeader } from "@/components/page-header";
import { PassBadge, Stat } from "@/components/exam-badges";
import { buttonVariants } from "@/components/ui/button";
import { isStaff } from "@/lib/auth";
import { athleteIdForUser } from "@/lib/access";
import { prisma } from "@/lib/db";
import { AUDIENCE_LABEL, examRequiredFor, summarizeAttempts } from "@/lib/exams";
import { requireUser } from "@/lib/guards";
import { parsePositions } from "@/lib/scoring";

export const metadata = { title: "Exams" };

export default async function ExamsPage() {
  const user = await requireUser();
  if (isStaff(user.role)) redirect("/coach/exams");
  if (user.role !== "ATHLETE") redirect("/today");

  const athleteId = await athleteIdForUser(user.id);
  if (!athleteId) {
    return <PageHeader eyebrow="Exams" title="Profile missing" description="Ask your coach to finish your profile." />;
  }
  const profile = await prisma.athleteProfile.findUnique({ where: { id: athleteId }, select: { positions: true } });
  const positions = parsePositions(profile?.positions ?? "");

  const exams = await prisma.exam.findMany({
    where: { published: true },
    orderBy: { title: "asc" },
    include: {
      _count: { select: { questions: true } },
      attempts: { where: { athleteId }, select: { percent: true, passed: true, createdAt: true } },
    },
  });

  const rows = exams
    .filter((exam) => exam._count.questions > 0)
    .map((exam) => ({
      exam,
      required: examRequiredFor(exam.audience, positions),
      summary: summarizeAttempts(exam.attempts),
    }))
    .sort((a, b) => Number(b.required) - Number(a.required));

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Football IQ"
        title="Exams"
        description="Leadership jobs take an exam on plays and reads. Retake as many times as you want. Every question shows the answer and the why when you finish."
      />
      {rows.length === 0 ? (
        <p className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">No exams are open yet. Your coach will post them here.</p>
      ) : (
        <ul className="grid gap-4">
          {rows.map(({ exam, required, summary }) => (
            <li key={exam.id} className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <div className="flex flex-wrap items-center gap-2">
                {required ? (
                  <span className="rounded-full bg-lion px-3 py-1 text-xs font-bold tracking-wide text-white">
                    Required for you
                  </span>
                ) : exam.audience === "CAPTAIN" ? (
                  <span className="rounded-full bg-ink px-3 py-1 text-xs font-bold tracking-wide text-white">
                    Required for captains · open to all
                  </span>
                ) : (
                  <span className="rounded-full bg-muted px-3 py-1 text-xs font-semibold">
                    For {AUDIENCE_LABEL[exam.audience]?.toLowerCase() ?? "everyone"} · open to all
                  </span>
                )}
                {summary ? <PassBadge passed={summary.everPassed} /> : null}
              </div>
              <div>
                <h2 className="font-display text-3xl tracking-wide">{exam.title}</h2>
                {exam.description ? <p className="mt-1 text-sm text-muted-foreground">{exam.description}</p> : null}
                <p className="mt-1 text-sm text-muted-foreground">
                  {exam._count.questions} questions · pass at {exam.passPercent}%
                </p>
              </div>
              {summary ? (
                <dl className="grid grid-cols-3 gap-2 text-center">
                  <Stat label="Latest" value={`${summary.latestPercent}%`} />
                  <Stat label="Best" value={`${summary.bestPercent}%`} />
                  <Stat label="Tries" value={String(summary.attempts)} />
                </dl>
              ) : null}
              <Link href={`/exams/${exam.slug}`} className={buttonVariants({ size: "touch" })}>
                {summary ? "Review or retake" : "Start exam"}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
