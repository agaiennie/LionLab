import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { PassBadge, Stat } from "@/components/exam-badges";
import { ExamTaker } from "@/components/exam-taker";
import { PageHeader } from "@/components/page-header";
import { buttonVariants } from "@/components/ui/button";
import { isStaff } from "@/lib/auth";
import { athleteIdForUser } from "@/lib/access";
import { prisma } from "@/lib/db";
import { parseAnswers, parseChoices, summarizeAttempts } from "@/lib/exams";
import { requireUser } from "@/lib/guards";

const LETTERS = ["A", "B", "C", "D", "E"];

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const exam = await prisma.exam.findUnique({ where: { slug: (await params).slug }, select: { title: true } });
  return { title: exam?.title ?? "Exam" };
}

export default async function ExamPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ attempt?: string; take?: string }>;
}) {
  const user = await requireUser();
  const { slug } = await params;
  if (isStaff(user.role)) {
    const exam = await prisma.exam.findUnique({ where: { slug }, select: { id: true } });
    redirect(exam ? `/coach/exams/${exam.id}` : "/coach/exams");
  }
  if (user.role !== "ATHLETE") redirect("/today");

  const athleteId = await athleteIdForUser(user.id);
  if (!athleteId) {
    return <PageHeader eyebrow="Exams" title="Profile missing" description="Ask your coach to finish your profile." />;
  }

  const exam = await prisma.exam.findFirst({
    where: { slug, published: true },
    include: { questions: { orderBy: [{ order: "asc" }, { id: "asc" }] } },
  });
  if (!exam || exam.questions.length === 0) notFound();

  const attempts = await prisma.examAttempt.findMany({
    where: { examId: exam.id, athleteId },
    orderBy: { createdAt: "desc" },
  });
  const summary = summarizeAttempts(attempts);
  const query = await searchParams;
  const reviewing = query.attempt ? attempts.find((a) => a.id === query.attempt) : undefined;
  const taking = query.take === "1" || attempts.length === 0;

  const back = (
    <Link href="/exams" className="text-sm font-semibold text-lion">
      All exams
    </Link>
  );

  if (reviewing) {
    const chosen = parseAnswers(reviewing.answers);
    const changed = reviewing.total !== exam.questions.length;
    return (
      <div className="grid gap-6">
        <PageHeader eyebrow="Results" title={exam.title} action={back} />
        <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <div className="flex flex-wrap items-center gap-3">
            <p className="font-display text-6xl">{reviewing.percent}%</p>
            <PassBadge
              passed={reviewing.passed}
              label={reviewing.passed ? `Passed · ${exam.passPercent}% to pass` : `Not yet · ${exam.passPercent}% to pass`}
            />
          </div>
          <p>
            {reviewing.correct} of {reviewing.total} right.{" "}
            {reviewing.passed
              ? "Good work. Keep it sharp: the coach adds new plays during the season."
              : "Read every explanation below, then take it again. Most players pass on the second or third try."}
          </p>
          <Link href={`/exams/${exam.slug}?take=1`} className={buttonVariants({ size: "touch" })}>
            Retake exam
          </Link>
        </section>

        {changed ? (
          <p className="rounded-lg bg-accent px-3 py-2 text-sm text-accent-foreground">
            The coach changed this exam after this attempt, so the answer review below may not line up. Your score stands.
          </p>
        ) : null}

        <ol className="grid gap-4">
          {exam.questions.map((q, i) => {
            const choices = parseChoices(q.choices);
            const pick = chosen[i];
            const right = pick === q.answerIndex;
            return (
              <li key={q.id} className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-semibold text-muted-foreground">
                    {i + 1}. {q.topic}
                  </p>
                  <span className={`text-sm font-bold ${right ? "text-emerald-700" : "text-lion"}`}>
                    {right ? "Right" : "Missed"}
                  </span>
                </div>
                <p className="font-semibold">{q.prompt}</p>
                <ul className="grid gap-1.5">
                  {choices.map((choice, c) => {
                    const isKey = c === q.answerIndex;
                    const isPick = c === pick;
                    return (
                      <li
                        key={c}
                        className={`rounded-lg px-3 py-2 text-sm ${
                          isKey
                            ? "bg-emerald-600/15 font-semibold ring-1 ring-emerald-600"
                            : isPick
                              ? "bg-lion/10 line-through ring-1 ring-lion"
                              : "bg-muted/50"
                        }`}
                      >
                        {LETTERS[c]}. {choice}
                        {isKey ? " ✓ correct answer" : isPick ? " (your answer)" : ""}
                      </li>
                    );
                  })}
                </ul>
                {q.explanation ? (
                  <p className="text-sm">
                    <span className="font-semibold">Why: </span>
                    {q.explanation}
                  </p>
                ) : null}
              </li>
            );
          })}
        </ol>
        <History slug={exam.slug} attempts={attempts} current={reviewing.id} />
      </div>
    );
  }

  if (taking) {
    return (
      <div className="grid gap-6">
        <PageHeader
          eyebrow={`${exam.questions.length} questions · pass at ${exam.passPercent}%`}
          title={exam.title}
          description={exam.description || undefined}
          action={back}
        />
        <ExamTaker
          examSlug={exam.slug}
          questions={exam.questions.map((q) => ({
            id: q.id,
            topic: q.topic,
            prompt: q.prompt,
            choices: parseChoices(q.choices),
          }))}
        />
      </div>
    );
  }

  // Overview: has attempts, not taking, not reviewing one.
  return (
    <div className="grid gap-6">
      <PageHeader eyebrow="Exam" title={exam.title} description={exam.description || undefined} action={back} />
      {summary ? (
        <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <PassBadge passed={summary.everPassed} />
          <dl className="grid grid-cols-3 gap-2">
            <Stat label="Latest" value={`${summary.latestPercent}%`} />
            <Stat label="Best" value={`${summary.bestPercent}%`} />
            <Stat label="Tries" value={String(summary.attempts)} />
          </dl>
          <p className="text-sm text-muted-foreground">
            Pass at {exam.passPercent}%. Coaches look at your latest score, so keep it up.
          </p>
          <Link href={`/exams/${exam.slug}?take=1`} className={buttonVariants({ size: "touch" })}>
            Retake exam
          </Link>
        </section>
      ) : null}
      <History slug={exam.slug} attempts={attempts} />
    </div>
  );
}

function History({
  slug,
  attempts,
  current,
}: {
  slug: string;
  attempts: { id: string; percent: number; passed: boolean; correct: number; total: number; createdAt: Date }[];
  current?: string;
}) {
  if (attempts.length === 0) return null;
  return (
    <section className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <h2 className="font-display text-3xl tracking-wide">Your attempts</h2>
      <ul className="grid gap-2">
        {attempts.map((a) => (
          <li key={a.id}>
            <Link
              href={`/exams/${slug}?attempt=${a.id}`}
              className={`flex min-h-11 items-center justify-between gap-3 rounded-lg px-3 py-2 ${
                a.id === current ? "bg-muted font-semibold" : "hover:bg-muted"
              }`}
            >
              <span>
                {a.createdAt.toLocaleDateString("en-US", { month: "short", day: "numeric" })} · {a.correct}/{a.total}
              </span>
              <span className="flex items-center gap-2">
                <span className="font-display text-xl">{a.percent}%</span>
                <PassBadge passed={a.passed} label={a.passed ? "Pass" : "Not yet"} />
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
