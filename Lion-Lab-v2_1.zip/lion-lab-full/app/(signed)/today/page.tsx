import Link from "next/link";
import { FuelBoard, StudyMinutesForm } from "@/components/habit-controls";
import { KidSwitch } from "@/components/kid-switch";
import { PageHeader } from "@/components/page-header";
import { athleteIdForUser, parentKids, pickId } from "@/lib/access";
import { getAthlete, latestByType, listAthletes } from "@/lib/data";
import { habitBoard, labelDay, loadAthleteDay } from "@/lib/days";
import { requireUser } from "@/lib/guards";
import { studyGateBlocks } from "@/lib/habits";

export const metadata = { title: "Today" };

function studyWord(status: "done" | "note" | "open") {
  if (status === "done") return "Study done";
  if (status === "note") return "Parent note on file";
  return "Study not done";
}

export default async function TodayPage({
  searchParams,
}: {
  searchParams: Promise<{ athlete?: string }>;
}) {
  const user = await requireUser();
  if (user.role === "PARENT") {
    const kids = await parentKids(user.id);
    const requested = (await searchParams).athlete;
    const current = pickId(kids.map((kid) => kid.id), requested);
    return (
      <ParentToday
        kids={kids.map((kid) => ({ id: kid.id, name: kid.name }))}
        current={current}
      />
    );
  }
  if (user.role === "ATHLETE") {
    const athleteId = await athleteIdForUser(user.id);
    if (!athleteId) {
      return (
        <PageHeader
          eyebrow="Athlete"
          title="Profile missing"
          description="Your coach has not finished your Lion Lab profile yet."
        />
      );
    }
    return <AthleteToday athleteId={athleteId} />;
  }
  return <StaffToday />;
}

async function AthleteToday({ athleteId }: { athleteId: string }) {
  const athlete = await getAthlete(athleteId);
  if (!athlete) {
    return <PageHeader eyebrow="Athlete" title="Profile missing" description="Ask your coach to check the roster." />;
  }
  const pack = await loadAthleteDay(athleteId);
  const forty = latestByType(athlete, "FORTY");
  const med = latestByType(athlete, "MEDBALL");
  const stance = latestByType(athlete, "STANCE");
  const blocked = studyGateBlocks({
    enabled: pack.team.studyGateEnabled,
    studyMinutes: pack.day.studyMinutes,
    goal: pack.team.studyGoalMinutes,
    override: pack.day.parentOverride,
  });

  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow={pack.team.seasonLabel}
        title="Today"
        description="Good players are smart students. Study, then train. The streak counts a day only when both are done."
      />
      <div className="grid gap-3 sm:grid-cols-3">
        <Due
          label="Study"
          value={studyWord(pack.snap.todayStatus)}
          detail={`${pack.day.studyMinutes} / ${pack.team.studyGoalMinutes} min`}
          href="/study"
        />
        <Due
          label="Mobility"
          value={pack.day.mobilityDone ? "Logged" : "Due"}
          detail={pack.day.homeTrainDone ? "Home training logged" : blocked ? "Study first" : "Open"}
          href="/train"
        />
        <Due
          label="Retest"
          value={forty ? "40 on file" : "No 40 yet"}
          detail={forty?.scored.retest ?? "Log a 40 so the next target is a number."}
          href="/measure"
        />
      </div>
      <p className="text-sm">
        Streak: <span className="font-semibold">{pack.snap.streak} day{pack.snap.streak === 1 ? "" : "s"}</span>
        {" · "}
        last study {pack.snap.lastStudy ? labelDay(pack.snap.lastStudy) : "none"}
      </p>
      <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <h2 className="font-display text-3xl tracking-wide">Study block</h2>
        <p className="mt-1 mb-3 text-sm text-muted-foreground">
          Default is a block before or after home training. The timer lives on Study.
        </p>
        <StudyMinutesForm athleteId={athlete.id} goal={pack.team.studyGoalMinutes} minutes={pack.day.studyMinutes} />
      </section>
      <section className="grid gap-3">
        <h2 className="font-display text-3xl tracking-wide">Fuel</h2>
        <FuelBoard athleteId={athlete.id} values={pack.day} editable />
      </section>
      <section className="grid gap-2">
        <h2 className="font-display text-3xl tracking-wide">Recent scores</h2>
        <ScoreLine label="40" value={forty ? `${forty.scored.rawLabel} · form ${forty.scored.percent}% · ESTIMATE ${forty.scored.estimate.display}` : "Not logged"} />
        <ScoreLine label="Med ball" value={med ? `${med.scored.rawLabel} · form ${med.scored.percent}% · ESTIMATE ${med.scored.estimate.display}` : "Not logged"} />
        <ScoreLine label="Stance" value={stance ? `${stance.scored.percent}% · ${stance.scored.estimate.display}` : "Not logged"} />
        <Link href="/athlete/profile" className="text-sm font-semibold text-lion">
          Edit profile
        </Link>
      </section>
    </div>
  );
}

async function ParentToday({
  kids,
  current,
}: {
  kids: { id: string; name: string }[];
  current: string | null;
}) {
  if (!current) {
    return (
      <PageHeader
        eyebrow="Parent"
        title="No athlete linked"
        description="A coach links your account to your athlete. If you signed up yourself, a coach will link you after approving the request."
      />
    );
  }
  const pack = await loadAthleteDay(current);
  const kid = kids.find((item) => item.id === current);
  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow="Parent"
        title={kid?.name ?? "Today"}
        description="Good players are smart students. This is today's study, mobility, and fuel. You see your linked athlete only."
      />
      <KidSwitch athletes={kids} current={current} path="/today" />
      <p className="font-display text-4xl tracking-wide">{studyWord(pack.snap.todayStatus)}</p>
      <p className="text-sm text-muted-foreground">
        {pack.day.studyMinutes} / {pack.team.studyGoalMinutes} min · streak {pack.snap.streak} · mobility{" "}
        {pack.day.mobilityDone ? "logged" : "not logged"} · fuel {pack.snap.fuelDone} of 4
      </p>
      <div className="flex flex-wrap gap-3 text-sm font-semibold">
        <Link href={`/home?athlete=${current}`} className="text-lion">Home plan</Link>
        <Link href={`/progress?athlete=${current}`} className="text-lion">Progress</Link>
        <Link href={`/notes?athlete=${current}`} className="text-lion">Notes</Link>
      </div>
      <FuelBoard athleteId={current} values={pack.day} editable={false} />
    </div>
  );
}

async function StaffToday() {
  const athletes = await listAthletes();
  const board = await habitBoard(athletes.map((athlete) => athlete.id));
  const studied = athletes.filter((athlete) => board.map.get(athlete.id)?.todayStatus === "done").length;
  return (
    <div className="grid gap-6">
      <PageHeader
        eyebrow={board.team.seasonLabel}
        title="Start here"
        description="Three taps. Then go work."
      />
      <div className="grid gap-3">
        <Link
          href="/field"
          className="rounded-xl border-2 border-lion bg-card px-4 py-5 hover:bg-lion/5"
        >
          <p className="font-display text-3xl tracking-wide text-lion">Field</p>
          <p className="mt-1 text-sm text-muted-foreground">FAST cards for the sideline</p>
        </Link>
        <Link
          href="/skills"
          className="rounded-xl border-2 border-border bg-card px-4 py-5 hover:border-lion"
        >
          <p className="font-display text-3xl tracking-wide text-lion">Skills</p>
          <p className="mt-1 text-sm text-muted-foreground">What to teach, step by step</p>
        </Link>
        <Link
          href="/coach"
          className="rounded-xl border-2 border-border bg-card px-4 py-5 hover:border-lion"
        >
          <p className="font-display text-3xl tracking-wide text-lion">Roster</p>
          <p className="mt-1 text-sm text-muted-foreground">Kids, study, and tests</p>
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { href: "/coach/measure", label: "Test day", hint: "Sprints, jumps, flex, balance" },
          { href: "/camera", label: "Camera", hint: "Balance & squat check" },
          { href: "/coach/fit", label: "Positions", hint: "Fit + depth board" },
          { href: "/coach/approvals", label: "Approvals", hint: "New sign-ups" },
        ].map((item) => (
          <Link key={item.href} href={item.href} className="rounded-xl bg-card px-3 py-4 ring-1 ring-foreground/10 hover:ring-lion">
            <p className="font-display text-xl tracking-wide text-lion">{item.label}</p>
            <p className="text-xs text-muted-foreground">{item.hint}</p>
          </Link>
        ))}
      </div>
      <p className="text-sm text-muted-foreground">
        Study today: {studied} of {athletes.length} · gate {board.team.studyGateEnabled ? "on" : "off"}
      </p>
    </div>
  );
}

function Due({ label, value, detail, href }: { label: string; value: string; detail: string; href: string }) {
  return (
    <Link href={href} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className="font-display text-2xl tracking-wide">{value}</p>
      <p className="mt-1 text-sm text-muted-foreground">{detail}</p>
    </Link>
  );
}

function ScoreLine({ label, value }: { label: string; value: string }) {
  return (
    <p className="text-sm">
      <span className="font-semibold">{label}.</span> {value}
    </p>
  );
}
