import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";

export const dynamic = "force-dynamic";

// Fonts are self-hosted (SIL Open Font License, via Fontsource) so builds and
// the field app never depend on reaching Google Fonts.
const sourceSans = localFont({
  src: [{ path: "./fonts/source-sans-3-latin-wght-normal.woff2", weight: "200 900", style: "normal" }],
  variable: "--font-source",
  display: "swap",
});

const barlow = localFont({
  src: [
    { path: "./fonts/barlow-condensed-latin-500-normal.woff2", weight: "500", style: "normal" },
    { path: "./fonts/barlow-condensed-latin-600-normal.woff2", weight: "600", style: "normal" },
    { path: "./fonts/barlow-condensed-latin-700-normal.woff2", weight: "700", style: "normal" },
  ],
  variable: "--font-barlow",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Lion Lab",
    template: "%s · Lion Lab",
  },
  description:
    "Red Lion Football field and home toolkit. Measure, train, and study. Good players are smart students.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${sourceSans.variable} ${barlow.variable} h-full antialiased`}
      style={{ colorScheme: "light" }}
    >
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
