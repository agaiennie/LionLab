import { NextResponse } from "next/server";
import { auth, isStaff } from "@/lib/auth";
import { latestByType, listAthletes } from "@/lib/data";
import { habitBoard, labelDay } from "@/lib/days";
import { csvCell } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await auth();
  if (!session?.user || !isStaff(session.user.role)) {
    return new NextResponse("Coaches only.", { status: 401 });
  }

  const athletes = await listAthletes();
  const headers = [
    "Name",
    "Email",
    "Grade",
    "Positions",
    "Height",
    "WeightLb",
    "FortyRaw",
    "FortyFormPercent",
    "FortyAdjustedEstimate",
    "MedBallRawFt",
    "MedBallFormPercent",
    "MedBallAdjustedEstimate",
    "StanceFormPercent",
    "StanceEstimate",
    "LastTest",
    "StudyStreak",
    "LastStudyDate",
    "StudyToday",
    "AcademicStatus",
  ];

  const habits = await habitBoard(athletes.map((athlete) => athlete.id));
  const lines = [headers.join(",")];
  for (const athlete of athletes) {
    const snap = habits.map.get(athlete.id);
    const forty = latestByType(athlete, "FORTY");
    const medball = latestByType(athlete, "MEDBALL");
    const stance = latestByType(athlete, "STANCE");
    const last = athlete.sessions[0];
    lines.push(
      [
        csvCell(athlete.name),
        csvCell(athlete.email),
        athlete.grade,
        csvCell(athlete.positions.join(" ")),
        csvCell(athlete.heightLabel),
        athlete.weightLbs,
        forty?.rawValue?.toFixed(2) ?? "",
        forty?.scored.percent ?? "",
        forty?.scored.estimate.display ?? "",
        medball?.rawValue?.toFixed(1) ?? "",
        medball?.scored.percent ?? "",
        medball?.scored.estimate.display ?? "",
        stance?.scored.percent ?? "",
        stance?.scored.estimate.display ?? "",
        last?.recordedOnLabel ?? "",
        snap?.streak ?? 0,
        snap?.lastStudy ? labelDay(snap.lastStudy) : "",
        snap?.todayStatus === "done" ? "done" : snap?.todayStatus === "note" ? "parent note" : "not yet",
        athlete.academicStatus,
      ].join(","),
    );
  }

  return new NextResponse(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="lion-lab-roster.csv"',
    },
  });
}
