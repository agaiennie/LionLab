"use server";

import { revalidatePath } from "next/cache";
import { auth, isStaff } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { skillById, weekKey } from "@/lib/content/skills";

export async function toggleSkillTaught(formData: FormData): Promise<void> {
  const session = await auth();
  if (!session?.user || !isStaff(session.user.role)) return;
  const athleteId = String(formData.get("athleteId") ?? "");
  const skillId = String(formData.get("skillId") ?? "");
  if (!skillById(skillId)) return;
  const athlete = await prisma.athleteProfile.findUnique({ where: { id: athleteId }, select: { id: true } });
  if (!athlete) return;
  const week = weekKey();
  const existing = await prisma.skillMark.findUnique({
    where: { athleteId_skillId_weekKey: { athleteId, skillId, weekKey: week } },
  });
  if (existing) {
    await prisma.skillMark.delete({ where: { id: existing.id } });
  } else {
    await prisma.skillMark.create({
      data: { athleteId, skillId, weekKey: week, markedById: session.user.id },
    });
  }
  revalidatePath("/skills");
  revalidatePath(`/skills/${skillId}`);
  revalidatePath(`/coach/athletes/${athleteId}`);
}
