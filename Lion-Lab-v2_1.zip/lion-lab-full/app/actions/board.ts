"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireStaff } from "@/lib/guards";
import type { ActionState } from "@/lib/validators";

function refreshBoard() {
  revalidatePath("/");
  revalidatePath("/coach/board");
}

export async function createPost(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const staff = await requireStaff();
  const title = String(formData.get("title") ?? "").trim();
  const body = String(formData.get("body") ?? "").trim();
  const fieldErrors: Record<string, string> = {};
  if (title.length < 2 || title.length > 100) fieldErrors.title = "Give it a short title (2 to 100 characters).";
  if (body.length < 2 || body.length > 2000) fieldErrors.body = "Write the post (up to 2000 characters).";
  if (Object.keys(fieldErrors).length > 0) return { fieldErrors };

  await prisma.publicPost.create({
    data: { title, body, pinned: formData.get("pinned") === "on", authorId: staff.id },
  });
  refreshBoard();
  return { message: "Posted. Anyone can see it on the program page." };
}

export async function deletePost(formData: FormData): Promise<void> {
  await requireStaff();
  const id = String(formData.get("postId") ?? "");
  await prisma.publicPost.deleteMany({ where: { id } });
  refreshBoard();
}

export async function togglePin(formData: FormData): Promise<void> {
  await requireStaff();
  const id = String(formData.get("postId") ?? "");
  const post = await prisma.publicPost.findUnique({ where: { id }, select: { pinned: true } });
  if (!post) return;
  await prisma.publicPost.update({ where: { id }, data: { pinned: !post.pinned } });
  refreshBoard();
}
