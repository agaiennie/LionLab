"use server";

import { revalidatePath } from "next/cache";
import { auth, isStaff } from "@/lib/auth";
import { canEditHome, canViewAthlete } from "@/lib/access";
import { prisma } from "@/lib/db";
import { getTeam, resolveDay, upsertDay } from "@/lib/days";
import { STUDY_GATE_DETAIL, STUDY_GATE_LINE, studyGateBlocks } from "@/lib/habits";
import { hashPassword } from "@/lib/password";
import { emailSchema, passwordSchema, type ActionState } from "@/lib/validators";

function refresh(athleteId?: string) {
  revalidatePath("/today");
  revalidatePath("/train");
  revalidatePath("/study");
  revalidatePath("/home");
  revalidatePath("/progress");
  revalidatePath("/notes");
  revalidatePath("/measure");
  revalidatePath("/path");
  revalidatePath("/coach");
  revalidatePath("/tracker");
  revalidatePath("/standards");
  revalidatePath("/admin");
  if (athleteId) revalidatePath(`/coach/athletes/${athleteId}`);
}

async function editor() {
  const session = await auth();
  if (!session?.user?.id) return null;
  return session.user;
}

async function gateMessage(athleteId: string, day: string): Promise<string | null> {
  const team = await getTeam();
  const log = await upsertDay(athleteId, day);
  if (
    studyGateBlocks({
      enabled: team.studyGateEnabled,
      studyMinutes: log.studyMinutes,
      goal: team.studyGoalMinutes,
      override: log.parentOverride,
    })
  ) {
    return `${STUDY_GATE_LINE} ${STUDY_GATE_DETAIL}`;
  }
  return null;
}

export async function addStudyMinutes(
  athleteId: string,
  dayRaw: string,
  minutes: number,
  mode: "add" | "set",
): Promise<ActionState> {
  const user = await editor();
  if (!user) return { error: "Sign in again." };
  if (!(await canEditHome(user, athleteId))) return { error: "You can log study for your own athlete only." };
  const day = resolveDay(dayRaw);
  if (!day) return { error: "That date is outside today." };
  const amount = Math.round(minutes);
  if (!Number.isFinite(amount) || amount < 1 || amount > 180) {
    return { error: "Enter 1 to 180 minutes." };
  }
  const log = await upsertDay(athleteId, day);
  const next = mode === "add" ? Math.min(480, log.studyMinutes + amount) : Math.max(log.studyMinutes, amount);
  await prisma.dayLog.update({ where: { id: log.id }, data: { studyMinutes: next } });
  refresh(athleteId);
  return { message: `Study logged: ${next} minutes today.` };
}

export async function logStudyMinutes(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const mode = formData.get("mode") === "add" ? "add" : "set";
  return addStudyMinutes(
    String(formData.get("athleteId") ?? ""),
    String(formData.get("day") ?? ""),
    Number(formData.get("minutes")),
    mode,
  );
}

const FUEL = ["water", "protein", "sleep", "lightJunk"] as const;
type FuelField = (typeof FUEL)[number];

export async function toggleFuelForm(formData: FormData): Promise<void> {
  await toggleFuel({}, formData);
}

export async function toggleFuel(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user) return { error: "Sign in again." };
  const athleteId = String(formData.get("athleteId") ?? "");
  if (!(await canEditHome(user, athleteId))) return { error: "You can update habits for your own athlete only." };
  const day = resolveDay(formData.get("day"));
  if (!day) return { error: "That date is outside today." };
  const field = String(formData.get("field") ?? "");
  if (!FUEL.includes(field as FuelField)) return { error: "Unknown habit." };
  const value = formData.get("value") === "1";
  const log = await upsertDay(athleteId, day);
  await prisma.dayLog.update({
    where: { id: log.id },
    data: { [field]: value },
  });
  refresh(athleteId);
  return { message: "Habit saved." };
}

export async function completeMobility(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user) return { error: "Sign in again." };
  const athleteId = String(formData.get("athleteId") ?? "");
  if (!(await canEditHome(user, athleteId))) return { error: "You can log mobility for your own athlete only." };
  const day = resolveDay(formData.get("day"));
  if (!day) return { error: "That date is outside today." };
  const blocked = await gateMessage(athleteId, day);
  if (blocked) return { error: blocked };
  const log = await upsertDay(athleteId, day);
  await prisma.dayLog.update({
    where: { id: log.id },
    data: {
      mobilityDone: true,
      mobilityTemplate: String(formData.get("template") ?? "").slice(0, 40),
    },
  });
  refresh(athleteId);
  return { message: "Mobility session logged." };
}

export async function completeHomeTrain(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user) return { error: "Sign in again." };
  const athleteId = String(formData.get("athleteId") ?? "");
  if (!(await canEditHome(user, athleteId))) return { error: "You can log home training for your own athlete only." };
  const day = resolveDay(formData.get("day"));
  if (!day) return { error: "That date is outside today." };
  const blocked = await gateMessage(athleteId, day);
  if (blocked) return { error: blocked };
  const log = await upsertDay(athleteId, day);
  await prisma.dayLog.update({ where: { id: log.id }, data: { homeTrainDone: true } });
  refresh(athleteId);
  return { message: "Home training logged." };
}

export async function saveParentOverride(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user || user.role !== "PARENT") return { error: "A parent leaves this note." };
  const athleteId = String(formData.get("athleteId") ?? "");
  if (!(await canEditHome(user, athleteId))) return { error: "This athlete is not linked to you." };
  const day = resolveDay(formData.get("day"));
  if (!day) return { error: "That date is outside today." };
  const clear = formData.get("clear") === "1";
  const note = clear ? "" : String(formData.get("note") ?? "").trim();
  if (!clear && note.length < 8) return { error: "Write a short note. A sentence is enough." };
  if (note.length > 240) return { error: "Keep the note under 240 characters." };
  const log = await upsertDay(athleteId, day);
  await prisma.dayLog.update({ where: { id: log.id }, data: { parentOverride: note } });
  refresh(athleteId);
  return { message: clear ? "Parent note cleared." : "Parent note saved. Home training can be logged." };
}

export async function addSubject(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user) return { error: "Sign in again." };
  const athleteId = String(formData.get("athleteId") ?? "");
  if (!(await canEditHome(user, athleteId))) return { error: "You can edit subjects for your own athlete only." };
  const name = String(formData.get("name") ?? "").trim();
  if (name.length < 2 || name.length > 60) return { error: "Enter a subject name." };
  const count = await prisma.subject.count({ where: { athleteId } });
  if (count >= 12) return { error: "Twelve subjects is the list limit." };
  await prisma.subject.create({ data: { athleteId, name } });
  refresh(athleteId);
  return { message: "Subject added." };
}

export async function removeSubject(formData: FormData): Promise<void> {
  const user = await editor();
  if (!user) return;
  const id = String(formData.get("subjectId") ?? "");
  const subject = await prisma.subject.findUnique({ where: { id } });
  if (!subject) return;
  if (!(await canEditHome(user, subject.athleteId))) return;
  await prisma.subject.delete({ where: { id } });
  refresh(subject.athleteId);
}

const poseSchemaFields = ["green", "yellow", "red", "weak"] as const;

export async function savePoseSession(input: {
  athleteId: string;
  movementId: string;
  movementName: string;
  position: string;
  place: "field" | "home";
  mode: "camera" | "checklist";
  overall: number | null;
  band: string;
  cues: string[];
  notes: string;
  day: string;
}): Promise<ActionState> {
  const user = await editor();
  if (!user) return { error: "Sign in again." };
  const athlete = await prisma.athleteProfile.findUnique({ where: { id: input.athleteId } });
  if (!athlete) return { error: "That athlete is not on the roster." };

  const staff = isStaff(user.role);
  const own = user.role === "ATHLETE" && athlete.userId === user.id;
  if (!staff && !own) return { error: "You can save a session for your own athlete only." };
  if (!(await canViewAthlete(user, athlete.id))) return { error: "You cannot save that session." };

  const day = resolveDay(input.day);
  if (!day) return { error: "That date is outside today." };
  if (input.place === "home") {
    const blocked = await gateMessage(athlete.id, day);
    if (blocked) return { error: blocked };
  }

  const movementId = input.movementId.trim().slice(0, 64);
  const movementName = input.movementName.trim().slice(0, 80);
  const position = input.position.trim().slice(0, 24);
  if (!movementId || !movementName || !position) return { error: "Pick a movement first." };
  if (input.place !== "field" && input.place !== "home") return { error: "Pick field or home." };
  if (input.mode !== "camera" && input.mode !== "checklist") return { error: "Unknown session type." };
  const band = poseSchemaFields.includes(input.band as (typeof poseSchemaFields)[number])
    ? input.band
    : "weak";
  const overall =
    input.overall == null || Number.isNaN(input.overall)
      ? null
      : Math.max(0, Math.min(100, Math.round(input.overall)));
  const cues = input.cues
    .map((cue) => cue.trim())
    .filter((cue) => cue.length > 0)
    .slice(0, 8);
  const notes = input.notes.trim().slice(0, 240);

  await prisma.poseSession.create({
    data: {
      athleteId: athlete.id,
      movementId,
      movementName,
      position,
      place: input.place,
      mode: input.mode,
      overall,
      band,
      cues: JSON.stringify(cues),
      notes,
      recordedOn: new Date(),
      recordedById: user.id,
    },
  });
  refresh(athlete.id);
  return { message: "Session saved to this athlete's history." };
}

export async function inviteParent(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user || !isStaff(user.role)) return { error: "Only a coach or admin can invite a parent." };
  const email = emailSchema.safeParse(formData.get("email"));
  const name = String(formData.get("name") ?? "").trim();
  const athleteIds = formData.getAll("athleteId").map(String).filter(Boolean);
  if (!email.success) return { fieldErrors: { email: "Enter an email address." } };
  if (name.length < 2) return { fieldErrors: { name: "Enter the parent's name." } };
  if (athleteIds.length === 0) return { error: "Link at least one athlete." };

  const athletes = await prisma.athleteProfile.findMany({
    where: { id: { in: athleteIds } },
    select: { id: true },
  });
  if (athletes.length !== athleteIds.length) return { error: "One of those athletes is not on the roster." };

  const existing = await prisma.user.findUnique({ where: { email: email.data } });
  if (existing && existing.role !== "PARENT") {
    return { fieldErrors: { email: "That email already belongs to a player or coach. Use the parent's own email." } };
  }

  let parentId = existing?.id;
  let temporaryPassword = "";
  if (!existing) {
    const password = passwordSchema.safeParse(formData.get("password"));
    if (!password.success) {
      return { fieldErrors: { password: password.error.issues[0]?.message ?? "Check the password." } };
    }
    temporaryPassword = password.data;
    const created = await prisma.user.create({
      data: {
        email: email.data,
        name,
        role: "PARENT",
        passwordHash: await hashPassword(password.data),
      },
    });
    parentId = created.id;
  } else if (existing.name !== name) {
    await prisma.user.update({ where: { id: existing.id }, data: { name } });
  }

  if (!parentId) return { error: "Could not create the parent account." };

  for (const athleteId of athleteIds) {
    await prisma.parentLink.upsert({
      where: { parentId_athleteId: { parentId, athleteId } },
      update: {},
      create: { parentId, athleteId },
    });
  }

  refresh(athleteIds[0]);
  if (temporaryPassword) {
    return {
      message: "Parent invited. Share this password in person.",
      invite: {
        athleteId: athleteIds[0] ?? "",
        name,
        email: email.data,
        temporaryPassword,
      },
    };
  }
  return { message: "Existing parent account linked to the selected athlete." };
}

export async function addCoachNote(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user || !isStaff(user.role)) return { error: "Only a coach can leave a note." };
  const athleteId = String(formData.get("athleteId") ?? "");
  const athlete = await prisma.athleteProfile.findUnique({ where: { id: athleteId } });
  if (!athlete) return { error: "That athlete is not on the roster." };
  const body = String(formData.get("body") ?? "").trim();
  if (body.length < 8) return { error: "Write a note a parent can use. A sentence is enough." };
  if (body.length > 500) return { error: "Keep the note under 500 characters." };
  await prisma.coachNote.create({
    data: { athleteId, authorId: user.id, body },
  });
  refresh(athleteId);
  return { message: "Note saved. The parent will see it under Notes." };
}

export async function updateTeamSettings(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await editor();
  if (!user || !isStaff(user.role)) return { error: "Only a coach or admin can change the standard." };
  const seasonLabel = String(formData.get("seasonLabel") ?? "").trim();
  const studyGoalMinutes = Number(formData.get("studyGoalMinutes"));
  const workMinutes = Number(formData.get("workMinutes"));
  const breakMinutes = Number(formData.get("breakMinutes"));
  const weeklyRaw = formData.get("weeklyStudyMinutes");
  const weeklyStudyMinutes = weeklyRaw == null || weeklyRaw === "" ? null : Number(weeklyRaw);
  if (seasonLabel.length < 2 || seasonLabel.length > 40) {
    return { fieldErrors: { seasonLabel: "Name the season, like Fall 2026." } };
  }
  if (!Number.isInteger(studyGoalMinutes) || studyGoalMinutes < 10 || studyGoalMinutes > 90) {
    return { fieldErrors: { studyGoalMinutes: "Study goal should be 10 to 90 minutes." } };
  }
  if (!Number.isInteger(workMinutes) || workMinutes < 5 || workMinutes > 60) {
    return { fieldErrors: { workMinutes: "Work timer should be 5 to 60 minutes." } };
  }
  if (!Number.isInteger(breakMinutes) || breakMinutes < 1 || breakMinutes > 20) {
    return { fieldErrors: { breakMinutes: "Break should be 1 to 20 minutes." } };
  }
  if (
    weeklyStudyMinutes != null &&
    (!Number.isInteger(weeklyStudyMinutes) || weeklyStudyMinutes < 30 || weeklyStudyMinutes > 900)
  ) {
    return { fieldErrors: { weeklyStudyMinutes: "Weekly study should be 30 to 900 minutes." } };
  }
  // Public-site fields. Only touched when the form sends them (the admin page form may not).
  const publicFields: { teamName?: string; levelLabel?: string; publicBlurb?: string; joinCode?: string } = {};
  if (formData.has("teamName")) {
    const teamName = String(formData.get("teamName") ?? "").trim();
    if (teamName.length < 2 || teamName.length > 60) return { fieldErrors: { teamName: "Team name should be 2 to 60 characters." } };
    publicFields.teamName = teamName;
  }
  if (formData.has("levelLabel")) {
    const levelLabel = String(formData.get("levelLabel") ?? "").trim();
    if (levelLabel.length < 2 || levelLabel.length > 40) return { fieldErrors: { levelLabel: "Level should be 2 to 40 characters, like Junior High." } };
    publicFields.levelLabel = levelLabel;
  }
  if (formData.has("publicBlurb")) {
    const publicBlurb = String(formData.get("publicBlurb") ?? "").trim();
    if (publicBlurb.length > 1000) return { fieldErrors: { publicBlurb: "Keep the blurb under 1000 characters." } };
    publicFields.publicBlurb = publicBlurb;
  }
  // Only an admin rotates the join code. A coach's form doesn't send it, and it is ignored if forced.
  if (user.role === "ADMIN" && formData.has("joinCode")) {
    const joinCode = String(formData.get("joinCode") ?? "").trim();
    if (!/^[A-Za-z0-9-]{3,24}$/.test(joinCode)) {
      return { fieldErrors: { joinCode: "Use 3 to 24 letters, numbers, or dashes." } };
    }
    publicFields.joinCode = joinCode;
  }
  await prisma.teamSetting.upsert({
    where: { id: "team" },
    update: {
      ...publicFields,
      seasonLabel,
      studyGateEnabled: formData.get("studyGateEnabled") === "on",
      studyGoalMinutes,
      workMinutes,
      breakMinutes,
      ...(weeklyStudyMinutes != null ? { weeklyStudyMinutes } : {}),
    },
    create: {
      id: "team",
      ...publicFields,
      seasonLabel,
      studyGateEnabled: formData.get("studyGateEnabled") === "on",
      studyGoalMinutes,
      workMinutes,
      breakMinutes,
      ...(weeklyStudyMinutes != null ? { weeklyStudyMinutes } : {}),
    },
  });
  refresh();
  revalidatePath("/");
  revalidatePath("/signup");
  revalidatePath("/join");
  return { message: "Standard saved for the roster." };
}
