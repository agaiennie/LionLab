"use server";

import { revalidatePath } from "next/cache";
import { isStaff } from "@/lib/auth";
import { canViewAthlete } from "@/lib/access";
import { isAcademicStatus, parentNextStatus } from "@/lib/academics";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/guards";
import type { ActionState } from "@/lib/validators";

const NOTE_MAX = 300;

export async function saveAcademicStatus(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await requireUser();
  const athleteId = String(formData.get("athleteId") ?? "");
  const requested = String(formData.get("status") ?? "");
  const note = String(formData.get("note") ?? "").trim();
  if (note.length > NOTE_MAX) return { error: `Keep the note under ${NOTE_MAX} characters.` };

  const athlete = await prisma.athleteProfile.findUnique({
    where: { id: athleteId },
    select: { id: true, academicStatus: true, academicNote: true },
  });
  if (!athlete) return { error: "That athlete is not on the roster." };

  let status: string;
  let savedNote: string;
  let message: string;
  if (isStaff(user.role)) {
    if (!isAcademicStatus(requested)) return { error: "Pick Good, Watch, or Hold." };
    status = requested;
    savedNote = note;
    message = `Academic status saved: ${status}.`;
  } else if (user.role === "PARENT") {
    if (!(await canViewAthlete(user, athleteId))) return { error: "This athlete is not linked to you." };
    const next = parentNextStatus(athlete.academicStatus, requested);
    if (!next) return { error: "Parents can mark Good or Watch. A coach sets Hold." };
    if (note.length < 4 && next === athlete.academicStatus && athlete.academicStatus === "HOLD") {
      return { error: "A coach clears a Hold. Add a note about grades and the coach will see it." };
    }
    status = next;
    savedNote = note ? `Parent: ${note.replace(/^Parent:\s*/i, "")}` : athlete.academicNote;
    message =
      athlete.academicStatus === "HOLD"
        ? "Note saved. Only a coach can clear a Hold."
        : `Academic update saved: ${status}. The coach will see it.`;
  } else {
    return { error: "A coach or parent updates academic status." };
  }

  await prisma.athleteProfile.update({
    where: { id: athleteId },
    data: { academicStatus: status, academicNote: savedNote, academicCheckedOn: new Date() },
  });

  for (const path of ["/study", "/home", "/fuel", "/today", "/coach", "/progress"]) revalidatePath(path);
  revalidatePath(`/coach/athletes/${athleteId}`);
  revalidatePath(`/coach/athletes/${athleteId}/edit`);
  return { message };
}
