"use server";

import { revalidatePath } from "next/cache";
import { athleteIdForUser } from "@/lib/access";
import { isStaff } from "@/lib/auth";
import { METRIC_BY_ID, isBetter, isMetricId, validateMetricValue, type MetricId } from "@/lib/content/metrics";
import { prisma } from "@/lib/db";
import { requireStaff, requireUser } from "@/lib/guards";

export type MeasureSource = "MANUAL" | "STOPWATCH" | "CAMERA";

export type MeasureInput = {
  athleteId: string;
  metric: string;
  value: number;
  side?: string;
  source: string;
  notes?: string;
};

export type SavedMeasure = {
  id: string;
  athleteId: string;
  metric: MetricId;
  side: string;
  value: number;
  /** Previous best for this athlete/metric/side, if any. */
  previousBest: number | null;
  /** True when this beats every earlier value. False on a first-ever entry. */
  personalBest: boolean;
  first: boolean;
};

export type SaveMeasureResult = {
  error?: string;
  /** Row-level problems keyed by index in the batch. Nothing is saved when any row fails. */
  rowErrors?: Record<number, string>;
  saved?: SavedMeasure[];
  message?: string;
};

/** Metrics an athlete may save for themselves from the camera (home self-test). */
const SELF_TEST_METRICS: MetricId[] = ["BALANCE_SL", "BALANCE_SWAY", "SQUAT_SCORE", "SIT_REACH"];
const SOURCES: MeasureSource[] = ["MANUAL", "STOPWATCH", "CAMERA"];
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const MAX_BATCH = 200;

function refresh() {
  for (const path of ["/coach", "/coach/measure", "/measure", "/coach/fit", "/path", "/progress", "/camera"]) {
    revalidatePath(path);
  }
}

function parseDay(raw: string): Date | null {
  if (!DAY.test(raw)) return null;
  const date = new Date(`${raw}T12:00:00.000Z`);
  if (Number.isNaN(date.getTime())) return null;
  // Allow the phone's local "today" even when UTC has rolled over.
  const latest = new Date(Date.now() + 36 * 3600 * 1000);
  if (raw < "2020-01-01" || date > latest) return null;
  return date;
}

function round(value: number, decimals: number) {
  const f = 10 ** decimals;
  return Math.round(value * f) / f;
}

export async function saveMeasurements(batch: MeasureInput[], recordedOn: string): Promise<SaveMeasureResult> {
  const user = await requireUser();
  const staff = isStaff(user.role);
  let selfAthleteId: string | null = null;
  if (!staff) {
    if (user.role !== "ATHLETE") return { error: "Only coaches can record measurements." };
    selfAthleteId = await athleteIdForUser(user.id);
    if (!selfAthleteId) return { error: "Your athlete profile is missing. Ask a coach." };
  }

  if (!Array.isArray(batch) || batch.length === 0) return { error: "Nothing to save. Fill in at least one number." };
  if (batch.length > MAX_BATCH) return { error: "Too many rows at once." };
  const date = parseDay(String(recordedOn ?? ""));
  if (!date) return { error: "Pick a test date (not in the future)." };

  const rowErrors: Record<number, string> = {};
  const clean: { athleteId: string; metric: MetricId; value: number; side: string; source: MeasureSource; notes: string }[] = [];

  batch.forEach((row, index) => {
    const metric = String(row?.metric ?? "");
    if (!isMetricId(metric)) {
      rowErrors[index] = "Unknown test.";
      return;
    }
    const def = METRIC_BY_ID[metric];
    const value = Number(row.value);
    const bad = validateMetricValue(metric, value);
    if (bad) {
      rowErrors[index] = bad;
      return;
    }
    const side = String(row.side ?? "");
    if (def.sided && side !== "L" && side !== "R") {
      rowErrors[index] = "Pick left or right.";
      return;
    }
    const source = String(row.source ?? "MANUAL") as MeasureSource;
    if (!SOURCES.includes(source)) {
      rowErrors[index] = "Unknown source.";
      return;
    }
    const athleteId = String(row.athleteId ?? "");
    let notes = String(row.notes ?? "").slice(0, 240);
    if (!staff) {
      if (athleteId !== selfAthleteId) {
        rowErrors[index] = "You can save your own numbers only.";
        return;
      }
      if (!SELF_TEST_METRICS.includes(metric) || source !== "CAMERA") {
        rowErrors[index] = "Self-tests are camera balance, squat, and sit-and-reach only. Your coach logs the rest.";
        return;
      }
      notes = notes ? `self-test · ${notes}`.slice(0, 240) : "self-test";
    }
    clean.push({ athleteId, metric, value: round(value, def.decimals), side: def.sided ? side : "", source, notes });
  });

  if (Object.keys(rowErrors).length > 0) {
    return { error: "Fix the marked rows. Nothing was saved.", rowErrors };
  }

  if (staff) {
    const ids = [...new Set(clean.map((row) => row.athleteId))];
    const found = await prisma.athleteProfile.count({ where: { id: { in: ids } } });
    if (found !== ids.length) return { error: "One of those athletes is no longer on the roster." };
  }

  // Previous values, for personal-best flags.
  const previous = await prisma.measurement.findMany({
    where: {
      OR: clean.map((row) => ({ athleteId: row.athleteId, metric: row.metric, side: row.side })),
    },
    select: { athleteId: true, metric: true, side: true, value: true },
  });
  const bestBefore = new Map<string, number>();
  for (const row of previous) {
    if (!isMetricId(row.metric)) continue;
    const key = `${row.athleteId}:${row.metric}:${row.side}`;
    const current = bestBefore.get(key);
    if (current == null || isBetter(row.metric, row.value, current)) bestBefore.set(key, row.value);
  }

  const created = await prisma.$transaction(
    clean.map((row) =>
      prisma.measurement.create({
        data: { ...row, recordedOn: date, recordedById: user.id },
        select: { id: true },
      }),
    ),
  );

  const saved: SavedMeasure[] = clean.map((row, index) => {
    const prev = bestBefore.get(`${row.athleteId}:${row.metric}:${row.side}`) ?? null;
    return {
      id: created[index].id,
      athleteId: row.athleteId,
      metric: row.metric,
      side: row.side,
      value: row.value,
      previousBest: prev,
      personalBest: prev != null && isBetter(row.metric, row.value, prev),
      first: prev == null,
    };
  });

  refresh();
  const pbs = saved.filter((row) => row.personalBest).length;
  return {
    saved,
    message: `Saved ${saved.length} ${saved.length === 1 ? "number" : "numbers"}.${pbs ? ` ${pbs} personal best${pbs === 1 ? "" : "s"}.` : ""}`,
  };
}

export async function deleteMeasurement(id: string): Promise<{ error?: string; message?: string }> {
  const user = await requireStaff();
  if (!isStaff(user.role)) return { error: "Only coaches can delete measurements." };
  const row = await prisma.measurement.findUnique({ where: { id: String(id) }, select: { id: true } });
  if (!row) return { error: "Already gone." };
  await prisma.measurement.delete({ where: { id: row.id } });
  refresh();
  return { message: "Deleted." };
}
