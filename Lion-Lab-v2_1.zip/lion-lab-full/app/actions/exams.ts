"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { isStaff } from "@/lib/auth";
import { athleteIdForUser } from "@/lib/access";
import { prisma } from "@/lib/db";
import { gradeAnswers } from "@/lib/exams";
import { requireUser } from "@/lib/guards";
import { fieldErrorsFrom, type ActionState } from "@/lib/validators";

const AUDIENCES = ["QB", "MLB", "CAPTAIN", "ALL"] as const;

function refresh(examId?: string, slug?: string) {
  revalidatePath("/exams");
  revalidatePath("/coach/exams");
  revalidatePath("/coach/fit");
  revalidatePath("/progress");
  if (slug) revalidatePath(`/exams/${slug}`);
  if (examId) revalidatePath(`/coach/exams/${examId}`);
}

async function staffOnly() {
  const user = await requireUser();
  return isStaff(user.role) ? user : null;
}

// ─── Athlete: take an exam ────────────────────────────────────────────────

export type SubmitResult = { error: string } | { attemptId: string; percent: number; passed: boolean };

/**
 * Grade on the server from the stored key. The client only sends choice
 * indexes, in question order. The client never sees or sends a score.
 */
export async function submitAttempt(examRef: string, answers: number[]): Promise<SubmitResult> {
  const user = await requireUser();
  if (user.role !== "ATHLETE") return { error: "Only athletes take exams." };
  const athleteId = await athleteIdForUser(user.id);
  if (!athleteId) return { error: "Your athlete profile is missing. Ask a coach." };

  const ref = String(examRef ?? "").slice(0, 80);
  const exam = await prisma.exam.findFirst({
    where: { OR: [{ slug: ref }, { id: ref }], published: true },
    include: { questions: { orderBy: [{ order: "asc" }, { id: "asc" }] } },
  });
  if (!exam) return { error: "That exam is not open." };
  if (exam.questions.length === 0) return { error: "This exam has no questions yet." };

  const parsed = z.array(z.number().int().min(0).max(4)).safeParse(answers);
  if (!parsed.success || parsed.data.length !== exam.questions.length) {
    return { error: "Answer every question, then submit. If the exam just changed, reload the page." };
  }

  const graded = gradeAnswers(exam.questions, parsed.data, exam.passPercent);
  const attempt = await prisma.examAttempt.create({
    data: {
      examId: exam.id,
      athleteId,
      answers: JSON.stringify(parsed.data),
      correct: graded.correct,
      total: graded.total,
      percent: graded.percent,
      passed: graded.passed,
    },
  });
  refresh(exam.id, exam.slug);
  revalidatePath(`/coach/athletes/${athleteId}`);
  return { attemptId: attempt.id, percent: graded.percent, passed: graded.passed };
}

// ─── Coach / admin: exams ─────────────────────────────────────────────────

const metaSchema = z.object({
  title: z.string().trim().min(3, "Give the exam a title.").max(80, "Keep the title under 80 characters."),
  audience: z.enum(AUDIENCES, { message: "Pick who takes it." }),
  description: z.string().trim().max(400, "Keep the description under 400 characters."),
  passPercent: z.coerce.number().int("Whole number.").min(50, "Pass mark should be 50 to 100.").max(100, "Pass mark should be 50 to 100."),
});

function readMeta(formData: FormData) {
  return metaSchema.safeParse({
    title: formData.get("title") ?? "",
    audience: formData.get("audience") ?? "",
    description: formData.get("description") ?? "",
    passPercent: formData.get("passPercent") ?? "",
  });
}

function slugify(title: string): string {
  return (
    title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 48) || "exam"
  );
}

export async function createExam(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (!(await staffOnly())) return { error: "Only a coach or admin can build exams." };
  const parsed = readMeta(formData);
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  const base = slugify(parsed.data.title);
  let slug = base;
  for (let n = 2; await prisma.exam.findUnique({ where: { slug }, select: { id: true } }); n++) {
    slug = `${base}-${n}`;
  }
  const exam = await prisma.exam.create({
    data: {
      slug,
      title: parsed.data.title,
      audience: parsed.data.audience,
      description: parsed.data.description,
      passPercent: parsed.data.passPercent,
      // Draft until the coach adds questions and publishes.
      published: false,
    },
  });
  refresh(exam.id, exam.slug);
  redirect(`/coach/exams/${exam.id}`);
}

export async function updateExamMeta(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (!(await staffOnly())) return { error: "Only a coach or admin can edit exams." };
  const examId = String(formData.get("examId") ?? "");
  const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { _count: { select: { questions: true } } } });
  if (!exam) return { error: "That exam is gone." };
  const parsed = readMeta(formData);
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const published = formData.get("published") === "on";
  if (published && exam._count.questions === 0) {
    return { fieldErrors: { published: "Add at least one question before publishing." } };
  }
  await prisma.exam.update({
    where: { id: exam.id },
    data: { ...parsed.data, published },
  });
  refresh(exam.id, exam.slug);
  return { message: published ? "Saved. Athletes can see this exam." : "Saved as a draft. Athletes cannot see it." };
}

export async function deleteExam(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (!(await staffOnly())) return { error: "Only a coach or admin can delete exams." };
  const examId = String(formData.get("examId") ?? "");
  if (formData.get("confirm") !== "on") {
    return { fieldErrors: { confirm: "Check the box to confirm. This also deletes every attempt." } };
  }
  const exam = await prisma.exam.findUnique({ where: { id: examId } });
  if (!exam) return { error: "That exam is already gone." };
  await prisma.exam.delete({ where: { id: exam.id } });
  refresh(undefined, exam.slug);
  redirect("/coach/exams");
}

// ─── Coach / admin: questions ─────────────────────────────────────────────

const questionSchema = z
  .object({
    topic: z.string().trim().max(40, "Keep the topic under 40 characters."),
    prompt: z.string().trim().min(1, "Write the question.").max(600, "Keep the question under 600 characters."),
    choices: z
      .array(z.string().trim().min(1).max(200, "Keep each answer under 200 characters."))
      .min(2, "Give at least 2 answers.")
      .max(5, "Five answers at most."),
    answerIndex: z.number().int(),
    explanation: z.string().trim().max(600, "Keep the explanation under 600 characters."),
  })
  .superRefine((value, ctx) => {
    if (value.answerIndex < 0 || value.answerIndex >= value.choices.length) {
      ctx.addIssue({ code: "custom", path: ["answerIndex"], message: "Mark which answer is right." });
    }
    if (new Set(value.choices.map((c) => c.toLowerCase())).size !== value.choices.length) {
      ctx.addIssue({ code: "custom", path: ["choices"], message: "Two answers are the same." });
    }
  });

/**
 * The form has five answer slots. Empty slots are dropped, and the "correct"
 * radio (a slot number) is mapped to its place in the kept list.
 */
function readQuestion(formData: FormData) {
  const slots = [0, 1, 2, 3, 4].map((i) => String(formData.get(`choice${i}`) ?? "").trim());
  const correctSlot = Number(formData.get("correct"));
  const kept: string[] = [];
  let answerIndex = -1;
  slots.forEach((text, slot) => {
    if (!text) return;
    if (slot === correctSlot) answerIndex = kept.length;
    kept.push(text);
  });
  return questionSchema.safeParse({
    topic: formData.get("topic") ?? "",
    prompt: formData.get("prompt") ?? "",
    choices: kept,
    answerIndex,
    explanation: formData.get("explanation") ?? "",
  });
}

export async function saveQuestion(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (!(await staffOnly())) return { error: "Only a coach or admin can edit questions." };
  const examId = String(formData.get("examId") ?? "");
  const questionId = String(formData.get("questionId") ?? "");
  const exam = await prisma.exam.findUnique({ where: { id: examId } });
  if (!exam) return { error: "That exam is gone." };

  const parsed = readQuestion(formData);
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const data = {
    topic: parsed.data.topic,
    prompt: parsed.data.prompt,
    choices: JSON.stringify(parsed.data.choices),
    answerIndex: parsed.data.answerIndex,
    explanation: parsed.data.explanation,
  };

  if (questionId) {
    const existing = await prisma.examQuestion.findUnique({ where: { id: questionId } });
    if (!existing || existing.examId !== exam.id) return { error: "That question is gone." };
    await prisma.examQuestion.update({ where: { id: existing.id }, data });
    refresh(exam.id, exam.slug);
    return { message: "Question saved." };
  }

  const count = await prisma.examQuestion.count({ where: { examId: exam.id } });
  if (count >= 60) return { error: "Sixty questions is the limit. Split it into two exams." };
  const last = await prisma.examQuestion.findFirst({ where: { examId: exam.id }, orderBy: { order: "desc" } });
  await prisma.examQuestion.create({ data: { ...data, examId: exam.id, order: (last?.order ?? -1) + 1 } });
  refresh(exam.id, exam.slug);
  return { message: "Question added to the end of the exam." };
}

export async function deleteQuestion(formData: FormData): Promise<void> {
  if (!(await staffOnly())) return;
  const questionId = String(formData.get("questionId") ?? "");
  const question = await prisma.examQuestion.findUnique({ where: { id: questionId }, include: { exam: true } });
  if (!question) return;
  await prisma.examQuestion.delete({ where: { id: question.id } });
  const left = await prisma.examQuestion.count({ where: { examId: question.examId } });
  if (left === 0 && question.exam.published) {
    await prisma.exam.update({ where: { id: question.examId }, data: { published: false } });
  }
  await renumber(question.examId);
  refresh(question.examId, question.exam.slug);
}

export async function moveQuestion(formData: FormData): Promise<void> {
  if (!(await staffOnly())) return;
  const questionId = String(formData.get("questionId") ?? "");
  const direction = formData.get("direction") === "up" ? -1 : 1;
  const question = await prisma.examQuestion.findUnique({ where: { id: questionId }, include: { exam: true } });
  if (!question) return;
  const list = await prisma.examQuestion.findMany({
    where: { examId: question.examId },
    orderBy: [{ order: "asc" }, { id: "asc" }],
    select: { id: true },
  });
  const from = list.findIndex((q) => q.id === question.id);
  const to = from + direction;
  if (from < 0 || to < 0 || to >= list.length) return;
  const ids = list.map((q) => q.id);
  [ids[from], ids[to]] = [ids[to]!, ids[from]!];
  await prisma.$transaction(ids.map((id, order) => prisma.examQuestion.update({ where: { id }, data: { order } })));
  refresh(question.examId, question.exam.slug);
}

async function renumber(examId: string) {
  const list = await prisma.examQuestion.findMany({
    where: { examId },
    orderBy: [{ order: "asc" }, { id: "asc" }],
    select: { id: true, order: true },
  });
  const changes = list
    .map((q, order) => ({ id: q.id, order, old: q.order }))
    .filter((q) => q.order !== q.old)
    .map((q) => prisma.examQuestion.update({ where: { id: q.id }, data: { order: q.order } }));
  if (changes.length) await prisma.$transaction(changes);
}
