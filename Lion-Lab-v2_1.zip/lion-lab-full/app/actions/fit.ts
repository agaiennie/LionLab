"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireStaff } from "@/lib/guards";
import { DEFAULT_DEPTH_NEEDS, ROLES, type RoleId, type WeightOverrides } from "@/lib/position-fit";
import type { ActionState } from "@/lib/validators";

function refresh() {
  revalidatePath("/coach/fit");
  revalidatePath("/coach/fit/weights");
  revalidatePath("/coach/recruit");
  revalidatePath("/path");
  revalidatePath("/progress");
}

export async function saveFitSettings(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireStaff();
  const overrides: WeightOverrides = {};
  const needs: Partial<Record<RoleId, number>> = {};
  for (const role of ROLES) {
    const need = Number(formData.get(`need:${role.id}`));
    if (Number.isFinite(need) && need >= 0 && need <= 20 && need !== DEFAULT_DEPTH_NEEDS[role.id]) {
      needs[role.id] = Math.round(need);
    }
    for (const factor of role.factors) {
      const raw = formData.get(`w:${role.id}:${factor.key}`);
      if (raw == null || raw === "") continue;
      const weight = Number(raw);
      if (!Number.isFinite(weight) || weight < 0 || weight > 10) {
        return { error: `${role.label}: weights must be between 0 and 10.` };
      }
      if (weight !== factor.weight) {
        overrides[role.id] = { ...(overrides[role.id] ?? {}), [factor.key]: weight };
      }
    }
  }
  await prisma.teamSetting.upsert({
    where: { id: "team" },
    update: { fitWeights: JSON.stringify(overrides), depthNeeds: JSON.stringify(needs) },
    create: { id: "team", fitWeights: JSON.stringify(overrides), depthNeeds: JSON.stringify(needs) },
  });
  refresh();
  return { message: "Saved. The board uses the new weights now." };
}

export async function resetFitSettings() {
  await requireStaff();
  await prisma.teamSetting.upsert({
    where: { id: "team" },
    update: { fitWeights: "", depthNeeds: "" },
    create: { id: "team" },
  });
  refresh();
}
