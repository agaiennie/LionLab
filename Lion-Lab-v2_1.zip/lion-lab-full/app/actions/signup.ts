"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { getTeam } from "@/lib/days";
import { requireStaff } from "@/lib/guards";
import { hashPassword } from "@/lib/password";
import { HONEYPOT, SPORTS } from "@/lib/signup";
import { emailSchema, fieldErrorsFrom, passwordSchema, type ActionState } from "@/lib/validators";


const SIGNUP_ROLES = ["PARENT", "ATHLETE", "COACH"] as const;

const SIGNUP_DONE = "A coach will approve you. You can sign in after that.";
const JOIN_DONE = "Thanks! A coach will reach out to your parent or guardian soon.";

export type FormEchoState = ActionState & { values?: Record<string, string> };

/** Send typed values back so React's form reset doesn't wipe them on an error. */
function echo(formData: FormData, state: ActionState): FormEchoState {
  const values: Record<string, string> = {};
  for (const [key, value] of formData.entries()) {
    if (typeof value !== "string" || key === "password" || key === HONEYPOT || key.startsWith("$")) continue;
    values[key] = key in values ? `${values[key]}|${value}` : value;
  }
  return { ...state, values };
}

function botFilled(formData: FormData) {
  return String(formData.get(HONEYPOT) ?? "").trim().length > 0;
}

function text(formData: FormData, key: string, max = 500) {
  return String(formData.get(key) ?? "").trim().slice(0, max);
}

const baseSchema = z.object({
  role: z.enum(SIGNUP_ROLES, { message: "Pick who you are." }),
  name: z.string().trim().min(2, "Enter a first and last name.").max(80),
  email: emailSchema,
  password: passwordSchema,
  phone: z.string().trim().max(30, "Keep the phone number short.").default(""),
  joinCode: z.string().trim().min(1, "Enter the team code. Get it from a coach."),
});

export async function signUp(_prev: FormEchoState, formData: FormData): Promise<FormEchoState> {
  // Pretend it worked so a bot learns nothing.
  if (botFilled(formData)) return { message: SIGNUP_DONE };

  const parsed = baseSchema.safeParse({
    role: formData.get("role") ?? "",
    name: formData.get("name"),
    email: formData.get("email"),
    password: formData.get("password"),
    phone: formData.get("phone") ?? "",
    joinCode: formData.get("joinCode"),
  });
  if (!parsed.success) return echo(formData, { fieldErrors: fieldErrorsFrom(parsed.error) });
  const data = parsed.data;

  const team = await getTeam();
  if (data.joinCode.toLowerCase() !== team.joinCode.trim().toLowerCase()) {
    return echo(formData, { fieldErrors: { joinCode: "That team code doesn't match. Get the code from a coach." } });
  }

  const fieldErrors: Record<string, string> = {};
  const kidNames = text(formData, "kidNames", 300);
  const parentName = text(formData, "parentName", 80);
  const parentEmailRaw = text(formData, "parentEmail", 200);
  const note = text(formData, "note", 500);
  let grade: number | null = null;
  let parentEmail = "";

  if (data.role === "PARENT" && kidNames.length < 2) {
    fieldErrors.kidNames = "Tell us which player(s) on the team are yours.";
  }
  if (data.role === "ATHLETE") {
    grade = Number(formData.get("grade"));
    if (!Number.isInteger(grade) || grade < 7 || grade > 12) {
      fieldErrors.grade = "Pick a grade from 7 to 12.";
    }
    if (parentName.length < 2) fieldErrors.parentName = "Enter a parent or guardian's name.";
    const pe = emailSchema.safeParse(parentEmailRaw);
    if (!pe.success) {
      fieldErrors.parentEmail = "Enter a parent or guardian's email.";
    } else if (pe.data === data.email) {
      fieldErrors.parentEmail = "Use your parent's own email, not yours.";
    } else {
      parentEmail = pe.data;
    }
  }
  if (Object.keys(fieldErrors).length > 0) return echo(formData, { fieldErrors });

  const existing = await prisma.user.findUnique({ where: { email: data.email }, select: { status: true } });
  if (existing) {
    return echo(formData, {
      fieldErrors: {
        email:
          existing.status === "PENDING"
            ? "That email already signed up and is waiting for a coach to approve it."
            : "That email already has a Lion Lab account. Try signing in instead.",
      },
    });
  }

  await prisma.user.create({
    data: {
      name: data.name,
      email: data.email,
      phone: data.phone,
      passwordHash: await hashPassword(data.password),
      role: data.role,
      status: "PENDING",
      accessRequest: {
        create: {
          role: data.role,
          kidNames: data.role === "PARENT" ? kidNames : "",
          parentName: data.role === "ATHLETE" ? parentName : "",
          parentEmail: data.role === "ATHLETE" ? parentEmail : "",
          grade: data.role === "ATHLETE" ? grade : null,
          note,
        },
      },
      // Placeholder body numbers; a coach fixes them on approval.
      athlete:
        data.role === "ATHLETE" && grade
          ? { create: { grade, positions: "ATH", heightInches: 60, weightLbs: 100 } }
          : undefined,
    },
  });

  revalidatePath("/coach/approvals");
  return { message: SIGNUP_DONE };
}

// ---------------------------------------------------------------------------
// Public interest form (no account)


export async function submitInterest(_prev: FormEchoState, formData: FormData): Promise<FormEchoState> {
  if (botFilled(formData)) return { message: JOIN_DONE };

  const fieldErrors: Record<string, string> = {};
  const name = text(formData, "name", 80);
  const school = text(formData, "school", 120);
  const interest = text(formData, "interest", 600);
  const parentName = text(formData, "parentName", 80);
  const gradeRaw = String(formData.get("grade") ?? "");
  const grade = gradeRaw ? Number(gradeRaw) : null;

  if (name.length < 2) fieldErrors.name = "Enter the student's name.";
  if (grade !== null && (!Number.isInteger(grade) || grade < 5 || grade > 12)) {
    fieldErrors.grade = "Pick a grade.";
  }
  if (parentName.length < 2) fieldErrors.parentName = "Enter a parent or guardian's name.";
  const parentEmail = emailSchema.safeParse(formData.get("parentEmail") ?? "");
  if (!parentEmail.success) fieldErrors.parentEmail = "Enter a parent or guardian's email.";

  const picked = formData
    .getAll("sports")
    .map(String)
    .filter((sport) => (SPORTS as readonly string[]).includes(sport));
  const otherSport = text(formData, "sportsOther", 80);
  const sports = [...picked.filter((sport) => sport !== "Other"), ...(otherSport ? [otherSport] : picked.includes("Other") ? ["Other"] : [])];

  let heightInches: number | null = null;
  const feet = String(formData.get("feet") ?? "").trim();
  const inches = String(formData.get("inches") ?? "").trim();
  if (feet || inches) {
    const total = Number(feet || 0) * 12 + Number(inches || 0);
    if (!Number.isFinite(total) || total < 40 || total > 84) {
      fieldErrors.height = "Height looks off. Leave it blank if you're not sure.";
    } else {
      heightInches = Math.round(total);
    }
  }
  let weightLbs: number | null = null;
  const weight = String(formData.get("weightLbs") ?? "").trim();
  if (weight) {
    const value = Number(weight);
    if (!Number.isFinite(value) || value < 50 || value > 400) {
      fieldErrors.weightLbs = "Weight looks off. Leave it blank if you're not sure.";
    } else {
      weightLbs = Math.round(value);
    }
  }

  if (Object.keys(fieldErrors).length > 0 || !parentEmail.success) return echo(formData, { fieldErrors });

  await prisma.prospect.create({
    data: {
      name,
      grade,
      school,
      sportsNow: sports.join(", "),
      interest,
      parentName,
      parentEmail: parentEmail.data,
      heightInches,
      weightLbs,
      status: "NEW",
      source: "PUBLIC_FORM",
    },
  });

  revalidatePath("/coach/recruit");
  return { message: JOIN_DONE };
}

// ---------------------------------------------------------------------------
// Coach approvals

function refreshApprovals() {
  revalidatePath("/coach/approvals");
  revalidatePath("/coach");
  revalidatePath("/admin");
  revalidatePath("/");
}

async function pendingTarget(userId: string) {
  return prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, role: true, status: true, athlete: { select: { id: true } } },
  });
}

/** Link a parent account to roster athletes. Same upsert pattern as inviteParent. */
async function linkParentTo(parentId: string, athleteIds: string[]) {
  if (athleteIds.length === 0) return;
  const athletes = await prisma.athleteProfile.findMany({
    where: { id: { in: athleteIds } },
    select: { id: true },
  });
  for (const { id: athleteId } of athletes) {
    await prisma.parentLink.upsert({
      where: { parentId_athleteId: { parentId, athleteId } },
      update: {},
      create: { parentId, athleteId },
    });
    revalidatePath(`/coach/athletes/${athleteId}`);
  }
}

export async function approveUser(formData: FormData): Promise<void> {
  const staff = await requireStaff();
  const userId = String(formData.get("userId") ?? "");
  const target = await pendingTarget(userId);
  if (!target || target.status !== "PENDING") redirect("/coach/approvals");
  if ((target.role === "COACH" || target.role === "ADMIN") && staff.role !== "ADMIN") {
    redirect("/coach/approvals?error=admin");
  }
  if (target.role === "ADMIN") redirect("/coach/approvals?error=admin");

  await prisma.user.update({ where: { id: target.id }, data: { status: "ACTIVE" } });
  if (target.role === "PARENT") {
    const athleteIds = formData.getAll("athleteId").map(String).filter(Boolean);
    await linkParentTo(target.id, athleteIds);
  }
  refreshApprovals();
  redirect(`/coach/approvals?approved=${target.id}`);
}

export async function denyUser(formData: FormData): Promise<void> {
  const staff = await requireStaff();
  const userId = String(formData.get("userId") ?? "");
  const target = await pendingTarget(userId);
  if (!target || target.status !== "PENDING") redirect("/coach/approvals");
  if ((target.role === "COACH" || target.role === "ADMIN") && staff.role !== "ADMIN") {
    redirect("/coach/approvals?error=admin");
  }
  // Keep the row (and its request) so the decision is on record.
  await prisma.user.update({ where: { id: target.id }, data: { status: "DISABLED" } });
  refreshApprovals();
  redirect("/coach/approvals?denied=1");
}

export async function linkParent(formData: FormData): Promise<void> {
  await requireStaff();
  const parentId = String(formData.get("userId") ?? "");
  const parent = await prisma.user.findUnique({ where: { id: parentId }, select: { role: true } });
  if (!parent || parent.role !== "PARENT") redirect("/coach/approvals");
  const athleteIds = formData.getAll("athleteId").map(String).filter(Boolean);
  await linkParentTo(parentId, athleteIds);
  refreshApprovals();
  redirect("/coach/approvals?linked=1");
}
