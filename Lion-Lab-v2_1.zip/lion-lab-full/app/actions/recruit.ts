"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireStaff } from "@/lib/guards";
import { fieldErrorsFrom, type ActionState } from "@/lib/validators";

const STATUSES = ["NEW", "CONTACTED", "TRYOUT", "JOINED", "NOT_NOW"] as const;

const optionalInt = (min: number, max: number) =>
  z.preprocess((v) => (v === "" || v == null ? undefined : v), z.coerce.number().int().min(min).max(max).optional());

const prospectSchema = z.object({
  name: z.string().trim().min(2, "Enter a name or a short description.").max(80),
  grade: optionalInt(5, 12),
  sportsNow: z.string().trim().max(120).default(""),
  interest: z.string().trim().max(300).default(""),
  parentName: z.string().trim().max(80).default(""),
  parentEmail: z.union([z.literal(""), z.string().trim().toLowerCase().email("Check the email.")]).default(""),
  heightInches: optionalInt(48, 84),
  weightLbs: optionalInt(60, 400),
  notes: z.string().trim().max(500).default(""),
});

export async function addProspect(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireStaff();
  const parsed = prospectSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  await prisma.prospect.create({ data: { ...parsed.data, source: "COACH", status: "NEW" } });
  revalidatePath("/coach/recruit");
  return { message: "Added to the list." };
}

export async function updateProspect(formData: FormData) {
  await requireStaff();
  const id = String(formData.get("id") ?? "");
  const status = String(formData.get("status") ?? "");
  const notes = formData.get("notes");
  if (!id || !(STATUSES as readonly string[]).includes(status)) return;
  await prisma.prospect.update({
    where: { id },
    data: { status, ...(typeof notes === "string" ? { notes: notes.slice(0, 500) } : {}) },
  });
  revalidatePath("/coach/recruit");
}

export async function deleteProspect(formData: FormData) {
  await requireStaff();
  const id = String(formData.get("id") ?? "");
  if (id) await prisma.prospect.deleteMany({ where: { id } });
  revalidatePath("/coach/recruit");
}
