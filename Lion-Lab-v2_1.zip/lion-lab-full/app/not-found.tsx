import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-full max-w-lg flex-col justify-center gap-3 px-4 py-16">
      <p className="font-display text-sm tracking-[0.18em] text-lion">LION LAB</p>
      <h1 className="font-display text-4xl tracking-wide">That page is not on the roster</h1>
      <p className="text-muted-foreground">Check the link, or head back to sign in.</p>
      <Link href="/" className="font-semibold text-lion">
        Home
      </Link>
    </div>
  );
}
