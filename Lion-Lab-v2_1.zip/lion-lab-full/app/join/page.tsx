import Link from "next/link";
import { JoinForm } from "@/components/join-form";
import { PublicHeader } from "@/components/shell";
import { getTeam } from "@/lib/days";

export const metadata = { title: "Interested in playing?" };

export default async function JoinPage() {
  const team = await getTeam();
  const school = `${team.teamName.replace(/\s+football$/i, "")} ${team.levelLabel}`.trim();
  return (
    <div className="flex min-h-svh flex-col bg-paper">
      <PublicHeader />
      <main className="mx-auto grid w-full max-w-lg gap-6 px-4 py-8">
        <header>
          <p className="font-display text-sm font-semibold tracking-[0.18em] text-lion">
            {team.teamName.toUpperCase()} · {team.levelLabel.toUpperCase()}
          </p>
          <h1 className="font-display text-4xl tracking-wide sm:text-5xl">Interested in playing?</h1>
          <p className="mt-2 text-xl font-semibold">No experience needed.</p>
          <p className="mt-2 text-lg text-muted-foreground">
            Everyone is welcome: boys and girls, big and small, kids who play three sports and kids who have never played
            one. We teach every step from the first day. Tell us a little and a coach will reach out to your family.
          </p>
        </header>
        <JoinForm defaultSchool={school} />
        <p className="text-sm text-muted-foreground">
          No account is made. We only use this to contact the parent or guardian about joining.{" "}
          <Link href="/" className="font-semibold text-lion">
            Program home
          </Link>
        </p>
      </main>
    </div>
  );
}
