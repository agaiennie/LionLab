import Link from "next/link";
import { AppNav } from "@/components/app-nav";
import { SignOutButton } from "@/components/sign-out-button";
import { Wordmark } from "@/components/wordmark";
import { homeFor } from "@/lib/auth";

export function Shell({
  role,
  name,
  children,
}: {
  role: string;
  name: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-svh flex-col">
      <header className="bg-ink text-white print:hidden">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center gap-x-4 gap-y-3 px-4 py-3">
          <Link href={homeFor(role)} className="mr-auto">
            <Wordmark tone="light" />
          </Link>
          <AppNav role={role} />
          <div className="flex items-center gap-3">
            <p className="hidden text-sm text-white/70 sm:block">{name}</p>
            <Link href="/account" className="text-sm font-semibold text-white/70 hover:text-white">
              Password
            </Link>
            <SignOutButton />
          </div>
        </div>
        <div className="h-1 bg-lion" />
      </header>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6">{children}</main>
      <footer className="border-t border-border px-4 py-4 text-center text-sm text-muted-foreground print:hidden">
        Estimates are coaching tools for practice. They are not medical advice, injury screens, or recruiting scores.
      </footer>
    </div>
  );
}

export function PublicHeader() {
  return (
    <header className="bg-ink text-white">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <Link href="/">
          <Wordmark tone="light" />
        </Link>
        <Link
          href="/signin"
          className="rounded-full bg-lion px-4 py-2 text-sm font-semibold text-white"
        >
          Sign in
        </Link>
      </div>
      <div className="h-1 bg-lion" />
    </header>
  );
}
