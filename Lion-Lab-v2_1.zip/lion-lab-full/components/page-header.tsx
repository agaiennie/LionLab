import Link from "next/link";

export function PageHeader({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="max-w-2xl">
        <p className="font-display text-sm font-semibold tracking-[0.18em] text-lion">
          {eyebrow}
        </p>
        <h1 className="font-display text-4xl font-semibold tracking-wide text-ink sm:text-5xl">
          {title}
        </h1>
        {description ? (
          <p className="mt-2 text-base text-muted-foreground">{description}</p>
        ) : null}
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <Link href="/glossary" className="text-sm font-semibold text-lion">
          Glossary
        </Link>
        {action}
      </div>
    </div>
  );
}
