import Link from "next/link";
import { METRICS, METRIC_BY_ID, formatMetric, type MetricId } from "@/lib/content/metrics";
import { latestMetrics } from "@/lib/fit-data";
import { prisma } from "@/lib/db";
import { ANCHORS, bandForGrade } from "@/lib/position-fit";

export type GapRow = {
  metric: MetricId;
  tested: number;
  roster: number;
  poor: number;
  belowOk: number;
  okOrBetter: number;
  /** Junior-high lines, for the label. */
  poorLine: number;
  okLine: number;
};

/**
 * Team-wide flexibility and balance gaps. Uses each athlete's latest number
 * (sided tests average L and R, same as position fit) against the ANCHORS for
 * their grade band: "poor" = at or past the poor anchor, "below ok" = short of
 * the midpoint between the poor and good anchors.
 */
export async function loadTeamGaps(): Promise<GapRow[]> {
  const metrics = METRICS.filter((m) => m.group === "FLEX" || m.group === "BALANCE").map((m) => m.id);
  const athletes = await prisma.athleteProfile.findMany({
    where: { user: { status: "ACTIVE" } },
    select: {
      grade: true,
      measurements: {
        where: { metric: { in: metrics } },
        orderBy: [{ recordedOn: "desc" }, { createdAt: "desc" }],
        select: { metric: true, value: true, side: true, recordedOn: true, source: true },
      },
    },
  });

  return metrics.map((metric) => {
    const lower = METRIC_BY_ID[metric].better === "lower";
    const jh = ANCHORS[metric]?.JH ?? [0, 0];
    const row: GapRow = {
      metric,
      tested: 0,
      roster: athletes.length,
      poor: 0,
      belowOk: 0,
      okOrBetter: 0,
      poorLine: jh[0],
      okLine: (jh[0] + jh[1]) / 2,
    };
    for (const a of athletes) {
      const latest = latestMetrics(a.measurements)[metric];
      const anchor = ANCHORS[metric]?.[bandForGrade(a.grade)];
      if (!latest || !anchor) continue;
      row.tested += 1;
      const [poor, good] = anchor;
      const ok = (poor + good) / 2;
      const v = latest.value;
      const atPoor = lower ? v >= poor : v <= poor;
      const underOk = lower ? v > ok : v < ok;
      if (atPoor) row.poor += 1;
      else if (underOk) row.belowOk += 1;
      else row.okOrBetter += 1;
    }
    return row;
  });
}

export async function TeamGaps() {
  const rows = await loadTeamGaps();
  const anyTested = rows.some((r) => r.tested > 0);
  return (
    <section className="rounded-xl bg-card p-4 ring-1 ring-foreground/10" data-testid="team-gaps">
      <h2 className="font-display text-2xl tracking-wide">Team gaps: flexibility and balance</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Latest number per athlete. &ldquo;Poor&rdquo; is at or past the poor line; &ldquo;below OK&rdquo; is short of the
        halfway mark to good. Lines shown are junior-high; grades 9+ use the high-school lines.
      </p>
      {!anyTested ? (
        <p className="mt-3 text-sm">No flexibility or balance numbers yet. Start with sit and reach and single-leg balance.</p>
      ) : null}
      <ul className="mt-3 grid gap-3 sm:grid-cols-2">
        {rows.map((r) => {
          const def = METRIC_BY_ID[r.metric];
          const flagged = r.poor + r.belowOk;
          const pct = (n: number) => (r.tested ? `${(n / r.tested) * 100}%` : "0%");
          return (
            <li key={r.metric} className="grid gap-1">
              <div className="flex items-baseline justify-between gap-2">
                <Link href={`/coach/measure?metric=${r.metric}`} className="font-semibold text-lion">
                  {def.label}
                </Link>
                <span className="text-sm text-muted-foreground">
                  {r.tested}/{r.roster} tested
                </span>
              </div>
              {r.tested > 0 ? (
                <>
                  <div className="flex h-3 overflow-hidden rounded-full bg-muted" aria-hidden>
                    <span className="bg-lion" style={{ width: pct(r.poor) }} />
                    <span className="bg-amber-400" style={{ width: pct(r.belowOk) }} />
                    <span className="bg-emerald-700" style={{ width: pct(r.okOrBetter) }} />
                  </div>
                  <p className="text-sm">
                    <strong>{flagged}</strong> of {r.tested} below OK · {r.poor} poor
                    <span className="text-muted-foreground">
                      {" "}
                      (poor {def.better === "lower" ? "≥" : "≤"} {formatMetric(r.metric, r.poorLine)}, OK{" "}
                      {def.better === "lower" ? "≤" : "≥"} {formatMetric(r.metric, r.okLine)})
                    </span>
                  </p>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">Not tested yet.</p>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
