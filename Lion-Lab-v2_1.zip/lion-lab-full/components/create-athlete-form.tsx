"use client";

import Link from "next/link";
import { useActionState } from "react";
import { createAthlete } from "@/app/actions";
import { AthleteFields } from "@/components/athlete-fields";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { ActionState } from "@/lib/validators";

export function CreateAthleteForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(createAthlete, {});

  if (state.invite) {
    return (
      <div className="grid max-w-xl gap-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
        <div>
          <p className="font-display text-sm tracking-[0.16em] text-lion">INVITE</p>
          <h2 className="font-display text-3xl tracking-wide">{state.invite.name} is on the roster</h2>
          <p className="mt-2 text-muted-foreground">
            Share this in person or on paper. Lion Lab does not email passwords, and athletes are not listed publicly.
          </p>
        </div>
        <dl className="grid gap-2 text-sm">
          <div>
            <dt className="text-muted-foreground">Sign-in email</dt>
            <dd className="font-semibold">{state.invite.email}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Temporary password</dt>
            <dd className="font-semibold">{state.invite.temporaryPassword}</dd>
          </div>
        </dl>
        <div className="flex flex-wrap gap-3">
          <Link
            href={`/coach/athletes/${state.invite.athleteId}`}
            className="inline-flex h-11 items-center rounded-lg bg-lion px-4 font-medium text-white"
          >
            Open their page
          </Link>
          <Link href="/coach" className="inline-flex h-11 items-center font-semibold text-lion">
            Back to roster
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form action={action} className="grid max-w-3xl gap-5">
      <AthleteFields
        includeEmail
        errors={state.fieldErrors}
        values={{
          name: "",
          email: "",
          grade: 9,
          positions: [],
          feet: 5,
          inches: 8,
          weightLbs: 150,
        }}
      />
      <div className="grid gap-1.5">
        <Label htmlFor="password">Temporary password</Label>
        <Input id="password" name="password" type="text" required minLength={8} className="h-11 text-base" />
        <p className="text-sm text-muted-foreground">
          At least 8 characters. You will see it once so you can hand it to the athlete.
        </p>
        {state.fieldErrors?.password ? (
          <p className="text-sm text-destructive">{state.fieldErrors.password}</p>
        ) : null}
      </div>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      <Button type="submit" size="touch" disabled={pending} className="w-fit">
        {pending ? "Saving…" : "Add athlete"}
      </Button>
    </form>
  );
}
