"use client";

import { useActionState } from "react";
import { addProspect } from "@/app/actions/recruit";
import { Button } from "@/components/ui/button";
import type { ActionState } from "@/lib/validators";

const field = "rounded-lg border border-input bg-card px-3 py-2 text-base";

export function ProspectForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(addProspect, {});
  const err = (k: string) => (state.fieldErrors?.[k] ? <span className="text-xs text-destructive">{state.fieldErrors[k]}</span> : null);
  return (
    <form action={action} className="grid gap-2 sm:grid-cols-2">
      <label className="grid gap-1 text-sm font-semibold sm:col-span-2">
        Name (or a description until you know it)
        <input name="name" required className={field} placeholder="8th-grade wrestler, 3rd period gym" />
        {err("name")}
      </label>
      <label className="grid gap-1 text-sm font-semibold">
        Grade
        <input name="grade" inputMode="numeric" className={field} />
        {err("grade")}
      </label>
      <label className="grid gap-1 text-sm font-semibold">
        Plays now
        <input name="sportsNow" className={field} placeholder="Wrestling, band" />
      </label>
      <label className="grid gap-1 text-sm font-semibold">
        Height (inches)
        <input name="heightInches" inputMode="numeric" className={field} />
        {err("heightInches")}
      </label>
      <label className="grid gap-1 text-sm font-semibold">
        Weight (lb)
        <input name="weightLbs" inputMode="numeric" className={field} />
        {err("weightLbs")}
      </label>
      <label className="grid gap-1 text-sm font-semibold sm:col-span-2">
        Why this kid / role you see
        <input name="interest" className={field} placeholder="Low center, great hips — RB or LB" />
      </label>
      <label className="grid gap-1 text-sm font-semibold">
        Parent/guardian
        <input name="parentName" className={field} />
      </label>
      <label className="grid gap-1 text-sm font-semibold">
        Parent email
        <input name="parentEmail" type="email" className={field} />
        {err("parentEmail")}
      </label>
      <div className="grid gap-1 sm:col-span-2">
        <Button type="submit" size="touch" disabled={pending}>
          {pending ? "Adding…" : "Add prospect"}
        </Button>
        {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
        {state.message ? <p className="text-sm">{state.message}</p> : null}
      </div>
    </form>
  );
}
