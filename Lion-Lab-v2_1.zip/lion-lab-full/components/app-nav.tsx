"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "cn";

const links = {
  ATHLETE: [
    { href: "/today", label: "Today" },
    { href: "/train", label: "Train" },
    { href: "/measure", label: "Measure" },
    { href: "/study", label: "Study" },
    { href: "/exams", label: "Exams" },
    { href: "/fuel", label: "Fuel" },
    { href: "/path", label: "My path" },
    { href: "/glossary", label: "Glossary" },
  ],
  PARENT: [
    { href: "/today", label: "Today" },
    { href: "/home", label: "Home" },
    { href: "/progress", label: "Progress" },
    { href: "/fuel", label: "Fuel" },
    { href: "/notes", label: "Notes" },
    { href: "/glossary", label: "Glossary" },
  ],
  COACH: [
    { href: "/today", label: "Today" },
    { href: "/coach", label: "Roster" },
    { href: "/coach/measure", label: "Test day" },
    { href: "/camera", label: "Camera" },
    { href: "/coach/fit", label: "Positions" },
    { href: "/coach/recruit", label: "Recruit" },
    { href: "/coach/exams", label: "Exams" },
    { href: "/field", label: "Field" },
    { href: "/skills", label: "Skills" },
    { href: "/coach/approvals", label: "Approvals" },
    { href: "/standards", label: "Standards" },
  ],
  ADMIN: [
    { href: "/today", label: "Today" },
    { href: "/coach", label: "Roster" },
    { href: "/coach/measure", label: "Test day" },
    { href: "/camera", label: "Camera" },
    { href: "/coach/fit", label: "Positions" },
    { href: "/coach/recruit", label: "Recruit" },
    { href: "/coach/exams", label: "Exams" },
    { href: "/field", label: "Field" },
    { href: "/skills", label: "Skills" },
    { href: "/coach/approvals", label: "Approvals" },
    { href: "/admin", label: "Users" },
    { href: "/standards", label: "Standards" },
  ],
} as const;

function isActive(pathname: string, href: string) {
  if (href === "/coach") {
    return pathname === "/coach" || pathname.startsWith("/coach/athletes") || pathname === "/coach/log";
  }
  if (href === "/glossary" || href === "/today" || href === "/admin") return pathname === href;
  return pathname === href || pathname.startsWith(`${href}/`);
}

export function AppNav({ role }: { role: string }) {
  const pathname = usePathname();
  const items = links[role as keyof typeof links] ?? links.ATHLETE;

  return (
    <nav className="flex max-w-full flex-nowrap items-center gap-1 overflow-x-auto">
      {items.map((item) => {
        const active = isActive(pathname, item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "shrink-0 rounded-full px-3 py-2 text-sm font-semibold",
              active ? "bg-lion text-white" : "text-white/80 hover:bg-white/10 hover:text-white",
            )}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
