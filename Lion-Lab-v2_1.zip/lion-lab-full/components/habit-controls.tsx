"use client";

import { useActionState } from "react";
import {
  addSubject,
  completeHomeTrain,
  completeMobility,
  logStudyMinutes,
  removeSubject,
  saveParentOverride,
  toggleFuelForm,
} from "@/app/actions/daily";
import { LocalDayInput } from "@/components/local-day";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FUEL_HABITS } from "@/lib/content/fuel";
import type { ActionState } from "@/lib/validators";

const card = "rounded-xl bg-card p-4 ring-1 ring-foreground/10";

export function StudyMinutesForm({
  athleteId,
  goal,
  minutes,
}: {
  athleteId: string;
  goal: number;
  minutes: number;
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(logStudyMinutes, {});
  return (
    <form action={action} className="grid gap-3">
      <input type="hidden" name="athleteId" value={athleteId} />
      <input type="hidden" name="mode" value="set" />
      <LocalDayInput />
      <p className="text-sm text-muted-foreground">
        Logged today: {minutes} min. Goal: {goal} min.
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <label className="grid gap-1 text-sm font-semibold" htmlFor={`studied-${athleteId}`}>
          Studied minutes
          <Input
            id={`studied-${athleteId}`}
            name="minutes"
            type="number"
            min={1}
            max={180}
            defaultValue={goal}
            required
            className="h-11 w-28 text-base"
          />
        </label>
        <Button type="submit" size="touch" disabled={pending}>
          {pending ? "Saving…" : "Log study"}
        </Button>
      </div>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      {state.message ? <p className="text-sm">{state.message}</p> : null}
    </form>
  );
}

export function FuelBoard({
  athleteId,
  values,
  editable,
}: {
  athleteId: string;
  values: { water: boolean; protein: boolean; sleep: boolean; lightJunk: boolean };
  editable: boolean;
}) {
  return (
    <ul className="grid gap-3">
      {FUEL_HABITS.map((habit) => {
        const done = values[habit.field];
        return (
          <li key={habit.id} className={card}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{habit.label}</p>
                <p className="mt-1 text-sm text-muted-foreground">{habit.tip}</p>
              </div>
              {editable ? (
                <form action={toggleFuelForm}>
                  <input type="hidden" name="athleteId" value={athleteId} />
                  <input type="hidden" name="field" value={habit.field} />
                  <input type="hidden" name="value" value={done ? "0" : "1"} />
                  <LocalDayInput />
                  <Button type="submit" size="touch" variant={done ? "secondary" : "outline"}>
                    {done ? "Done" : "Mark"}
                  </Button>
                </form>
              ) : (
                <span className="text-sm font-semibold">{done ? "Done" : "Not yet"}</span>
              )}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

export function MobilityComplete({
  athleteId,
  template,
  done,
}: {
  athleteId: string;
  template: string;
  done: boolean;
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(completeMobility, {});
  if (done) {
    return <p className="text-sm font-semibold">Mobility session logged for today.</p>;
  }
  return (
    <form action={action} className="grid gap-2">
      <input type="hidden" name="athleteId" value={athleteId} />
      <input type="hidden" name="template" value={template} />
      <LocalDayInput />
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Saving…" : "Session done"}
      </Button>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      {state.message ? <p className="text-sm">{state.message}</p> : null}
    </form>
  );
}

export function HomeTrainComplete({ athleteId, done }: { athleteId: string; done: boolean }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(completeHomeTrain, {});
  if (done) return <p className="text-sm font-semibold">Home training logged for today.</p>;
  return (
    <form action={action} className="grid gap-2">
      <input type="hidden" name="athleteId" value={athleteId} />
      <LocalDayInput />
      <Button type="submit" size="touch" variant="outline" disabled={pending}>
        {pending ? "Saving…" : "Home training done"}
      </Button>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      {state.message ? <p className="text-sm">{state.message}</p> : null}
    </form>
  );
}

export function ParentOverrideForm({
  athleteId,
  note,
}: {
  athleteId: string;
  note: string;
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(saveParentOverride, {});
  return (
    <form action={action} className="grid gap-2">
      <input type="hidden" name="athleteId" value={athleteId} />
      <LocalDayInput />
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`override-${athleteId}`}>
        Parent note
        <textarea
          id={`override-${athleteId}`}
          name="note"
          defaultValue={note}
          rows={3}
          maxLength={240}
          className="rounded-lg border border-input bg-card px-3 py-2 text-base"
          placeholder="Bus was late. Study is after dinner."
        />
      </label>
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="touch" disabled={pending}>
          Save note
        </Button>
        <Button type="submit" name="clear" value="1" size="touch" variant="outline" disabled={pending}>
          Clear note
        </Button>
      </div>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      {state.message ? <p className="text-sm">{state.message}</p> : null}
    </form>
  );
}

export function SubjectEditor({
  athleteId,
  subjects,
}: {
  athleteId: string;
  subjects: { id: string; name: string }[];
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(addSubject, {});
  return (
    <div className="grid gap-3">
      {subjects.length === 0 ? (
        <p className="text-sm text-muted-foreground">No subjects yet. Add the classes on this week's schedule.</p>
      ) : (
        <ul className="grid gap-2">
          {subjects.map((subject) => (
            <li key={subject.id} className="flex items-center justify-between gap-3 rounded-lg bg-muted px-3 py-2">
              <span className="font-semibold">{subject.name}</span>
              <form action={removeSubject}>
                <input type="hidden" name="subjectId" value={subject.id} />
                <Button type="submit" size="sm" variant="ghost">
                  Remove
                </Button>
              </form>
            </li>
          ))}
        </ul>
      )}
      <form action={action} className="flex flex-wrap items-end gap-2">
        <input type="hidden" name="athleteId" value={athleteId} />
        <label className="grid gap-1 text-sm font-semibold" htmlFor={`subject-${athleteId}`}>
          Add a subject
          <Input id={`subject-${athleteId}`} name="name" required maxLength={60} className="h-11 w-56 text-base" />
        </label>
        <Button type="submit" size="touch" variant="outline" disabled={pending}>
          Add
        </Button>
      </form>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      {state.message ? <p className="text-sm">{state.message}</p> : null}
    </div>
  );
}
