import { STUDY_GATE_DETAIL, STUDY_GATE_LINE } from "@/lib/habits";

export function GateBanner({ blocked, enabled }: { blocked: boolean; enabled: boolean }) {
  if (!enabled) {
    return (
      <p className="rounded-xl bg-card px-4 py-3 text-sm ring-1 ring-foreground/10">
        The study gate is off this week. Home sessions can be logged without a study block. The line stays the same: {STUDY_GATE_LINE}
      </p>
    );
  }
  if (!blocked) {
    return (
      <p className="rounded-xl bg-card px-4 py-3 text-sm ring-1 ring-foreground/10">
        Study block is in for today. Home training can be logged.
      </p>
    );
  }
  return (
    <div className="rounded-xl bg-accent px-4 py-3 text-accent-foreground">
      <p className="font-display text-2xl tracking-wide">{STUDY_GATE_LINE}</p>
      <p className="mt-1 text-sm">{STUDY_GATE_DETAIL} Field tests a coach logs are not part of this.</p>
    </div>
  );
}
