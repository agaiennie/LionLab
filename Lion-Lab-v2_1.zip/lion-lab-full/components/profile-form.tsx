"use client";

import { useActionState } from "react";
import { updateAthlete } from "@/app/actions";
import { AthleteFields } from "@/components/athlete-fields";
import { Button } from "@/components/ui/button";
import type { ActionState } from "@/lib/validators";

export function ProfileForm({
  athleteId,
  includeEmail,
  values,
}: {
  athleteId: string;
  includeEmail: boolean;
  values: {
    name: string;
    email: string;
    grade: number;
    positions: string[];
    feet: number;
    inches: number;
    weightLbs: number;
  };
}) {
  const action = updateAthlete.bind(null, athleteId);
  const [state, formAction, pending] = useActionState<ActionState, FormData>(action, {});

  return (
    <form action={formAction} className="grid max-w-3xl gap-5">
      {state.message ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm text-accent-foreground">{state.message}</p>
      ) : null}
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      <AthleteFields includeEmail={includeEmail} values={values} errors={state.fieldErrors} />
      <Button type="submit" size="touch" disabled={pending} className="w-fit">
        {pending ? "Saving…" : "Save profile"}
      </Button>
    </form>
  );
}
