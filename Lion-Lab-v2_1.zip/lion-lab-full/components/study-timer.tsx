"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addStudyMinutes } from "@/app/actions/daily";
import { Button } from "@/components/ui/button";
import { localDay } from "@/lib/habits";

type Mode = "idle" | "work" | "paused" | "break";

export function StudyTimer({
  athleteId,
  workMinutes,
  breakMinutes,
  logged,
}: {
  athleteId: string;
  workMinutes: number;
  breakMinutes: number;
  logged: number;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [mode, setMode] = useState<Mode>("idle");
  const [resume, setResume] = useState<"work" | "break">("work");
  const [left, setLeft] = useState(workMinutes * 60);
  const [note, setNote] = useState("");
  const finishing = useRef(false);

  useEffect(() => {
    if (mode !== "work" && mode !== "break") return;
    const id = window.setInterval(() => {
      setLeft((value) => (value > 0 ? value - 1 : 0));
    }, 1000);
    return () => window.clearInterval(id);
  }, [mode]);

  useEffect(() => {
    if (left > 0 || finishing.current) return;
    if (mode === "work") {
      finishing.current = true;
      start(async () => {
        const result = await addStudyMinutes(athleteId, localDay(), workMinutes, "add");
        setNote(result.message ?? result.error ?? "");
        router.refresh();
      });
      setMode("break");
      setLeft(breakMinutes * 60);
      finishing.current = false;
    } else if (mode === "break") {
      finishing.current = true;
      setMode("idle");
      setLeft(workMinutes * 60);
      finishing.current = false;
    }
  }, [left, mode, athleteId, workMinutes, breakMinutes, router]);

  const minutes = String(Math.floor(left / 60)).padStart(2, "0");
  const seconds = String(left % 60).padStart(2, "0");
  const label = mode === "break" ? "Break" : mode === "paused" ? "Paused" : "Study";

  return (
    <div className="grid gap-3">
      <p className="font-display text-6xl tracking-wide tabular-nums">
        {minutes}:{seconds}
      </p>
      <p className="text-sm text-muted-foreground">
        {label} · {workMinutes} on / {breakMinutes} off · {logged} min logged today
      </p>
      <div className="flex flex-wrap gap-2">
        {mode === "work" || mode === "break" ? (
          <Button
            type="button"
            size="touch"
            variant="outline"
            onClick={() => {
              setResume(mode === "break" ? "break" : "work");
              setMode("paused");
            }}
          >
            Pause
          </Button>
        ) : (
          <Button
            type="button"
            size="touch"
            onClick={() => {
              if (mode === "idle") setLeft(workMinutes * 60);
              setMode(mode === "paused" ? resume : "work");
            }}
          >
            {mode === "paused" ? "Resume" : "Start study"}
          </Button>
        )}
      </div>
      {pending ? <p className="text-sm">Saving the block…</p> : null}
      {note ? <p className="text-sm">{note}</p> : null}
    </div>
  );
}
