"use client";

import { useActionState } from "react";
import { saveFitSettings } from "@/app/actions/fit";
import { Button } from "@/components/ui/button";
import type { ActionState } from "@/lib/validators";

type Row = {
  id: string;
  label: string;
  need: number;
  factors: { key: string; label: string; weight: number; defaultWeight: number; note: string }[];
};

export function FitWeightsForm({ roles }: { roles: Row[] }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(saveFitSettings, {});
  return (
    <form action={action} className="grid gap-4">
      {roles.map((role) => (
        <fieldset key={role.id} className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <legend className="font-display text-xl tracking-wide">{role.label}</legend>
          <label className="flex items-center justify-between gap-3 text-sm font-semibold">
            Players needed
            <input
              type="number"
              name={`need:${role.id}`}
              defaultValue={role.need}
              min={0}
              max={20}
              inputMode="numeric"
              className="w-20 rounded-lg border border-input bg-card px-3 py-2 text-base"
            />
          </label>
          {role.factors.map((f) => (
            <label key={f.key} className="flex items-center justify-between gap-3 text-sm">
              <span>
                {f.label}
                <span className="text-muted-foreground">
                  {f.note ? ` · ${f.note}` : ""} · default {f.defaultWeight}
                </span>
              </span>
              <input
                type="number"
                step="0.25"
                min={0}
                max={10}
                inputMode="decimal"
                name={`w:${role.id}:${f.key}`}
                defaultValue={f.weight}
                className="w-20 rounded-lg border border-input bg-card px-3 py-2 text-base"
              />
            </label>
          ))}
        </fieldset>
      ))}
      <div className="sticky bottom-3 grid gap-2">
        <Button type="submit" size="touch" disabled={pending}>
          {pending ? "Saving…" : "Save weights & needs"}
        </Button>
        {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
        {state.message ? <p className="rounded-lg bg-card p-2 text-sm ring-1 ring-foreground/10">{state.message}</p> : null}
      </div>
    </form>
  );
}
