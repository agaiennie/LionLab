"use client";

import { useActionState } from "react";
import { updateTeamSettings } from "@/app/actions/daily";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { ActionState } from "@/lib/validators";

export function StandardsForm({
  seasonLabel,
  studyGateEnabled,
  studyGoalMinutes,
  workMinutes,
  breakMinutes,
  weeklyStudyMinutes,
  publicSite,
}: {
  seasonLabel: string;
  studyGateEnabled: boolean;
  studyGoalMinutes: number;
  workMinutes: number;
  breakMinutes: number;
  /** Weekly study requirement (Mon–Sun). Field shows only when given. */
  weeklyStudyMinutes?: number;
  /** When given, the form also edits the public program page. joinCode is editable only when canEditJoinCode. */
  publicSite?: {
    teamName: string;
    levelLabel: string;
    publicBlurb: string;
    joinCode: string;
    canEditJoinCode: boolean;
  };
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(updateTeamSettings, {});
  return (
    <form action={action} className="grid gap-4">
      {state.message ? <p className="rounded-lg bg-accent px-3 py-2 text-sm">{state.message}</p> : null}
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      <div className="grid gap-1.5">
        <Label htmlFor="season">Season</Label>
        <Input id="season" name="seasonLabel" defaultValue={seasonLabel} required className="h-11 text-base" />
        {state.fieldErrors?.seasonLabel ? (
          <p className="text-sm text-destructive">{state.fieldErrors.seasonLabel}</p>
        ) : null}
      </div>
      <label className="flex items-start gap-3 text-sm">
        <input
          type="checkbox"
          name="studyGateEnabled"
          defaultChecked={studyGateEnabled}
          className="mt-1 size-4 accent-[#C8102E]"
        />
        <span>
          <span className="font-semibold">Study gate for home sessions</span>
          <span className="mt-1 block text-muted-foreground">
            Home mobility, home training, and home body-tracker saves need today&apos;s study block or a parent note. Field logs stay open.
          </span>
        </span>
      </label>
      <div className="grid gap-3 sm:grid-cols-3">
        <NumberField
          id="goal"
          name="studyGoalMinutes"
          label="Study goal (min)"
          defaultValue={studyGoalMinutes}
          error={state.fieldErrors?.studyGoalMinutes}
        />
        <NumberField
          id="work"
          name="workMinutes"
          label="Timer work"
          defaultValue={workMinutes}
          error={state.fieldErrors?.workMinutes}
        />
        <NumberField
          id="break"
          name="breakMinutes"
          label="Timer break"
          defaultValue={breakMinutes}
          error={state.fieldErrors?.breakMinutes}
        />
      </div>
      {publicSite ? (
        <fieldset className="grid gap-3 border-t border-border pt-4">
          <legend className="font-display text-xl tracking-wide">Public program page</legend>
          <TextField id="teamName" name="teamName" label="Team name" defaultValue={publicSite.teamName} error={state.fieldErrors?.teamName} />
          <TextField id="levelLabel" name="levelLabel" label="Level" defaultValue={publicSite.levelLabel} error={state.fieldErrors?.levelLabel} />
          <div className="grid gap-1.5">
            <Label htmlFor="publicBlurb">Blurb for families</Label>
            <Textarea
              id="publicBlurb"
              name="publicBlurb"
              rows={4}
              maxLength={1000}
              defaultValue={publicSite.publicBlurb}
              placeholder="Leave blank to use the default welcome."
              className="text-base"
            />
            {state.fieldErrors?.publicBlurb ? <p className="text-sm text-destructive">{state.fieldErrors.publicBlurb}</p> : null}
          </div>
          {publicSite.canEditJoinCode ? (
            <TextField id="joinCode" name="joinCode" label="Team join code" defaultValue={publicSite.joinCode} error={state.fieldErrors?.joinCode} />
          ) : (
            <div className="grid gap-1.5">
              <Label htmlFor="joinCode-view">Team join code</Label>
              <Input id="joinCode-view" value={publicSite.joinCode} readOnly disabled className="h-11 text-base" />
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            Families type the join code on the sign-up page. {publicSite.canEditJoinCode ? "Rotate it each season." : "Only an admin can change it."}
          </p>
        </fieldset>
      ) : null}
      {weeklyStudyMinutes != null ? (
      <div className="grid gap-1.5">
        <NumberField
          id="weekly"
          name="weeklyStudyMinutes"
          label="Weekly study requirement (min, Mon–Sun)"
          defaultValue={weeklyStudyMinutes}
          error={state.fieldErrors?.weeklyStudyMinutes}
        />
        <p className="text-sm text-muted-foreground">
          Academics first. Athletes on academic Watch get 1.5× this target and a weekly check-in.
        </p>
      </div>
      ) : null}
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Saving…" : "Save standard"}
      </Button>
    </form>
  );
}

function TextField({
  id,
  name,
  label,
  defaultValue,
  error,
}: {
  id: string;
  name: string;
  label: string;
  defaultValue: string;
  error?: string;
}) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} name={name} defaultValue={defaultValue} required className="h-11 text-base" />
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
    </div>
  );
}

function NumberField({
  id,
  name,
  label,
  defaultValue,
  error,
}: {
  id: string;
  name: string;
  label: string;
  defaultValue: number;
  error?: string;
}) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        name={name}
        type="number"
        defaultValue={defaultValue}
        required
        className="h-11 text-base"
      />
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
    </div>
  );
}
