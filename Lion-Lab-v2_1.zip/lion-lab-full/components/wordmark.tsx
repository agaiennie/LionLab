import { cn } from "cn";

export function Wordmark({ tone = "dark" }: { tone?: "dark" | "light" }) {
  return (
    <span className="block leading-none">
      <span
        className={cn(
          "font-display text-[1.7rem] font-semibold tracking-[0.16em]",
          tone === "light" ? "text-white" : "text-ink",
        )}
      >
        LION LAB
      </span>
      <span className="mt-1 block font-display text-[0.7rem] font-semibold tracking-[0.22em] text-lion">
        RED LION FOOTBALL
      </span>
    </span>
  );
}
