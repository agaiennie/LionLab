import Link from "next/link";
import { loadFitConfig, loadFitRoster } from "@/lib/fit-data";
import { confidenceWord, fitRoles, ROLE_BY_ID } from "@/lib/position-fit";

/**
 * Top position fits for one athlete. Server component.
 * The caller must already have checked the viewer may see this athlete.
 * Scores compare against the whole active roster, but only this athlete's
 * standing is shown — no teammate names or numbers leak to families.
 */
export async function FitCard({
  athleteId,
  audience,
  limit = 3,
}: {
  athleteId: string;
  audience: "staff" | "family";
  limit?: number;
}) {
  const [{ roles }, roster] = await Promise.all([loadFitConfig(), loadFitRoster()]);
  const athlete = roster.find((a) => a.id === athleteId);
  if (!athlete) return null;
  const fits = fitRoles(athlete, roster, roles).slice(0, limit);
  const top = fits[0];
  const measuredCount = Object.keys(athlete.latest).length;

  return (
    <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="font-display text-2xl tracking-wide">Position fit · ESTIMATE</h2>
          <p className="text-sm text-muted-foreground">
            Declared: {athlete.positions.join(", ") || "none"} · {measuredCount} tests on file
          </p>
        </div>
        {audience === "staff" ? (
          <Link href="/coach/fit" className="text-sm font-semibold text-lion">
            Team board
          </Link>
        ) : null}
      </div>
      {!top || top.confidence < 0.3 ? (
        <p className="text-sm text-muted-foreground">
          Not enough tests yet. Run the Test day battery (sprints, 5-10-5, long jump, ball toss, balance, flexibility) and this fills in.
        </p>
      ) : (
        <ol className="grid gap-3">
          {fits.map((fit, i) => (
            <li key={fit.role} className="rounded-lg border border-border p-3">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="font-display text-xl tracking-wide">
                  {i + 1}. {fit.label}
                </p>
                <p className="text-sm">
                  <span className="font-semibold">{fit.score}</span>/100 · confidence {confidenceWord(fit.confidence)}
                </p>
              </div>
              <p className="text-sm text-muted-foreground">{ROLE_BY_ID[fit.role].job}</p>
              {fit.strengths.length ? (
                <p className="mt-1 text-sm">
                  <span className="font-semibold">Why:</span> {fit.strengths.join(" · ")}
                </p>
              ) : null}
              {fit.work.length ? (
                <p className="mt-1 text-sm">
                  <span className="font-semibold">Work on:</span> {fit.work.join(" · ")}
                </p>
              ) : null}
              {fit.missing.length ? (
                <p className="mt-1 text-sm text-muted-foreground">Needs a test: {fit.missing.join(", ")}</p>
              ) : null}
            </li>
          ))}
        </ol>
      )}
      <p className="text-xs text-muted-foreground">
        {audience === "family"
          ? "This is a coaching estimate from test numbers, height, and weight. Bodies change fast in junior high — a late growth spurt can change the answer. Coaches make position decisions, and effort, attitude, and grades count too."
          : "Weighted team percentiles (same grade band when 8+ are tested; coaching anchors otherwise). Adjust weights on the team board. Not a depth chart by itself."}
      </p>
    </section>
  );
}
