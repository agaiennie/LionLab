"use client";

import Link from "next/link";
import { useState } from "react";
import { FAST, FAST_COACH_RULE, FAST_FINISH, FAST_LINE } from "@/lib/content/fast";
import { TESTS } from "@/lib/scoring";
import { cn } from "cn";

const tabs = [
  { id: "fast", label: "FAST" },
  { id: "play", label: "Declared play" },
  { id: "mobility", label: "Mobility" },
  { id: "measure", label: "Measure" },
] as const;

type TabId = (typeof tabs)[number]["id"];

export function FieldDeck({
  drills,
  catalog,
}: {
  drills: { name: string; cue: string; dose: string; stop: string }[];
  catalog: { name: string; cue: string }[];
}) {
  const [tab, setTab] = useState<TabId>("fast");

  return (
    <div className="grid gap-4">
      <div className="flex gap-2 overflow-x-auto print:hidden">
        {tabs.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={cn(
              "shrink-0 rounded-full px-4 py-2 text-sm font-semibold",
              tab === item.id ? "bg-lion text-white" : "bg-card ring-1 ring-foreground/10",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      <section className={cn("min-h-[70vh]", tab === "fast" ? "block" : "hidden print:block")}>
        <p className="font-display text-sm tracking-[0.18em] text-lion">LION STANDARD</p>
        <ul className="mt-4 grid gap-4">
          {FAST.map((item) => (
            <li key={item.letter}>
              <p className="font-display text-5xl tracking-wide sm:text-6xl">
                <span className="text-lion">{item.letter}</span> {item.word}
              </p>
              <p className="mt-1 text-lg">{item.doThis}</p>
            </li>
          ))}
        </ul>
        <ul className="mt-6 grid gap-2 text-lg">
          {FAST_FINISH.map((finish) => (
            <li key={finish.role}>
              <span className="font-semibold">{finish.role}.</span> {finish.detail}
            </li>
          ))}
        </ul>
        <p className="mt-6 font-semibold">{FAST_LINE}</p>
        <p className="mt-2 text-sm text-muted-foreground">{FAST_COACH_RULE}</p>
        <p className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm font-semibold">
          <Link href="/skills/first-step" className="text-lion">Teach F</Link>
          <Link href="/skills/attack-contact" className="text-lion">Teach A</Link>
          <Link href="/skills/athletic-stance" className="text-lion">Teach S</Link>
          <Link href="/skills/tackle-wrap" className="text-lion">Through — tackle</Link>
          <Link href="/skills/ol-finish-block" className="text-lion">Through — block</Link>
        </p>
      </section>
      <section className={cn("min-h-[70vh]", tab === "play" ? "block" : "hidden print:block")}>
        <p className="font-display text-sm tracking-[0.18em] text-lion">THIS SNAP</p>
        <h2 className="mt-3 font-display text-5xl leading-none tracking-wide sm:text-7xl">
          Declared play. Win your one.
        </h2>
        <p className="mt-4 text-xl">Do your job. Win your one landmark.</p>
        <p className="mt-2 text-lg text-muted-foreground">Do not play everyone else's assignment.</p>
      </section>
      <section className={cn(tab === "mobility" ? "block" : "hidden print:block")}>
        <p className="font-display text-sm tracking-[0.18em] text-lion">COACH CARD</p>
        <h2 className="font-display text-4xl tracking-wide">Today's mobility</h2>
        <ul className="mt-4 grid gap-3">
          {drills.map((drill) => (
            <li key={drill.name} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <p className="font-display text-3xl tracking-wide">{drill.name}</p>
              <p className="text-lg">{drill.cue}</p>
              <p className="mt-1 text-sm text-muted-foreground">{drill.dose}</p>
              <p className="mt-1 text-sm">Stop: {drill.stop}</p>
            </li>
          ))}
        </ul>
        <h3 className="mt-6 font-display text-2xl tracking-wide">Cue list</h3>
        <ul className="mt-2 grid gap-1 text-sm">
          {catalog.map((drill) => (
            <li key={drill.name}>
              <span className="font-semibold">{drill.name}.</span> {drill.cue}
            </li>
          ))}
        </ul>
      </section>
      <section className={cn(tab === "measure" ? "block" : "hidden print:block")}>
        <p className="font-display text-sm tracking-[0.18em] text-lion">HOW TO TEST</p>
        <ul className="mt-4 grid gap-4">
          {Object.values(TESTS).map((test) => (
            <li key={test.type} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <p className="font-display text-3xl tracking-wide">{test.label}</p>
              <p className="mt-2">{test.protocol}</p>
              <ul className="mt-2 list-disc pl-5 text-sm">
                {test.items.map((item) => (
                  <li key={item.id}>{item.label}</li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-sm text-muted-foreground">
          Raw is the clock or the tape. The adjusted number is an ESTIMATE. Log it from the athlete's page.
        </p>
      </section>
    </div>
  );
}
