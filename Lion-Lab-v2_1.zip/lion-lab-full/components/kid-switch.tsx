import { Button } from "@/components/ui/button";

export function KidSwitch({
  athletes,
  current,
  path,
}: {
  athletes: { id: string; name: string }[];
  current: string;
  path: string;
}) {
  if (athletes.length < 2) return null;
  return (
    <form action={path} className="mb-4 flex flex-wrap items-center gap-2">
      <label htmlFor={`${path}-kid`} className="text-sm font-semibold">
        Athlete
      </label>
      <select
        id={`${path}-kid`}
        name="athlete"
        defaultValue={current}
        className="h-11 rounded-lg border border-input bg-card px-3 text-base"
      >
        {athletes.map((athlete) => (
          <option key={athlete.id} value={athlete.id}>
            {athlete.name}
          </option>
        ))}
      </select>
      <Button type="submit" variant="outline" size="touch">
        Show
      </Button>
    </form>
  );
}
