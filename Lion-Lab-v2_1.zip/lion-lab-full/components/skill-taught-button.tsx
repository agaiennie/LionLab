import { toggleSkillTaught } from "@/app/actions/skills";

export function SkillTaughtButton({
  athleteId,
  skillId,
  taught,
}: {
  athleteId: string;
  skillId: string;
  taught: boolean;
}) {
  return (
    <form action={toggleSkillTaught}>
      <input type="hidden" name="athleteId" value={athleteId} />
      <input type="hidden" name="skillId" value={skillId} />
      <button
        type="submit"
        className={
          taught
            ? "h-11 rounded-lg bg-ink px-4 text-sm font-semibold text-white"
            : "h-11 rounded-lg bg-card px-4 text-sm font-semibold ring-1 ring-foreground/10"
        }
      >
        {taught ? "Taught this week" : "Mark taught"}
      </button>
    </form>
  );
}
