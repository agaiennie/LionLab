"use client";

import { useActionState } from "react";
import { saveAcademicStatus } from "@/app/actions/academics";
import { Button } from "@/components/ui/button";
import type { ActionState } from "@/lib/validators";

const selectClass = "h-11 rounded-lg border border-input bg-card px-3 text-base";

export function AcademicForm({
  athleteId,
  mode,
  status,
  note,
}: {
  athleteId: string;
  mode: "staff" | "parent";
  status: string;
  note: string;
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(saveAcademicStatus, {});
  const options =
    mode === "staff"
      ? [
          { value: "GOOD", label: "Good — cleared" },
          { value: "WATCH", label: "Watch — extra study, weekly check-in" },
          { value: "HOLD", label: "Hold — no game until grades are fixed" },
        ]
      : [
          { value: "GOOD", label: "Good — grades are passing" },
          { value: "WATCH", label: "Watch — a grade is slipping" },
        ];
  const held = mode === "parent" && status === "HOLD";
  return (
    <form action={action} className="grid gap-3">
      <input type="hidden" name="athleteId" value={athleteId} />
      {held ? (
        <>
          <input type="hidden" name="status" value="GOOD" />
          <p className="text-sm text-muted-foreground">
            A coach clears a Hold. Leave a note about grades and the coach will see it.
          </p>
        </>
      ) : (
        <label className="grid gap-1 text-sm font-semibold" htmlFor={`academic-status-${athleteId}`}>
          {mode === "staff" ? "Status" : "Update"}
          <select
            id={`academic-status-${athleteId}`}
            name="status"
            defaultValue={status === "HOLD" && mode === "parent" ? "WATCH" : status}
            className={selectClass}
          >
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
      )}
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`academic-note-${athleteId}`}>
        Note {mode === "parent" ? "for the coach" : "(athlete and parents can see it)"}
        <textarea
          id={`academic-note-${athleteId}`}
          name="note"
          rows={2}
          maxLength={300}
          defaultValue={mode === "staff" ? note : ""}
          className="rounded-lg border border-input bg-card px-3 py-2 text-base"
          placeholder={mode === "staff" ? "Math is a D. Study hall Tue/Thu." : "Science grade dropped. We're doing 20 extra minutes a night."}
        />
      </label>
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Saving…" : mode === "staff" ? "Save academic status" : "Send academic update"}
      </Button>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      {state.message ? <p className="rounded-lg bg-accent px-3 py-2 text-sm">{state.message}</p> : null}
    </form>
  );
}
