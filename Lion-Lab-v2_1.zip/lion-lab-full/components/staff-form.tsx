"use client";

import { useActionState } from "react";
import { createStaff } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { ActionState } from "@/lib/validators";

const fieldClass = "h-11 w-full rounded-lg border border-input bg-card px-3 text-base";

export function StaffForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(createStaff, {});

  return (
    <form action={action} className="grid gap-4">
      {state.message && !state.invite ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm">{state.message}</p>
      ) : null}
      {state.invite ? (
        <div className="rounded-lg bg-accent px-3 py-3 text-sm text-accent-foreground">
          <p>{state.message}</p>
          <p className="mt-2 font-semibold">
            {state.invite.name} · {state.invite.email}
          </p>
          <p>Password: {state.invite.temporaryPassword}</p>
        </div>
      ) : null}
      <div className="grid gap-1.5">
        <Label htmlFor="staff-name">Name</Label>
        <Input id="staff-name" name="name" required className="h-11 text-base" />
        {state.fieldErrors?.name ? <p className="text-sm text-destructive">{state.fieldErrors.name}</p> : null}
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="staff-email">Email</Label>
        <Input id="staff-email" name="email" type="email" required className="h-11 text-base" />
        {state.fieldErrors?.email ? <p className="text-sm text-destructive">{state.fieldErrors.email}</p> : null}
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="staff-password">Temporary password</Label>
        <Input id="staff-password" name="password" type="text" required minLength={8} className="h-11 text-base" />
        {state.fieldErrors?.password ? (
          <p className="text-sm text-destructive">{state.fieldErrors.password}</p>
        ) : null}
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="staff-role">Role</Label>
        <select id="staff-role" name="role" defaultValue="COACH" className={fieldClass}>
          <option value="COACH">Coach</option>
          <option value="ADMIN">Admin</option>
        </select>
      </div>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      <Button type="submit" size="touch" disabled={pending} className="w-fit">
        {pending ? "Saving…" : "Add staff"}
      </Button>
    </form>
  );
}
