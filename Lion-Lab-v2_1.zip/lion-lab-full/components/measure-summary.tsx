import { METRIC_GROUPS, formatMetric, isBetter, isMetricId, metricsInGroup, type MetricDef, type MetricId } from "@/lib/content/metrics";
import { prisma } from "@/lib/db";
import { formatRecordedOn } from "@/lib/format";

type Line = {
  metric: MetricId;
  side: string;
  latest: number;
  latestOn: Date;
  best: number;
  bestOn: Date;
  /** Oldest to newest, up to 3. */
  trend: number[];
  source: string;
};

function arrow(metric: MetricId, trend: number[]): string {
  if (trend.length < 2) return "";
  const a = trend[trend.length - 2];
  const b = trend[trend.length - 1];
  if (a === b) return "same";
  return isBetter(metric, b, a) ? "better" : "worse";
}

/**
 * "My numbers": latest value per metric (and side), personal best with date,
 * and a text trend of the last 3 results. Server component; the caller does the
 * access check (athlete self, linked parent, or staff).
 */
export async function MeasureSummary({
  athleteId,
  showEmpty = false,
  title = "My numbers",
}: {
  athleteId: string;
  showEmpty?: boolean;
  title?: string;
}) {
  const rows = await prisma.measurement.findMany({
    where: { athleteId },
    orderBy: [{ recordedOn: "desc" }, { createdAt: "desc" }],
    select: { metric: true, side: true, value: true, recordedOn: true, source: true },
  });

  const lines = new Map<string, Line>();
  for (const row of rows) {
    if (!isMetricId(row.metric)) continue;
    const key = `${row.metric}:${row.side}`;
    const line = lines.get(key);
    if (!line) {
      lines.set(key, {
        metric: row.metric,
        side: row.side,
        latest: row.value,
        latestOn: row.recordedOn,
        best: row.value,
        bestOn: row.recordedOn,
        trend: [row.value],
        source: row.source,
      });
      continue;
    }
    if (isBetter(row.metric, row.value, line.best)) {
      line.best = row.value;
      line.bestOn = row.recordedOn;
    }
    if (line.trend.length < 3) line.trend.unshift(row.value);
  }

  const groups = METRIC_GROUPS.map((group) => {
    const metrics = metricsInGroup(group.id);
    const items = metrics.flatMap((m): { def: MetricDef; line: Line | null }[] => {
      const found = [...lines.values()].filter((l) => l.metric === m.id).sort((a, b) => a.side.localeCompare(b.side));
      if (found.length) return found.map((line) => ({ def: m, line }));
      return showEmpty ? [{ def: m, line: null }] : [];
    });
    return { group, items };
  }).filter((g) => g.items.length > 0);

  return (
    <section className="grid gap-3" data-testid="measure-summary">
      <h2 className="font-display text-3xl tracking-wide">{title}</h2>
      {groups.length === 0 ? (
        <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">
          No test-day numbers yet. Sprints, jumps, flexibility, and balance show up here once a coach logs them.
        </p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {groups.map(({ group, items }) => (
            <div key={group.id} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <h3 className="font-display text-xl tracking-wide">{group.label}</h3>
              <ul className="mt-2 grid gap-2">
                {items.map(({ def, line }) => (
                  <li key={`${def.id}:${line?.side ?? ""}`} className="grid gap-0.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-sm font-semibold">
                        {def.label}
                        {line?.side ? ` · ${line.side === "L" ? "left" : "right"}` : ""}
                      </span>
                      <span className="font-display text-2xl tracking-wide">
                        {line ? formatMetric(def.id, line.latest) : "—"}
                      </span>
                    </div>
                    {line ? (
                      <p className="text-xs text-muted-foreground">
                        {formatRecordedOn(line.latestOn.toISOString())}
                        {line.source === "CAMERA" ? " · camera" : line.source === "STOPWATCH" ? " · hand time" : ""} · best{" "}
                        {formatMetric(def.id, line.best)} ({formatRecordedOn(line.bestOn.toISOString())})
                        {line.trend.length > 1 ? (
                          <>
                            {" "}
                            · last {line.trend.length}: {line.trend.map((v) => formatMetric(def.id, v)).join(" → ")} (
                            {arrow(def.id, line.trend)})
                          </>
                        ) : null}
                      </p>
                    ) : (
                      <p className="text-xs text-muted-foreground">Not tested yet.</p>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
