"use client";

import { useActionState, useMemo, useState } from "react";
import { saveSession } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FORMULA_VERSION, TESTS, scoreTest, type TestType } from "@/lib/scoring";
import type { ActionState } from "@/lib/validators";

export function TestForm({
  athleteId,
  sessionId,
  initial,
}: {
  athleteId: string;
  sessionId: string | null;
  initial?: {
    testType: TestType;
    rawValue: number | null;
    passedIds: string[];
    notes: string;
    recordedOn: string;
  };
}) {
  const action = saveSession.bind(null, athleteId, sessionId);
  const [state, formAction, pending] = useActionState<ActionState, FormData>(action, {});
  const [testType, setTestType] = useState<TestType>(initial?.testType ?? "FORTY");
  const [raw, setRaw] = useState(
    initial?.rawValue == null ? "" : String(initial.rawValue),
  );
  const [passed, setPassed] = useState<string[]>(initial?.passedIds ?? []);
  const test = TESTS[testType];

  const preview = useMemo(() => {
    const numeric = Number(raw);
    const rawValue = test.unit && Number.isFinite(numeric) && raw.trim() !== "" ? numeric : null;
    return scoreTest(testType, rawValue, passed);
  }, [passed, raw, test.unit, testType]);

  function toggle(id: string, checked: boolean) {
    setPassed((current) => {
      if (checked) return current.includes(id) ? current : [...current, id];
      return current.filter((item) => item !== id);
    });
  }

  return (
    <form action={formAction} className="grid gap-6">
      <fieldset className="grid gap-2">
        <legend className="text-sm font-medium">Test</legend>
        <div className="grid gap-2 sm:grid-cols-3">
          {(Object.keys(TESTS) as TestType[]).map((type) => (
            <label
              key={type}
              className={`cursor-pointer rounded-xl border px-3 py-3 ${
                testType === type ? "border-lion bg-accent" : "border-border bg-card"
              }`}
            >
              <input
                type="radio"
                name="testType"
                value={type}
                checked={testType === type}
                onChange={() => setTestType(type)}
                className="sr-only"
              />
              <span className="block font-display text-xl tracking-wide">{TESTS[type].short}</span>
              <span className="text-sm text-muted-foreground">{TESTS[type].label}</span>
            </label>
          ))}
        </div>
      </fieldset>

      <div className="rounded-xl bg-ink px-4 py-3 text-sm text-white/90">{test.protocol}</div>

      <div className="grid gap-4 sm:grid-cols-2">
        {test.unit ? (
          <div className="grid gap-1.5">
            <Label htmlFor="raw">{test.unit === "seconds" ? "Time (seconds)" : "Distance (feet)"}</Label>
            <Input
              id="raw"
              name="raw"
              inputMode="decimal"
              value={raw}
              onChange={(event) => setRaw(event.target.value)}
              className="h-11 text-base"
              required
            />
            {state.fieldErrors?.raw ? <p className="text-sm text-destructive">{state.fieldErrors.raw}</p> : null}
          </div>
        ) : (
          <input type="hidden" name="raw" value="" />
        )}
        <div className="grid gap-1.5">
          <Label htmlFor="recordedOn">Date</Label>
          <Input
            id="recordedOn"
            name="recordedOn"
            type="date"
            defaultValue={initial?.recordedOn}
            required
            className="h-11 text-base"
          />
          {state.fieldErrors?.recordedOn ? (
            <p className="text-sm text-destructive">{state.fieldErrors.recordedOn}</p>
          ) : null}
        </div>
      </div>

      <fieldset className="grid gap-2">
        <legend className="text-sm font-medium">Form checklist</legend>
        <p className="text-sm text-muted-foreground">
          Check an item only if it was solid on the rep you are logging. {preview.passedCount} of{" "}
          {preview.totalCount} checked.
        </p>
        {test.items.map((item) => (
          <div
            key={item.id}
            className="flex items-start gap-3 rounded-xl border border-border bg-card px-3 py-3"
          >
            <Checkbox
              id={`check-${testType}-${item.id}`}
              name="passed"
              value={item.id}
              checked={passed.includes(item.id)}
              onCheckedChange={(checked) => toggle(item.id, checked)}
              className="mt-1 size-5"
            />
            <label htmlFor={`check-${testType}-${item.id}`} className="grid gap-0.5">
              <span className="font-semibold">{item.label}</span>
              <span className="text-sm text-muted-foreground">{item.cue}</span>
            </label>
          </div>
        ))}
      </fieldset>

      <div className="grid gap-1.5">
        <Label htmlFor="notes">Coach note</Label>
        <Textarea
          id="notes"
          name="notes"
          defaultValue={initial?.notes ?? ""}
          maxLength={500}
          placeholder="What should they remember next practice?"
          className="min-h-24 text-base"
        />
        {state.fieldErrors?.notes ? <p className="text-sm text-destructive">{state.fieldErrors.notes}</p> : null}
      </div>

      <div className="sticky bottom-3 grid gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
        <div className="grid grid-cols-3 gap-2">
          <PreviewStat label="Raw" value={preview.rawLabel} />
          <PreviewStat label="Form" value={`${preview.percent}%`} />
          <PreviewStat label="Adjusted ESTIMATE" value={preview.estimate.display} emphasize />
        </div>
        <p className="text-xs text-muted-foreground">
          Formula {FORMULA_VERSION} · {preview.estimate.math}
        </p>
        <p className="text-sm">{preview.retest}</p>
        {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
        <Button type="submit" size="touch" disabled={pending}>
          {pending ? "Saving…" : sessionId ? "Update test" : "Save test"}
        </Button>
      </div>
    </form>
  );
}

function PreviewStat({
  label,
  value,
  emphasize = false,
}: {
  label: string;
  value: string;
  emphasize?: boolean;
}) {
  return (
    <div>
      <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className={`font-display text-2xl leading-none font-semibold ${emphasize ? "text-lion" : ""}`}>
        {value}
      </p>
    </div>
  );
}
