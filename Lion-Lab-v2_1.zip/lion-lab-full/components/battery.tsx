import { ResultCard, resultProps } from "@/components/result-card";
import { latestByType, type AthleteRecord } from "@/lib/data";
import { TEST_TYPES } from "@/lib/scoring";

export function Battery({
  athlete,
  logHref,
}: {
  athlete: AthleteRecord;
  logHref?: string;
}) {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {TEST_TYPES.map((type) => {
        const latest = latestByType(athlete, type);
        if (!latest) {
          return <ResultCard key={type} testType={type} emptyHref={logHref} />;
        }
        return <ResultCard key={type} {...resultProps(latest)} />;
      })}
    </div>
  );
}
