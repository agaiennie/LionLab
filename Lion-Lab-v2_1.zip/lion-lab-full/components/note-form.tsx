"use client";

import { useActionState } from "react";
import { addCoachNote } from "@/app/actions/daily";
import { Button } from "@/components/ui/button";
import type { ActionState } from "@/lib/validators";

export function NoteForm({ athleteId }: { athleteId: string }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(addCoachNote, {});
  return (
    <form action={action} className="grid gap-2">
      <input type="hidden" name="athleteId" value={athleteId} />
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`note-${athleteId}`}>
        Note for home
        <textarea
          id={`note-${athleteId}`}
          name="body"
          required
          rows={3}
          maxLength={500}
          className="rounded-lg border border-input bg-card px-3 py-2 text-base"
          placeholder="Study before the extra throws. Finish through the line."
        />
      </label>
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Saving…" : "Save note"}
      </Button>
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      {state.message ? <p className="text-sm">{state.message}</p> : null}
    </form>
  );
}
