"use client";

import Link from "next/link";
import { useActionState } from "react";
import { submitInterest, type FormEchoState } from "@/app/actions/signup";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { HONEYPOT, SPORTS } from "@/lib/signup";

export function JoinForm({ defaultSchool }: { defaultSchool: string }) {
  const [state, action, pending] = useActionState<FormEchoState, FormData>(submitInterest, {});
  const values = state.values ?? {};
  const errors = state.fieldErrors ?? {};
  const pickedSports = (values.sports ?? "").split("|");

  if (state.message && !state.fieldErrors) {
    return (
      <div className="grid gap-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10" role="status">
        <p className="font-display text-3xl tracking-wide text-lion">Thank you!</p>
        <p className="text-lg">{state.message}</p>
        <p className="text-muted-foreground">No experience needed. Bring sneakers, water, and a good attitude.</p>
        <Link href="/" className="font-semibold text-lion">
          ← Program home
        </Link>
      </div>
    );
  }

  return (
    <form key={JSON.stringify(values)} action={action} className="grid gap-5">
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor={HONEYPOT}>Leave this empty</label>
        <input id={HONEYPOT} name={HONEYPOT} type="text" tabIndex={-1} autoComplete="off" defaultValue="" />
      </div>
      {Object.keys(errors).length > 0 ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm" role="alert">
          Check the boxes marked in red.
        </p>
      ) : null}

      <section className="grid gap-4">
        <h2 className="font-display text-2xl tracking-wide">About the student</h2>
        <Field id="name" label="Student name" error={errors.name} defaultValue={values.name} required />
        <div className="grid gap-1.5">
          <Label htmlFor="grade" className="text-base">
            Grade
          </Label>
          <select
            id="grade"
            name="grade"
            defaultValue={values.grade ?? ""}
            className="h-12 rounded-lg border border-input bg-background px-3 text-base"
          >
            <option value="">Pick a grade</option>
            {[5, 6, 7, 8, 9].map((grade) => (
              <option key={grade} value={grade}>
                {grade}th grade
              </option>
            ))}
          </select>
          <FieldError message={errors.grade} />
        </div>
        <Field id="school" label="School" defaultValue={values.school ?? defaultSchool} error={errors.school} />
        <fieldset className="grid gap-2">
          <legend className="mb-1 text-base font-semibold">Sports they play now</legend>
          <p className="-mt-1 mb-1 text-sm text-muted-foreground">
            None is a great answer. Lots of our players never played a sport before.
          </p>
          <div className="grid grid-cols-2 gap-2">
            {SPORTS.map((sport) => (
              <label
                key={sport}
                className="flex min-h-11 items-center gap-2 rounded-lg border border-border bg-card px-3 text-base has-checked:border-lion"
              >
                <input
                  type="checkbox"
                  name="sports"
                  value={sport}
                  defaultChecked={pickedSports.includes(sport)}
                  className="size-5 accent-[#C8102E]"
                />
                {sport}
              </label>
            ))}
          </div>
          <Input
            name="sportsOther"
            placeholder="Other sport or activity (dance, martial arts, band…)"
            defaultValue={values.sportsOther}
            className="h-12 text-base"
            aria-label="Other sport or activity"
          />
        </fieldset>
        <div className="grid gap-1.5">
          <Label htmlFor="interest" className="text-base">
            What sounds fun? (optional)
          </Label>
          <Textarea
            id="interest"
            name="interest"
            rows={3}
            defaultValue={values.interest}
            placeholder="Running fast, hitting, catching, being on a team, getting stronger…"
            className="text-base"
          />
        </div>
        <div className="grid gap-1.5">
          <p className="text-base font-semibold">Height and weight (optional)</p>
          <p className="-mt-1 text-sm text-muted-foreground">
            Skip it if you don&apos;t know. Every size has a spot on a football team.
          </p>
          <div className="grid grid-cols-3 gap-2">
            <Input name="feet" type="number" min={3} max={7} placeholder="ft" defaultValue={values.feet} className="h-12 text-base" aria-label="Height feet" />
            <Input name="inches" type="number" min={0} max={11} placeholder="in" defaultValue={values.inches} className="h-12 text-base" aria-label="Height inches" />
            <Input name="weightLbs" type="number" min={50} max={400} placeholder="lb" defaultValue={values.weightLbs} className="h-12 text-base" aria-label="Weight in pounds" />
          </div>
          <FieldError message={errors.height ?? errors.weightLbs} />
        </div>
      </section>

      <section className="grid gap-4">
        <h2 className="font-display text-2xl tracking-wide">Parent or guardian</h2>
        <p className="-mt-2 text-sm text-muted-foreground">A coach contacts the parent or guardian, not the student.</p>
        <Field id="parentName" label="Parent or guardian name" error={errors.parentName} defaultValue={values.parentName} required />
        <Field
          id="parentEmail"
          label="Parent or guardian email"
          type="email"
          error={errors.parentEmail}
          defaultValue={values.parentEmail}
          required
        />
      </section>

      <Button type="submit" size="touch" disabled={pending} className="h-12 text-lg">
        {pending ? "Sending…" : "Send to the coaches"}
      </Button>
    </form>
  );
}

function Field({
  id,
  label,
  error,
  ...props
}: { id: string; label: string; error?: string } & React.ComponentProps<"input">) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id} className="text-base">
        {label}
      </Label>
      <Input id={id} name={id} aria-invalid={error ? true : undefined} className="h-12 text-base" {...props} />
      <FieldError message={error} />
    </div>
  );
}

function FieldError({ message }: { message?: string }) {
  return message ? <p className="text-sm text-destructive">{message}</p> : null;
}
