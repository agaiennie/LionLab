"use client";

import { useActionState, useEffect, useRef } from "react";
import { createExam, deleteExam, deleteQuestion, saveQuestion, updateExamMeta } from "@/app/actions/exams";
import { Button } from "@/components/ui/button";
import type { ActionState } from "@/lib/validators";

const field = "rounded-lg border border-input bg-card px-3 py-2 text-base";
const AUDIENCES = [
  { code: "QB", label: "Quarterbacks" },
  { code: "MLB", label: "Middle linebackers" },
  { code: "CAPTAIN", label: "Captains" },
  { code: "ALL", label: "Everyone" },
];

function Err({ state, name }: { state: ActionState; name: string }) {
  const text = state.fieldErrors?.[name];
  return text ? <span className="text-sm font-normal text-destructive">{text}</span> : null;
}

function Status({ state }: { state: ActionState }) {
  return (
    <>
      {state.error ? (
        <p className="text-sm text-destructive" role="alert">
          {state.error}
        </p>
      ) : null}
      {state.message ? <p className="text-sm">{state.message}</p> : null}
    </>
  );
}

export type ExamMeta = {
  id: string;
  title: string;
  audience: string;
  description: string;
  passPercent: number;
  published: boolean;
};

/** New exam (no `exam`) or edit exam meta. */
export function ExamMetaForm({ exam }: { exam?: ExamMeta }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(exam ? updateExamMeta : createExam, {});
  const id = exam?.id ?? "new";
  return (
    <form action={action} className="grid gap-3">
      {exam ? <input type="hidden" name="examId" value={exam.id} /> : null}
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`title-${id}`}>
        Title
        <input id={`title-${id}`} name="title" required maxLength={80} defaultValue={exam?.title} className={field} placeholder="Our base plays: 22 Power" />
        <Err state={state} name="title" />
      </label>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="grid gap-1 text-sm font-semibold" htmlFor={`audience-${id}`}>
          Who takes it
          <select id={`audience-${id}`} name="audience" defaultValue={exam?.audience ?? "ALL"} className={`${field} h-11`}>
            {AUDIENCES.map((a) => (
              <option key={a.code} value={a.code}>
                {a.label}
              </option>
            ))}
          </select>
          <Err state={state} name="audience" />
        </label>
        <label className="grid gap-1 text-sm font-semibold" htmlFor={`pass-${id}`}>
          Pass mark (%)
          <input id={`pass-${id}`} name="passPercent" type="number" inputMode="numeric" min={50} max={100} required defaultValue={exam?.passPercent ?? 80} className={`${field} h-11`} />
          <Err state={state} name="passPercent" />
        </label>
      </div>
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`desc-${id}`}>
        Description
        <textarea id={`desc-${id}`} name="description" rows={2} maxLength={400} defaultValue={exam?.description} className={field} placeholder="What this exam covers." />
        <Err state={state} name="description" />
      </label>
      {exam ? (
        <label className="flex min-h-11 items-center gap-3 text-base font-semibold">
          <input type="checkbox" name="published" defaultChecked={exam.published} className="size-6 accent-[#C8102E]" />
          Published (athletes can see and take it)
          <Err state={state} name="published" />
        </label>
      ) : null}
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Saving…" : exam ? "Save exam details" : "Create exam"}
      </Button>
      <Status state={state} />
    </form>
  );
}

export type EditorQuestion = {
  id: string;
  topic: string;
  prompt: string;
  choices: string[];
  answerIndex: number;
  explanation: string;
};

/** Add (no `question`) or edit one question. Five answer slots; blanks are dropped. */
export function QuestionForm({ examId, question }: { examId: string; question?: EditorQuestion }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(saveQuestion, {});
  const formRef = useRef<HTMLFormElement>(null);
  const id = question?.id ?? "new";

  useEffect(() => {
    if (!question && state.message) formRef.current?.reset();
  }, [state, question]);

  return (
    <form ref={formRef} action={action} className="grid gap-3">
      <input type="hidden" name="examId" value={examId} />
      {question ? <input type="hidden" name="questionId" value={question.id} /> : null}
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`topic-${id}`}>
        Topic (short)
        <input id={`topic-${id}`} name="topic" maxLength={40} defaultValue={question?.topic} className={field} placeholder="Trips right, Cover 3" />
        <Err state={state} name="topic" />
      </label>
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`prompt-${id}`}>
        Question
        <textarea id={`prompt-${id}`} name="prompt" rows={3} maxLength={600} required defaultValue={question?.prompt} className={field} placeholder="We run 22 Power vs a 4-3. The Will linebacker blitzes the B gap. Where does the QB look?" />
        <Err state={state} name="prompt" />
      </label>
      <fieldset className="grid gap-2">
        <legend className="mb-1 text-sm font-semibold">Answers: tap the circle next to the right one. Leave extra slots blank (2 to 5 answers).</legend>
        {[0, 1, 2, 3, 4].map((slot) => (
          <div key={slot} className="flex items-center gap-2">
            <input
              type="radio"
              name="correct"
              value={slot}
              defaultChecked={question ? question.answerIndex === slot : slot === 0}
              aria-label={`Answer ${slot + 1} is correct`}
              className="size-6 shrink-0 accent-[#C8102E]"
            />
            <input
              name={`choice${slot}`}
              maxLength={200}
              defaultValue={question?.choices[slot] ?? ""}
              aria-label={`Answer ${slot + 1}`}
              placeholder={slot < 2 ? `Answer ${slot + 1}` : `Answer ${slot + 1} (optional)`}
              className={`${field} w-full`}
            />
          </div>
        ))}
        <Err state={state} name="choices" />
        <Err state={state} name="answerIndex" />
      </fieldset>
      <label className="grid gap-1 text-sm font-semibold" htmlFor={`why-${id}`}>
        Why (shown after the exam)
        <textarea id={`why-${id}`} name="explanation" rows={2} maxLength={600} defaultValue={question?.explanation} className={field} placeholder="The blitzer left the hook zone. Hot throw to the slot." />
        <Err state={state} name="explanation" />
      </label>
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Saving…" : question ? "Save question" : "Add question"}
      </Button>
      <Status state={state} />
    </form>
  );
}

export function DeleteQuestionButton({ questionId }: { questionId: string }) {
  return (
    <form
      action={deleteQuestion}
      onSubmit={(event) => {
        if (!window.confirm("Delete this question? Past scores stay, but reviews of old attempts may not line up.")) {
          event.preventDefault();
        }
      }}
    >
      <input type="hidden" name="questionId" value={questionId} />
      <Button type="submit" variant="destructive" size="touch">
        Delete question
      </Button>
    </form>
  );
}

export function DeleteExamForm({ examId, attempts }: { examId: string; attempts: number }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(deleteExam, {});
  return (
    <form action={action} className="grid gap-3">
      <input type="hidden" name="examId" value={examId} />
      <label className="flex min-h-11 items-center gap-3 text-base">
        <input type="checkbox" name="confirm" className="size-6 accent-[#C8102E]" />
        Yes, delete this exam, its questions, and {attempts} {attempts === 1 ? "attempt" : "attempts"}.
      </label>
      <Err state={state} name="confirm" />
      <Button type="submit" variant="destructive" size="touch" disabled={pending}>
        {pending ? "Deleting…" : "Delete exam"}
      </Button>
      <Status state={state} />
    </form>
  );
}
