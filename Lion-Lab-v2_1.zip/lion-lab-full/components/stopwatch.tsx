"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type StopwatchResult =
  | { kind: "time"; ms: number; splitMs: number | null }
  | { kind: "count"; reps: number };

/**
 * Field stopwatch. performance.now() for timing (not Date), hundredths on screen,
 * phone-sized buttons stacked for one thumb.
 *  - mode "time": START / STOP, optional SPLIT (first tap only), RESET.
 *  - mode "count": 60-second clock with a giant +1 rep button (push-ups).
 */
export function Stopwatch({
  mode = "time",
  allowSplit = false,
  splitLabel = "SPLIT",
  countSeconds = 60,
  onDone,
  onReset,
}: {
  mode?: "time" | "count";
  allowSplit?: boolean;
  splitLabel?: string;
  countSeconds?: number;
  onDone?: (result: StopwatchResult) => void;
  onReset?: () => void;
}) {
  const [phase, setPhase] = useState<"ready" | "running" | "stopped">("ready");
  const [elapsed, setElapsed] = useState(0);
  const [split, setSplit] = useState<number | null>(null);
  const [reps, setReps] = useState(0);
  const startRef = useRef(0);
  const rafRef = useRef<number | null>(null);
  const repsRef = useRef(0);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  const stopLoop = () => {
    if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
  };

  useEffect(() => stopLoop, []);

  const buzz = (pattern: number | number[]) => {
    try {
      navigator.vibrate?.(pattern);
    } catch {
      // not supported
    }
  };

  const finish = useCallback(
    (ms: number) => {
      stopLoop();
      setElapsed(ms);
      setPhase("stopped");
      buzz([60, 40, 60]);
      if (mode === "count") doneRef.current?.({ kind: "count", reps: repsRef.current });
    },
    [mode],
  );

  function start() {
    startRef.current = performance.now();
    setElapsed(0);
    setSplit(null);
    setReps(0);
    repsRef.current = 0;
    setPhase("running");
    buzz(40);
    const loop = () => {
      const ms = performance.now() - startRef.current;
      if (mode === "count" && ms >= countSeconds * 1000) {
        finish(countSeconds * 1000);
        return;
      }
      setElapsed(ms);
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
  }

  function stop() {
    const ms = performance.now() - startRef.current;
    finish(ms);
    if (mode === "time") doneRef.current?.({ kind: "time", ms, splitMs: split });
  }

  function takeSplit() {
    if (split != null) return;
    const ms = performance.now() - startRef.current;
    setSplit(ms);
    buzz(30);
  }

  function addRep() {
    repsRef.current += 1;
    setReps(repsRef.current);
  }

  function reset() {
    stopLoop();
    setPhase("ready");
    setElapsed(0);
    setSplit(null);
    setReps(0);
    repsRef.current = 0;
    onReset?.();
  }

  const shown =
    mode === "count" ? Math.max(0, countSeconds - elapsed / 1000).toFixed(2) : (elapsed / 1000).toFixed(2);

  return (
    <div className="grid gap-3 select-none" data-testid="stopwatch">
      <div className="rounded-2xl bg-ink px-4 py-5 text-center text-white">
        <p className="font-mono text-7xl font-bold tabular-nums sm:text-8xl" aria-live="off" data-testid="stopwatch-time">
          {shown}
          <span className="ml-1 text-3xl text-white/60">s</span>
        </p>
        {mode === "count" ? (
          <p className="mt-1 text-2xl font-semibold" data-testid="stopwatch-reps">
            {reps} reps
          </p>
        ) : allowSplit ? (
          <p className="mt-1 text-xl text-white/80">
            {splitLabel}: {split == null ? "—" : `${(split / 1000).toFixed(2)}s`}
          </p>
        ) : null}
      </div>

      {phase === "ready" ? (
        <button
          type="button"
          onClick={start}
          className="h-40 w-full touch-manipulation rounded-2xl bg-emerald-700 font-display text-6xl tracking-wide text-white active:scale-[0.98]"
        >
          START
        </button>
      ) : null}

      {phase === "running" && mode === "time" ? (
        <div className="grid gap-3">
          {allowSplit ? (
            <button
              type="button"
              onClick={takeSplit}
              disabled={split != null}
              className="h-24 w-full touch-manipulation rounded-2xl bg-amber-400 font-display text-4xl tracking-wide text-ink disabled:opacity-40"
            >
              {splitLabel}
            </button>
          ) : null}
          <button
            type="button"
            onClick={stop}
            className="h-40 w-full touch-manipulation rounded-2xl bg-lion font-display text-6xl tracking-wide text-white active:scale-[0.98]"
          >
            STOP
          </button>
        </div>
      ) : null}

      {phase === "running" && mode === "count" ? (
        <div className="grid gap-3">
          <button
            type="button"
            onClick={addRep}
            className="h-48 w-full touch-manipulation rounded-2xl bg-emerald-700 font-display text-7xl tracking-wide text-white active:scale-[0.98]"
          >
            +1
          </button>
          <button
            type="button"
            onClick={() => finish(performance.now() - startRef.current)}
            className="h-16 w-full rounded-2xl bg-lion font-display text-3xl tracking-wide text-white"
          >
            STOP EARLY
          </button>
        </div>
      ) : null}

      {phase !== "ready" ? (
        <button
          type="button"
          onClick={reset}
          className="h-16 w-full touch-manipulation rounded-2xl border-2 border-foreground/20 bg-card font-display text-3xl tracking-wide"
        >
          RESET
        </button>
      ) : null}
    </div>
  );
}
