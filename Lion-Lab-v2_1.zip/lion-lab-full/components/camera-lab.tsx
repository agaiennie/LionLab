"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { saveMeasurements, type MeasureInput } from "@/app/actions/measure";
import { formatMetric } from "@/lib/content/metrics";
import { localDay } from "@/lib/habits";
import {
  BALANCE,
  balanceSeconds,
  bestSquat,
  newBalanceState,
  newSquatState,
  reachRead,
  readFeet,
  squatDone,
  stepBalance,
  stepSquat,
  swayPercent,
  toAspect,
  type BalanceState,
  type Pt,
  type Side,
  type SquatState,
} from "@/lib/pose-metrics";

type PoseApi = {
  init: () => Promise<unknown>;
  detect: (video: HTMLVideoElement, ts: number) => Promise<{ landmarks: Pt[] | null; timestamp: number } | null>;
  drawSkeleton: (
    ctx: CanvasRenderingContext2D,
    canvas: HTMLCanvasElement,
    landmarks: unknown,
    opts: { mirror?: boolean; band?: string },
  ) => void;
  syncCanvasSize: (canvas: HTMLCanvasElement, video: HTMLVideoElement) => void;
  resetClock?: () => void;
};

function poseApi(): PoseApi | undefined {
  return (window as unknown as { RLPose?: PoseApi }).RLPose;
}

function loadScript(src: string, module: boolean) {
  return new Promise<void>((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(`script[data-pose="${src}"]`);
    if (existing) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = src;
    script.dataset.pose = src;
    if (module) script.type = "module";
    script.onload = () => resolve();
    script.onerror = () => {
      script.remove();
      reject(new Error(src));
    };
    document.head.appendChild(script);
  });
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("timeout")), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      },
    );
  });
}

type Mode = "balance" | "squat" | "reach" | "form";

const MODES: { id: Mode; label: string; view: string; how: string }[] = [
  {
    id: "balance",
    label: "Single-leg balance",
    view: "Front view",
    how: "Face the phone. Hands on hips. Lift one foot and close your eyes: the clock starts itself and stops when the foot comes down (30 s cap).",
  },
  {
    id: "squat",
    label: "Deep squat check",
    view: "Side view",
    how: "Stand sideways to the phone, feet shoulder width, arms straight overhead. Squat as deep as you can, heels down, chest up. Three reps; best one counts.",
  },
  {
    id: "reach",
    label: "Sit and reach guide",
    view: "Side view",
    how: "Sit sideways to the phone, legs straight, soles against the box. Reach slowly and hold 2 seconds. The camera guides; the tape measure is the number.",
  },
  {
    id: "form",
    label: "Lift and stance form",
    view: "Side or front",
    how: "Squat, hinge, stance, and position drills are scored in the body tracker.",
  },
];

type CamState = "off" | "starting" | "on";

type Live = {
  seen: boolean;
  // balance
  phase?: BalanceState["phase"];
  seconds?: number;
  sway?: number | null;
  gap?: number;
  standing?: Side | null;
  stopReason?: string;
  // squat
  knee?: number | null;
  reps?: number;
  // reach
  ratio?: number | null;
  inches?: number | null;
};

export function CameraLab({
  staff,
  athletes,
  selfAthleteId,
  trackerHref,
}: {
  staff: boolean;
  athletes: { id: string; name: string }[];
  selfAthleteId: string | null;
  trackerHref: string;
}) {
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const runningRef = useRef(false);
  const modeRef = useRef<Mode>("balance");
  const balanceRef = useRef<BalanceState>(newBalanceState());
  const squatRef = useRef<SquatState>(newSquatState());
  const reachBestRef = useRef<{ ratio: number; inches: number | null } | null>(null);
  const shoeRef = useRef<number | null>(null);

  const [mode, setMode] = useState<Mode>("balance");
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [cam, setCam] = useState<CamState>("off");
  const [envError, setEnvError] = useState("");
  const [camError, setCamError] = useState("");
  const [modelError, setModelError] = useState("");
  const [live, setLive] = useState<Live>({ seen: false });
  const [athleteId, setAthleteId] = useState(staff ? (athletes[0]?.id ?? "") : (selfAthleteId ?? ""));
  const [side, setSide] = useState<Side>("L");
  const [balanceResult, setBalanceResult] = useState<{ seconds: number; sway: number | null; standing: Side | null; reason: string } | null>(null);
  const [squatResult, setSquatResult] = useState<SquatState | null>(null);
  const [shoe, setShoe] = useState("");
  const [tape, setTape] = useState("");
  const [reachBest, setReachBest] = useState<{ ratio: number; inches: number | null } | null>(null);
  const [message, setMessage] = useState("");
  const [pending, start] = useTransition();

  modeRef.current = mode;
  const athleteName = athletes.find((a) => a.id === athleteId)?.name ?? "athlete";

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!window.isSecureContext) {
      setEnvError(
        "The camera needs a secure page. Open Lion Lab over https:// (or http://localhost on this computer). Plain http on a network address blocks the camera.",
      );
    } else if (!navigator.mediaDevices?.getUserMedia) {
      setEnvError("This browser can't open a camera. Try Chrome or Safari, or use the stopwatch and type the number.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    runningRef.current = false;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    const video = videoRef.current;
    if (video) video.srcObject = null;
    const canvas = canvasRef.current;
    canvas?.getContext("2d")?.clearRect(0, 0, canvas.width, canvas.height);
    setCam("off");
  }, []);

  useEffect(() => stopCamera, [stopCamera]);

  function resetMeasure(next: Mode = modeRef.current) {
    balanceRef.current = newBalanceState();
    squatRef.current = newSquatState();
    reachBestRef.current = null;
    setBalanceResult(null);
    setSquatResult(null);
    setReachBest(null);
    setLive({ seen: false });
    setMessage("");
    if (next !== "reach") setTape("");
  }

  function pickMode(next: Mode) {
    setMode(next);
    modeRef.current = next;
    resetMeasure(next);
  }

  function onFrame(landmarks: Pt[] | null, t: number, aspect: number) {
    const lm = landmarks ? toAspect(landmarks, aspect) : null;
    const m = modeRef.current;
    if (m === "balance") {
      const prev = balanceRef.current;
      const next = stepBalance(prev, lm, t);
      balanceRef.current = next;
      const feet = lm ? readFeet(lm) : null;
      const sway = next.phase === "waiting" ? null : swayPercent(next.hips, next.torsos, next.startT);
      setLive({
        seen: Boolean(feet),
        phase: next.phase,
        seconds: balanceSeconds(next, t),
        sway,
        gap: next.gap,
        standing: next.standing,
        stopReason: next.stopReason,
      });
      if (next.phase === "done" && prev.phase !== "done") {
        const result = { seconds: balanceSeconds(next), sway, standing: next.standing, reason: next.stopReason };
        setBalanceResult(result);
        if (next.standing) setSide(next.standing);
        try {
          navigator.vibrate?.([80, 50, 80]);
        } catch {
          /* no vibrate */
        }
      }
    } else if (m === "squat") {
      const prev = squatRef.current;
      const next = stepSquat(prev, lm);
      squatRef.current = next;
      setLive({ seen: Boolean(next.last && lm), knee: next.last?.knee ?? null, reps: next.reps.length });
      if (next.reps.length !== prev.reps.length) setSquatResult(next);
    } else if (m === "reach") {
      const read = lm ? reachRead(lm, shoeRef.current) : null;
      if (read) {
        const best = reachBestRef.current;
        if (!best || read.ratio > best.ratio) {
          reachBestRef.current = { ratio: read.ratio, inches: read.inches };
          setReachBest(reachBestRef.current);
        }
      }
      setLive({ seen: Boolean(read), ratio: read?.ratio ?? null, inches: read?.inches ?? null });
    }
  }

  async function startCamera() {
    setCamError("");
    setModelError("");
    setMessage("");
    if (envError) return;
    setCam("starting");
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing, width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
    } catch (error) {
      const name = error instanceof DOMException ? error.name : "";
      setCam("off");
      if (name === "NotAllowedError" || name === "SecurityError") {
        setCamError(
          "Camera permission was blocked. Tap the lock or camera icon in the address bar, allow the camera, and try again. Or use the stopwatch and type the number.",
        );
      } else if (name === "NotFoundError" || name === "OverconstrainedError") {
        setCamError("No camera found for that setting. Try the other camera button, or type the number instead.");
      } else if (name === "NotReadableError") {
        setCamError("Another app is using the camera. Close it and try again.");
      } else {
        setCamError("The camera did not open. Refresh and try again, or type the number instead.");
      }
      return;
    }
    streamRef.current = stream;
    const video = videoRef.current;
    if (!video) {
      stopCamera();
      return;
    }
    video.srcObject = stream;
    try {
      await video.play();
    } catch {
      // autoplay can reject; the muted inline video usually still plays
    }

    try {
      await withTimeout(
        (async () => {
          await loadScript("/pose/vision-loader.js", true);
          await loadScript("/pose/pose.js", false);
          const api = poseApi();
          if (!api) throw new Error("pose");
          await api.init();
        })(),
        30_000,
      );
    } catch {
      stopCamera();
      setModelError(
        "The body-tracking model did not load (it downloads once over the internet). Check the connection and try again. Until then, use the stopwatch on Test day or type the number.",
      );
      return;
    }

    resetMeasure();
    runningRef.current = true;
    setCam("on");
    const tick = async () => {
      if (!runningRef.current) return;
      const api = poseApi();
      const v = videoRef.current;
      const canvas = canvasRef.current;
      if (api && v && canvas) {
        const now = performance.now();
        const detected = await api.detect(v, now);
        if (detected && runningRef.current) {
          const aspect = (v.videoWidth || 640) / (v.videoHeight || 480);
          onFrame(detected.landmarks, detected.timestamp ?? now, aspect);
          api.syncCanvasSize(canvas, v);
          const ctx = canvas.getContext("2d");
          if (ctx) api.drawSkeleton(ctx, canvas, detected.landmarks, { mirror: false, band: detected.landmarks ? "green" : "weak" });
        }
      }
      if (runningRef.current) requestAnimationFrame(() => void tick());
    };
    void tick();
  }

  function save(batch: MeasureInput[]) {
    if (!athleteId) {
      setMessage(staff ? "Pick an athlete first." : "Your athlete profile is missing. Ask a coach.");
      return;
    }
    setMessage("");
    start(async () => {
      const result = await saveMeasurements(
        batch.map((row) => ({ ...row, athleteId })),
        localDay(),
      );
      if (result.error) {
        const detail = result.rowErrors ? Object.values(result.rowErrors).join(" ") : "";
        setMessage(`${result.error} ${detail}`.trim());
        return;
      }
      const pbs = (result.saved ?? []).filter((r) => r.personalBest);
      setMessage(
        `Saved to ${staff ? athleteName : "your numbers"}.${pbs.length ? ` Personal best: ${pbs.map((r) => formatMetric(r.metric, r.value)).join(", ")}!` : ""}`,
      );
      router.refresh();
    });
  }

  function saveBalance() {
    if (!balanceResult) return;
    const batch: MeasureInput[] = [
      { athleteId, metric: "BALANCE_SL", value: Math.round(balanceResult.seconds * 10) / 10, side, source: "CAMERA", notes: "camera" },
    ];
    if (balanceResult.sway != null) {
      batch.push({ athleteId, metric: "BALANCE_SWAY", value: Math.round(balanceResult.sway * 10) / 10, side, source: "CAMERA", notes: "camera" });
    }
    save(batch);
  }

  function saveSquat() {
    const best = squatResult ? bestSquat(squatResult) : null;
    if (!best) return;
    save([
      {
        athleteId,
        metric: "SQUAT_SCORE",
        value: best.score,
        source: "CAMERA",
        notes: `camera best of ${squatResult?.reps.length ?? 0}${best.cues.length ? `; ${best.cues.map((c) => c.split(".")[0]).join("; ")}` : ""}`,
      },
    ]);
  }

  function saveReach() {
    const value = Number(tape.replace(",", "."));
    if (tape.trim() === "" || !Number.isFinite(value)) {
      setMessage("Type the tape number (inches past the toes; short of the toes is negative).");
      return;
    }
    const guide = reachBest
      ? `camera guide ${(reachBest.ratio * 100).toFixed(0)}% of leg${reachBest.inches != null ? ` ≈ ${reachBest.inches.toFixed(1)} in` : ""}`
      : "no camera guide";
    save([{ athleteId, metric: "SIT_REACH", value, source: "CAMERA", notes: `tape entry; ${guide}` }]);
  }

  const modeDef = MODES.find((m) => m.id === mode)!;
  const bigBtn = "h-16 w-full rounded-2xl font-display text-3xl tracking-wide disabled:opacity-50";
  const squatBest = squatResult ? bestSquat(squatResult) : null;
  const liveSway = live.sway;

  return (
    <div className="grid gap-5" data-testid="camera-lab">
      <div className="rounded-xl bg-ink p-4 text-white">
        <p className="font-semibold">Setup</p>
        <p className="mt-1">
          Phone on a stand at hip height, 8–10 feet away, whole body in frame, good light, plain background.
        </p>
        <p className="mt-2 text-sm text-white/80">
          Video never leaves this phone. Only the numbers are saved. Nothing is recorded.
        </p>
      </div>

      {envError ? (
        <p className="rounded-xl bg-accent px-4 py-3 font-semibold text-accent-foreground" role="alert" data-testid="env-error">
          {envError}
        </p>
      ) : null}

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4" role="tablist" aria-label="Camera test">
        {MODES.map((m) => (
          <button
            key={m.id}
            type="button"
            role="tab"
            aria-selected={mode === m.id}
            onClick={() => pickMode(m.id)}
            className={`min-h-16 rounded-xl px-3 py-2 text-left ring-1 ring-foreground/10 ${mode === m.id ? "bg-lion text-white" : "bg-card"}`}
          >
            <span className="block font-semibold leading-tight">{m.label}</span>
            <span className={`text-xs ${mode === m.id ? "text-white/80" : "text-muted-foreground"}`}>{m.view}</span>
          </button>
        ))}
      </div>

      <p className="text-base">{modeDef.how}</p>

      {mode === "form" ? (
        <div className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <p>
            Form checks for lifts (Feed-Bucket Squat, Barn-Floor Hinge, and the rest) and position stances run in the body
            tracker, which already scores joint angles and saves a session.
          </p>
          <Link href={trackerHref} className="flex h-16 items-center justify-center rounded-2xl bg-lion font-display text-3xl tracking-wide text-white">
            Open body tracker
          </Link>
        </div>
      ) : (
        <>
          {staff ? (
            <label className="grid gap-1 text-sm font-semibold">
              Athlete
              <select
                value={athleteId}
                onChange={(e) => setAthleteId(e.target.value)}
                className="h-14 rounded-lg border border-input bg-card px-3 text-xl font-semibold"
                data-testid="camera-athlete"
              >
                {athletes.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </label>
          ) : (
            <p className="text-sm text-muted-foreground">Home self-test. Results save to your numbers and are marked self-test.</p>
          )}

          <div className="grid grid-cols-2 gap-2">
            {(["user", "environment"] as const).map((f) => (
              <button
                key={f}
                type="button"
                disabled={cam !== "off"}
                onClick={() => setFacing(f)}
                className={`h-12 rounded-xl font-semibold ring-1 ring-foreground/10 disabled:opacity-60 ${facing === f ? "bg-ink text-white" : "bg-card"}`}
              >
                {f === "user" ? "Front (selfie) camera" : "Back camera"}
              </button>
            ))}
          </div>

          <div className="relative overflow-hidden rounded-xl bg-ink">
            <video
              ref={videoRef}
              playsInline
              muted
              autoPlay
              className={`block aspect-[4/3] w-full object-contain ${facing === "user" ? "-scale-x-100" : ""}`}
            />
            <canvas
              ref={canvasRef}
              className={`pointer-events-none absolute inset-0 h-full w-full ${facing === "user" ? "-scale-x-100" : ""}`}
            />
            {cam === "on" ? (
              <div className="absolute inset-x-0 top-0 flex flex-wrap items-start justify-between gap-2 p-3 text-white">
                {mode === "balance" ? (
                  <>
                    <span className="rounded-lg bg-black/60 px-3 py-1 font-mono text-5xl font-bold tabular-nums" data-testid="balance-live">
                      {(live.seconds ?? 0).toFixed(1)}s
                    </span>
                    <span className="rounded-lg bg-black/60 px-3 py-1 text-sm">
                      {!live.seen
                        ? "Can't see both feet"
                        : live.phase === "waiting"
                          ? "Lift one foot"
                          : live.phase === "lifted"
                            ? `On ${live.standing === "L" ? "left" : "right"} leg`
                            : "Done"}
                    </span>
                  </>
                ) : null}
                {mode === "squat" ? (
                  <>
                    <span className="rounded-lg bg-black/60 px-3 py-1 font-mono text-4xl font-bold">
                      Rep {Math.min(live.reps ?? 0, 3)}/3
                    </span>
                    <span className="rounded-lg bg-black/60 px-3 py-1 text-sm">
                      {live.seen ? `Knee ${Math.round(live.knee ?? 0)}°` : "Turn sideways, whole body in frame"}
                    </span>
                  </>
                ) : null}
                {mode === "reach" ? (
                  <span className="rounded-lg bg-black/60 px-3 py-1 text-lg">
                    {live.seen && live.ratio != null
                      ? `${live.ratio >= 0 ? "Past" : "Short of"} toes: ${Math.abs(live.ratio * 100).toFixed(0)}% of leg${
                          live.inches != null ? ` (≈ ${live.inches >= 0 ? "+" : ""}${live.inches.toFixed(1)} in)` : ""
                        }`
                      : "Sideways, hips to toes in frame"}
                  </span>
                ) : null}
              </div>
            ) : (
              <div className="absolute inset-0 grid place-items-center p-4 text-center text-white/80">
                {cam === "starting" ? "Opening camera and loading the body model…" : "Camera off"}
              </div>
            )}
          </div>

          {mode === "balance" && cam === "on" && live.phase !== "waiting" ? (
            <div className="grid gap-1" aria-label="Sway meter">
              <div className="flex justify-between text-sm">
                <span className="font-semibold">Sway</span>
                <span>{liveSway == null ? "—" : `${liveSway.toFixed(1)}% of torso`}</span>
              </div>
              <div className="h-4 overflow-hidden rounded-full bg-muted">
                <div
                  className={`h-full ${liveSway == null ? "" : liveSway <= 5 ? "bg-emerald-700" : liveSway <= 12 ? "bg-amber-400" : "bg-lion"}`}
                  style={{ width: `${Math.min(100, ((liveSway ?? 0) / 25) * 100)}%` }}
                />
              </div>
            </div>
          ) : null}

          <div className="grid gap-2">
            {cam === "on" ? (
              <button type="button" onClick={stopCamera} className={`${bigBtn} bg-secondary`}>
                Stop camera
              </button>
            ) : (
              <button
                type="button"
                onClick={() => void startCamera()}
                disabled={cam === "starting" || Boolean(envError)}
                className={`${bigBtn} bg-emerald-700 text-white`}
                data-testid="start-camera"
              >
                {cam === "starting" ? "Opening…" : "Start camera"}
              </button>
            )}
            {camError ? (
              <p className="rounded-xl bg-accent px-4 py-3 text-accent-foreground" role="alert" data-testid="camera-error">
                {camError}
              </p>
            ) : null}
            {modelError ? (
              <p className="rounded-xl bg-accent px-4 py-3 text-accent-foreground" role="alert" data-testid="model-error">
                {modelError}{" "}
                {staff ? (
                  <Link href="/coach/measure" className="font-semibold text-lion underline">
                    Go to Test day
                  </Link>
                ) : null}
              </p>
            ) : null}
          </div>

          {mode === "balance" && balanceResult ? (
            <div className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10" data-testid="balance-result">
              <p className="font-display text-6xl tracking-wide">{balanceResult.seconds.toFixed(1)}s</p>
              <p>
                Sway {balanceResult.sway == null ? "— (hold too short to measure)" : `${balanceResult.sway.toFixed(1)}% of torso`}
                {balanceResult.reason === "cap" ? " · hit the 30 s cap" : balanceResult.reason === "lost" ? " · camera lost the body; check it" : ""}
              </p>
              <p className="text-sm font-semibold">Which leg was the athlete standing on? (confirm)</p>
              <div className="grid grid-cols-2 gap-2">
                {(["L", "R"] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSide(s)}
                    className={`h-14 rounded-xl text-xl font-semibold ring-1 ring-foreground/10 ${side === s ? "bg-ink text-white" : "bg-card"}`}
                  >
                    {s === "L" ? "Left leg" : "Right leg"}
                  </button>
                ))}
              </div>
              <button type="button" onClick={saveBalance} disabled={pending} className={`${bigBtn} bg-lion text-white`}>
                {pending ? "Saving…" : `Save to ${staff ? athleteName : "me"}`}
              </button>
              <button type="button" onClick={() => resetMeasure()} className="h-12 rounded-xl font-semibold ring-1 ring-foreground/20">
                Try again / other leg
              </button>
            </div>
          ) : null}

          {mode === "squat" && squatResult && squatBest ? (
            <div className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10" data-testid="squat-result">
              <p className="font-display text-6xl tracking-wide">
                {squatBest.score}
                <span className="ml-2 text-xl text-muted-foreground">
                  best of {squatResult.reps.length}
                  {squatDone(squatResult) ? "" : " so far"}
                </span>
              </p>
              <p className="text-sm">
                Depth {squatBest.parts.depth}/60 · Trunk {squatBest.parts.trunk}/25 · Heels {squatBest.parts.heels}/15 · deepest knee{" "}
                {Math.round(squatBest.minKnee)}°
              </p>
              <p className="text-sm text-muted-foreground">Reps: {squatResult.reps.map((r) => r.score).join(" · ")}</p>
              {squatBest.cues.length ? (
                <ul className="list-disc pl-5 font-semibold">
                  {squatBest.cues.map((c) => (
                    <li key={c}>{c}</li>
                  ))}
                </ul>
              ) : (
                <p className="font-semibold text-emerald-700">Clean rep. Heels down, chest up, good depth.</p>
              )}
              <button type="button" onClick={saveSquat} disabled={pending} className={`${bigBtn} bg-lion text-white`}>
                {pending ? "Saving…" : `Save to ${staff ? athleteName : "me"}`}
              </button>
              <button type="button" onClick={() => resetMeasure()} className="h-12 rounded-xl font-semibold ring-1 ring-foreground/20">
                Start over
              </button>
            </div>
          ) : null}

          {mode === "reach" ? (
            <div className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10" data-testid="reach-panel">
              <p className="text-sm">
                The camera can&rsquo;t know inches by itself. It shows how far the hands got past the toes as a share of leg
                length. Add a shoe length to get a rough inch guess. The tape measure is the number that gets saved.
              </p>
              <label className="grid gap-1 text-sm font-semibold">
                Shoe length in inches (optional, for the guess)
                <input
                  inputMode="decimal"
                  value={shoe}
                  onChange={(e) => {
                    setShoe(e.target.value);
                    const n = Number(e.target.value);
                    shoeRef.current = Number.isFinite(n) && n > 4 && n < 16 ? n : null;
                  }}
                  placeholder="10.5"
                  className="h-12 w-40 rounded-lg border border-input bg-background px-3 text-xl"
                />
              </label>
              {reachBest ? (
                <p>
                  Best reach seen: <strong>{(reachBest.ratio * 100).toFixed(0)}%</strong> of leg length{" "}
                  {reachBest.ratio >= 0 ? "past" : "short of"} the toes
                  {reachBest.inches != null ? ` (camera guess ${reachBest.inches >= 0 ? "+" : ""}${reachBest.inches.toFixed(1)} in)` : ""}.
                </p>
              ) : null}
              <label className="grid gap-1 text-sm font-semibold">
                Tape measure (inches; short of the toes is negative)
                <input
                  inputMode="decimal"
                  value={tape}
                  onChange={(e) => setTape(e.target.value)}
                  placeholder="-2.5"
                  className="h-14 w-40 rounded-lg border border-input bg-background px-3 text-2xl font-semibold"
                  data-testid="tape-input"
                />
              </label>
              <button type="button" onClick={saveReach} disabled={pending || tape.trim() === ""} className={`${bigBtn} bg-lion text-white`}>
                {pending ? "Saving…" : `Save to ${staff ? athleteName : "me"}`}
              </button>
              <p className="text-xs text-muted-foreground">Stop at a stretch, not pain. Skip with a current hamstring or back injury.</p>
            </div>
          ) : null}

          {message ? (
            <p className="rounded-xl bg-accent px-4 py-3 font-semibold text-accent-foreground" role="status">
              {message}
            </p>
          ) : null}
        </>
      )}

      <p className="text-xs text-muted-foreground">
        Camera numbers are ESTIMATES from a phone. Use the same spot, distance, and light each time and compare an athlete
        to their own past numbers. Balance timer: starts when one foot is clearly up ({Math.round(BALANCE.LIFT_ON * 100)}% of
        leg length), stops when it comes back down. Not a medical device. Stop for pain and see the ATC.
      </p>
    </div>
  );
}
