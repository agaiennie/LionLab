"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { fastWords } from "@/lib/content/fast";
import { PHASES, positionLabel, type SkillPhase } from "@/lib/content/skills";
import { cn } from "cn";

export type SkillListItem = {
  id: string;
  name: string;
  phase: SkillPhase;
  positions: string[];
  fastLetters: string[];
  what: string;
};

const filters = ["ALL", "QB", "RB", "WR", "TE", "OL", "DL", "LB", "DB", "ST", "K"] as const;

export function SkillBrowser({ skills }: { skills: SkillListItem[] }) {
  const [query, setQuery] = useState("");
  const [phase, setPhase] = useState<SkillPhase | "all">("all");
  const [position, setPosition] = useState<(typeof filters)[number]>("ALL");

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return skills.filter((skill) => {
      const matchesQuery =
        needle.length === 0 ||
        skill.name.toLowerCase().includes(needle) ||
        skill.what.toLowerCase().includes(needle);
      const matchesPhase = phase === "all" || skill.phase === phase;
      const matchesPosition =
        position === "ALL" ||
        skill.positions.includes("ALL") ||
        skill.positions.includes(position) ||
        (position === "K" && skill.positions.includes("ST"));
      return matchesQuery && matchesPhase && matchesPosition;
    });
  }, [skills, query, phase, position]);

  return (
    <div className="grid gap-4">
      <Input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search skills"
        aria-label="Search skills"
        className="h-11 text-base"
      />
      <div className="flex gap-2 overflow-x-auto">
        {PHASES.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setPhase(item.id)}
            className={cn(
              "h-11 shrink-0 rounded-full px-4 text-sm font-semibold",
              phase === item.id ? "bg-lion text-white" : "bg-card ring-1 ring-foreground/10",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      <div className="flex gap-2 overflow-x-auto">
        {filters.map((code) => (
          <button
            key={code}
            type="button"
            onClick={() => setPosition(code)}
            className={cn(
              "h-11 shrink-0 rounded-full px-4 text-sm font-semibold",
              position === code ? "bg-ink text-white" : "bg-card ring-1 ring-foreground/10",
            )}
          >
            {code === "ALL" ? "All" : code}
          </button>
        ))}
      </div>
      <p className="text-sm text-muted-foreground">
        {visible.length} {visible.length === 1 ? "skill" : "skills"}
        {position !== "ALL" ? ` · ${positionLabel(position)}` : ""}
      </p>
      {visible.length === 0 ? (
        <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">
          No skill matches that search. Clear a filter or try another position.
        </p>
      ) : (
        <ul className="grid gap-3">
          {visible.map((skill) => (
            <li key={skill.id}>
              <Link
                href={`/skills/${skill.id}`}
                className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10"
              >
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <p className="font-display text-2xl tracking-wide">{skill.name}</p>
                  <p className="text-sm font-semibold text-lion">Teach</p>
                </div>
                <p className="text-sm text-muted-foreground">{skill.what}</p>
                <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  {skill.positions.includes("ALL") ? "All positions" : skill.positions.join(" · ")}
                  {skill.fastLetters.length > 0 ? ` · FAST ${fastWords(skill.fastLetters)}` : ""}
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
