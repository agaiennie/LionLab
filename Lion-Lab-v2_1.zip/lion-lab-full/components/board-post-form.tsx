"use client";

import { useActionState } from "react";
import { createPost } from "@/app/actions/board";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { ActionState } from "@/lib/validators";

export function BoardPostForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(createPost, {});
  return (
    <form action={action} className="grid gap-4">
      {state.message ? <p className="rounded-lg bg-accent px-3 py-2 text-sm">{state.message}</p> : null}
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      <div className="grid gap-1.5">
        <Label htmlFor="post-title" className="text-base">Title</Label>
        <Input id="post-title" name="title" required maxLength={100} className="h-12 text-base" placeholder="Practice moved to 4:30" />
        {state.fieldErrors?.title ? <p className="text-sm text-destructive">{state.fieldErrors.title}</p> : null}
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="post-body" className="text-base">Post</Label>
        <Textarea id="post-body" name="body" required rows={5} maxLength={2000} className="text-base" />
        {state.fieldErrors?.body ? <p className="text-sm text-destructive">{state.fieldErrors.body}</p> : null}
      </div>
      <label className="flex items-center gap-3 text-base">
        <input type="checkbox" name="pinned" className="size-5 accent-[#C8102E]" />
        Pin to the top
      </label>
      <p className="text-sm text-muted-foreground">
        Anyone on the internet can read this. Never post a player&apos;s name with a score, grade, injury, or number.
      </p>
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Posting…" : "Post to the public board"}
      </Button>
    </form>
  );
}
