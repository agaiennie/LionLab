import { PassBadge } from "@/components/exam-badges";
import { examSummaryForAthlete } from "@/lib/exams";

/**
 * Server component: one athlete's latest and best score per exam.
 * The caller must already have checked the viewer can see this athlete.
 */
export async function ExamSummary({ athleteId }: { athleteId: string }) {
  const rows = await examSummaryForAthlete(athleteId);
  return (
    <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <h2 className="font-display text-3xl tracking-wide">Exams</h2>
      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground">No exams taken yet.</p>
      ) : (
        <ul className="grid gap-2">
          {rows.map((row) => (
            <li key={row.examId} className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-muted/50 px-3 py-2">
              <div>
                <p className="font-semibold">{row.title}</p>
                <p className="text-xs text-muted-foreground">
                  {row.attempts} {row.attempts === 1 ? "try" : "tries"} · pass at {row.passPercent}% · last{" "}
                  {row.lastTakenAt.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </p>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <span>
                  Latest <span className="font-display text-xl">{row.latestPercent}%</span>
                </span>
                <span>
                  Best <span className="font-display text-xl">{row.bestPercent}%</span>
                </span>
                <PassBadge passed={row.everPassed} label={row.everPassed ? "Passed" : "Not yet"} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
