"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteMeasurement, saveMeasurements, type MeasureInput, type SavedMeasure } from "@/app/actions/measure";
import { Stopwatch, type StopwatchResult } from "@/components/stopwatch";
import { METRIC_BY_ID, formatMetric, validateMetricValue, type MetricId } from "@/lib/content/metrics";
import { localDay } from "@/lib/habits";

export type TestDayAthlete = {
  id: string;
  name: string;
  grade: number;
  positions: string[];
  /** Last recorded value per side ("" for non-sided). */
  last: Record<string, { value: number; day: string }>;
};

const POSITION_GROUPS: { id: string; label: string; codes: string[] }[] = [
  { id: "ALL", label: "Everyone", codes: [] },
  { id: "LINE", label: "Linemen", codes: ["OL", "DL"] },
  { id: "BACKS", label: "QB / RB", codes: ["QB", "RB"] },
  { id: "ENDS", label: "WR / TE", codes: ["WR", "TE"] },
  { id: "LB", label: "Backers", codes: ["LB"] },
  { id: "DB", label: "Secondary", codes: ["DB"] },
  { id: "OTHER", label: "K / ATH", codes: ["K", "ATH"] },
];

type RowStatus = { text: string; tone: "pb" | "ok" | "error" };

function sidesFor(metric: MetricId): string[] {
  return METRIC_BY_ID[metric].sided ? ["L", "R"] : [""];
}

export function TestDay({
  metric,
  athletes,
  today,
  stopwatchCapable,
}: {
  metric: MetricId;
  athletes: TestDayAthlete[];
  today: string;
  stopwatchCapable: boolean;
}) {
  const def = METRIC_BY_ID[metric];
  const router = useRouter();
  const [day, setDay] = useState(today);
  const touchedDay = useRef(false);
  const [group, setGroup] = useState("ALL");
  const [grade, setGrade] = useState("ALL");
  const [mode, setMode] = useState<"grid" | "stopwatch">("grid");
  const [values, setValues] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<Record<string, RowStatus>>({});
  const [message, setMessage] = useState("");
  const [lastSaved, setLastSaved] = useState<SavedMeasure[]>([]);
  const [pending, start] = useTransition();

  useEffect(() => {
    if (!touchedDay.current) setDay(localDay());
  }, []);

  const grades = useMemo(() => [...new Set(athletes.map((a) => a.grade))].sort((a, b) => a - b), [athletes]);
  const shown = useMemo(() => {
    const codes = POSITION_GROUPS.find((g) => g.id === group)?.codes ?? [];
    return athletes.filter(
      (a) =>
        (grade === "ALL" || String(a.grade) === grade) &&
        (codes.length === 0 || a.positions.some((p) => codes.includes(p))),
    );
  }, [athletes, group, grade]);

  const sides = sidesFor(metric);
  const key = (athleteId: string, side: string) => `${athleteId}:${side}`;
  const filled = shown.flatMap((a) =>
    sides
      .map((side) => ({ athlete: a, side, raw: (values[key(a.id, side)] ?? "").trim() }))
      .filter((cell) => cell.raw !== ""),
  );

  function nameOf(id: string) {
    return athletes.find((a) => a.id === id)?.name ?? "Athlete";
  }

  function run(batch: MeasureInput[], onSaved?: () => void) {
    setMessage("");
    start(async () => {
      const result = await saveMeasurements(batch, day);
      if (result.error) {
        setMessage(result.error);
        if (result.rowErrors) {
          const next: Record<string, RowStatus> = {};
          for (const [i, text] of Object.entries(result.rowErrors)) {
            const row = batch[Number(i)];
            if (row) next[row.athleteId] = { text, tone: "error" };
          }
          setStatus((s) => ({ ...s, ...next }));
        }
        return;
      }
      const saved = result.saved ?? [];
      setLastSaved(saved);
      const next: Record<string, RowStatus> = {};
      for (const row of saved) {
        const label = `${row.side ? `${row.side} ` : ""}${formatMetric(row.metric, row.value)}`;
        const prev = next[row.athleteId]?.text;
        const text = row.personalBest
          ? `PB! ${label} (was ${formatMetric(row.metric, row.previousBest)})`
          : row.first
            ? `First: ${label}`
            : `Saved ${label}`;
        next[row.athleteId] = {
          text: prev ? `${prev} · ${text}` : text,
          tone: row.personalBest || next[row.athleteId]?.tone === "pb" ? "pb" : "ok",
        };
      }
      setStatus((s) => ({ ...s, ...next }));
      setMessage(result.message ?? "Saved.");
      onSaved?.();
      router.refresh();
    });
  }

  function saveAll() {
    const errors: Record<string, RowStatus> = {};
    const batch: MeasureInput[] = [];
    for (const cell of filled) {
      const value = Number(cell.raw.replace(",", "."));
      const bad = validateMetricValue(metric, value);
      if (bad) errors[cell.athlete.id] = { text: bad, tone: "error" };
      else batch.push({ athleteId: cell.athlete.id, metric, value, side: cell.side, source: "MANUAL" });
    }
    if (Object.keys(errors).length) {
      setStatus((s) => ({ ...s, ...errors }));
      setMessage("Fix the red rows. Nothing was saved.");
      return;
    }
    if (batch.length === 0) {
      setMessage("Type at least one number.");
      return;
    }
    run(batch, () => {
      setValues((v) => {
        const next = { ...v };
        for (const row of batch) delete next[key(row.athleteId, row.side ?? "")];
        return next;
      });
    });
  }

  function undoLast() {
    const ids = lastSaved.map((row) => row.id);
    if (ids.length === 0) return;
    start(async () => {
      for (const id of ids) await deleteMeasurement(id);
      setLastSaved([]);
      setStatus((s) => {
        const next = { ...s };
        for (const row of lastSaved) delete next[row.athleteId];
        return next;
      });
      setMessage(`Removed ${ids.length} just-saved ${ids.length === 1 ? "number" : "numbers"}.`);
      router.refresh();
    });
  }

  function onEnter(event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key !== "Enter") return;
    event.preventDefault();
    const inputs = Array.from(document.querySelectorAll<HTMLInputElement>("input[data-grid-input]"));
    const i = inputs.indexOf(event.currentTarget);
    inputs[i + 1]?.focus();
  }

  const selectClass = "h-12 rounded-lg border border-input bg-card px-3 text-base font-normal";

  return (
    <div className="grid gap-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <label className="grid gap-1 text-sm font-semibold">
          Test date
          <input
            type="date"
            value={day}
            max={today > day ? today : day}
            onChange={(e) => {
              touchedDay.current = true;
              setDay(e.target.value);
            }}
            className={selectClass}
          />
        </label>
        <label className="grid gap-1 text-sm font-semibold">
          Position group
          <select value={group} onChange={(e) => setGroup(e.target.value)} className={selectClass} data-testid="filter-group">
            {POSITION_GROUPS.map((g) => (
              <option key={g.id} value={g.id}>
                {g.label}
              </option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-sm font-semibold">
          Grade
          <select value={grade} onChange={(e) => setGrade(e.target.value)} className={selectClass}>
            <option value="ALL">All grades</option>
            {grades.map((g) => (
              <option key={g} value={String(g)}>
                Grade {g}
              </option>
            ))}
          </select>
        </label>
      </div>

      {stopwatchCapable ? (
        <div className="grid grid-cols-2 gap-2" role="tablist">
          {(["grid", "stopwatch"] as const).map((m) => (
            <button
              key={m}
              type="button"
              role="tab"
              aria-selected={mode === m}
              onClick={() => setMode(m)}
              className={`h-14 rounded-xl text-lg font-semibold ring-1 ring-foreground/10 ${
                mode === m ? "bg-ink text-white" : "bg-card"
              }`}
            >
              {m === "grid" ? "Type numbers" : "Stopwatch mode"}
            </button>
          ))}
        </div>
      ) : null}

      {message ? (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-accent px-4 py-3 text-accent-foreground" role="status">
          <span className="font-semibold">{message}</span>
          {lastSaved.length > 0 ? (
            <button type="button" onClick={undoLast} disabled={pending} className="h-10 rounded-lg px-3 text-sm font-semibold text-lion underline">
              Undo that save
            </button>
          ) : null}
        </div>
      ) : null}

      {mode === "stopwatch" && stopwatchCapable ? (
        <StopwatchStation
          metric={metric}
          athletes={shown}
          pending={pending}
          onSave={(batch, after) => run(batch, after)}
          status={status}
          nameOf={nameOf}
        />
      ) : shown.length === 0 ? (
        <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">No athletes match that filter.</p>
      ) : (
        <>
          <ul className="divide-y divide-border overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10" data-testid="entry-grid">
            {shown.map((a) => {
              const st = status[a.id];
              return (
                <li key={a.id} className="grid gap-2 px-3 py-3 sm:grid-cols-[1fr_auto] sm:items-center">
                  <div className="min-w-0">
                    <p className="truncate text-lg font-semibold">{a.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Gr {a.grade} · {a.positions.join(" ") || "—"}
                      {sides.map((side) =>
                        a.last[side] ? (
                          <span key={side} className="opacity-70">
                            {" "}
                            · last {side ? `${side} ` : ""}
                            {formatMetric(metric, a.last[side].value)}
                          </span>
                        ) : null,
                      )}
                    </p>
                    {st?.text ? (
                      <p
                        className={`mt-1 text-sm font-semibold ${
                          st.tone === "pb" ? "text-emerald-700" : st.tone === "error" ? "text-destructive" : "text-muted-foreground"
                        }`}
                        data-testid={`status-${a.id}`}
                      >
                        {st.text}
                      </p>
                    ) : null}
                  </div>
                  <div className="flex gap-2">
                    {sides.map((side) => (
                      <label key={side} className="grid gap-0.5 text-xs font-semibold">
                        {side ? (side === "L" ? "Left" : "Right") : <span className="sr-only">{def.short}</span>}
                        <input
                          data-grid-input
                          data-athlete={a.id}
                          inputMode="decimal"
                          enterKeyHint="next"
                          autoComplete="off"
                          value={values[key(a.id, side)] ?? ""}
                          placeholder={a.last[side] ? a.last[side].value.toFixed(def.decimals) : def.unit}
                          onChange={(e) => {
                            const v = e.target.value;
                            setValues((cur) => ({ ...cur, [key(a.id, side)]: v }));
                            if (status[a.id]?.tone === "error") setStatus((s) => ({ ...s, [a.id]: { text: "", tone: "ok" } }));
                          }}
                          onKeyDown={onEnter}
                          aria-label={`${a.name} ${def.short}${side ? ` ${side}` : ""}`}
                          className={`h-14 w-28 rounded-lg border bg-background px-3 text-right text-2xl font-semibold tabular-nums placeholder:text-muted-foreground/40 ${
                            st?.tone === "error" && st.text ? "border-destructive" : "border-input"
                          }`}
                        />
                      </label>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
          <div className="sticky bottom-3 z-10">
            <button
              type="button"
              onClick={saveAll}
              disabled={pending || filled.length === 0}
              className="h-16 w-full rounded-2xl bg-lion font-display text-3xl tracking-wide text-white shadow-lg disabled:opacity-50"
            >
              {pending ? "Saving…" : `Save all${filled.length ? ` (${filled.length})` : ""}`}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function StopwatchStation({
  metric,
  athletes,
  pending,
  onSave,
  status,
  nameOf,
}: {
  metric: MetricId;
  athletes: TestDayAthlete[];
  pending: boolean;
  onSave: (batch: MeasureInput[], after: () => void) => void;
  status: Record<string, RowStatus>;
  nameOf: (id: string) => string;
}) {
  const def = METRIC_BY_ID[metric];
  const [athleteId, setAthleteId] = useState(athletes[0]?.id ?? "");
  const [side, setSide] = useState<"L" | "R">("L");
  const [result, setResult] = useState<StopwatchResult | null>(null);
  const [resetKey, setResetKey] = useState(0);
  const [note, setNote] = useState("");

  useEffect(() => {
    if (!athletes.some((a) => a.id === athleteId)) setAthleteId(athletes[0]?.id ?? "");
  }, [athletes, athleteId]);

  const isCount = def.unit === "reps";
  const allowSplit = metric === "SPRINT_40";

  if (athletes.length === 0) {
    return <p className="rounded-xl bg-card px-4 py-6 text-muted-foreground ring-1 ring-foreground/10">No athletes match that filter.</p>;
  }

  let value: number | null = null;
  let split: number | null = null;
  if (result?.kind === "time") {
    value = Math.round(result.ms / 10) / 100;
    split = result.splitMs != null ? Math.round(result.splitMs / 10) / 100 : null;
  } else if (result?.kind === "count") {
    value = result.reps;
  }
  const bad = value != null ? validateMetricValue(metric, value) : null;
  const splitBad = split != null ? validateMetricValue("SPLIT_10", split) : null;

  function save() {
    if (value == null || bad) return;
    const batch: MeasureInput[] = [
      { athleteId, metric, value, side: def.sided ? side : "", source: "STOPWATCH", notes: note },
    ];
    if (split != null && !splitBad) batch.push({ athleteId, metric: "SPLIT_10", value: split, source: "STOPWATCH", notes: note });
    onSave(batch, () => {
      setResult(null);
      setNote("");
      setResetKey((k) => k + 1);
      // Next athlete in line (or the other leg first for sided tests).
      if (def.sided && side === "L") {
        setSide("R");
        return;
      }
      setSide("L");
      const i = athletes.findIndex((a) => a.id === athleteId);
      const next = athletes[i + 1];
      if (next) setAthleteId(next.id);
    });
  }

  const st = status[athleteId];

  return (
    <div className="grid gap-3" data-testid="stopwatch-station">
      <label className="grid gap-1 text-sm font-semibold">
        Athlete
        <select
          value={athleteId}
          onChange={(e) => {
            setAthleteId(e.target.value);
            setResult(null);
            setResetKey((k) => k + 1);
          }}
          className="h-14 rounded-lg border border-input bg-card px-3 text-xl font-semibold"
        >
          {athletes.map((a) => (
            <option key={a.id} value={a.id}>
              {a.name} · Gr {a.grade}
            </option>
          ))}
        </select>
      </label>
      {def.sided ? (
        <div className="grid grid-cols-2 gap-2">
          {(["L", "R"] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSide(s)}
              className={`h-14 rounded-xl text-xl font-semibold ring-1 ring-foreground/10 ${side === s ? "bg-ink text-white" : "bg-card"}`}
            >
              {s === "L" ? "Left leg" : "Right leg"}
            </button>
          ))}
        </div>
      ) : null}
      {st?.text ? (
        <p className={`text-sm font-semibold ${st.tone === "pb" ? "text-emerald-700" : st.tone === "error" ? "text-destructive" : ""}`}>
          {nameOf(athleteId)}: {st.text}
        </p>
      ) : null}
      <Stopwatch
        key={resetKey}
        mode={isCount ? "count" : "time"}
        allowSplit={allowSplit}
        splitLabel="10-YD SPLIT"
        onDone={setResult}
        onReset={() => setResult(null)}
      />
      {result && value != null ? (
        <div className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <p className="text-lg">
            {nameOf(athleteId)}
            {def.sided ? ` · ${side === "L" ? "left" : "right"} leg` : ""}:{" "}
            <span className="font-display text-3xl">{formatMetric(metric, value)}</span>
            {split != null ? <span className="ml-2 text-muted-foreground">10 yd {formatMetric("SPLIT_10", split)}</span> : null}
          </p>
          {bad ? <p className="text-sm text-destructive">{bad} Reset and run it again.</p> : null}
          {splitBad ? <p className="text-sm text-muted-foreground">Split looks off ({splitBad}). Only the 40 will save.</p> : null}
          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            maxLength={120}
            placeholder="Note (optional): slipped, false start…"
            className="h-12 rounded-lg border border-input bg-background px-3 text-base"
          />
          <button
            type="button"
            onClick={save}
            disabled={pending || Boolean(bad)}
            className="h-16 w-full rounded-2xl bg-lion font-display text-3xl tracking-wide text-white disabled:opacity-50"
          >
            {pending ? "Saving…" : "Save"}
          </button>
        </div>
      ) : null}
      <p className="text-sm text-muted-foreground">
        Hand times: same timer, same spot every test day. Hand timing usually reads faster than electronic
        timing, so compare this athlete to their own hand times, not to combine numbers.
      </p>
    </div>
  );
}
