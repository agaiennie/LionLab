import { logout } from "@/app/actions";
import { Button } from "@/components/ui/button";

export function SignOutButton() {
  return (
    <form action={logout}>
      <Button
        type="submit"
        variant="outline"
        className="h-10 border-white/20 bg-transparent text-white hover:bg-white/10 hover:text-white"
      >
        Sign out
      </Button>
    </form>
  );
}
