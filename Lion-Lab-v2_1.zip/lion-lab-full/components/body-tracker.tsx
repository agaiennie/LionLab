"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { savePoseSession } from "@/app/actions/daily";
import { Button } from "@/components/ui/button";
import { STUDY_GATE_LINE, localDay } from "@/lib/habits";

type Movement = {
  id: string;
  name: string;
  description: string;
  view: string;
  setupTips: string[];
  idealCues: string[];
  positions: string[];
};

type Live = { overall: number | null; band: string };

type Review = {
  mode: "camera" | "checklist";
  overall: number | null;
  band: string;
  cues: string[];
};

type Sample = { t: number; overall: number | null; band: string; weak: boolean };

declare global {
  interface Window {
    RLMovements?: {
      bySportAndPosition: (sport: string, position: string) => Movement[];
      bySport?: (sport: string) => Movement[];
      positionsFor: (sport: string) => string[];
      byId: (id: string) => Movement | null;
    };
    RLScore?: {
      scoreFrame: (
        movement: Movement,
        landmarks: unknown,
        ts: number,
      ) => { overall: number | null; band: string; weak: boolean; fixes: string[] };
      sessionAggregate: (timeline: { samples: Sample[] }) => { overall: number | null; band: string };
      buildTimeline: (samples: Sample[]) => { samples: Sample[] };
    };
    RLPose?: {
      init: () => Promise<unknown>;
      detect: (
        video: HTMLVideoElement,
        ts: number,
      ) => Promise<{ landmarks: unknown; timestamp: number } | null>;
      drawSkeleton: (
        ctx: CanvasRenderingContext2D,
        canvas: HTMLCanvasElement,
        landmarks: unknown,
        opts: { mirror?: boolean; band?: string },
      ) => void;
      syncCanvasSize: (canvas: HTMLCanvasElement, video: HTMLVideoElement) => void;
    };
  }
}

function loadScript(src: string, module: boolean) {
  return new Promise<void>((resolve, reject) => {
    const existing = document.querySelector(`script[data-pose="${src}"]`);
    if (existing) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = src;
    script.dataset.pose = src;
    if (module) script.type = "module";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(src));
    document.head.appendChild(script);
  });
}

const LIFTS = "Lifts";

function bandOf(percent: number): string {
  if (percent >= 80) return "green";
  if (percent >= 55) return "yellow";
  return "red";
}

export function BandPill({ band, score }: { band: string; score: number | null }) {
  const tone =
    band === "green"
      ? "bg-emerald-700 text-white"
      : band === "yellow"
        ? "bg-amber-400 text-ink"
        : band === "red"
          ? "bg-lion text-white"
          : "bg-muted text-ink";
  const label = score == null ? "No score" : String(score);
  return (
    <span className={`inline-flex rounded-full px-2 py-0.5 text-sm font-semibold ${tone}`}>
      {label} · {band}
    </span>
  );
}

export function BodyTracker({
  athleteId,
  athleteName,
  initialPosition,
  placeDefault,
  allowFieldToggle,
  studyBlocked,
}: {
  athleteId: string;
  athleteName: string;
  initialPosition: string;
  placeDefault: "home" | "field";
  allowFieldToggle: boolean;
  studyBlocked: boolean;
}) {
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const runningRef = useRef(false);
  const samplesRef = useRef<Sample[]>([]);
  const fixesRef = useRef<string[]>([]);
  const movementRef = useRef<Movement | null>(null);

  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [positions, setPositions] = useState<string[]>(["General"]);
  const [position, setPosition] = useState(initialPosition);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [movementId, setMovementId] = useState("");
  const [checked, setChecked] = useState<string[]>([]);
  const [atHome, setAtHome] = useState(placeDefault === "home");
  const [notes, setNotes] = useState("");
  const [live, setLive] = useState<Live | null>(null);
  const [cameraState, setCameraState] = useState<"off" | "starting" | "on">("off");
  const [cameraError, setCameraError] = useState("");
  const [review, setReview] = useState<Review | null>(null);
  const [message, setMessage] = useState("");
  const [pending, start] = useTransition();

  const movement = movements.find((item) => item.id === movementId) ?? null;
  movementRef.current = movement;
  const place = allowFieldToggle ? (atHome ? "home" : "field") : placeDefault;
  const homeBlocked = place === "home" && studyBlocked;

  useEffect(() => {
    let cancel = false;
    (async () => {
      try {
        await loadScript("/pose/movements.js", false);
        await loadScript("/pose/score.js", false);
        if (cancel) return;
        const list = window.RLMovements?.positionsFor("football") ?? ["General"];
        // Weight-room form checks live under sport "lifts"; offer them as one extra choice.
        setPositions(window.RLMovements?.bySport ? [...list, LIFTS] : list);
        setReady(true);
      } catch {
        if (!cancel) setLoadError("Movement list did not load. Refresh and try again.");
      }
    })();
    return () => {
      cancel = true;
      runningRef.current = false;
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  useEffect(() => {
    if (!ready || !window.RLMovements) return;
    const next =
      position === LIFTS && window.RLMovements.bySport
        ? window.RLMovements.bySport("lifts")
        : window.RLMovements.bySportAndPosition("football", position);
    setMovements(next);
    setMovementId((current) => (next.some((item) => item.id === current) ? current : (next[0]?.id ?? "")));
    setChecked([]);
    setReview(null);
  }, [ready, position]);

  function toggleCue(cue: string) {
    setChecked((current) => (current.includes(cue) ? current.filter((item) => item !== cue) : [...current, cue]));
  }

  async function startCamera() {
    setCameraError("");
    setMessage("");
    setReview(null);
    if (!movement) {
      setCameraError("Pick a movement first.");
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError("This browser has no camera. Use the checklist.");
      return;
    }
    setCameraState("starting");
    try {
      await loadScript("/pose/vision-loader.js", true);
      await loadScript("/pose/pose.js", false);
      if (!window.RLPose) throw new Error("pose");
      await window.RLPose.init();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) throw new Error("video");
      video.srcObject = stream;
      await video.play();
      samplesRef.current = [];
      fixesRef.current = [];
      runningRef.current = true;
      setCameraState("on");
      const started = performance.now();
      const tick = async () => {
        if (!runningRef.current) return;
        const currentVideo = videoRef.current;
        const canvas = canvasRef.current;
        const currentMovement = movementRef.current;
        if (currentVideo && canvas && window.RLPose && window.RLScore && currentMovement) {
          const detected = await window.RLPose.detect(currentVideo, performance.now());
          if (detected?.landmarks && runningRef.current) {
            const frame = window.RLScore.scoreFrame(currentMovement, detected.landmarks, detected.timestamp);
            samplesRef.current.push({
              t: Math.round(performance.now() - started),
              overall: frame.overall,
              band: frame.band,
              weak: frame.weak,
            });
            if (frame.fixes?.length) fixesRef.current = frame.fixes.slice(0, 4);
            window.RLPose.syncCanvasSize(canvas, currentVideo);
            const ctx = canvas.getContext("2d");
            if (ctx) {
              window.RLPose.drawSkeleton(ctx, canvas, detected.landmarks, {
                mirror: false,
                band: frame.weak ? "weak" : frame.band,
              });
            }
            setLive({ overall: frame.overall, band: frame.weak ? "weak" : frame.band });
          }
        }
        if (runningRef.current) requestAnimationFrame(() => void tick());
      };
      void tick();
    } catch {
      setCameraState("off");
      setCameraError("Camera stays off. Use the checklist. A checklist session can still be saved.");
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  }

  function stopCamera() {
    runningRef.current = false;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCameraState("off");
    const score = window.RLScore;
    if (!score) {
      setReview({ mode: "camera", overall: null, band: "weak", cues: ["Tracking weak"] });
      return;
    }
    const summary = score.sessionAggregate(score.buildTimeline(samplesRef.current));
    setReview({
      mode: "camera",
      overall: summary.overall,
      band: summary.band || "weak",
      cues: fixesRef.current,
    });
    setLive(null);
  }

  function save(mode: "checklist" | "camera") {
    if (!movement) return;
    const cues = movement.idealCues ?? [];
    const checklistScore = cues.length === 0 ? 0 : Math.round((checked.length / cues.length) * 100);
    const payload =
      mode === "checklist"
        ? {
            overall: checklistScore,
            band: cues.length === 0 ? "weak" : bandOf(checklistScore),
            cues: cues.filter((cue) => !checked.includes(cue)),
          }
        : {
            overall: review?.overall ?? null,
            band: review?.band ?? "weak",
            cues: review?.cues ?? [],
          };
    setMessage("");
    start(async () => {
      const result = await savePoseSession({
        athleteId,
        movementId: movement.id,
        movementName: movement.name,
        position,
        place,
        mode,
        overall: payload.overall,
        band: payload.band,
        cues: payload.cues,
        notes,
        day: localDay(),
      });
      setMessage(result.error ?? result.message ?? "");
      if (!result.error) router.refresh();
    });
  }

  const cues = movement?.idealCues ?? [];
  const checklistScore = cues.length === 0 ? 0 : Math.round((checked.length / cues.length) * 100);

  return (
    <div id="tracker" className="grid gap-4">
      <p className="text-sm text-muted-foreground">
        {athleteName}. Football only. Red under 55, yellow 55–79, green 80 or better. Tracking weak means the camera lost the joints.
      </p>
      {loadError ? <p className="text-sm text-destructive">{loadError}</p> : null}
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="grid gap-1 text-sm font-semibold">
          Position
          <select
            value={position}
            onChange={(event) => setPosition(event.target.value)}
            className="h-11 rounded-lg border border-input bg-card px-3 text-base font-normal"
          >
            {positions.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-sm font-semibold">
          Movement
          <select
            value={movementId}
            onChange={(event) => {
              setMovementId(event.target.value);
              setChecked([]);
              setReview(null);
            }}
            className="h-11 rounded-lg border border-input bg-card px-3 text-base font-normal"
          >
            {movements.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      {allowFieldToggle ? (
        <label className="flex items-start gap-3 text-sm">
          <input
            type="checkbox"
            checked={atHome}
            onChange={(event) => setAtHome(event.target.checked)}
            className="mt-1 size-4 accent-[#C8102E]"
          />
          <span>
            <span className="font-semibold">Home session</span>
            <span className="mt-1 block text-muted-foreground">
              On the field with the team, turn this off. Field sessions are not gated.
            </span>
          </span>
        </label>
      ) : (
        <p className="text-sm">Field station. This save is not gated by the study block.</p>
      )}
      {homeBlocked ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm text-accent-foreground">
          {STUDY_GATE_LINE} Finish today's study block, or ask a parent for a note, before a home session can be saved.
        </p>
      ) : null}
      {movement ? (
        <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <p className="font-semibold">{movement.name}</p>
          <p className="mt-1 text-sm text-muted-foreground">{movement.description}</p>
          <p className="mt-2 text-sm">Camera view: {movement.view}. {movement.setupTips?.[0]}</p>
          <p className="mt-3 text-sm font-semibold">
            Checklist · <BandPill band={cues.length ? bandOf(checklistScore) : "weak"} score={checklistScore} />
          </p>
          <ul className="mt-2 grid gap-2">
            {cues.map((cue) => {
              const id = `cue-${movement.id}-${cue}`;
              return (
                <li key={cue} className="flex items-start gap-2">
                  <input
                    id={id}
                    type="checkbox"
                    checked={checked.includes(cue)}
                    onChange={() => toggleCue(cue)}
                    className="mt-1 size-4 accent-[#C8102E]"
                  />
                  <label htmlFor={id} className="text-sm">
                    {cue}
                  </label>
                </li>
              );
            })}
          </ul>
          <Button type="button" size="touch" className="mt-3" disabled={pending} onClick={() => save("checklist")}>
            Save checklist
          </Button>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">
          {ready ? "No movements for that position. Try General." : "Loading movements…"}
        </p>
      )}
      <div className="grid gap-3">
        <div className="relative overflow-hidden rounded-xl bg-ink">
          <video ref={videoRef} playsInline muted autoPlay className="block aspect-[4/3] w-full -scale-x-100 object-contain" />
          <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full -scale-x-100" />
          {live ? (
            <div className="absolute top-3 left-3">
              <BandPill band={live.band} score={live.overall} />
            </div>
          ) : null}
        </div>
        <div className="flex flex-wrap gap-2">
          {cameraState === "on" ? (
            <Button type="button" size="touch" variant="secondary" onClick={stopCamera}>
              Stop
            </Button>
          ) : (
            <Button type="button" size="touch" variant="outline" disabled={cameraState === "starting"} onClick={() => void startCamera()}>
              {cameraState === "starting" ? "Opening camera…" : "Start camera"}
            </Button>
          )}
        </div>
        {cameraError ? <p className="text-sm">{cameraError}</p> : null}
        {review?.mode === "camera" ? (
          <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
            <p className="font-semibold">
              Camera summary <BandPill band={review.band} score={review.overall} />
            </p>
            {review.cues.length > 0 ? (
              <ul className="mt-2 list-disc pl-5 text-sm">
                {review.cues.map((cue) => (
                  <li key={cue}>{cue}</li>
                ))}
              </ul>
            ) : (
              <p className="mt-2 text-sm text-muted-foreground">No cue from the frames that tracked.</p>
            )}
            <Button type="button" size="touch" className="mt-3" disabled={pending} onClick={() => save("camera")}>
              Save camera session
            </Button>
          </div>
        ) : null}
      </div>
      <label className="grid gap-1 text-sm font-semibold">
        Session note
        <input
          value={notes}
          onChange={(event) => setNotes(event.target.value)}
          maxLength={240}
          className="h-11 rounded-lg border border-input bg-card px-3 text-base font-normal"
        />
      </label>
      {message ? <p className="text-sm">{message}</p> : null}
      <p className="text-xs text-muted-foreground">
        Not a medical device. Stop for pain, numbness, or a stinger and see the ATC. Camera scoring needs localhost or https.
      </p>
    </div>
  );
}
