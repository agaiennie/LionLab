import { ACADEMIC_TONE as TONE } from "@/components/academic-chip";
import { AcademicForm } from "@/components/academic-form";
import {
  ACADEMIC_MEANING,
  GRADES_FIRST_LINE,
  PIAA_LINE,
  asAcademicStatus,
} from "@/lib/academics";
import { prisma } from "@/lib/db";

export async function AcademicCard({
  athleteId,
  canEdit,
}: {
  athleteId: string;
  canEdit: "staff" | "parent" | "none";
}) {
  const athlete = await prisma.athleteProfile.findUnique({
    where: { id: athleteId },
    select: { academicStatus: true, academicNote: true, academicCheckedOn: true },
  });
  if (!athlete) return null;
  const status = asAcademicStatus(athlete.academicStatus);
  const meaning = ACADEMIC_MEANING[status];
  const checked = athlete.academicCheckedOn
    ? new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", timeZone: "UTC" }).format(
        athlete.academicCheckedOn,
      )
    : null;

  return (
    <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10" aria-label="Academic status">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="font-display text-3xl tracking-wide">Academics</h2>
        <span className={`rounded-full px-3 py-1 text-sm font-semibold ring-1 ${TONE[status]}`}>
          {meaning.label}
        </span>
      </div>
      <p className="font-semibold">{meaning.meaning}</p>
      {athlete.academicNote ? <p className="text-sm">Note: {athlete.academicNote}</p> : null}
      <p className="text-xs text-muted-foreground">{checked ? `Last checked ${checked}.` : "Not checked yet this season."}</p>
      <p className="text-sm">
        <span className="font-semibold text-lion">{GRADES_FIRST_LINE}</span> {PIAA_LINE}
      </p>
      {canEdit !== "none" ? (
        <div className="border-t border-foreground/10 pt-3">
          <AcademicForm athleteId={athleteId} mode={canEdit} status={status} note={athlete.academicNote} />
        </div>
      ) : null}
    </section>
  );
}
