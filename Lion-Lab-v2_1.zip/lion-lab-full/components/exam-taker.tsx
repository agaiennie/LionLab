"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { submitAttempt } from "@/app/actions/exams";
import { Button } from "@/components/ui/button";

export type TakerQuestion = { id: string; topic: string; prompt: string; choices: string[] };

const LETTERS = ["A", "B", "C", "D", "E"];

/** One question per card. The answer key never reaches the browser. */
export function ExamTaker({ examSlug, questions }: { examSlug: string; questions: TakerQuestion[] }) {
  const router = useRouter();
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(() => questions.map(() => null));
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  const total = questions.length;
  const onReview = index >= total;
  const answered = answers.filter((a) => a !== null).length;
  const question = questions[index];

  function choose(choice: number) {
    setAnswers((prev) => prev.map((a, i) => (i === index ? choice : a)));
  }

  function submit() {
    setError(null);
    if (answers.some((a) => a === null)) {
      setError("Answer every question first.");
      return;
    }
    startTransition(async () => {
      const result = await submitAttempt(examSlug, answers as number[]);
      if ("error" in result) {
        setError(result.error);
        return;
      }
      router.push(`/exams/${examSlug}?attempt=${result.attemptId}`);
      router.refresh();
    });
  }

  return (
    <div className="grid gap-4">
      <div className="grid gap-1">
        <div className="flex justify-between text-sm font-semibold">
          <span>{onReview ? "Check and submit" : `Question ${index + 1} of ${total}`}</span>
          <span className="text-muted-foreground">{answered} answered</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-muted" aria-hidden>
          <div className="h-full bg-lion transition-all" style={{ width: `${(answered / total) * 100}%` }} />
        </div>
      </div>

      {!onReview && question ? (
        <section className="grid gap-4 rounded-xl bg-card p-4 ring-1 ring-foreground/10" aria-live="polite">
          {question.topic ? (
            <p className="font-display text-sm font-semibold tracking-[0.18em] text-lion">{question.topic}</p>
          ) : null}
          <h2 className="text-xl font-semibold leading-snug">{question.prompt}</h2>
          <div className="grid gap-3" role="radiogroup" aria-label="Answers">
            {question.choices.map((choice, i) => {
              const selected = answers[index] === i;
              return (
                <button
                  key={i}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => choose(i)}
                  className={`flex min-h-14 w-full items-start gap-3 rounded-lg border-2 px-4 py-3 text-left text-base transition-colors ${
                    selected ? "border-lion bg-lion/10 font-semibold" : "border-input bg-card hover:bg-muted"
                  }`}
                >
                  <span
                    className={`grid size-7 shrink-0 place-items-center rounded-full text-sm font-bold ${
                      selected ? "bg-lion text-white" : "bg-muted"
                    }`}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-0.5">{choice}</span>
                </button>
              );
            })}
          </div>
        </section>
      ) : null}

      {onReview ? (
        <section className="grid gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
          <h2 className="font-display text-3xl tracking-wide">Ready?</h2>
          <p>
            {answered} of {total} answered. Tap a number to go back to it.
          </p>
          <div className="flex flex-wrap gap-2">
            {questions.map((q, i) => (
              <button
                key={q.id}
                type="button"
                onClick={() => setIndex(i)}
                className={`grid size-11 place-items-center rounded-lg text-base font-bold ${
                  answers[i] === null ? "bg-amber-400 text-ink" : "bg-muted"
                }`}
                aria-label={`Question ${i + 1}${answers[i] === null ? ", not answered" : ""}`}
              >
                {i + 1}
              </button>
            ))}
          </div>
          <Button size="touch" onClick={submit} disabled={pending || answered < total}>
            {pending ? "Grading…" : "Submit exam"}
          </Button>
        </section>
      ) : null}

      {error ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm text-accent-foreground" role="alert">
          {error}
        </p>
      ) : null}

      <div className="grid grid-cols-2 gap-3">
        <Button size="touch" variant="outline" disabled={index === 0} onClick={() => setIndex((i) => Math.max(0, i - 1))}>
          Back
        </Button>
        {onReview ? (
          <span />
        ) : (
          <Button
            size="touch"
            disabled={answers[index] === null}
            onClick={() => setIndex((i) => Math.min(total, i + 1))}
          >
            {index === total - 1 ? "Finish" : "Next"}
          </Button>
        )}
      </div>
    </div>
  );
}
