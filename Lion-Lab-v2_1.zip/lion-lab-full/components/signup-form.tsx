"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { signUp, type FormEchoState } from "@/app/actions/signup";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { HONEYPOT } from "@/lib/signup";

const ROLES = [
  { value: "PARENT", label: "Parent or guardian", hint: "See your own kid's work, study, and coach notes." },
  { value: "ATHLETE", label: "Athlete", hint: "Train, study, and track your own numbers." },
  { value: "COACH", label: "Coach", hint: "Staff on this team. An admin approves coaches." },
] as const;

type Role = (typeof ROLES)[number]["value"];

export function SignupForm() {
  const [state, action, pending] = useActionState<FormEchoState, FormData>(signUp, {});
  const values = state.values ?? {};
  const [role, setRole] = useState<Role | "">((values.role as Role) ?? "");
  const errors = state.fieldErrors ?? {};

  if (state.message && !state.fieldErrors) {
    return (
      <div className="grid gap-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10" role="status">
        <p className="font-display text-3xl tracking-wide text-lion">You&apos;re signed up</p>
        <p className="text-lg">{state.message}</p>
        <p className="text-muted-foreground">
          If you try to sign in before then, you&apos;ll see a &quot;waiting for approval&quot; note. That&apos;s normal.
        </p>
        <div className="flex flex-wrap gap-4">
          <Link href="/" className="font-semibold text-lion">
            ← Program home
          </Link>
          <Link href="/signin" className="font-semibold text-lion">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form key={JSON.stringify(values)} action={action} className="grid gap-5">
      {/* Honeypot: hidden from people and screen readers. */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor={HONEYPOT}>Leave this empty</label>
        <input id={HONEYPOT} name={HONEYPOT} type="text" tabIndex={-1} autoComplete="off" defaultValue="" />
      </div>

      {state.error ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm" role="alert">
          {state.error}
        </p>
      ) : null}
      {Object.keys(errors).length > 0 ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm" role="alert">
          Check the boxes marked in red. Re-type your password.
        </p>
      ) : null}

      <fieldset className="grid gap-2">
        <legend className="mb-2 font-display text-2xl tracking-wide">I am a…</legend>
        {ROLES.map((option) => (
          <label
            key={option.value}
            className="flex cursor-pointer items-start gap-3 rounded-xl border-2 border-border bg-card px-4 py-3 has-checked:border-lion has-checked:bg-lion/5"
          >
            <input
              type="radio"
              name="role"
              value={option.value}
              checked={role === option.value}
              onChange={() => setRole(option.value)}
              className="mt-1.5 size-5 accent-[#C8102E]"
              required
            />
            <span>
              <span className="block font-display text-xl tracking-wide">{option.label}</span>
              <span className="block text-sm text-muted-foreground">{option.hint}</span>
            </span>
          </label>
        ))}
        <FieldError message={errors.role} />
      </fieldset>

      {role ? (
        <>
          <Field
            id="joinCode"
            label="Team code"
            hint="Get the code from a coach."
            error={errors.joinCode}
            defaultValue={values.joinCode}
            autoComplete="off"
            autoCapitalize="characters"
            required
          />
          <Field id="name" label="Your name" error={errors.name} defaultValue={values.name} autoComplete="name" required />
          <Field
            id="email"
            label="Your email"
            type="email"
            error={errors.email}
            defaultValue={values.email}
            autoComplete="email"
            required
          />
          <Field
            id="password"
            label="Password"
            type="password"
            hint="At least 8 characters."
            error={errors.password}
            autoComplete="new-password"
            minLength={8}
            required
          />
          <Field
            id="phone"
            label="Phone (optional)"
            type="tel"
            error={errors.phone}
            defaultValue={values.phone}
            autoComplete="tel"
          />

          {role === "PARENT" ? (
            <Field
              id="kidNames"
              label="Your player(s) on the team"
              hint="First and last name. A coach uses this to link you to your kid."
              error={errors.kidNames}
              defaultValue={values.kidNames}
              required
            />
          ) : null}

          {role === "ATHLETE" ? (
            <>
              <div className="grid gap-1.5">
                <Label htmlFor="grade" className="text-base">
                  Grade
                </Label>
                <select
                  id="grade"
                  name="grade"
                  defaultValue={values.grade ?? ""}
                  required
                  className="h-12 rounded-lg border border-input bg-background px-3 text-base"
                >
                  <option value="" disabled>
                    Pick a grade
                  </option>
                  {[7, 8, 9, 10, 11, 12].map((grade) => (
                    <option key={grade} value={grade}>
                      {grade}th grade
                    </option>
                  ))}
                </select>
                <FieldError message={errors.grade} />
              </div>
              <div className="grid gap-3 rounded-xl bg-muted/50 p-3">
                <p className="text-sm">
                  <span className="font-semibold">A parent or guardian is required.</span> Players are minors, so a coach
                  checks with your parent before approving you.
                </p>
                <Field
                  id="parentName"
                  label="Parent or guardian name"
                  error={errors.parentName}
                  defaultValue={values.parentName}
                  required
                />
                <Field
                  id="parentEmail"
                  label="Parent or guardian email"
                  type="email"
                  error={errors.parentEmail}
                  defaultValue={values.parentEmail}
                  required
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Your coach sets your height, weight, and positions when they approve you.
              </p>
            </>
          ) : null}

          {role === "ATHLETE" || role === "COACH" ? (
            <div className="grid gap-1.5">
              <Label htmlFor="note" className="text-base">
                {role === "COACH" ? "What do you coach?" : "Anything a coach should know? (optional)"}
              </Label>
              <Textarea
                id="note"
                name="note"
                rows={2}
                defaultValue={values.note}
                placeholder={role === "COACH" ? "OL assistant" : "Positions you want to try, other sports…"}
                className="text-base"
              />
              <FieldError message={errors.note} />
            </div>
          ) : null}

          <p className="rounded-lg bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
            Privacy: an athlete&apos;s numbers are visible only to that athlete, their linked parents, and coaches. The
            public site never shows individual kids.
          </p>

          <Button type="submit" size="touch" disabled={pending} className="h-12 text-lg">
            {pending ? "Sending…" : "Create my account"}
          </Button>
        </>
      ) : (
        <p className="text-muted-foreground">Pick one to see the rest of the form.</p>
      )}
    </form>
  );
}

function Field({
  id,
  label,
  hint,
  error,
  ...props
}: {
  id: string;
  label: string;
  hint?: string;
  error?: string;
} & React.ComponentProps<"input">) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id} className="text-base">
        {label}
      </Label>
      {hint ? <p className="-mt-1 text-sm text-muted-foreground">{hint}</p> : null}
      <Input id={id} name={id} aria-invalid={error ? true : undefined} className="h-12 text-base" {...props} />
      <FieldError message={error} />
    </div>
  );
}

function FieldError({ message }: { message?: string }) {
  return message ? <p className="text-sm text-destructive">{message}</p> : null;
}
