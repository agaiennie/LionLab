import { ACADEMIC_MEANING, asAcademicStatus, type AcademicStatus } from "@/lib/academics";

export const ACADEMIC_TONE: Record<AcademicStatus, string> = {
  GOOD: "bg-emerald-100 text-emerald-900 ring-emerald-300 dark:bg-emerald-950 dark:text-emerald-100 dark:ring-emerald-800",
  WATCH: "bg-amber-100 text-amber-900 ring-amber-300 dark:bg-amber-950 dark:text-amber-100 dark:ring-amber-800",
  HOLD: "bg-red-100 text-red-900 ring-red-300 dark:bg-red-950 dark:text-red-100 dark:ring-red-800",
};

/** Small status chip. Safe in client and server components. */
export function AcademicChip({ status, hideGood = false }: { status: string; hideGood?: boolean }) {
  const value = asAcademicStatus(status);
  if (hideGood && value === "GOOD") return null;
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ring-1 ${ACADEMIC_TONE[value]}`}
      title={ACADEMIC_MEANING[value].meaning}
    >
      {value === "HOLD" ? "Academic hold" : value === "WATCH" ? "Academic watch" : "Academics good"}
    </span>
  );
}
