import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TESTS, type TestType } from "@/lib/scoring";

export function ResultCard({
  testType,
  rawLabel,
  passedCount,
  totalCount,
  percent,
  estimate,
  math,
  cues,
  retest,
  notes,
  meta,
  emptyHref,
}: {
  testType: TestType;
  rawLabel?: string;
  passedCount?: number;
  totalCount?: number;
  percent?: number;
  estimate?: string;
  math?: string;
  cues?: string[];
  retest?: string;
  notes?: string;
  meta?: string;
  emptyHref?: string;
}) {
  const test = TESTS[testType];
  const empty = percent == null;

  return (
    <Card className="h-full text-base">
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <CardTitle className="font-display text-2xl tracking-wide">{test.label}</CardTitle>
          <Badge variant="outline" className="border-lion text-lion">
            ESTIMATE
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4">
        {empty ? (
          <div className="grid gap-3">
            <p className="text-muted-foreground">No {test.short.toLowerCase()} on file yet.</p>
            {emptyHref ? (
              <Link href={emptyHref} className="font-semibold text-lion">
                Log one
              </Link>
            ) : (
              <p className="text-sm text-muted-foreground">Your coach logs this test.</p>
            )}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-2">
              <NumberBlock label="Raw" value={rawLabel ?? "—"} />
              <NumberBlock
                label="Form"
                value={`${percent}%`}
                detail={`${passedCount} of ${totalCount}`}
              />
              <NumberBlock label="Adjusted" value={estimate ?? "—"} emphasize />
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-muted" aria-hidden>
              <div className="h-full bg-lion" style={{ width: `${percent}%` }} />
            </div>
            <p className="text-xs leading-relaxed text-muted-foreground">
              Formula {`v1`} · {math}
            </p>
            <div>
              <p className="text-sm font-semibold">Coaching cues</p>
              {cues && cues.length > 0 ? (
                <ul className="mt-1 list-disc space-y-1 pl-5 text-sm">
                  {cues.map((cue) => (
                    <li key={cue}>{cue}</li>
                  ))}
                </ul>
              ) : (
                <p className="mt-1 text-sm text-muted-foreground">
                  Checklist was clean. Chase the retest number.
                </p>
              )}
            </div>
            <p className="rounded-lg bg-accent px-3 py-2 text-sm text-accent-foreground">{retest}</p>
            {notes ? <p className="text-sm text-muted-foreground">Note: {notes}</p> : null}
            {meta ? <p className="text-xs text-muted-foreground">{meta}</p> : null}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function NumberBlock({
  label,
  value,
  detail,
  emphasize = false,
}: {
  label: string;
  value: string;
  detail?: string;
  emphasize?: boolean;
}) {
  return (
    <div>
      <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{label}</p>
      <p
        className={
          value.length > 8
            ? "font-display text-2xl leading-none font-semibold tracking-wide"
            : "font-display text-3xl leading-none font-semibold tracking-wide tabular-nums sm:text-4xl"
        }
      >
        <span className={emphasize ? "text-lion" : undefined}>{value}</span>
      </p>
      {detail ? <p className="mt-1 text-xs text-muted-foreground">{detail}</p> : null}
    </div>
  );
}

export function resultProps(
  session: {
    testType: TestType;
    notes: string;
    recordedOnLabel: string;
    recordedBy: string;
    scored: {
      rawLabel: string;
      passedCount: number;
      totalCount: number;
      percent: number;
      estimate: { display: string; math: string };
      cues: string[];
      retest: string;
    };
  },
) {
  return {
    testType: session.testType,
    rawLabel: session.scored.rawLabel,
    passedCount: session.scored.passedCount,
    totalCount: session.scored.totalCount,
    percent: session.scored.percent,
    estimate: session.scored.estimate.display,
    math: session.scored.estimate.math,
    cues: session.scored.cues,
    retest: session.scored.retest,
    notes: session.notes,
    meta: `${session.recordedOnLabel} · logged by ${session.recordedBy}`,
  };
}
