import {
  WATCH_MULTIPLIER,
  effectiveWeeklyTarget,
  weekStartKey,
  weekStudyTotal,
} from "@/lib/academics";
import { labelDay } from "@/lib/days";
import { shiftDay } from "@/lib/habits";

/** "This week: X of Y minutes" — Monday through Sunday. */
export function WeeklyStudy({
  days,
  today,
  baseTarget,
  status,
}: {
  days: { day: string; studyMinutes: number }[];
  today: string;
  baseTarget: number;
  status: string;
}) {
  const start = weekStartKey(today);
  const total = weekStudyTotal(days, start);
  const target = effectiveWeeklyTarget(baseTarget, status);
  const pct = target > 0 ? Math.min(100, Math.round((total / target) * 100)) : 0;
  const done = total >= target;
  return (
    <div className="grid gap-2" aria-label="Weekly study requirement">
      <p className="font-display text-2xl tracking-wide">
        This week: {total} of {target} minutes
      </p>
      <div className="h-3 overflow-hidden rounded-full bg-foreground/10" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div className={`h-full ${done ? "bg-emerald-600" : "bg-lion"}`} style={{ width: `${pct}%` }} />
      </div>
      <p className="text-sm text-muted-foreground">
        Week of {labelDay(start)}–{labelDay(shiftDay(start, 6))} (Mon–Sun).{" "}
        {status === "WATCH"
          ? `Academic Watch: the team requirement of ${baseTarget} minutes is raised ${WATCH_MULTIPLIER}× to ${target}.`
          : `Team requirement: ${baseTarget} minutes a week. On academic Watch it goes up ${WATCH_MULTIPLIER}×.`}
        {done ? " Requirement met." : ""}
      </p>
    </div>
  );
}
