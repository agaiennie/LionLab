"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteMeasurement } from "@/app/actions/measure";

export function DeleteMeasurementButton({ id, label }: { id: string; label: string }) {
  const router = useRouter();
  const [armed, setArmed] = useState(false);
  const [pending, start] = useTransition();
  const [error, setError] = useState("");

  if (!armed) {
    return (
      <button type="button" onClick={() => setArmed(true)} className="h-9 rounded-lg px-2 text-sm font-semibold text-lion">
        Delete
      </button>
    );
  }
  return (
    <span className="flex items-center gap-2">
      {error ? <span className="text-destructive">{error}</span> : null}
      <button
        type="button"
        disabled={pending}
        aria-label={`Confirm delete ${label}`}
        onClick={() =>
          start(async () => {
            const result = await deleteMeasurement(id);
            if (result.error) setError(result.error);
            else router.refresh();
          })
        }
        className="h-9 rounded-lg bg-lion px-3 text-sm font-semibold text-white"
      >
        {pending ? "…" : "Yes, delete"}
      </button>
      <button type="button" onClick={() => setArmed(false)} className="h-9 px-2 text-sm">
        Keep
      </button>
    </span>
  );
}
