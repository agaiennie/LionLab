"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { AcademicChip } from "@/components/academic-chip";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { GRADES, POSITIONS } from "@/lib/scoring";

export type RosterRow = {
  id: string;
  name: string;
  email: string;
  grade: number;
  positions: string[];
  heightLabel: string;
  weightLbs: number;
  forty: string;
  medball: string;
  stance: string;
  updated: string;
  study: string;
  /** GOOD | WATCH | HOLD. Optional so older callers still compile. */
  academicStatus?: string;
};

const selectClass = "h-11 rounded-lg border border-input bg-card px-3 text-base";

export function RosterBoard({ rows }: { rows: RosterRow[] }) {
  const [query, setQuery] = useState("");
  const [grade, setGrade] = useState("all");
  const [position, setPosition] = useState("all");

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesQuery =
        needle.length === 0 ||
        row.name.toLowerCase().includes(needle) ||
        row.email.toLowerCase().includes(needle);
      const matchesGrade = grade === "all" || String(row.grade) === grade;
      const matchesPosition = position === "all" || row.positions.includes(position);
      return matchesQuery && matchesGrade && matchesPosition;
    });
  }, [rows, query, grade, position]);

  const filtered = query.trim() !== "" || grade !== "all" || position !== "all";

  return (
    <div className="grid gap-4">
      <div className="grid gap-3 sm:grid-cols-[1fr_9rem_11rem]">
        <Input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search name or email"
          aria-label="Search athletes"
          className="h-11 text-base"
        />
        <select
          value={grade}
          onChange={(event) => setGrade(event.target.value)}
          aria-label="Filter by grade"
          className={selectClass}
        >
          <option value="all">All grades</option>
          {GRADES.map((item) => (
            <option key={item} value={item}>
              Grade {item}
            </option>
          ))}
        </select>
        <select
          value={position}
          onChange={(event) => setPosition(event.target.value)}
          aria-label="Filter by position"
          className={selectClass}
        >
          <option value="all">All positions</option>
          {POSITIONS.map((item) => (
            <option key={item.code} value={item.code}>
              {item.code} · {item.label}
            </option>
          ))}
        </select>
      </div>
      <p className="text-sm text-muted-foreground">
        {visible.length} {visible.length === 1 ? "athlete" : "athletes"}
      </p>
      {visible.length === 0 ? (
        <div className="rounded-xl bg-card px-4 py-8 text-center ring-1 ring-foreground/10">
          <p className="font-semibold">
            {filtered ? "No athletes match that filter." : "No athletes yet."}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            {filtered ? "Clear the search or pick another grade." : "Add an athlete to start the roster."}
          </p>
        </div>
      ) : (
        <>
          <div className="hidden md:block">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Athlete</TableHead>
                  <TableHead>Gr</TableHead>
                  <TableHead>Pos</TableHead>
                  <TableHead>40 · form · est</TableHead>
                  <TableHead>Med ball · form · est</TableHead>
                  <TableHead>Stance</TableHead>
                  <TableHead>Study</TableHead>
                  <TableHead>Updated</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell>
                      <Link href={`/coach/athletes/${row.id}`} className="font-semibold hover:underline">
                        {row.name}
                      </Link>
                      {row.academicStatus ? (
                        <span className="ml-2 align-middle">
                          <AcademicChip status={row.academicStatus} hideGood />
                        </span>
                      ) : null}
                      <div className="text-xs text-muted-foreground">{row.email}</div>
                    </TableCell>
                    <TableCell>{row.grade}</TableCell>
                    <TableCell>{row.positions.join(" ")}</TableCell>
                    <TableCell>{row.forty}</TableCell>
                    <TableCell>{row.medball}</TableCell>
                    <TableCell>{row.stance}</TableCell>
                    <TableCell>{row.study}</TableCell>
                    <TableCell>{row.updated}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="grid gap-3 md:hidden">
            {visible.map((row) => (
              <Link
                key={row.id}
                href={`/coach/athletes/${row.id}`}
                className="grid gap-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10"
              >
                <div className="flex items-baseline justify-between gap-3">
                  <p className="font-display text-2xl tracking-wide">
                    {row.name}
                    {row.academicStatus ? (
                      <span className="ml-2 align-middle font-sans">
                        <AcademicChip status={row.academicStatus} hideGood />
                      </span>
                    ) : null}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Gr {row.grade} · {row.positions.join(" ")}
                  </p>
                </div>
                <p className="text-sm">40 {row.forty}</p>
                <p className="text-sm">Med ball {row.medball}</p>
                <p className="text-sm">Stance {row.stance}</p>
                <p className="text-sm">Study {row.study}</p>
              </Link>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
