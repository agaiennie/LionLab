"use client";

import { useActionState } from "react";
import { inviteParent } from "@/app/actions/daily";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { ActionState } from "@/lib/validators";

export function ParentInviteForm({
  athletes,
}: {
  athletes: { id: string; name: string }[];
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(inviteParent, {});
  const locked = athletes.length === 1;

  return (
    <form action={action} className="grid gap-3">
      {state.invite ? (
        <div className="rounded-lg bg-accent px-3 py-3 text-sm text-accent-foreground">
          <p>{state.message}</p>
          <p className="mt-2 font-semibold">
            {state.invite.name} · {state.invite.email}
          </p>
          <p>Password: {state.invite.temporaryPassword}</p>
        </div>
      ) : state.message ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm">{state.message}</p>
      ) : null}
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      <div className="grid gap-1.5">
        <Label htmlFor="parent-name">Parent name</Label>
        <Input id="parent-name" name="name" required className="h-11 text-base" />
        {state.fieldErrors?.name ? <p className="text-sm text-destructive">{state.fieldErrors.name}</p> : null}
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="parent-email">Parent email</Label>
        <Input id="parent-email" name="email" type="email" required className="h-11 text-base" />
        {state.fieldErrors?.email ? <p className="text-sm text-destructive">{state.fieldErrors.email}</p> : null}
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="parent-password">Temporary password</Label>
        <Input id="parent-password" name="password" type="text" minLength={8} className="h-11 text-base" />
        <p className="text-xs text-muted-foreground">Needed for a new email. Share it in person. Skip it to link an existing parent.</p>
        {state.fieldErrors?.password ? (
          <p className="text-sm text-destructive">{state.fieldErrors.password}</p>
        ) : null}
      </div>
      {locked ? (
        <input type="hidden" name="athleteId" value={athletes[0]?.id} />
      ) : (
        <fieldset className="grid gap-2">
          <legend className="text-sm font-semibold">Link to</legend>
          {athletes.map((athlete) => (
            <label key={athlete.id} className="flex items-center gap-2 text-sm" htmlFor={`link-${athlete.id}`}>
              <input id={`link-${athlete.id}`} type="checkbox" name="athleteId" value={athlete.id} className="size-4 accent-[#C8102E]" />
              {athlete.name}
            </label>
          ))}
        </fieldset>
      )}
      <Button type="submit" size="touch" disabled={pending}>
        {pending ? "Saving…" : "Invite parent"}
      </Button>
    </form>
  );
}
