export function PassBadge({ passed, label }: { passed: boolean; label?: string }) {
  return passed ? (
    <span className="inline-flex rounded-full bg-emerald-600 px-3 py-1 text-xs font-bold text-white">{label ?? "Passed"}</span>
  ) : (
    <span className="inline-flex rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-ink">{label ?? "Not passed yet"}</span>
  );
}

export function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-muted px-2 py-2 text-center">
      <dt className="text-xs font-semibold text-muted-foreground">{label}</dt>
      <dd className="font-display text-2xl">{value}</dd>
    </div>
  );
}
