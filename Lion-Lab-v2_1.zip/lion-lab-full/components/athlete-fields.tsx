"use client";

import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GRADES, POSITIONS } from "@/lib/scoring";

const fieldClass = "h-11 w-full rounded-lg border border-input bg-card px-3 text-base";

export function AthleteFields({
  values,
  includeEmail,
  errors,
}: {
  values: {
    name: string;
    email: string;
    grade: number;
    positions: string[];
    feet: number;
    inches: number;
    weightLbs: number;
  };
  includeEmail: boolean;
  errors?: Record<string, string>;
}) {
  return (
    <div className="grid gap-4">
      <Field label="Name" htmlFor="name" error={errors?.name}>
        <Input id="name" name="name" defaultValue={values.name} required className="h-11 text-base" />
      </Field>
      {includeEmail ? (
        <Field label="Email" htmlFor="email" error={errors?.email} hint="This is their sign-in. It is not shown on a public page.">
          <Input
            id="email"
            name="email"
            type="email"
            defaultValue={values.email}
            required
            className="h-11 text-base"
          />
        </Field>
      ) : null}
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Grade" htmlFor="grade" error={errors?.grade}>
          <select id="grade" name="grade" defaultValue={values.grade} className={fieldClass}>
            {GRADES.map((grade) => (
              <option key={grade} value={grade}>
                Grade {grade}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Height" htmlFor="feet" error={errors?.feet ?? errors?.inches}>
          <div className="grid grid-cols-2 gap-2">
            <select id="feet" name="feet" defaultValue={values.feet} className={fieldClass} aria-label="Feet">
              {[4, 5, 6, 7].map((feet) => (
                <option key={feet} value={feet}>
                  {feet} ft
                </option>
              ))}
            </select>
            <select name="inches" defaultValue={values.inches} className={fieldClass} aria-label="Inches">
              {Array.from({ length: 12 }, (_, inches) => (
                <option key={inches} value={inches}>
                  {inches} in
                </option>
              ))}
            </select>
          </div>
        </Field>
        <Field label="Weight (lb)" htmlFor="weightLbs" error={errors?.weightLbs}>
          <Input
            id="weightLbs"
            name="weightLbs"
            type="number"
            min={70}
            max={400}
            defaultValue={values.weightLbs}
            required
            className="h-11 text-base"
          />
        </Field>
      </div>
      <fieldset className="grid gap-2">
        <legend className="text-sm font-medium">Positions</legend>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          {POSITIONS.map((position) => (
            <div
              key={position.code}
              className="flex items-center gap-3 rounded-lg border border-border bg-card px-3 py-3"
            >
              <Checkbox
                id={`pos-${position.code}`}
                name="positions"
                value={position.code}
                defaultChecked={values.positions.includes(position.code)}
              />
              <label htmlFor={`pos-${position.code}`}>
                <span className="font-semibold">{position.code}</span>
                <span className="text-muted-foreground"> · {position.label}</span>
              </label>
            </div>
          ))}
        </div>
        {errors?.positions ? <p className="text-sm text-destructive">{errors.positions}</p> : null}
      </fieldset>
    </div>
  );
}

function Field({
  label,
  htmlFor,
  error,
  hint,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {hint ? <p className="text-sm text-muted-foreground">{hint}</p> : null}
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
    </div>
  );
}
