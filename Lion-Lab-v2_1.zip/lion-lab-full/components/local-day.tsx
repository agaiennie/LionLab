"use client";

import { useEffect, useState } from "react";
import { localDay } from "@/lib/habits";

export function LocalDayInput() {
  const [day, setDay] = useState("");
  useEffect(() => {
    setDay(localDay());
  }, []);
  return <input type="hidden" name="day" value={day} />;
}
