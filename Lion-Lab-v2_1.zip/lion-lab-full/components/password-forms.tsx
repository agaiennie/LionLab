"use client";

import { useActionState } from "react";
import { changePassword, resetAthletePassword } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { ActionState } from "@/lib/validators";

export function ChangePasswordForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(changePassword, {});

  return (
    <form action={action} className="grid max-w-md gap-4">
      {state.message ? (
        <p className="rounded-lg bg-accent px-3 py-2 text-sm text-accent-foreground">{state.message}</p>
      ) : null}
      <Field label="Current password" name="current" type="password" error={state.fieldErrors?.current} />
      <Field label="New password" name="next" type="password" error={state.fieldErrors?.next} />
      <Field label="Confirm new password" name="confirm" type="password" error={state.fieldErrors?.confirm} />
      {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
      <Button type="submit" size="touch" disabled={pending} className="w-fit">
        {pending ? "Saving…" : "Update password"}
      </Button>
    </form>
  );
}

export function ResetPasswordForm({ athleteId }: { athleteId: string }) {
  const action = resetAthletePassword.bind(null, athleteId);
  const [state, formAction, pending] = useActionState<ActionState, FormData>(action, {});

  return (
    <form action={formAction} className="grid gap-3">
      <Field
        label="New temporary password"
        name="password"
        type="text"
        error={state.fieldErrors?.password}
      />
      <Button type="submit" size="touch" variant="outline" disabled={pending} className="w-fit">
        {pending ? "Saving…" : "Reset password"}
      </Button>
      {state.invite ? (
        <div className="rounded-lg bg-accent px-3 py-3 text-sm text-accent-foreground">
          <p>{state.message}</p>
          <p className="mt-2">
            {state.invite.name} · {state.invite.email}
          </p>
          <p className="font-semibold">Password: {state.invite.temporaryPassword}</p>
        </div>
      ) : null}
    </form>
  );
}

function Field({
  label,
  name,
  type,
  error,
}: {
  label: string;
  name: string;
  type: string;
  error?: string;
}) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} type={type} required minLength={name === "current" ? 1 : 8} className="h-11 text-base" />
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
    </div>
  );
}
