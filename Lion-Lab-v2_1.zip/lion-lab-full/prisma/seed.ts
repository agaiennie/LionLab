import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { makeAdapter } from "../lib/db-adapter";
import { hash } from "bcryptjs";
import { DEMO_PASSWORD } from "../lib/demo-accounts";
import { shiftDay, todayKey } from "../lib/habits";
import { seedDemoRoster } from "../lib/seed/demo-roster";
import { seedDemoAttempts, seedExams } from "../lib/seed/exams";

const prisma = new PrismaClient({ adapter: makeAdapter() });

async function upsertUser(input: {
  email: string;
  name: string;
  role: "ATHLETE" | "COACH" | "ADMIN" | "PARENT";
}) {
  const passwordHash = await hash(DEMO_PASSWORD, 10);
  return prisma.user.upsert({
    where: { email: input.email },
    update: { name: input.name, role: input.role },
    create: {
      email: input.email,
      name: input.name,
      role: input.role,
      passwordHash,
    },
  });
}

async function main() {
  const admin = await upsertUser({
    email: "admin@lionlab.local",
    name: "Sam Okonkwo",
    role: "ADMIN",
  });
  const coach = await upsertUser({
    email: "coach@lionlab.local",
    name: "Dana Ruiz",
    role: "COACH",
  });

  const roster = [
    {
      email: "marcus@lionlab.local",
      name: "Marcus Hale",
      grade: 8,
      positions: "WR,DB",
      heightInches: 67,
      weightLbs: 128,
      sessions: [
        {
          testType: "FORTY",
          rawValue: 5.62,
          passedIds: ["stance", "arms", "posture"],
          notes: "Early season. False step, and he coasted before the line.",
          recordedOn: new Date("2026-08-18T12:00:00.000Z"),
        },
        {
          testType: "FORTY",
          rawValue: 5.48,
          passedIds: ["stance", "first-step", "arms", "posture"],
          notes: "Cleaner start. Still stood up before the line.",
          recordedOn: new Date("2026-09-12T12:00:00.000Z"),
        },
        {
          testType: "MEDBALL",
          rawValue: 24.5,
          passedIds: ["base", "load", "sequence", "release", "finish"],
          notes: "Best rotational throw of the day.",
          recordedOn: new Date("2026-09-12T12:00:00.000Z"),
        },
        {
          testType: "STANCE",
          rawValue: null,
          passedIds: ["feet", "knees", "hands", "hold"],
          notes: "Rounds the back when he gets tired.",
          recordedOn: new Date("2026-09-08T12:00:00.000Z"),
        },
      ],
    },
    {
      email: "avery@lionlab.local",
      name: "Avery Chen",
      grade: 7,
      positions: "RB",
      heightInches: 61,
      weightLbs: 112,
      sessions: [
        {
          testType: "FORTY",
          rawValue: 5.85,
          passedIds: ["stance", "arms", "finish"],
          notes: "Speed shows up once the first step is downhill.",
          recordedOn: new Date("2026-09-10T12:00:00.000Z"),
        },
        {
          testType: "MEDBALL",
          rawValue: 19,
          passedIds: ["base", "load", "finish"],
          notes: "Arms take over. Keep the hip load.",
          recordedOn: new Date("2026-09-10T12:00:00.000Z"),
        },
        {
          testType: "STANCE",
          rawValue: null,
          passedIds: ["feet", "knees", "chest", "hands", "hold"],
          notes: "Base looks game-ready.",
          recordedOn: new Date("2026-09-10T12:00:00.000Z"),
        },
      ],
    },
    {
      email: "jordan@lionlab.local",
      name: "Jordan Brooks",
      grade: 8,
      positions: "LB,DL",
      heightInches: 68,
      weightLbs: 168,
      sessions: [
        {
          testType: "FORTY",
          rawValue: 5.95,
          passedIds: ["stance", "first-step", "arms", "posture", "finish"],
          notes: "Long stride and a clean finish.",
          recordedOn: new Date("2026-09-05T12:00:00.000Z"),
        },
        {
          testType: "MEDBALL",
          rawValue: 27,
          passedIds: ["base", "load", "sequence", "release"],
          notes: "Falls off the front foot at the end.",
          recordedOn: new Date("2026-09-05T12:00:00.000Z"),
        },
        {
          testType: "STANCE",
          rawValue: null,
          passedIds: ["feet", "knees", "hands"],
          notes: "Eyes drop and the back rounds.",
          recordedOn: new Date("2026-09-05T12:00:00.000Z"),
        },
      ],
    },
  ];

  for (const athlete of roster) {
    const user = await upsertUser({
      email: athlete.email,
      name: athlete.name,
      role: "ATHLETE",
    });
    const profile = await prisma.athleteProfile.upsert({
      where: { userId: user.id },
      update: {
        grade: athlete.grade,
        positions: athlete.positions,
        heightInches: athlete.heightInches,
        weightLbs: athlete.weightLbs,
      },
      create: {
        userId: user.id,
        grade: athlete.grade,
        positions: athlete.positions,
        heightInches: athlete.heightInches,
        weightLbs: athlete.weightLbs,
      },
    });

    const alreadyLogged = await prisma.testSession.count({
      where: { athleteId: profile.id },
    });
    if (alreadyLogged > 0) continue;

    await prisma.testSession.createMany({
      data: athlete.sessions.map((session) => ({
        athleteId: profile.id,
        testType: session.testType,
        rawValue: session.rawValue,
        passedIds: JSON.stringify(session.passedIds),
        notes: session.notes,
        recordedOn: session.recordedOn,
        recordedById: coach.id,
      })),
    });
  }

  const marcus = await prisma.user.findUnique({
    where: { email: "marcus@lionlab.local" },
    include: { athlete: true },
  });
  const parent = await upsertUser({
    email: "parent@lionlab.local",
    name: "Pat Hale",
    role: "PARENT",
  });

  if (marcus?.athlete) {
    await prisma.parentLink.upsert({
      where: { parentId_athleteId: { parentId: parent.id, athleteId: marcus.athlete.id } },
      update: {},
      create: { parentId: parent.id, athleteId: marcus.athlete.id },
    });
    await ensureSubjects(marcus.athlete.id, ["Pre-Algebra", "English 8", "Science 8"]);
    const yesterday = shiftDay(todayKey(), -1);
    await prisma.dayLog.upsert({
      where: { athleteId_day: { athleteId: marcus.athlete.id, day: yesterday } },
      update: {},
      create: {
        athleteId: marcus.athlete.id,
        day: yesterday,
        studyMinutes: 25,
        water: true,
        protein: true,
        sleep: true,
        lightJunk: true,
        mobilityDone: true,
        mobilityTemplate: "short",
      },
    });
    const note = "Finish through the line on the 40. Study before extra throws at home.";
    const existingNote = await prisma.coachNote.findFirst({
      where: { athleteId: marcus.athlete.id, body: note },
    });
    if (!existingNote) {
      await prisma.coachNote.create({
        data: { athleteId: marcus.athlete.id, authorId: coach.id, body: note },
      });
    }
  }

  await ensureSubjectsFor("avery@lionlab.local", ["Math 7", "English 7", "Science 7"]);
  await ensureSubjectsFor("jordan@lionlab.local", ["Algebra I", "English 8", "U.S. History"]);

  await prisma.teamSetting.upsert({
    where: { id: "team" },
    update: {},
    create: { id: "team", seasonLabel: "Fall 2026" },
  });

  await seedExams(prisma);
  await seedDemoRoster(prisma, { passwordHash: await hash(DEMO_PASSWORD, 10), coachId: coach.id });
  await seedDemoAttempts(prisma);
  await seedCoreMeasurements(coach.id);

  if ((await prisma.prospect.count({ where: { source: "COACH" } })) === 0) {
    await prisma.prospect.createMany({
      data: [
        {
          name: "Sample: 8th-grade wrestler (112 lb)",
          grade: 8,
          sportsNow: "Wrestling",
          interest: "Coach Ruiz saw him in PE. Low center, great hips.",
          heightInches: 61,
          weightLbs: 112,
          status: "CONTACTED",
          source: "COACH",
          notes: "Talk to wrestling coach first — season overlap in winter only.",
        },
        {
          name: "Sample: 7th-grade soccer player",
          grade: 7,
          sportsNow: "Soccer",
          interest: "Kicks with both feet. Asked about kicking.",
          status: "NEW",
          source: "COACH",
        },
      ],
    });
  }

  console.log("Lion Lab seed ready.");
  console.log(`Admin ${admin.email} / Coach ${coach.email} / Parent ${parent.email} / password ${DEMO_PASSWORD}`);
}

/** Test-day numbers for the three original demo athletes (only if they have none). */
async function seedCoreMeasurements(coachId: string) {
  const sets: Record<string, [string, number, string?][]> = {
    "marcus@lionlab.local": [
      ["SPRINT_40", 5.48], ["SPLIT_10", 1.78], ["PRO_AGILITY", 4.86], ["BROAD_JUMP", 88], ["VERTICAL", 21.5], ["MEDBALL_CHEST", 15.5],
      ["PUSHUPS", 28], ["PLANK", 75], ["SIT_REACH", -4.5], ["KNEE_WALL", 3.1, "L"], ["KNEE_WALL", 2.6, "R"],
      ["SQUAT_SCORE", 48], ["BALANCE_SL", 6.2, "L"], ["BALANCE_SL", 9.8, "R"], ["BALANCE_SWAY", 14, "L"], ["BALANCE_SWAY", 9, "R"],
    ],
    "avery@lionlab.local": [
      ["SPRINT_40", 5.85], ["SPLIT_10", 1.84], ["PRO_AGILITY", 4.92], ["BROAD_JUMP", 80], ["VERTICAL", 17], ["MEDBALL_CHEST", 12],
      ["PUSHUPS", 24], ["PLANK", 90], ["SIT_REACH", 1.5], ["KNEE_WALL", 4.2, "L"], ["KNEE_WALL", 4.4, "R"],
      ["SQUAT_SCORE", 78], ["BALANCE_SL", 16, "L"], ["BALANCE_SL", 14.5, "R"],
    ],
    "jordan@lionlab.local": [
      ["SPRINT_40", 5.95], ["SPLIT_10", 1.92], ["PRO_AGILITY", 5.02], ["BROAD_JUMP", 84], ["VERTICAL", 18], ["MEDBALL_CHEST", 19.5],
      ["PUSHUPS", 30], ["PLANK", 60], ["SIT_REACH", -7], ["KNEE_WALL", 2.2, "L"], ["KNEE_WALL", 2.5, "R"],
      ["SQUAT_SCORE", 35], ["BALANCE_SL", 4.1, "L"], ["BALANCE_SL", 5.0, "R"],
    ],
  };
  for (const [email, rows] of Object.entries(sets)) {
    const user = await prisma.user.findUnique({ where: { email }, include: { athlete: true } });
    if (!user?.athlete) continue;
    if ((await prisma.measurement.count({ where: { athleteId: user.athlete.id } })) > 0) continue;
    await prisma.measurement.createMany({
      data: rows.map(([metric, value, side]) => ({
        athleteId: user.athlete!.id,
        metric,
        value,
        side: side ?? "",
        source: metric.startsWith("BALANCE") || metric === "SQUAT_SCORE" ? "CAMERA" : "MANUAL",
        recordedOn: new Date("2026-09-15T12:00:00.000Z"),
        recordedById: coachId,
      })),
    });
  }
}

async function ensureSubjects(athleteId: string, names: string[]) {
  const have = await prisma.subject.count({ where: { athleteId } });
  if (have > 0) return;
  await prisma.subject.createMany({
    data: names.map((name) => ({ athleteId, name })),
  });
}

async function ensureSubjectsFor(email: string, names: string[]) {
  const user = await prisma.user.findUnique({ where: { email }, include: { athlete: true } });
  if (!user?.athlete) return;
  await ensureSubjects(user.athlete.id, names);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
